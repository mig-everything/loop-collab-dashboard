package io.eazo.converter.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import io.eazo.converter.core.ConvertResult
import io.eazo.converter.core.UnitConverter
import io.eazo.converter.model.Dimension
import io.eazo.converter.model.UnitCatalog
import io.eazo.converter.model.UnitDef

/**
 * 单位换算器主界面（单屏，REQ-005 Android 单机基线）。
 *
 * 覆盖 US-1（输入+来源/目标+即时换算）、US-2（单位即时切换）、US-3（结果一键复制）、
 * US-4（反向交换）。跨量纲不可选（AC2.2：单屏同时只呈现一个量纲的单位词表）。
 * 单色调色板镜像鸿蒙浅色态，供 C4-rubric 截图打分。
 */
class MainActivity : Activity() {

    private val colBackground = Color.parseColor("#FAFAFA")
    private val colSurface = Color.parseColor("#FFFFFF")
    private val colText = Color.parseColor("#1A1A1A")
    private val colTextSecondary = Color.parseColor("#757575")
    private val colAccent = Color.parseColor("#3F51B5")
    private val colOnAccent = Color.parseColor("#FFFFFF")
    private val colChipBg = Color.parseColor("#E8EAF6")
    private val colChipText = Color.parseColor("#3F51B5")
    private val colResult = Color.parseColor("#1A237E")

    private var dimension: Dimension = Dimension.LENGTH
    private var fromUnit: UnitDef = UnitCatalog.defaultFrom(Dimension.LENGTH)
    private var toUnit: UnitDef = UnitCatalog.defaultTo(Dimension.LENGTH)

    private lateinit var inputEdit: EditText
    private lateinit var fromSpinner: Spinner
    private lateinit var toSpinner: Spinner
    private lateinit var resultText: TextView
    private lateinit var resultUnitText: TextView
    private lateinit var copyBtn: Button
    private lateinit var dimButtons: MutableMap<Dimension, Button>

    /** 最近一次成功换算结果（用于反向交换 US-4 与复制 US-3）。 */
    private var lastResult: ConvertResult.Ok? = null

    /** 抑制 Spinner/TextWatcher 在程序化刷新期间触发的重算。 */
    private var suppressEvents = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(colBackground)
            setPadding(dp(20), dp(28), dp(20), dp(16))
        }

        // 标题
        root.addView(
            TextView(this).apply {
                text = "单位换算器"
                textSize = 24f
                setTextColor(colText)
            }
        )

        // 量纲切换行（长度/重量/温度）
        val dimRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }
        dimButtons = mutableMapOf()
        for (d in listOf(Dimension.LENGTH, Dimension.WEIGHT, Dimension.TEMPERATURE, Dimension.SPEED)) {
            val btn = Button(this).apply {
                text = dimLabel(d)
                textSize = 14f
                setOnClickListener { selectDimension(d) }
            }
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginEnd = if (d == Dimension.SPEED) 0 else dp(8)
            btn.layoutParams = lp
            dimButtons[d] = btn
            dimRow.addView(btn)
        }
        root.addView(dimRow)

        // 数值输入
        root.addView(
            TextView(this).apply {
                text = "数值"
                textSize = 13f
                setTextColor(colTextSecondary)
                setPadding(0, dp(20), 0, dp(6))
            }
        )
        inputEdit = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
            hint = "输入数值，如 1"
            textSize = 20f
            setTextColor(colText)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(colSurface, dp(12).toFloat())
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { if (!suppressEvents) recompute() }
            })
        }
        root.addView(inputEdit)

        // 来源 / 目标 选择行 + 反向交换
        val convRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(16), 0, 0)
        }
        fromSpinner = Spinner(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val swapBtn = Button(this).apply {
            text = "⇄"
            textSize = 18f
            setBackgroundColor(colChipBg)
            setTextColor(colChipText)
            setOnClickListener { swapUnits() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(10)
                marginEnd = dp(10)
            }
        }
        toSpinner = Spinner(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        convRow.addView(fromSpinner)
        convRow.addView(swapBtn)
        convRow.addView(toSpinner)
        root.addView(convRow)

        // 结果卡
        val resultCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            background = rounded(colSurface, dp(14).toFloat())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(20) }
        }
        resultText = TextView(this).apply {
            text = "—"
            textSize = 34f
            setTextColor(colResult)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        resultUnitText = TextView(this).apply {
            text = ""
            textSize = 20f
            setTextColor(colTextSecondary)
        }
        resultCard.addView(resultText)
        resultCard.addView(resultUnitText)
        root.addView(resultCard)

        // 复制按钮
        copyBtn = Button(this).apply {
            text = "复制结果"
            textSize = 16f
            setBackgroundColor(colAccent)
            setTextColor(colOnAccent)
            isEnabled = false
            setOnClickListener { copyResult() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(16) }
        }
        root.addView(copyBtn)

        setContentView(root)
        window.decorView.setBackgroundColor(colBackground)

        initSpinners()
        highlightDimensions()
        recompute()
    }

    private fun initSpinners() {
        fromSpinner.adapter = unitAdapter(UnitCatalog.of(dimension))
        toSpinner.adapter = unitAdapter(UnitCatalog.of(dimension))
        fromSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, pos: Int, id: Long) {
                if (suppressEvents) return
                fromUnit = UnitCatalog.of(dimension)[pos]
                recompute()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        toSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, pos: Int, id: Long) {
                if (suppressEvents) return
                toUnit = UnitCatalog.of(dimension)[pos]
                recompute()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        // 设置初始选择（suppress 抑制监听）
        suppressEvents = true
        fromSpinner.setSelection(UnitCatalog.of(dimension).indexOf(fromUnit))
        toSpinner.setSelection(UnitCatalog.of(dimension).indexOf(toUnit))
        suppressEvents = false
    }

    private fun unitAdapter(units: List<UnitDef>): ArrayAdapter<String> =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, units.map { it.symbol + " · " + it.displayName })
            .apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

    private fun selectDimension(d: Dimension) {
        if (dimension == d) return
        dimension = d
        fromUnit = UnitCatalog.defaultFrom(d)
        toUnit = UnitCatalog.defaultTo(d)
        lastResult = null
        highlightDimensions()
        suppressEvents = true
        fromSpinner.adapter = unitAdapter(UnitCatalog.of(d))
        toSpinner.adapter = unitAdapter(UnitCatalog.of(d))
        fromSpinner.setSelection(UnitCatalog.of(d).indexOf(fromUnit))
        toSpinner.setSelection(UnitCatalog.of(d).indexOf(toUnit))
        suppressEvents = false
        recompute()
    }

    private fun highlightDimensions() {
        for ((d, btn) in dimButtons) {
            val active = d == dimension
            btn.background = rounded(if (active) colAccent else colChipBg, dp(8).toFloat())
            btn.setTextColor(if (active) colOnAccent else colChipText)
        }
    }

    private fun swapUnits() {
        val oldFrom = fromUnit
        val oldTo = toUnit
        val oldResult = lastResult
        // 交换来源/目标（US-4）
        fromUnit = oldTo
        toUnit = oldFrom
        // 输入与结果位置互换：把上一次结果作为新输入（AC4.1，如 1 in=2.54 cm ↔ 2.54 cm=1 in）
        if (oldResult != null) {
            inputEdit.setText(oldResult.display)
        }
        suppressEvents = true
        fromSpinner.setSelection(UnitCatalog.of(dimension).indexOf(fromUnit))
        toSpinner.setSelection(UnitCatalog.of(dimension).indexOf(toUnit))
        suppressEvents = false
        recompute()
    }

    private fun recompute() {
        val input = inputEdit.text.toString()
        // 空输入保持占位符 "—"，不当作非法输入提示（对齐 UX）
        if (input.isBlank()) {
            lastResult = null
            copyBtn.isEnabled = false
            resultUnitText.text = ""
            resultText.text = "—"
            return
        }
        val r = UnitConverter.convert(input, fromUnit, toUnit)
        when (r) {
            is ConvertResult.Ok -> {
                resultText.text = r.display
                resultUnitText.text = " " + toUnit.symbol
                lastResult = r
                copyBtn.isEnabled = true
            }
            is ConvertResult.Err -> {
                lastResult = null
                copyBtn.isEnabled = false
                resultUnitText.text = ""
                resultText.text = when (r.reason) {
                    ConvertResult.Err.INVALID -> "无效输入"
                    ConvertResult.Err.OVERFLOW -> "超出范围"
                    ConvertResult.Err.DIMENSION_MISMATCH -> "量纲不一致"
                    ConvertResult.Err.UNKNOWN_UNIT -> "无法换算"
                    else -> "无法换算"
                }
            }
        }
    }

    private fun copyResult() {
        val r = lastResult ?: return
        val text = r.display + " " + toUnit.symbol
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("单位换算结果", text))
        Toast.makeText(this, "已复制：$text", Toast.LENGTH_SHORT).show()
    }

    private fun dimLabel(d: Dimension): String = when (d) {
        Dimension.LENGTH -> "长度"
        Dimension.WEIGHT -> "重量"
        Dimension.TEMPERATURE -> "温度"
        Dimension.SPEED -> "速度"
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(color)
            cornerRadius = radius
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
