package io.eazo.converter.model

/**
 * 量纲（维度）。跨量纲换算不可选（AC2.2），同一量纲内任意两单位可互换。
 */
enum class Dimension { LENGTH, WEIGHT, TEMPERATURE, SPEED }

/**
 * 单位定义（数据驱动，NFR §9「词表可扩展」：新增单位仅加一条数据，不改换算逻辑）。
 *
 * 换算统一用仿射变换表示：base = value * factorToBase + offsetToBase。
 * - 长度/重量为线性比例，offsetToBase 恒为 0（base 分别为米 / 千克）。
 * - 温度为仿射变换（含偏移），base 为摄氏度（°C），offsetToBase 非 0（NIST SP 811 口径）。
 */
data class UnitDef(
    val key: String,         // 稳定标识（cm / in / kg / lb / c / f / k ...）
    val symbol: String,      // 显示符号（cm / in / kg / lb / °C / °F / K）
    val displayName: String, // 中文名（厘米 / 英寸 / 千克 / 磅 / 摄氏 ...）
    val dimension: Dimension,
    val factorToBase: Double,
    val offsetToBase: Double,
)

/**
 * 封闭单位词表（PRD §5 数据语义基线，17 个单位）。
 *
 * 权威换算系数（国际标准精确值，双端同源）：
 * - 长度（以米为基准）：1 in = 2.54 cm（精确）；1 ft = 30.48 cm；1 yd = 0.9144 m；
 *   1 mi = 1.609344 km（精确）；1 km = 1000 m；1 m = 100 cm；1 cm = 10 mm。
 * - 重量（以千克为基准）：1 kg = 1000 g；1 g = 1000 mg；1 lb = 0.45359237 kg（精确）；
 *   1 oz = 28.349523125 g；1 t = 1000 kg。
 * - 温度（以摄氏为基准，仿射）：°F = °C × 9/5 + 32；K = °C + 273.15。
 */
object UnitCatalog {

    val UNITS: List<UnitDef> = listOf(
        // 长度（8，base = 米）
        UnitDef("mm", "mm", "毫米", Dimension.LENGTH, 0.001, 0.0),
        UnitDef("cm", "cm", "厘米", Dimension.LENGTH, 0.01, 0.0),
        UnitDef("m", "m", "米", Dimension.LENGTH, 1.0, 0.0),
        UnitDef("km", "km", "千米", Dimension.LENGTH, 1000.0, 0.0),
        UnitDef("in", "in", "英寸", Dimension.LENGTH, 0.0254, 0.0),
        UnitDef("ft", "ft", "英尺", Dimension.LENGTH, 0.3048, 0.0),
        UnitDef("yd", "yd", "码", Dimension.LENGTH, 0.9144, 0.0),
        UnitDef("mi", "mi", "英里", Dimension.LENGTH, 1609.344, 0.0),
        // 重量（6，base = 千克）
        UnitDef("mg", "mg", "毫克", Dimension.WEIGHT, 1e-6, 0.0),
        UnitDef("g", "g", "克", Dimension.WEIGHT, 0.001, 0.0),
        UnitDef("kg", "kg", "千克", Dimension.WEIGHT, 1.0, 0.0),
        UnitDef("t", "t", "吨", Dimension.WEIGHT, 1000.0, 0.0),
        UnitDef("oz", "oz", "盎司", Dimension.WEIGHT, 0.028349523125, 0.0),
        UnitDef("lb", "lb", "磅", Dimension.WEIGHT, 0.45359237, 0.0),
        // 温度（3，base = 摄氏度，仿射；单位 ID 对齐契约 §2：celsius/fahrenheit/kelvin）
        UnitDef("celsius", "°C", "摄氏", Dimension.TEMPERATURE, 1.0, 0.0),
        UnitDef("fahrenheit", "°F", "华氏", Dimension.TEMPERATURE, 5.0 / 9.0, -160.0 / 9.0),
        UnitDef("kelvin", "K", "开尔文", Dimension.TEMPERATURE, 1.0, -273.15),
        // 速度（5，base = 米每秒，线性比例；系数为国际标准精确值/有理式，双端同源）
        // 1 km/h = 1000/3600 m/s；1 mph = 0.44704 m/s（精确）；1 knot = 1852/3600 m/s；1 ft/s = 0.3048 m/s。
        UnitDef("mps", "m/s", "米每秒", Dimension.SPEED, 1.0, 0.0),
        UnitDef("kmh", "km/h", "千米每小时", Dimension.SPEED, 1000.0 / 3600.0, 0.0),
        UnitDef("mph", "mph", "英里每小时", Dimension.SPEED, 0.44704, 0.0),
        UnitDef("knot", "kn", "节", Dimension.SPEED, 1852.0 / 3600.0, 0.0),
        UnitDef("fps", "ft/s", "英尺每秒", Dimension.SPEED, 0.3048, 0.0),
    )

    private val byKey: Map<String, UnitDef> = UNITS.associateBy { it.key }

    fun byKey(key: String): UnitDef? = byKey[key]

    fun of(dimension: Dimension): List<UnitDef> = UNITS.filter { it.dimension == dimension }

    /** 各量纲默认的「来源单位」，用作 UI 初始选择。 */
    fun defaultFrom(dimension: Dimension): UnitDef = when (dimension) {
        Dimension.LENGTH -> byKey("cm")!!
        Dimension.WEIGHT -> byKey("kg")!!
        Dimension.TEMPERATURE -> byKey("celsius")!!
        Dimension.SPEED -> byKey("kmh")!!
    }

    /** 各量纲默认的「目标单位」，用作 UI 初始选择。 */
    fun defaultTo(dimension: Dimension): UnitDef = when (dimension) {
        Dimension.LENGTH -> byKey("in")!!
        Dimension.WEIGHT -> byKey("lb")!!
        Dimension.TEMPERATURE -> byKey("fahrenheit")!!
        Dimension.SPEED -> byKey("mph")!!
    }
}
