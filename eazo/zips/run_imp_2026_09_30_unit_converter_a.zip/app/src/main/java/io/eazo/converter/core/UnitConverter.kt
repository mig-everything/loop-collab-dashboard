package io.eazo.converter.core

import io.eazo.converter.model.Dimension
import io.eazo.converter.model.UnitCatalog
import io.eazo.converter.model.UnitDef
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.util.Locale
import kotlin.math.abs

/**
 * 换算结果（判别式联合，契约 02 §1 双端 1:1）。
 *
 * - 成功携带 `raw`（全精度结果，AC1.2/1.3 断言 raw）+ `display`（展示字符串，AC-UC6 断言 display）。
 * - 失败携带 `reason`（契约四值：invalid / dimension_mismatch / overflow / unknown_unit）。
 */
sealed class ConvertResult {
    data class Ok(val raw: Double, val display: String) : ConvertResult()
    data class Err(val reason: String) : ConvertResult() {
        companion object {
            const val INVALID = "invalid"
            const val DIMENSION_MISMATCH = "dimension_mismatch"
            const val OVERFLOW = "overflow"
            const val UNKNOWN_UNIT = "unknown_unit"
        }
    }
}

/**
 * 单位换算核心（REQ-005 单机基线，纯本地确定性计算）。
 *
 * 语义对齐接口契约 02（docs/arch/req005/02-interface-contract.md，权威）：
 * - 封闭词表 17 单位（见 [UnitCatalog]），温度单位 ID 为 celsius/fahrenheit/kelvin（契约 §2）。
 * - 两段式唯一路径（C1）：base = toBase(value, from) → raw = fromBase(base, to)，中间全精度 double，
 *   舍入只在展示层 format 发生一次（禁中间舍入）。
 * - 温度仿射唯一路径（C3）：六个温度方向一律经 base = 摄氏度 中转，用显式分支（不用数据表系数），
 *   保证与鸿蒙侧 raw 逐 bit 一致（数据表系数会产生 211.99999999999997 这类尾差，破坏 AC1.2/1.3 raw 断言）。
 * - 校验三层（契约 §6）：① invalid（输入层）→ ② dimension_mismatch（量纲层）→ ③ overflow（数值层，C2）。
 * - 显示口径（契约 §3.2）：长度/重量 6 位有效数字去尾零；温度定点 1 位保留尾零（两套规则分派，不混用）。
 * - 数值输入边界（契约 §5 C2）：接受科学计数法；|v| 严格 > 1e15 或结果非有限 → overflow；1e15 本身合法。
 */
object UnitConverter {

    /** 数值输入绝对值上限（契约 §5 C2：严格 > 1e15 判 overflow，1e15 本身合法）。 */
    const val MAX_INPUT = 1e15

    /**
     * 换算入口：输入字符串 + 来源/目标单位 → ConvertResult。
     *
     * @param input 用户输入的数值字符串（允许整数/小数/负数/科学计数法）。
     * @param from  来源单位；@param to 目标单位；必须同量纲。
     */
    fun convert(input: String, from: UnitDef, to: UnitDef): ConvertResult {
        // ① invalid（输入层）：空 / 非数字 / 多小数点 / NaN / Inf
        val value = parseNumber(input) ?: return ConvertResult.Err(ConvertResult.Err.INVALID)
        // ② dimension_mismatch（量纲层）：from/to 不同量纲（AC2.2）
        if (from.dimension != to.dimension) {
            return ConvertResult.Err(ConvertResult.Err.DIMENSION_MISMATCH)
        }
        // ③ overflow（C2 唯一判据，E：输入幅值严格 > 1e15）
        if (abs(value) > MAX_INPUT) {
            return ConvertResult.Err(ConvertResult.Err.OVERFLOW)
        }
        // 两段式换算（中间全精度，不舍入）
        val base = toBase(value, from)
        val raw = fromBase(base, to)
        // D：结果非有限（如 1e308 × 1e3 = Inf）→ overflow
        if (!raw.isFinite()) {
            return ConvertResult.Err(ConvertResult.Err.OVERFLOW)
        }
        // 展示层唯一一次舍入（C1）
        val display = format(raw, to.dimension)
        return ConvertResult.Ok(raw, display)
    }

    /**
     * 按单位 key 换算（防御 unknown_unit：from/to 不在封闭词表内）。
     * 供 UI / 差分用例以字符串 id 调用，与鸿蒙侧 convertByKey 对齐。
     */
    fun convert(input: String, fromKey: String, toKey: String): ConvertResult {
        val from = UnitCatalog.byKey(fromKey) ?: return ConvertResult.Err(ConvertResult.Err.UNKNOWN_UNIT)
        val to = UnitCatalog.byKey(toKey) ?: return ConvertResult.Err(ConvertResult.Err.UNKNOWN_UNIT)
        return convert(input, from, to)
    }

    /**
     * 转基准单位（契约 §4.1）。温度走仿射分支（经摄氏度中转，显式公式），线性量纲走通用系数。
     * 公开暴露以支撑 §4.2 六方向恒等断言（A06），与鸿蒙侧 Converter.toBase 对齐。
     */
    fun toBase(value: Double, from: UnitDef): Double {
        if (from.dimension == Dimension.TEMPERATURE) {
            return when (from.key) {
                "celsius" -> value
                "fahrenheit" -> (value - 32) * 5 / 9
                else -> value - 273.15 // kelvin
            }
        }
        return value * from.factorToBase + from.offsetToBase
    }

    /**
     * 从基准单位还原（契约 §4.1）。温度走仿射分支（显式公式），线性量纲走通用系数。
     */
    fun fromBase(base: Double, to: UnitDef): Double {
        if (to.dimension == Dimension.TEMPERATURE) {
            return when (to.key) {
                "celsius" -> base
                "fahrenheit" -> base * 9 / 5 + 32
                else -> base + 273.15 // kelvin
            }
        }
        return (base - to.offsetToBase) / to.factorToBase
    }

    /**
     * 展示层舍入分派（契约 §3.2）：温度定点 1 位保留尾零；长度/重量 6 位有效数字去尾零。
     */
    private fun format(value: Double, dimension: Dimension): String =
        if (dimension == Dimension.TEMPERATURE) formatTemperature(value) else formatLengthWeight(value)

    /**
     * 温度：定点 1 位小数、保留尾零（round-half-away-from-zero 后 %.1f）。
     * 契约 §3.2 "round(raw × 10) / 10" 语义，先 round 再定点，规避 -273.15 这类浮点尾差
     * （-273.15 * 10 = -2731.5 精确，roundHalfAway → -2732 → "-273.2"，而非直接 %.1f 的 "-273.1"）。
     */
    private fun formatTemperature(value: Double): String {
        val rounded = roundHalfAway(value * 10) / 10
        return String.format(Locale.US, "%.1f", rounded)
    }

    /** 半舍入（远离零）：契约 §3.2 "round(raw × 10) / 10" 语义，不能用 Math.round（其 .5 向 +∞ 舍入）。 */
    private fun roundHalfAway(v: Double): Double =
        if (v >= 0) Math.floor(v + 0.5) else Math.ceil(v - 0.5)

    /**
     * 长度/重量：6 位有效数字（HALF_UP）去尾零（及去尾部小数点），整数无小数点（"100" 而非 "100."）。
     * 用 BigDecimal 保证确定性，避免 float 末位差异（AC-UC6 双端逐字段一致）。
     */
    private fun formatLengthWeight(value: Double): String {
        if (value == 0.0) return "0"
        val rounded = BigDecimal.valueOf(value).round(MathContext(6, RoundingMode.HALF_UP))
        return rounded.stripTrailingZeros().toPlainString()
    }

    /**
     * 输入解析（契约 §1 "invalid" 定义：空 / 非数字 / 多小数点 / NaN）。
     * 合法格式：可选符号 + 整数/小数（单小数点）+ 可选科学计数法指数；拒绝空串 / 多小数点 / 非法字符 / 无指数数字。
     */
    private fun parseNumber(input: String): Double? {
        val s = input.trim()
        if (s.isEmpty()) return null
        var i = 0
        // 可选符号
        if (s[i] == '+' || s[i] == '-') i++
        // 整数部分
        var digitsBefore = 0
        while (i < s.length && s[i].isDigit()) {
            i++
            digitsBefore++
        }
        // 可选小数部分（单小数点）
        var digitsAfter = 0
        if (i < s.length && s[i] == '.') {
            i++
            while (i < s.length && s[i].isDigit()) {
                i++
                digitsAfter++
            }
        }
        // 至少一位数字
        if (digitsBefore == 0 && digitsAfter == 0) return null
        // 可选科学计数法指数
        if (i < s.length && (s[i] == 'e' || s[i] == 'E')) {
            i++
            if (i < s.length && (s[i] == '+' || s[i] == '-')) i++
            var expDigits = 0
            while (i < s.length && s[i].isDigit()) {
                i++
                expDigits++
            }
            if (expDigits == 0) return null
        }
        // 必须消费整串（拒绝 "1.2.3"、"abc"、"1e15+1" 等尾部垃圾）
        if (i != s.length) return null
        val v = s.toDoubleOrNull() ?: return null
        if (!v.isFinite()) return null
        return v
    }
}
