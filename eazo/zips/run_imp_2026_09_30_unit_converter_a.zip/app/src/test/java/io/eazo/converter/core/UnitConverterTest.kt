package io.eazo.converter.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * REQ-005 Android 基线 UnitConverter 纯逻辑单测（回对齐 SA 契约 5a07d10 后）。
 *
 * 覆盖契约 §2/§3/§4/§5/§6 全部语义：
 * - 39 锚点（0°C=32°F、100°C=212°F、0°C=273.2K、1in=2.54cm、1kg=2.20462lb、1lb=0.453592kg…）；
 * - D1 温度单位 ID（celsius/fahrenheit/kelvin）、D2 温度定点 1 位保留尾零、
 *   D3 错误 reason 四值、D4 科学计数法输入、D5 ConvertResult {ok, raw, display}。
 * 纯 Kotlin、无 Android 平台依赖，与鸿蒙侧差分断言 1:1 镜像，对「显示字符串」逐字段比较，
 * 并对「raw」做数值正确性断言（AC1.2/1.3）。
 */
class UnitConverterTest {

    private fun ok(input: String, from: String, to: String): String {
        val r = UnitConverter.convert(input, from, to)
        assertTrue("expected Ok but got $r", r is ConvertResult.Ok)
        return (r as ConvertResult.Ok).display
    }

    private fun okRaw(input: String, from: String, to: String): Double {
        val r = UnitConverter.convert(input, from, to)
        assertTrue("expected Ok but got $r", r is ConvertResult.Ok)
        return (r as ConvertResult.Ok).raw
    }

    private fun err(input: String, from: String, to: String): String {
        val r = UnitConverter.convert(input, from, to)
        assertTrue("expected Err but got $r", r is ConvertResult.Err)
        return (r as ConvertResult.Err).reason
    }

    // ---- 长度锚点（AC1.2 / 线性比例，6 位有效数字去尾零） ----

    @Test fun oneInchEquals254Cm() = assertEquals("2.54", ok("1", "in", "cm"))

    @Test fun thirtyFiveCmEqualsInch() = assertEquals("13.7795", ok("35", "cm", "in"))

    @Test fun oneMileEqualsKm() = assertEquals("1.60934", ok("1", "mi", "km"))

    @Test fun oneFootEqualsCm() = assertEquals("30.48", ok("1", "ft", "cm"))

    @Test fun oneYardEqualsMeter() = assertEquals("0.9144", ok("1", "yd", "m"))

    @Test fun oneKmEqualsMeter() = assertEquals("1000", ok("1", "km", "m"))

    @Test fun oneMeterEqualsCm() = assertEquals("100", ok("1", "m", "cm"))

    // ---- 重量锚点（AC1.2 / 线性比例） ----

    @Test fun oneKgEqualsLb() = assertEquals("2.20462", ok("1", "kg", "lb"))

    @Test fun oneLbEqualsKg() = assertEquals("0.453592", ok("1", "lb", "kg"))

    @Test fun seventyFiveKgEqualsLb() = assertEquals("165.347", ok("75", "kg", "lb"))

    @Test fun twoHundredLbEqualsKg() = assertEquals("90.7185", ok("200", "lb", "kg"))

    @Test fun oneOzEqualsGram() = assertEquals("28.3495", ok("1", "oz", "g"))

    @Test fun oneTonEqualsKg() = assertEquals("1000", ok("1", "t", "kg"))

    @Test fun oneGramEqualsMg() = assertEquals("1000", ok("1", "g", "mg"))

    // ---- 温度锚点（AC1.2/1.3 / 仿射变换含偏移，定点 1 位保留尾零） ----

    @Test fun zeroCelsiusEquals32F() = assertEquals("32.0", ok("0", "celsius", "fahrenheit"))

    @Test fun hundredCelsiusEquals212F() = assertEquals("212.0", ok("100", "celsius", "fahrenheit"))

    @Test fun zeroCelsiusEquals2732K() = assertEquals("273.2", ok("0", "celsius", "kelvin"))

    @Test fun hundredCelsiusEquals3732K() = assertEquals("373.2", ok("100", "celsius", "kelvin"))

    @Test fun threeFiftyFEqualsCelsius() = assertEquals("176.7", ok("350", "fahrenheit", "celsius"))

    @Test fun thirtyTwoFEqualsZeroC() = assertEquals("0.0", ok("32", "fahrenheit", "celsius"))

    @Test fun twoHundredTwelveFEquals100C() = assertEquals("100.0", ok("212", "fahrenheit", "celsius"))

    @Test fun negativeFortyCEqualsNegativeFortyF() = assertEquals("-40.0", ok("-40", "celsius", "fahrenheit"))

    @Test fun twoHundredSeventyThreeKEqualsZeroC() = assertEquals("0.0", ok("273.15", "kelvin", "celsius"))

    /** AC1.3：温度必须含偏移——0°C 若按纯乘法会得 0°F，此处显式断言非 0。 */
    @Test fun zeroCelsiusIsNotZeroFahrenheit() {
        assertTrue(ok("0", "celsius", "fahrenheit") != "0")
    }

    /** AC1.3：100°C 若按纯乘法会得 180°F，此处显式断言非 180。 */
    @Test fun hundredCelsiusIsNot180Fahrenheit() {
        assertTrue(ok("100", "celsius", "fahrenheit") != "180")
    }

    // ---- 数值输入边界（AC1.4，D3 对齐 reason 四值 + D4 科学计数法） ----

    @Test fun emptyInputReturnsInvalid() = assertEquals("invalid", err("", "cm", "in"))

    @Test fun whitespaceInputReturnsInvalid() = assertEquals("invalid", err("   ", "cm", "in"))

    @Test fun nonNumericReturnsInvalid() = assertEquals("invalid", err("abc", "cm", "in"))

    @Test fun multipleDecimalPointsReturnsInvalid() =
        assertEquals("invalid", err("1.2.3", "cm", "in"))

    @Test fun scientificNotationAccepted() = assertEquals("10000", ok("1e2", "m", "cm"))

    @Test fun outOfRangeInputReturnsOverflow() =
        assertEquals("overflow", err("10000000000000000", "cm", "in"))

    @Test fun negativeLengthAllowed() = assertEquals("-1.9685", ok("-5", "cm", "in"))

    @Test fun negativeTemperatureMeaningful() = assertEquals("-40.0", ok("-40", "celsius", "fahrenheit"))

    // ---- 跨量纲不可选（AC2.2，D3 对齐 dimension_mismatch） ----

    @Test fun lengthToWeightMismatch() = assertEquals("dimension_mismatch", err("1", "cm", "kg"))

    @Test fun temperatureToWeightMismatch() = assertEquals("dimension_mismatch", err("1", "celsius", "lb"))

    @Test fun unknownUnitKeyReturnsUnknownUnit() = assertEquals("unknown_unit", err("1", "xx", "cm"))

    // ---- 舍入口径（契约 §3.2：6 位有效数字 + 去尾零） ----

    @Test fun oneCmEqualsInch() = assertEquals("0.393701", ok("1", "cm", "in"))

    @Test fun stripTrailingZeros() = assertEquals("1000", ok("1", "t", "kg"))

    @Test fun leadingDecimalAccepted() = assertEquals("0.254", ok(".1", "in", "cm"))

    // ---- 温度六个方向经 celsius 中转（契约 §4.1 / A07） ----

    @Test fun fahrenheitToKelvinViaCelsius() = assertEquals("273.2", ok("32", "fahrenheit", "kelvin"))

    @Test fun kelvinToFahrenheitViaCelsius() = assertEquals("32.0", ok("273.15", "kelvin", "fahrenheit"))

    @Test fun zeroKelvinToCelsius() = assertEquals("-273.2", ok("0", "kelvin", "celsius"))

    // ---- overflow/underflow 边界（契约 §5.1 / C2 唯一判据：严格 >1e15 + !isFinite(raw)） ----

    @Test fun threshold1e15IsOk() {
        val r = UnitConverter.convert("1e15", "m", "cm")
        assertTrue("1e15 恰值应合法，got $r", r is ConvertResult.Ok)
    }

    @Test fun threshold1e15Plus1IsOverflow() =
        assertEquals("overflow", err("1000000000000001", "m", "cm"))

    @Test fun resultInfIsOverflow() = assertEquals("overflow", err("1e308", "km", "m"))

    @Test fun subnormalIsOkNoUnderflow() {
        val r = UnitConverter.convert("1e-320", "m", "cm")
        assertTrue("1e-320 次正规应合法（本 REQ 无 underflow），got $r", r is ConvertResult.Ok)
    }

    // ---- D5 ConvertResult {ok, raw, display}：raw 数值正确性断言（AC1.2/1.3） ----

    @Test fun rawLengthAnchor() = assertEquals(2.54, okRaw("1", "in", "cm"), 0.0)

    @Test fun rawWeightAnchor() = assertEquals(2.2046226218487757, okRaw("1", "kg", "lb"), 0.0)

    @Test fun rawTemperatureZeroCtoF() = assertEquals(32.0, okRaw("0", "celsius", "fahrenheit"), 0.0)

    @Test fun rawTemperature100CtoF() = assertEquals(212.0, okRaw("100", "celsius", "fahrenheit"), 0.0)

    @Test fun rawTemperature350FtoC() = assertEquals(176.66666666666666, okRaw("350", "fahrenheit", "celsius"), 0.0)

    @Test fun rawTemperatureZeroCtoK() = assertEquals(273.15, okRaw("0", "celsius", "kelvin"), 1e-9)

    // ---- 温度双向逆变换恒等（契约 §4.2 / A06：fromBase(toBase(v,u),u) == v，浮点容差内） ----

    @Test fun temperatureRoundtripIdentity() {
        val ids = listOf("celsius", "fahrenheit", "kelvin")
        val values = doubleArrayOf(0.0, 25.0, -40.0, 100.0, 32.0, 212.0, 300.0)
        val catalog = io.eazo.converter.model.UnitCatalog
        for (v in values) {
            for (id in ids) {
                val u = catalog.byKey(id)!!
                val back = UnitConverter.fromBase(UnitConverter.toBase(v, u), u)
                assertTrue("roundtrip $id $v -> $back", kotlin.math.abs(back - v) < 1e-9)
            }
        }
    }

    // ---- 速度锚点（增量⑦：新增 SPEED 量纲，线性比例 6 位有效数字去尾零） ----

    @Test fun oneMpsEqualsFps() = assertEquals("3.28084", ok("1", "mps", "fps"))

    @Test fun hundredKmhEqualsMph() = assertEquals("62.1371", ok("100", "kmh", "mph"))

    @Test fun sixtyMphEqualsKmh() = assertEquals("96.5606", ok("60", "mph", "kmh"))

    @Test fun oneKmhEqualsMps() = assertEquals("0.277778", ok("1", "kmh", "mps"))

    @Test fun oneMpsEqualsKmh() = assertEquals("3.6", ok("1", "mps", "kmh"))

    @Test fun oneKnotEqualsKmh() = assertEquals("1.852", ok("1", "knot", "kmh"))

    @Test fun oneMphEqualsMps() = assertEquals("0.44704", ok("1", "mph", "mps"))

    @Test fun speedToWeightMismatch() = assertEquals("dimension_mismatch", err("1", "kmh", "kg"))

    @Test fun rawSpeedMphToMps() = assertEquals(0.44704, okRaw("1", "mph", "mps"), 0.0)

    @Test fun rawSpeedFpsToMps() = assertEquals(0.3048, okRaw("1", "fps", "mps"), 0.0)

    @Test fun speedRoundtripIdentity() {
        val ids = listOf("mps", "kmh", "mph", "knot", "fps")
        val values = doubleArrayOf(0.0, 1.0, 60.0, 100.0, -10.0)
        val catalog = io.eazo.converter.model.UnitCatalog
        for (v in values) {
            for (id in ids) {
                val u = catalog.byKey(id)!!
                val back = UnitConverter.fromBase(UnitConverter.toBase(v, u), u)
                assertTrue("roundtrip $id $v -> $back", kotlin.math.abs(back - v) < 1e-9)
            }
        }
    }
}
