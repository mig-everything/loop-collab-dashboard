package io.eazo.fb2f90f6.platform

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import io.eazo.fb2f90f6.core.MetronomeCore.intervalMs
import io.eazo.fb2f90f6.core.MetronomeCore.isAccent
import io.eazo.fb2f90f6.model.EngineSnapshot

/**
 * 骨架模板平台层：AppRepo 进程内单例（生成器硬规则 ①——UI/卡片层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * REQ-022 落点：持有 MetronomeEngine（状态机 §2.5）+ AudioTick（SoundPool 短音）；
 * 系统时钟唯一取用点（§3 虚拟时钟链）——t₀ 取一次 → elapsed 派生 → 传纯函数，
 * UI 与 core 均禁直取系统时间；BPM/拍号持久化 SharedPreferences（last_bpm/last_ts）。
 */
object AppRepo {

    private const val PREFS_NAME = "req022_metronome"

    @Volatile private var engine: MetronomeEngine? = null
    private var audio: AudioTick? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lastTickBeat = -1

    /** 节拍发声调度：running 期 ~25ms 轮询 snapshot，跨拍边界即触发短音（调度容差 §3 R5 注记——
     *  对账锚是纯函数映射，非发声时刻）。 */
    private val tickRunnable = object : Runnable {
        override fun run() {
            val eng = engine ?: return
            val snap = eng.snapshot()
            if (!snap.isRunning) return
            if (snap.beatIndex > lastTickBeat) {
                lastTickBeat = snap.beatIndex
                audio?.play(isAccent(snap.currentBeat, snap.beatsPerBar))
            }
            handler.postDelayed(this, pollDelayMs(snap))
        }
    }

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo {
        if (engine == null) {
            synchronized(this) {
                if (engine == null) {
                    val prefs = context.applicationContext
                        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    audio = AudioTick.create(context.applicationContext)
                    engine = MetronomeEngine(SharedPrefsStore(prefs)) { SystemClock.elapsedRealtime() }
                }
            }
        }
        return this
    }

    /** 硬规则 ②：refresh 只重读内存态，禁止从持久化 load()（持久化仅在引擎初始化冷启动读一次）。 */
    fun refresh() {
        // 内存态即引擎当前状态，无额外重读动作
    }

    fun snapshot(): EngineSnapshot = requireEngine().snapshot()

    fun start() {
        val eng = requireEngine()
        if (eng.start()) {
            lastTickBeat = -1
            handler.removeCallbacks(tickRunnable)
            handler.post(tickRunnable)
        }
    }

    fun stop() {
        if (requireEngine().stop()) {
            handler.removeCallbacks(tickRunnable)
            lastTickBeat = -1
        }
    }

    /** running 中改 BPM/拍号 = 重基准重启（计数归零）——发声去重基准须同步重置。 */
    fun setBpm(value: Int) {
        requireEngine().setBpm(value)
        lastTickBeat = -1
    }

    fun setTimeSignature(id: String) {
        requireEngine().setTimeSignature(id)
        lastTickBeat = -1
    }

    private fun requireEngine(): MetronomeEngine =
        engine ?: error("AppRepo 未初始化：须先经 getRepo(context) 获取")

    /** 轮询间隔：下一拍边界前的等待（封顶 25ms 保平坦推进，至少 5ms 防 busy-loop）。 */
    private fun pollDelayMs(snap: EngineSnapshot): Long {
        val iv = intervalMs(snap.bpm).toLong()
        val next = iv - (snap.elapsedBase % iv)
        return next.coerceIn(5L, 25L)
    }
}

/** SharedPreferences → KeyValueStore 适配（引擎 JVM 单测注入内存实现，双实现同接口）。 */
private class SharedPrefsStore(private val prefs: SharedPreferences) : KeyValueStore {
    override fun putInt(key: String, value: Int) = prefs.edit().putInt(key, value).apply()
    override fun getInt(key: String, def: Int): Int = prefs.getInt(key, def)
    override fun putString(key: String, value: String) = prefs.edit().putString(key, value).apply()
    override fun getString(key: String, def: String): String = prefs.getString(key, def) ?: def
}
