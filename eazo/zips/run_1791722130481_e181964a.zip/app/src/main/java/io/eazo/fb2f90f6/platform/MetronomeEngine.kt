package io.eazo.fb2f90f6.platform

import io.eazo.fb2f90f6.core.MetronomeCore.beatCountAt
import io.eazo.fb2f90f6.core.MetronomeCore.clampBpm
import io.eazo.fb2f90f6.model.EngineSnapshot
import io.eazo.fb2f90f6.model.timeSignatureById

/**
 * REQ-022 节拍器运行状态机（契约 §2.5，冻结版）：
 * 2 态（idle/running）× 4 事件（start/stop/setBpm/setTimeSignature），未列出组合 = 忽略。
 *
 * 与 Android 框架解耦（JVM 单测直驱）：时钟/持久化均注入——系统时钟唯一取用点在
 * platform 层 AppRepo（t₀ 取一次 → elapsed 派生），core 纯函数只接受参数（§3 虚拟时钟链）。
 */
interface KeyValueStore {
    fun putInt(key: String, value: Int)
    fun getInt(key: String, def: Int): Int
    fun putString(key: String, value: String)
    fun getString(key: String, def: String): String
}

/** 系统时钟端口（运行层唯一取用点注入；测试注入虚拟时钟）。 */
typealias Clock = () -> Long

class MetronomeEngine(private val store: KeyValueStore, private val clock: Clock) {

    companion object {
        const val KEY_LAST_BPM = "last_bpm"
        const val KEY_LAST_TS = "last_ts"
        const val STATE_IDLE = "idle"
        const val STATE_RUNNING = "running"
        const val DEFAULT_BPM = 120
        const val DEFAULT_TS_ID = "TS1"
    }

    /** 初始态 idle，载入持久化 last_bpm/last_ts（冷启动唯一 load 点；onResume 只 refresh 内存态）。 */
    var state: String = STATE_IDLE
        private set
    var bpm: Int = clampBpm(store.getInt(KEY_LAST_BPM, DEFAULT_BPM))
        private set
    var tsId: String = persistedTsId()
        private set

    /** 会话 t₀（start/重基准时经 clock 取一次；idle 时无效）。 */
    private var t0: Long = 0

    val isRunning: Boolean get() = state == STATE_RUNNING

    fun elapsedBase(): Long = if (isRunning) clock() - t0 else 0L

    /** 节拍计数：running = beatCountAt(elapsed, bpm)；idle 恒 0（stop 归零）。 */
    fun beatIndex(): Int =
        if (isRunning) beatCountAt(elapsedBase().toInt(), bpm) else 0

    fun snapshot(): EngineSnapshot {
        val ts = timeSignatureById(tsId)!!
        val elapsed = elapsedBase() // 单次取值派生，防跨拍边界读分裂
        val count = if (isRunning) beatCountAt(elapsed.toInt(), bpm) else 0
        return EngineSnapshot(
            state = state,
            bpm = bpm,
            tsId = tsId,
            tsName = ts.name,
            beatsPerBar = ts.beatsPerBar,
            beatIndex = count,
            currentBeat = if (isRunning) count % ts.beatsPerBar else 0, // = currentBeatIndex(elapsed,bpm,bpb)
            elapsedBase = elapsed,
        )
    }

    /** ("idle","start") → running：t₀ 取一次，beatIndex=0。running 再 start = 忽略。 */
    fun start(): Boolean {
        if (isRunning) return false
        state = STATE_RUNNING
        t0 = clock()
        return true
    }

    /** ("running","stop") → idle：计数归零、elapsed 清零。idle 再 stop = 忽略。 */
    fun stop(): Boolean {
        if (!isRunning) return false
        state = STATE_IDLE
        t0 = 0
        return true
    }

    /** setBpm：clamp 收敛；running 中 = 重基准重启（t₀ 重取、beatIndex=0，下一拍恒重音）；idle 持久化。 */
    fun setBpm(value: Int) {
        bpm = clampBpm(value)
        store.putInt(KEY_LAST_BPM, bpm)
        if (isRunning) rebase()
    }

    /** setTimeSignature：合法 id 才生效；running 中 = 重基准重启；idle 持久化。未列出 = 忽略。 */
    fun setTimeSignature(id: String) {
        if (timeSignatureById(id) == null) return
        tsId = id
        store.putString(KEY_LAST_TS, tsId)
        if (isRunning) rebase()
    }

    /** §2.5 重基准重启（AD-2）：原子 stop+start——beat_index 归零，下一拍恒为新小节第 1 拍（重音）。 */
    private fun rebase() {
        t0 = clock()
    }

    private fun persistedTsId(): String {
        val saved = store.getString(KEY_LAST_TS, DEFAULT_TS_ID)
        return if (timeSignatureById(saved) != null) saved else DEFAULT_TS_ID
    }
}
