package io.eazo.fb2f90f6.platform

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File

/**
 * REQ-022 节拍发声端口（契约 §2.4/C5）：SoundPool 短音触发——重拍 1000Hz / 弱拍 800Hz
 * 方波 ~30ms（预生成 PCM WAV，写入 cacheDir 后 load）。只触发、不承载确定性：发声结果
 * 不回流任何数据；无声卡/初始化失败 → no-op 降级（可视化-only 继续，禁崩溃禁阻塞节拍循环）。
 */
class AudioTick private constructor(private val pool: SoundPool?, accentId: Int, weakId: Int) {

    private val ids = intArrayOf(accentId, weakId)

    /** 触发一次节拍短音（accent=重拍）。降级态/加载失败 = no-op。 */
    fun play(accent: Boolean) {
        val pool = this.pool ?: return
        val id = ids[if (accent) 0 else 1]
        if (id <= 0) return
        try {
            pool.play(id, 1f, 1f, 1, 0, 1f)
        } catch (_: IllegalStateException) {
            // 播放失败 no-op：禁崩溃禁阻塞节拍循环
        }
    }

    fun release() {
        pool?.release()
    }

    companion object {
        private const val RATE = 44100
        private const val DURATION_MS = 30

        /** 工厂：任一环节失败返回 no-op 实例（不抛出——降级路径 §2.4-3）。 */
        fun create(context: Context): AudioTick {
            return try {
                val pool = SoundPool.Builder()
                    .setMaxStreams(2)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .build()
                val accent = loadWav(pool, context, "req022_accent.wav", 1000)
                val weak = loadWav(pool, context, "req022_weak.wav", 800)
                AudioTick(pool, accent, weak)
            } catch (_: Exception) {
                AudioTick(null, 0, 0)
            }
        }

        /** 生成 30ms 单声道 16bit 方波 WAV（首尾 2ms 线性淡入淡出防爆音）并载入 SoundPool。 */
        private fun loadWav(pool: SoundPool, context: Context, name: String, freqHz: Int): Int {
            val samples = RATE * DURATION_MS / 1000
            val fade = RATE * 2 / 1000
            val data = ByteArray(samples * 2)
            for (i in 0 until samples) {
                val square = if ((i * freqHz / RATE) % 2 == 0) 1 else -1
                val gain = when {
                    i < fade -> i.toFloat() / fade
                    i >= samples - fade -> (samples - i).toFloat() / fade
                    else -> 1f
                }
                val v = (square * gain * 0.6 * Short.MAX_VALUE).toInt()
                data[i * 2] = (v and 0xFF).toByte()
                data[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
            }
            val header = wavHeader(data.size)
            val file = File(context.cacheDir, name)
            file.outputStream().use { it.write(header); it.write(data) }
            return pool.load(file.absolutePath, 1)
        }

        /** 44 字节标准 WAV 头（PCM16 mono 44.1kHz）。 */
        private fun wavHeader(dataLen: Int): ByteArray {
            val total = 36 + dataLen
            val h = ByteArray(44)
            val riff = "RIFF".toByteArray(Charsets.US_ASCII)
            val wave = "WAVE".toByteArray(Charsets.US_ASCII)
            val fmt = "fmt ".toByteArray(Charsets.US_ASCII)
            val datad = "data".toByteArray(Charsets.US_ASCII)
            System.arraycopy(riff, 0, h, 0, 4); putLe(h, 4, total)
            System.arraycopy(wave, 0, h, 8, 4)
            System.arraycopy(fmt, 0, h, 12, 4); putLe(h, 16, 16)
            putLe(h, 20, 1); putLe(h, 22, 1); putLe(h, 24, RATE)
            putLe(h, 28, RATE * 2); putLe(h, 32, 2); putLe(h, 34, 16)
            System.arraycopy(datad, 0, h, 36, 4); putLe(h, 40, dataLen)
            return h
        }

        private fun putLe(dst: ByteArray, offset: Int, value: Int) {
            dst[offset] = (value and 0xFF).toByte()
            dst[offset + 1] = ((value shr 8) and 0xFF).toByte()
            dst[offset + 2] = ((value shr 16) and 0xFF).toByte()
            dst[offset + 3] = ((value shr 24) and 0xFF).toByte()
        }
    }
}
