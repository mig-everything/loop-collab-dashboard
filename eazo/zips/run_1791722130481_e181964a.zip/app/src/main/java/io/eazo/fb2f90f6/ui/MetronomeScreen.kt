package io.eazo.fb2f90f6.ui

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import io.eazo.fb2f90f6.core.MetronomeCore.BPM_MAX
import io.eazo.fb2f90f6.core.MetronomeCore.BPM_MIN
import io.eazo.fb2f90f6.data.TimeSignatures
import io.eazo.fb2f90f6.model.EngineSnapshot
import io.eazo.fb2f90f6.platform.AppRepo
import kotlinx.coroutines.delay

/**
 * REQ-022 节拍器单页三区（契约 §3）：BPM 控件 + 拍号选择 + 节拍圆点可视化 + 信息仪表。
 * 600dp 断点自适应（单列 ↔ 双列）；UI 不直取系统时间——运行态经 AppRepo.snapshot() 轮询。
 */
@Composable
fun MetronomeScreen() {
    val repo = AppRepo.getRepo(LocalContext.current)
    var snap by remember { mutableStateOf(repo.snapshot()) }

    fun apply(mutate: () -> Unit) {
        mutate()
        snap = repo.snapshot()
    }

    LaunchedEffect(snap.isRunning) {
        while (snap.isRunning) {
            snap = repo.snapshot()
            delay(30)
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(20.dp),
    ) {
        val twoCols = maxWidth >= 600.dp
        if (twoCols) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(28.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(20.dp)) {
                    BpmZone(snap) { v -> apply { repo.setBpm(v) } }
                    SignatureZone(snap) { id -> apply { repo.setTimeSignature(id) } }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(20.dp)) {
                    BeatZone(snap)
                    InfoZone(snap)
                    RunZone(snap, onStart = { apply { repo.start() } }, onStop = { apply { repo.stop() } })
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
            ) {
                BpmZone(snap) { v -> apply { repo.setBpm(v) } }
                SignatureZone(snap) { id -> apply { repo.setTimeSignature(id) } }
                Spacer(Modifier.height(20.dp))
                BeatZone(snap)
                Spacer(Modifier.height(20.dp))
                InfoZone(snap)
                Spacer(Modifier.height(24.dp))
                RunZone(snap, onStart = { apply { repo.start() } }, onStop = { apply { repo.stop() } })
            }
        }
    }
}

/** 区①：BPM 调节（−/+ 与滑杆，clamp 40~240 整数）。 */
@Composable
private fun BpmZone(snap: EngineSnapshot, onBpm: (Int) -> Unit) {
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("BPM", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RoundIconBtn("减小 BPM", { onBpm(snap.bpm - 1) }) {
                    Box(
                        Modifier
                            .size(width = 18.dp, height = 3.dp)
                            .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(2.dp))
                    )
                }
                Text(
                    text = snap.bpm.toString(),
                    style = MaterialTheme.typography.displayLarge,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 22.dp),
                )
                RoundIconBtn("增大 BPM", { onBpm(snap.bpm + 1) }) {
                    Icon(Icons.Filled.Add, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
            }
            Slider(
                value = snap.bpm.toFloat(),
                onValueChange = { onBpm(it.toInt()) },
                valueRange = BPM_MIN.toFloat()..BPM_MAX.toFloat(),
                colors = SliderDefaults.colors(
                    thumbColor = MaterialTheme.colorScheme.primary,
                    activeTrackColor = MaterialTheme.colorScheme.primary,
                ),
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "范围 $BPM_MIN – $BPM_MAX · 间隔 ${io.eazo.fb2f90f6.core.MetronomeCore.intervalMs(snap.bpm)} ms",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** 区②：拍号三选一（TS1 2/4 / TS2 3/4 / TS3 4/4）。 */
@Composable
private fun SignatureZone(snap: EngineSnapshot, onPick: (String) -> Unit) {
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("拍号", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                TimeSignatures.ALL.forEach { ts ->
                    FilterChip(
                        selected = snap.tsId == ts.id,
                        onClick = { onPick(ts.id) },
                        label = { Text(ts.name, style = MaterialTheme.typography.titleMedium) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                        ),
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}

/** 区③：节拍圆点可视化——当前拍放大高亮，重音拍（小节第 1 拍）主色描边。 */
@Composable
private fun BeatZone(snap: EngineSnapshot) {
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
                repeat(snap.beatsPerBar) { i ->
                    val active = snap.isRunning && snap.currentBeat == i
                    val accent = i == 0
                    val size by animateDpAsState(
                        targetValue = if (active) 34.dp else 18.dp,
                        animationSpec = spring(dampingRatio = 0.45f),
                        label = "beatDot",
                    )
                    val color = when {
                        active && accent -> MaterialTheme.colorScheme.primary
                        active -> MaterialTheme.colorScheme.tertiary
                        accent -> MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
                        else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                    }
                    Box(
                        modifier = Modifier
                            .size(size)
                            .background(color, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {}
                }
            }
            Text(
                text = if (snap.isRunning) "第 ${snap.currentBeat + 1} 拍" + if (snap.currentBeat == 0) " · 重音" else "" else "待开始",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** 信息仪表：当前 BPM / 拍号 / 节拍计数（AC-S7.1）。 */
@Composable
private fun InfoZone(snap: EngineSnapshot) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        InfoCard("BPM", snap.bpm.toString(), Modifier.weight(1f))
        InfoCard("拍号", snap.tsName, Modifier.weight(1f))
        InfoCard("节拍计数", snap.beatIndex.toString(), Modifier.weight(1f))
    }
}

@Composable
private fun InfoCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant, modifier = modifier) {
        Column(
            Modifier.padding(vertical = 14.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** 开始/停止（停止后计数归零）。 */
@Composable
private fun RunZone(snap: EngineSnapshot, onStart: () -> Unit, onStop: () -> Unit) {
    val running = snap.isRunning
    Button(
        onClick = { if (running) onStop() else onStart() },
        colors = ButtonDefaults.buttonColors(
            containerColor = if (running) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
        ),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().height(58.dp),
    ) {
        if (running) {
            // 停止方块（material-icons-core 无 Stop/Pause，Canvas 图形替代）
            Box(
                Modifier
                    .size(22.dp)
                    .background(androidx.compose.material3.LocalContentColor.current, RoundedCornerShape(5.dp))
            )
        } else {
            Icon(Icons.Filled.PlayArrow, contentDescription = "开始")
        }
        Spacer(Modifier.size(8.dp))
        Text(if (running) "停止" else "开始", style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
private fun RoundIconBtn(desc: String, onClick: () -> Unit, glyph: @Composable () -> Unit) {
    androidx.compose.material3.FilledTonalButton(
        onClick = onClick,
        shape = CircleShape,
        contentPadding = androidx.compose.foundation.layout.PaddingValues(14.dp),
        colors = androidx.compose.material3.ButtonDefaults.filledTonalButtonColors(
            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
        ),
        modifier = Modifier.size(56.dp),
    ) {
        androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) { glyph() }
    }
}
