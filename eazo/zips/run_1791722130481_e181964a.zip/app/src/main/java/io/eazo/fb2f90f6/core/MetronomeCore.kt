package io.eazo.fb2f90f6.core

/**
 * REQ-022 节拍器确定性核心（契约 02-interface-contract §2，冻结 commit 12dc199）。
 *
 * 全函数纯函数：禁 IO/网络/随机/时钟/UI（契约 §8 D7）——elapsed 一律显式传参，
 * 无内部取时。双端语义与鸿蒙 MetronomeCore.ets 逐函数 1:1。
 */
object MetronomeCore {

    const val BPM_MIN = 40
    const val BPM_MAX = 240

    /** §2.1 round_half_up(60000/bpm)，免浮点整数式 (60000 + bpm/2) / bpm（Int 域天然 half-up）。 */
    fun intervalMs(bpm: Int): Int = (60000 + bpm / 2) / bpm

    /** §2.2 拍号重音（★ 0-based：beat 0 = 首小节第 1 拍，恒重音）。 */
    fun isAccent(beatIndex: Int, beatsPerBar: Int): Boolean = beatIndex % beatsPerBar == 0

    /** §2.3 节拍计数 floor(elapsed/interval)——已完成完整间隔数（Int 整除天然 floor，正值域）。 */
    fun beatCountAt(elapsedMs: Int, bpm: Int): Int = elapsedMs / intervalMs(bpm)

    /** §2.3 当前拍推导 beat_count % bpb（展示层辅助值，推导值数据态可测）。 */
    fun currentBeatIndex(elapsedMs: Int, bpm: Int, beatsPerBar: Int): Int =
        beatCountAt(elapsedMs, bpm) % beatsPerBar

    /** §6.5 BPM 域收敛：越界收敛到 40/240，域内原样返回。 */
    fun clampBpm(bpm: Int): Int = if (bpm < BPM_MIN) BPM_MIN else if (bpm > BPM_MAX) BPM_MAX else bpm

    /** §3 UI 自适应判定（600vp 断点，单列 ↔ 双列；纯函数便于双端同锚断言）。 */
    fun layoutColumns(widthDp: Int): Int = if (widthDp >= 600) 2 else 1
}
