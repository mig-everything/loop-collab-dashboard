package io.eazo.fb2f90f6.model

import io.eazo.fb2f90f6.data.TimeSignature
import io.eazo.fb2f90f6.data.TimeSignatures

/**
 * REQ-022 数据模型辅助（契约 §1/§4）：拍号规范序列化 + 运行层快照类型。
 * 字段名与鸿蒙侧 1:1（生成器硬规则 ③）。
 */

/** §4.1 规范序列化：每行 `id|name|beats_per_bar`（半角 | 与 /），按 id 升序 LF 连接、行尾无换行。 */
fun serializeTimeSignatures(all: List<TimeSignature> = TimeSignatures.ALL): String =
    all.sortedBy { it.id }.joinToString("\n") { "${it.id}|${it.name}|${it.beatsPerBar}" }

/** 按 id 查拍号（三选一；未命中返回 null，调用方忽略）。 */
fun timeSignatureById(id: String): TimeSignature? =
    TimeSignatures.ALL.firstOrNull { it.id == id }

/** 运行层快照（契约 §1.1 RunState 展示派生；idle 时 beatIndex/elapsedBase 恒 0）。 */
data class EngineSnapshot(
    val state: String,          // "idle" | "running"
    val bpm: Int,
    val tsId: String,
    val tsName: String,         // 展示态便捷字段（"2/4" 等）
    val beatsPerBar: Int,
    val beatIndex: Int,         // 节拍计数（running 时 = beatCountAt(elapsed, bpm)）
    val currentBeat: Int,       // 当前拍（= beatIndex % beatsPerBar）
    val elapsedBase: Long,      // 会话虚拟时钟（start/重基准起累计 ms；idle = 0）
) {
    val isRunning: Boolean get() = state == "running"
}
