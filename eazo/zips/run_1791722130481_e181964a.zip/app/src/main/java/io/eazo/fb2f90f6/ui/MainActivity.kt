package io.eazo.fb2f90f6.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import io.eazo.fb2f90f6.platform.AppRepo

/**
 * 骨架模板主界面：单 Activity + Jetpack Compose（UI 锁死声明式——与鸿蒙 ArkUI
 * 声明式对称，禁止 XML 布局/drawable 扇出；图标用 material-icons，主题用
 * Compose MaterialTheme）。
 *
 * REQ-022：Screen 整体替换为 MetronomeScreen（保留 AppTheme 包裹）；硬规则 ②：
 * onResume 只 refresh()（重读内存态），禁止从持久化 load()。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AppRepo.getRepo(this) // 冷启动初始化（含 last_bpm/last_ts 唯一 load 点）
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MetronomeScreen()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(this).refresh()
    }
}

/** 需求主题：深色舞台 + 琥珀主色（节拍重音）+ 青绿次色（弱拍），仅 Compose MaterialTheme。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFFFB74D),
            onPrimary = Color(0xFF33270A),
            secondary = Color(0xFF80CBC4),
            onSecondary = Color(0xFF0B2B28),
            tertiary = Color(0xFF4DD0E1),
            background = Color(0xFF14171C),
            onBackground = Color(0xFFE6E8EC),
            surface = Color(0xFF14171C),
            surfaceVariant = Color(0xFF1F242C),
            onSurface = Color(0xFFE6E8EC),
            onSurfaceVariant = Color(0xFF9AA3AE),
            outline = Color(0xFF5A6472),
            error = Color(0xFFEF7B7B),
        ),
        content = content,
    )
}
