package io.eazo.fb2f90f6.contract

import io.eazo.fb2f90f6.core.MetronomeCore.beatCountAt
import io.eazo.fb2f90f6.core.MetronomeCore.clampBpm
import io.eazo.fb2f90f6.core.MetronomeCore.currentBeatIndex
import io.eazo.fb2f90f6.core.MetronomeCore.intervalMs
import io.eazo.fb2f90f6.core.MetronomeCore.isAccent
import io.eazo.fb2f90f6.core.MetronomeCore.layoutColumns
import io.eazo.fb2f90f6.data.TimeSignatures
import io.eazo.fb2f90f6.model.serializeTimeSignatures
import io.eazo.fb2f90f6.platform.KeyValueStore
import io.eazo.fb2f90f6.platform.MetronomeEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.security.MessageDigest

/**
 * REQ-022 契约用例（02-interface-contract v1.0，冻结 commit 12dc199；用例清单
 * eazo-cases-1.0.0 共 14 条）：slug 逐字等于用例名，断言集为 §6 锚点全集的同集展开。
 * 全部 JVM 纯逻辑——虚拟时钟/内存持久化注入，不依赖 Android 框架。
 */
class MetronomeContractTest {

    // ---------- 测试基座：内存持久化 + 虚拟时钟（core 禁取时，运行层注入） ----------

    private class MemStore : KeyValueStore {
        val map = mutableMapOf<String, Any>()
        override fun putInt(key: String, value: Int) { map[key] = value }
        override fun getInt(key: String, def: Int): Int = map[key] as? Int ?: def
        override fun putString(key: String, value: String) { map[key] = value }
        override fun getString(key: String, def: String): String = map[key] as? String ?: def
    }

    private class FakeClock(var now: Long = 0L)

    private fun engine(store: MemStore = MemStore(), clock: FakeClock = FakeClock()) =
        Pair(MetronomeEngine(store) { clock.now }, clock)

    // ---------- C01 bpm_adjust_range：BPM 调节 40~240 整数，越界收敛 ----------

    @Test
    fun `bpm_adjust_range`() {
        // §6.5 域收敛 4 锚点
        assertEquals(40, clampBpm(39))
        assertEquals(40, clampBpm(40))
        assertEquals(240, clampBpm(240))
        assertEquals(240, clampBpm(241))
        // 域内原样返回（整数）
        assertEquals(120, clampBpm(120))
        // 引擎入口同样收敛
        val (e, _) = engine()
        e.setBpm(7); assertEquals(40, e.bpm)
        e.setBpm(999); assertEquals(240, e.bpm)
    }

    // ---------- C02 time_signature_select：拍号三选一 ----------

    @Test
    fun `time_signature_select`() {
        // 常量数据面：3 项、id 升序、name↔bpb 自洽（§1.2/§4）
        assertEquals(3, TimeSignatures.ALL.size)
        assertEquals(listOf("TS1", "TS2", "TS3"), TimeSignatures.IDS)
        TimeSignatures.ALL.forEach { assertEquals(it.name[0] - '0', it.beatsPerBar) }
        assertEquals(listOf("2/4", "3/4", "4/4"), TimeSignatures.ALL.map { it.name })
        // 引擎切换：合法 id 生效；非法 id 忽略（状态机封闭性）
        val (e, _) = engine()
        e.setTimeSignature("TS3")
        assertEquals("TS3", e.tsId)
        assertEquals("4/4", e.snapshot().tsName)
        e.setTimeSignature("TS9")
        assertEquals("TS3", e.tsId)
    }

    // ---------- C03 start_stop_toggle：开始/停止，停止后计数归零 ----------

    @Test
    fun `start_stop_toggle`() {
        val (e, c) = engine()
        // 初始 idle；start → running、beatIndex=0
        assertFalse(e.isRunning)
        assertTrue(e.start())
        assertTrue(e.isRunning)
        assertEquals(0, e.beatIndex())
        // 推进 3 拍后 stop → idle、计数归零（elapsed 清零）
        c.now = 1500
        assertEquals(3, e.beatIndex())
        assertTrue(e.stop())
        assertFalse(e.isRunning)
        assertEquals(0, e.beatIndex())
        assertEquals(0L, e.elapsedBase())
        // 再 start 从 0 重开；重复 start/stop = 忽略（封闭性 §6.6）
        assertTrue(e.start())
        assertEquals(0, e.beatIndex())
        assertFalse(e.start())
        assertTrue(e.stop())
        assertFalse(e.stop())
        // 重基准重启：running 中 setBpm → 仍 running、beatIndex==0、下一拍恒重音（AD-2）
        e.start(); c.now = 3000 // t₀=1500，elapsed 1500ms → 120bpm 第 4 拍
        assertEquals(3, e.beatIndex())
        e.setBpm(180)
        assertTrue(e.isRunning)
        assertEquals(0, e.beatIndex())
        assertTrue(isAccent(currentBeatIndex(e.elapsedBase().toInt(), e.bpm, 4), 4))
    }

    // ---------- C04 interval_ms_deterministic：间隔确定性 10 锚点 ----------

    @Test
    fun `interval_ms_deterministic`() {
        // §6.2 十锚点（round_half_up(60000/bpm)）
        assertEquals(1500, intervalMs(40))
        assertEquals(1000, intervalMs(60))
        assertEquals(667, intervalMs(90))
        assertEquals(600, intervalMs(100))
        assertEquals(500, intervalMs(120))
        assertEquals(451, intervalMs(133))
        assertEquals(375, intervalMs(160))
        assertEquals(313, intervalMs(192))
        assertEquals(300, intervalMs(200))
        assertEquals(250, intervalMs(240))
        // 同输入重算全等（确定性）
        (40..240).forEach { b -> assertEquals(intervalMs(b), intervalMs(b)) }
    }

    // ---------- C05 interval_ms_round_half_up：half-up 判别点 ----------

    @Test
    fun `interval_ms_round_half_up`() {
        // 192→313（60000/192=312.5，禁 half-even 312）；90→667（666.66…，禁浮点 floor 666）
        assertEquals(313, intervalMs(192))
        assertEquals(667, intervalMs(90))
        // 133→451（451.127… 非整除，禁不取整返回小数）
        assertEquals(451, intervalMs(133))
    }

    // ---------- C06 accent_first_beat：每小节第 1 拍重音（0-based） ----------

    @Test
    fun `accent_first_beat`() {
        // §6.3 三模式串：beat_index 0..2N-1 展开
        assertEquals("1010", (0 until 4).joinToString("") { if (isAccent(it, 2)) "1" else "0" })
        assertEquals("100100", (0 until 6).joinToString("") { if (isAccent(it, 3)) "1" else "0" })
        assertEquals("10001000", (0 until 8).joinToString("") { if (isAccent(it, 4)) "1" else "0" })
        // 0-based 首拍重音判别（1-based 实现首拍不重，V3）
        assertTrue(isAccent(0, 4))
        assertFalse(isAccent(1, 4))
    }

    // ---------- C07 beat_count_progression：节拍计数 floor 9 锚点 ----------

    @Test
    fun `beat_count_progression`() {
        // §6.4 九锚点（floor 完整间隔数）
        assertEquals(0, beatCountAt(0, 120))
        assertEquals(0, beatCountAt(499, 120)) // floor 判别真样本（round/ceil 误 1，V4/V7）
        assertEquals(1, beatCountAt(500, 120))
        assertEquals(2, beatCountAt(1000, 120))
        assertEquals(120, beatCountAt(60000, 120))
        assertEquals(60, beatCountAt(60000, 60))
        assertEquals(240, beatCountAt(60000, 240))
        assertEquals(1, beatCountAt(999, 100))
        assertEquals(50, beatCountAt(30000, 100))
        // 区间性质 D3：c*iv ≤ el < (c+1)*iv
        listOf(120, 100, 240).forEach { b ->
            val iv = intervalMs(b)
            (0..2000).forEach { k ->
                val c = beatCountAt(k, b)
                assertTrue(k >= c * iv && k < (c + 1) * iv)
            }
        }
    }

    // ---------- C08 current_beat_highlight：当前拍高亮（推导值周期） ----------

    @Test
    fun `current_beat_highlight`() {
        // D4 周期锚点：bpm=120/bpb=4 前 16 拍 0123×4
        val iv = intervalMs(120)
        val seq = (0 until 16).joinToString("") { currentBeatIndex(it * iv, 120, 4).toString() }
        assertEquals("0123012301230123", seq)
        // §8 直断言：3 拍后当前拍 = 3
        assertEquals(3, currentBeatIndex(1500, 120, 4))
        // 与 snapshot 展示派生对齐（渲染展示态、推导值数据态可测；4/4 同 D4 口径）
        val (e, c) = engine()
        e.setTimeSignature("TS3")
        e.start()
        c.now = 1500
        assertEquals(3, e.snapshot().currentBeat)
        assertEquals(3, e.snapshot().beatIndex)
    }

    // ---------- C09 display_bpm_signature_count：信息区 BPM/拍号/计数 ----------

    @Test
    fun `display_bpm_signature_count`() {
        val (e, c) = engine()
        e.setBpm(96)
        e.setTimeSignature("TS2")
        e.start()
        c.now = 1000 // interval(96)=625ms → 已完成 1 拍
        val snap = e.snapshot()
        assertEquals(96, snap.bpm)
        assertEquals("3/4", snap.tsName)
        assertEquals(1, snap.beatIndex)
        assertTrue(snap.isRunning)
        // 停止后信息区计数归零（AC-S3.1）
        e.stop()
        assertEquals(0, e.snapshot().beatIndex)
        assertEquals(96, e.snapshot().bpm) // BPM/拍号保留（记忆上次设置）
    }

    // ---------- C10 time_signature_serialization_hash：拍号序列化 SHA-256 ----------

    @Test
    fun `time_signature_serialization_hash`() {
        val bytes = serializeTimeSignatures().toByteArray(Charsets.UTF_8)
        // §8 直断言：字节长 29 + 哈希命中
        assertEquals(TimeSignatures.TS_BYTES, bytes.size)
        assertEquals(29, bytes.size)
        val hex = MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }
        assertEquals(TimeSignatures.TS_SHA256, hex)
        assertEquals("4575625db61285cdb81183eeaaf395c7089014d23a52a56fecea98556a4f064c", hex)
        // 半角分隔符/斜杠纯净（全角变异 V5 系必分叉）
        assertEquals("TS1|2/4|2\nTS2|3/4|3\nTS3|4/4|4", serializeTimeSignatures())
    }

    // ---------- C11 beat_loop_continuous：节拍循环推进（计数单调 + 重音周期 + stop 归零） ----------

    @Test
    fun `beat_loop_continuous`() {
        val (e, c) = engine()
        e.setTimeSignature("TS3") // 4/4
        e.start()
        val iv = intervalMs(120)
        var last = 0
        for (beat in 1..16) { // 判定口径 §3 R5：计数按 interval 单调推进 + 重音周期正确
            c.now = beat * iv.toLong()
            val count = e.beatIndex()
            assertTrue("计数须单调 +1 推进", count == last + 1)
            assertEquals(count, beat)
            val cur = e.snapshot().currentBeat
            assertEquals(cur, beat % 4)           // 周期 0123
            assertEquals(cur == 0, isAccent(cur, 4)) // 重音对齐（D5）
            last = count
        }
        e.stop()
        assertEquals(0, e.beatIndex()) // stop 归零
    }

    // ---------- C12 no_random_source：无随机源/无时间源（纯函数） ----------

    @Test
    fun `no_random_source`() {
        // ① 动态：同输入多次重算全等、常量不变（确定性）
        repeat(50) {
            assertEquals(313, intervalMs(192))
            assertEquals(1, beatCountAt(500, 120))
            assertEquals(3, TimeSignatures.ALL.size)
        }
        // ② 静态：core/data 源文件禁 Random/Date/时钟/IO（D7 禁用清单）
        val root = listOf(
            File("src/main/java/io/eazo/fb2f90f6"),
            File("app/src/main/java/io/eazo/fb2f90f6"),
            File("android-baseline/app/src/main/java/io/eazo/fb2f90f6"),
        ).firstOrNull { it.isDirectory } ?: error("未定位业务源码根（user.dir=${System.getProperty("user.dir")}）")
        val forbidden = Regex("Math\\.random|kotlin\\.random|java\\.util\\.Random|System\\.currentTimeMillis|SystemClock|java\\.util\\.Date|System\\.nanoTime")
        val files = root.walkTopDown()
            .filter { it.extension == "kt" }
            .filter { it.relativeTo(root).path.startsWith("core/") || it.relativeTo(root).path.startsWith("data/") }
            .toList()
        assertTrue("core/data 源文件须非空", files.isNotEmpty())
        files.forEach { f ->
            forbidden.findAll(f.readText()).forEach {
                error("${f.name} 含禁用源 ${it.value}（core/data 禁随机/时间源）")
            }
        }
    }

    // ---------- C13 local_state_persist：本地状态持久化（last_bpm/last_ts） ----------

    @Test
    fun `local_state_persist`() {
        val store = MemStore()
        val (e1, _) = engine(store)
        e1.setBpm(96)
        e1.setTimeSignature("TS3")
        e1.stop() // （e1 从未运行，stop 忽略——幂等）
        // 「重启」：同持久化介质新建引擎 → 恢复上次 BPM/拍号
        val clock2 = FakeClock(0)
        val e2 = MetronomeEngine(store) { clock2.now }
        assertEquals(96, e2.bpm)
        assertEquals("TS3", e2.tsId)
        assertEquals(96, store.getInt("last_bpm", -1))
        assertEquals("TS3", store.getString("last_ts", ""))
        // 全新介质 → 默认值
        val (e3, _) = engine()
        assertEquals(120, e3.bpm)
        assertEquals("TS1", e3.tsId)
    }

    // ---------- C14 multiscreen_adaptive：多端自适应（600dp 断点，可降级） ----------

    @Test
    fun `multiscreen_adaptive`() {
        assertEquals(1, layoutColumns(360))  // 手机竖屏单列
        assertEquals(1, layoutColumns(599))
        assertEquals(2, layoutColumns(600)) // 平板横屏双列（600dp 断点）
        assertEquals(2, layoutColumns(840))
    }
}
