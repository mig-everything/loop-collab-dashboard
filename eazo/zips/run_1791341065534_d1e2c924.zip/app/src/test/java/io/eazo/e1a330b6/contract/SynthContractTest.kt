package io.eazo.e1a330b6.contract

import io.eazo.e1a330b6.core.EngineParams
import io.eazo.e1a330b6.core.Lcg
import io.eazo.e1a330b6.core.NoiseConstants
import io.eazo.e1a330b6.core.NoiseConstants.A
import io.eazo.e1a330b6.core.NoiseConstants.BROWN_LEAK
import io.eazo.e1a330b6.core.NoiseConstants.M
import io.eazo.e1a330b6.core.NoiseConstants.PHASE_INC_A4
import io.eazo.e1a330b6.core.NoiseConstants.PHASE_INC_C5
import io.eazo.e1a330b6.core.NoiseConstants.PINK_K
import io.eazo.e1a330b6.core.NoiseConstants.PRESET_BYTES
import io.eazo.e1a330b6.core.NoiseConstants.PRESET_SHA256
import io.eazo.e1a330b6.core.NoiseConstants.SEED
import io.eazo.e1a330b6.core.NoiseConstants.SINE_TABLE_BYTES
import io.eazo.e1a330b6.core.NoiseConstants.SINE_TABLE_N
import io.eazo.e1a330b6.core.NoiseConstants.SINE_TABLE_SHA256
import io.eazo.e1a330b6.core.NoiseConstants.SR
import io.eazo.e1a330b6.core.NoisePresets
import io.eazo.e1a330b6.core.SineTable
import io.eazo.e1a330b6.core.SynthEngine
import io.eazo.e1a330b6.core.Synthesizer
import io.eazo.e1a330b6.core.engineKindOf
import io.eazo.e1a330b6.core.floorDiv
import io.eazo.e1a330b6.platform.CardDataBuilder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

/**
 * REQ-014 契约回归用例(契约 §6 双端断言清单 126 条;与鸿蒙 Hypium SynthContract.test.ets
 * 同集同断言):A 组 PRNG 状态 8 + B 组逐样本 5×16=80 + C 组 H1~H5 10 + D 组 chunk2 10
 * + E 组 D1/D2 4 + F 组正弦表结构 4 + 参数直断言 10;
 * 附加:SHA-256 自检向量 / 会话连续性 P8 / CardDataBuilder 纯推导。
 */
class SynthContractTest {

    private val white16 = listOf(
        17639, -16609, -28861, -22753, 1854, -22747, -27141, -23212,
        24842, -6434, 3330, 4213, -23914, 21359, -12497, 15244
    )
    private val pink16 = listOf(
        -11913, -19377, -11813, -9017, -10003, -6998, -10803, -3529,
        -4718, -8513, -13794, -8707, -2188, -2928, -2399, -5341
    )
    private val brown16 = listOf(
        352, 12, -566, -1010, -953, -1389, -1905, -2332,
        -1789, -1882, -1778, -1659, -2105, -1636, -1854, -1513
    )
    private val toneA416 = listOf(
        0, 2059, 4111, 6146, 8157, 10135, 12074, 13964,
        15800, 17573, 19276, 20904, 22448, 23904, 25265, 26527
    )
    private val toneC516 = listOf(
        0, 2461, 4907, 7326, 9704, 12027, 14282, 16456,
        18537, 20514, 22375, 24109, 25708, 27161, 28460, 29599
    )

    private val states8 = listOf(
        1224328423L, 99499807L, 1550978883L, 1145579295L,
        1560315710L, 1303324453L, 640882171L, 1676158292L
    )

    private val h = listOf(
        "0b8a5fdbd1d751978eb488e9265421e63575a4c00ff9260edcd1438fd04828f2", // H1 white
        "af0b1e9999fa1c77949741261e41fcaa2cf0690b333334594a274cc3d8ea461b", // H2 pink
        "88f42799ea1832d38bbc821a1b960fc5936b6084562c41c112b709eb58a09506", // H3 brown
        "7310e5900163a0fe22f1e8a8d3096cb0305e62ebb03c55bdc14918fe7837b039", // H4 tone_a4
        "32e92b5b21ab83dcbe70411feed0349f983bbcfac6452c1981ff88919e9c3f20"  // H5 tone_c5
    )
    private val hBytes = listOf(6318, 5787, 5308, 6417, 6419)

    private val h2nd = listOf(
        "72fba63db1e4d4a464307dbbd27e2e5422d114240a51da50658d863d5a319505", // H1c2
        "757070c782cdde2fe916e1fcf9ce72a628eb7526da7e478189e8dc7d65a59f49", // H2c2
        "a6a08a0095cff8c73dd8b3e622da45f922e9eb56ed68e5ad7164e7e5d657fd56", // H3c2
        "9f6f0f2b4e5a391b8e7be962de4afc14ae660a22f55d8e3406186c3577cd1cf3", // H4c2
        "df30babcf172b4176c615d1e1472acf1b55c97570e06958b5fe2bd175cd775a2"  // H5c2
    )
    private val h2ndBytes = listOf(6372, 5713, 5544, 6421, 6423)

    private val streamIds = listOf("white", "pink", "brown", "tone_a4", "tone_c5")

    /** 规范序列化(契约 §6.3):逗号分隔十进制、无空格、UTF-8、行尾无换行。 */
    private fun serialize(samples: List<Int>): String = samples.joinToString(",")

    private fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private fun utf8Len(s: String): Int = s.toByteArray(Charsets.UTF_8).size

    private fun newEngine(presetId: String): SynthEngine {
        val params = EngineParams()
        params.phaseInc = if (presetId == "tone_c5") PHASE_INC_C5 else PHASE_INC_A4
        return SynthEngine(presetId, params)
    }

    // ---- 参数直断言(契约 §8,10 条) ----
    @Test fun assertParamsDirect() {
        assertEquals(44100, SR)
        assertEquals(2147483647L, M)
        assertEquals(16807L, A)
        assertEquals(4096, SINE_TABLE_N)
        assertEquals(20261007L, SEED)
        assertEquals(6, PINK_K)
        assertEquals(20, BROWN_LEAK)
        assertEquals(41, PHASE_INC_A4)
        assertEquals(49, PHASE_INC_C5)
        assertTrue(Math.round(440.0 * 4096 / 44100) == 41L && Math.round(523.0 * 4096 / 44100) == 49L)
        // 附加:Long 域安全(< 2^53)+ floorDiv 负值向下
        assertTrue((M - 1) * A < 9007199254740992L)
        assertEquals(-2L, floorDiv(-7L, 6L))
    }

    // ---- A 组:PRNG 状态锚点 state_1~8(8 条) ----
    @Test fun assertPrngStates() {
        val lcg = Lcg(20261007L)
        for (i in 0 until 8) assertEquals(states8[i], lcg.next())
    }

    // ---- B 组:逐样本锚点 5 流 × 16(80 条) ----
    @Test fun assertWhiteSamples() {
        val out = newEngine("white").synthChunk(16)
        for (i in 0 until 16) assertEquals(white16[i], out[i])
    }

    @Test fun assertPinkSamples() {
        val out = newEngine("pink").synthChunk(16)
        for (i in 0 until 16) assertEquals(pink16[i], out[i])
    }

    @Test fun assertBrownSamples() {
        val out = newEngine("brown").synthChunk(16)
        for (i in 0 until 16) assertEquals(brown16[i], out[i])
    }

    @Test fun assertToneA4Samples() {
        val out = newEngine("tone_a4").synthChunk(16)
        for (i in 0 until 16) assertEquals(toneA416[i], out[i])
    }

    /** TR-Req C1 补锚点:C5 必须用增量 49(误用 41 从样本 1 起分叉被抓获)。 */
    @Test fun assertToneC5Samples() {
        val out = newEngine("tone_c5").synthChunk(16)
        for (i in 0 until 16) assertEquals(toneC516[i], out[i])
    }

    // ---- C 组:首块 1024 样本流哈希 H1~H5(哈希+字节数,10 条) ----
    @Test fun assertStreamHashes() {
        for (i in 0 until 5) {
            val s = serialize(newEngine(streamIds[i]).synthChunk(1024))
            assertEquals(h[i], sha256(s))
            assertEquals(hBytes[i], utf8Len(s))
        }
    }

    // ---- D 组:chunk2 连续性 H1c2~H5c2(哈希+字节数,10 条;形态② synthesize 2048 取后 1024) ----
    @Test fun assertChunk2Hashes() {
        for (i in 0 until 5) {
            val full = Synthesizer().synthesize(streamIds[i], 2048)
            val s = serialize(full.subList(1024, 2048))
            assertEquals(h2nd[i], sha256(s))
            assertEquals(h2ndBytes[i], utf8Len(s))
        }
    }

    /** 附加:P8 会话连续性——两次 synthChunk(1024) 拼接 == 一次 synthChunk(2048)。 */
    @Test fun assertSessionContinuity() {
        for (i in 0 until 5) {
            val engine = newEngine(streamIds[i])
            val c1 = engine.synthChunk(1024)
            val c2 = engine.synthChunk(1024)
            val joined = serialize(c1) + "," + serialize(c2)
            assertEquals(serialize(newEngine(streamIds[i]).synthChunk(2048)), joined)
        }
    }

    // ---- E 组:常量数据面哈希 D1/D2(哈希+字节数,4 条) ----
    @Test fun assertDataFaces() {
        val presetText = NoisePresets.ALL.joinToString("\n") {
            "${it.presetId}|${it.name}|${it.kind}|${it.defaultParam}"
        }
        assertEquals(PRESET_SHA256, sha256(presetText))
        assertEquals(PRESET_BYTES, utf8Len(presetText))
        val sineText = SineTable.TABLE.joinToString(",")
        assertEquals(SINE_TABLE_SHA256, sha256(sineText))
        assertEquals(SINE_TABLE_BYTES, utf8Len(sineText))
    }

    // ---- F 组:正弦表结构锚点(4 条) ----
    @Test fun assertSineStructure() {
        assertEquals(4096, SineTable.TABLE.size)
        assertTrue(
            SineTable.TABLE[0] == 0 && SineTable.TABLE[1] == 50 &&
                SineTable.TABLE[2] == 101 && SineTable.TABLE[3] == 151
        )
        assertTrue(
            SineTable.TABLE[4092] == -201 && SineTable.TABLE[4093] == -151 &&
                SineTable.TABLE[4094] == -101 && SineTable.TABLE[4095] == -50
        )
        assertTrue(
            PHASE_INC_A4 == Math.round(440.0 * 4096 / 44100).toInt() &&
                PHASE_INC_C5 == Math.round(523.0 * 4096 / 44100).toInt()
        )
    }

    // ---- 附加:CardDataBuilder 纯推导(04-harmony-features §1,与鸿蒙同断言) ----
    @Test fun assertCardData() {
        val data = CardDataBuilder.buildCardData()
        assertEquals(3, data.buttons.size)
        assertEquals(NoisePresets.ALL[0].presetId, data.buttons[0].presetId)
        assertEquals(NoisePresets.ALL[0].name, data.buttons[0].name)
        assertEquals(NoisePresets.ALL[1].presetId, data.buttons[1].presetId)
        assertEquals(NoisePresets.ALL[2].presetId, data.buttons[2].presetId)
        assertEquals(3, data.timers.size)
        assertTrue(data.timers[0] == 15 && data.timers[1] == 30 && data.timers[2] == 60)
    }

    /** 附加:引擎 kind 派生与预设参数解析(契约 §3.6/§5.2)。 */
    @Test fun assertEngineKindAndParams() {
        assertEquals("tone", engineKindOf("tone_a4"))
        assertEquals("tone", engineKindOf("tone_c5"))
        assertEquals("white", engineKindOf("white"))
        assertEquals("pink", engineKindOf("pink"))
        assertEquals("brown", engineKindOf("brown"))
        assertEquals(20261007L, io.eazo.e1a330b6.core.engineParamsFor("brown").seed)
        assertEquals(49, io.eazo.e1a330b6.core.engineParamsFor("tone_c5").phaseInc)
        assertEquals(41, io.eazo.e1a330b6.core.engineParamsFor("tone_a4").phaseInc)
    }

    /** 附加:切换 presetId = 会话重建(同 SEED 重起;引擎语义与鸿蒙 1:1)。 */
    @Test fun assertSwitchResetsSession() {
        val synth = Synthesizer()
        val first = synth.synthesize("white", 8)
        synth.synthesize("pink", 8)
        val back = synth.synthesize("white", 8)
        assertEquals(first, back)
    }
}
