package io.eazo.e1a330b6.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import io.eazo.e1a330b6.platform.AppRepo

/**
 * 主界面:单 Activity + Jetpack Compose(声明式,与鸿蒙 ArkUI 对称)。
 * 硬规则②:onResume 只 refresh()(重读内存态),禁止从持久化 load()。
 * 硬规则④:冷启动 onCreate(intent) 与热启动 onNewIntent(intent) 共用 applyOpenIntent。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AppRepo.getRepo(applicationContext).applyOpenIntent(intent)
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SleepScreen(AppRepo.getRepo(applicationContext))
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        AppRepo.getRepo(applicationContext).applyOpenIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        // 硬规则②:onResume 只重读内存态刷新,绝不从持久化重新 load。
        AppRepo.getRepo(applicationContext).refresh()
    }
}

/** 夜色主题(Compose MaterialTheme 落点,不另建 XML 主题)。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(), content = content)
}
