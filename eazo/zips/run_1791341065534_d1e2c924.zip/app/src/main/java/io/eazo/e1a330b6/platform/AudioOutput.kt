package io.eazo.e1a330b6.platform

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import io.eazo.e1a330b6.core.NoiseConstants.SR

/**
 * 音频输出(platform 端口,契约 §2/§9):样本流 → AudioTrack,PCM 16-bit 流式 write。
 * 不入对账面;音量增益 gain = volume/100 在本层应用(AC-S2.2,浮点仅本层允许)。
 * 与鸿蒙 platform/AudioOutput.ets 1:1(同 chunk=4096 / 波形 48 条 × 每块 32 峰)。
 */
class AudioOutput {

    companion object {
        const val AUDIO_CHUNK = 4096          // 每次合成 ~93ms @44100
        private const val WAVE_BAR_MAX = 48   // 波形条数(展示态)
        private const val WAVE_BARS_PER_CHUNK = 32
    }

    private var track: AudioTrack? = null
    private var worker: Thread? = null
    @Volatile private var running = false
    @Volatile private var source: (() -> List<Int>)? = null
    @Volatile private var gainOf: (() -> Double)? = null
    private val waveBars = ArrayDeque<Float>()

    fun isRunning(): Boolean = track != null

    /** 启动流式播放:source 提供下一块 int16 样本流;gainOf 提供当前增益(0.0~1.0)。 */
    fun start(source: () -> List<Int>, gainOf: () -> Double) {
        if (track != null) return
        this.source = source
        this.gainOf = gainOf
        val minBuf = AudioTrack.getMinBufferSize(
            SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val track = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build(),
            AudioFormat.Builder()
                .setSampleRate(SR)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build(),
            maxOf(minBuf, SR),   // ≥ 1s 缓冲
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )
        track.play()
        this.track = track
        running = true
        worker = Thread { pumpLoop() }.apply {
            name = "noise-audio-pump"
            isDaemon = true
            start()
        }
    }

    fun stop() {
        running = false
        source = null
        gainOf = null
        worker?.join(300)
        worker = null
        track?.let {
            try {
                it.stop()
                it.release()
            } catch (_: IllegalStateException) {
            }
        }
        track = null
    }

    /** 波形快照(展示态,UI Canvas 消费;0.0~1.0 归一化条高)。 */
    fun getWaveBars(): List<Float> = waveBars.toList()

    private fun pumpLoop() {
        while (running) {
            val src = source ?: break
            val chunk = src()
            if (chunk.isEmpty()) break
            val track = track ?: break
            val gain = gainOf?.invoke() ?: 1.0
            val pcm = ShortArray(chunk.size)
            for (i in chunk.indices) {
                var v = Math.round(chunk[i] * gain)
                if (v > 32767) v = 32767 else if (v < -32768) v = -32768
                pcm[i] = v.toShort()
            }
            pushWaveBars(chunk)
            track.write(pcm, 0, pcm.size)
        }
    }

    /** 每块取 32 个峰值条,滚动保留最近 48 条。 */
    private fun pushWaveBars(chunk: List<Int>) {
        val per = chunk.size / WAVE_BARS_PER_CHUNK
        repeat(WAVE_BARS_PER_CHUNK) { b ->
            var peak = 0
            var i = b * per
            while (i < (b + 1) * per && i < chunk.size) {
                val abs = Math.abs(chunk[i])
                if (abs > peak) peak = abs
                i++
            }
            if (waveBars.size >= WAVE_BAR_MAX) waveBars.removeFirst()
            waveBars.addLast((peak / 32768f).coerceIn(0f, 1f))
        }
    }
}
