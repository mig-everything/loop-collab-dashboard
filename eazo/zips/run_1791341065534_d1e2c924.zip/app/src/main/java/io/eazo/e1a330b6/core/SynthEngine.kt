package io.eazo.e1a330b6.core

import io.eazo.e1a330b6.core.NoiseConstants.A
import io.eazo.e1a330b6.core.NoiseConstants.BROWN_LEAK
import io.eazo.e1a330b6.core.NoiseConstants.M
import io.eazo.e1a330b6.core.NoiseConstants.PHASE_INC_A4
import io.eazo.e1a330b6.core.NoiseConstants.PINK_K
import io.eazo.e1a330b6.core.NoiseConstants.SEED

/**
 * 合成引擎(契约 §3):white/pink/brown/tone 四态 + 会话状态机(§3.6,C3 闭合)。
 * ★ 全程整数域(Long/Int),禁浮点;除法一律 floorDiv;跨 synthChunk 调用会话延续(不重 seed)。
 * 与鸿蒙 core/SynthEngine.ets 1:1(同集同断言锚点 state_1~8 / B 组 5×16 / H1~H5 / H1c2~H5c2)。
 */

val TONE_PRESET_IDS: List<String> = listOf("tone_a4", "tone_c5")

/** kind = presetId ∈ {tone_a4, tone_c5} ? "tone" : presetId(契约 §3.6)。 */
fun engineKindOf(presetId: String): String =
    if (TONE_PRESET_IDS.contains(presetId)) "tone" else presetId

/** 整数除法:floorDiv(a, b) = floor(a / b),负值亦向下取整(★ 禁裸 / 对负商向零截断,契约 §1)。 */
fun floorDiv(a: Long, b: Long): Long = Math.floorDiv(a, b)

class EngineParams(
    var seed: Long = SEED,
    var phaseInc: Int = PHASE_INC_A4,
)

class SynthEngine(val presetId: String, params: EngineParams) {

    val kind: String = engineKindOf(presetId)
    private val lcg: Lcg? = if (kind == "tone") null else Lcg(params.seed)
    private val counter = LongArray(PINK_K)  // pink K=6(C4 注记:初始 0 不可观测,i=0 全刷新)
    private var brownState: Long = 0
    private var phase: Int = 0
    private val phaseInc: Int
    private var n: Long = 0                   // 会话内全局样本序号

    init {
        // tone 零 LCG 消耗(§3.5);噪声类各自独立起会话(同 SEED 从 state_0 起)
        phaseInc = if (kind == "tone") params.phaseInc else 0
    }

    /** 会话状态延续:挂起态(lcg.state/counter/brownState/phase/n)跨调用保留(§3.6)。 */
    fun synthChunk(count: Int): List<Int> {
        val out = ArrayList<Int>(count)
        for (i in 0 until count) {
            out.add(one())
            n += 1
        }
        return out
    }

    private fun one(): Int = when (kind) {
        "white" -> whiteOne()
        "pink" -> pinkOne()
        "brown" -> brownOne()
        else -> toneOne()
    }

    /** white(§3.1):每样本恰推进 1 次,(ns % 65536) - 32768,禁浮点缩放。 */
    private fun whiteOne(): Int {
        val ns = lcg!!.next()
        return (ns % 65536).toInt() - 32768
    }

    /** pink(§3.2,Voss-McCartney K=6):octave k 每 2^k 样本刷新一次;仅刷新消耗 white 流。 */
    private fun pinkOne(): Int {
        var sum = 0L
        for (k in 0 until PINK_K) {
            if (n and ((1L shl k) - 1L) == 0L) {
                counter[k] = whiteOne().toLong()
            }
            sum += counter[k]
        }
        return floorDiv(sum, PINK_K.toLong()).toInt()
    }

    /** brown(§3.3,漏积分器 LEAK=20 千分比):brown_state 初始 0,每样本恰 1 次 white 推进。 */
    private fun brownOne(): Int {
        val w = whiteOne().toLong()
        brownState = floorDiv(brownState * (1000 - BROWN_LEAK) + w * BROWN_LEAK, 1000)
        return brownState.toInt()
    }

    /** tone(§3.4,相位累加器查表):SINE_TABLE 查表,禁运行时浮点 sin 重算。 */
    private fun toneOne(): Int {
        val sample = SineTable.TABLE[phase and 4095]
        phase = (phase + phaseInc) and 4095
        return sample
    }
}
