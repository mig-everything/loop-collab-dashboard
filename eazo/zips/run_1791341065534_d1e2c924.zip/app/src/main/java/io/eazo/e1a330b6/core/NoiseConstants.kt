package io.eazo.e1a330b6.core

/**
 * 契约 §1 常量(语义基线,双端单测直断言——禁改值,改值即契约违约)。
 * 对应 docs/arch/req014/02-interface-contract.md §1;与鸿蒙 core/NoiseConstants.ets 1:1。
 */
object NoiseConstants {
    const val SR = 44100             // 采样率(仅文档/展示态用;核心合成不依赖)
    const val M = 2147483647L        // Park-Miller LCG 模(2^31-1)
    const val A = 16807L             // Park-Miller LCG 乘子
    const val SINE_TABLE_N = 4096    // 正弦表长度
    const val SEED = 20261007L       // 默认种子
    const val PINK_K = 6             // Voss-McCartney octave 数
    const val BROWN_LEAK = 20        // 棕噪音泄漏(千分比)
    const val PHASE_INC_A4 = 41      // round(440*4096/44100),预计算常量(禁运行时重算)
    const val PHASE_INC_C5 = 49      // round(523*4096/44100),预计算常量(禁运行时重算)

    // 常量数据面哈希锁(D1/D2,契约 §6.5)——运行期序列化后 SHA-256 必须命中。
    const val PRESET_SHA256 = "61548dafee8e9dab02c1a665a499da2d641685496f1c6b58644e41e8d35167b0"
    const val PRESET_BYTES = 200
    const val SINE_TABLE_SHA256 = "f57eb4677c2c66861886cbbecb1d1bd65191ef841feb83b5f2b54ef51df828de"
    const val SINE_TABLE_BYTES = 25726
}
