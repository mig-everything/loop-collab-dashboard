package io.eazo.e1a330b6.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import io.eazo.e1a330b6.R
import io.eazo.e1a330b6.platform.AppRepo
import io.eazo.e1a330b6.platform.CardDataBuilder
import io.eazo.e1a330b6.ui.MainActivity

/**
 * 桌面卡片(与鸿蒙 widget/NoiseQuickCard.ets 对等位,US-6):
 * 三噪声键 + 定时快捷,数据 = CardDataBuilder 纯推导;点键 PendingIntent 深链 MainActivity
 * 带_EXTRA { presetId / timerMinutes / autoplay }(与应用内 applyOpenIntent 同一解析口径)。
 * 硬规则①:只经 AppRepo.getRepo(context);硬规则②:只读内存态。
 */
class SleepWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val data = CardDataBuilder.buildCardData()
        ids.forEach { id -> render(context, manager, id, data) }
    }

    private fun render(context: Context, manager: AppWidgetManager, id: Int, data: io.eazo.e1a330b6.platform.CardData) {
        val views = RemoteViews(context.packageName, R.layout.widget_sleep).apply {
            setTextViewText(R.id.widget_title, "白噪音快捷")
            setTextViewText(R.id.widget_state, if (AppRepo.getRepo(context).isPlaying) "播放中" else "点击启动")
            // 三噪声键:前两键占现有 Button 槽位,第三键并入 state 行(布局保持单 Button 平台约束)
            data.buttons.firstOrNull()?.let { b ->
                setTextViewText(R.id.widget_toggle, "启动${b.name}")
                setOnClickPendingIntent(R.id.widget_toggle, deepLink(context, b.presetId, 0))
            }
            data.buttons.getOrNull(2)?.let { b ->
                setOnClickPendingIntent(R.id.widget_state, deepLink(context, b.presetId, 0))
            }
        }
        manager.updateAppWidget(id, views)
    }

    /** 深链 MainActivity:{ presetId, timerMinutes(0=不带), autoplay:true }。 */
    private fun deepLink(context: Context, presetId: String, timerMinutes: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("presetId", presetId)
            putExtra("autoplay", true)
            if (timerMinutes > 0) putExtra("timerMinutes", timerMinutes)
        }
        return PendingIntent.getActivity(
            context,
            presetId.hashCode() * 31 + timerMinutes,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }

    /** 卡片定时快捷广播(定时白噪音):15/30/60。 */
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TIMER) {
            val minutes = intent.getIntExtra("minutes", 0)
            val pi = deepLink(context, "white", minutes)
            try {
                pi.send(context, 0, Intent().putExtra("minutes", minutes))
            } catch (_: PendingIntent.CanceledException) {
            }
        }
    }

    companion object {
        private const val ACTION_TIMER = "io.eazo.e1a330b6.widget.TIMER"
    }
}
