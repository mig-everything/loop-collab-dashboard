package io.eazo.e1a330b6.core

import io.eazo.e1a330b6.core.NoiseConstants.PHASE_INC_A4

/**
 * 合成器(契约 §3.6 synthesize 主径 API,AC-S2.1):
 * 同 presetId 会话复用;切换 presetId = 旧会话丢弃、新会话从初始态起(同 SEED)。
 * 与鸿蒙 core/Synthesizer.ets 1:1。
 */

/** defaultParam("key=value" 对,";" 连接,契约 §5.3)解析——纯函数。 */
fun parseDefaultParam(defaultParam: String): Map<String, String> {
    val map = LinkedHashMap<String, String>()
    for (pair in defaultParam.split(";")) {
        val eq = pair.indexOf('=')
        if (eq < 0) continue
        map[pair.substring(0, eq)] = pair.substring(eq + 1)
    }
    return map
}

/** 参数口径(契约 §5.2):noise 解析 seed/leak(brown,当前固定 LEAK 常量);tone 解析 phaseInc。 */
fun engineParamsFor(presetId: String): EngineParams {
    val params = EngineParams()
    for (p in NoisePresets.ALL) {
        if (p.presetId == presetId) {
            val kv = parseDefaultParam(p.defaultParam)
            kv["seed"]?.let { params.seed = it.toLong() }
            kv["phaseInc"]?.let { params.phaseInc = it.toInt() }
            break
        }
    }
    return params
}

class Synthesizer {
    private var engine: SynthEngine? = null
    private var currentPresetId = ""

    fun synthesize(presetId: String, sampleCount: Int): List<Int> {
        var pid = presetId
        if (!NoisePresets.ALL.any { it.presetId == pid }) {
            // 未知 presetId:按白噪音口径兜底(不抛异常,播放器不因配置错而崩)
            pid = "white"
        }
        if (engine == null || currentPresetId != pid) {
            engine = SynthEngine(pid, engineParamsFor(pid))
            currentPresetId = pid
        }
        return engine!!.synthChunk(sampleCount)
    }

    /** 显式丢弃会话(回到同 presetId 也重建重起)。 */
    fun reset() {
        engine = null
        currentPresetId = ""
    }
}
