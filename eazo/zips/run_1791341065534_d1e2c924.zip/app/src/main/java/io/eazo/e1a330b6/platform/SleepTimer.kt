package io.eazo.e1a330b6.platform

import android.os.Handler
import android.os.Looper

/**
 * 睡眠定时(platform 端口,契约 §2,US-3):15/30/60 分钟,整数秒递减,到时自动停止。
 * 与鸿蒙 platform/SleepTimer.ets 1:1。
 */
class SleepTimer {

    companion object {
        const val TICK_MS = 1000L
        val TIMER_MINUTES: List<Int> = listOf(15, 30, 60)
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var runnable: Runnable? = null
    private var remaining = 0
    private var onTick: ((Int) -> Unit)? = null
    private var onFinish: (() -> Unit)? = null
    /** AC-S3.2 判定面:到 0 只触发一次停止(重复 tick 不再回调)。 */
    var finishCount = 0
        private set

    fun isRunning(): Boolean = runnable != null

    fun getRemainingSeconds(): Int = remaining

    fun start(minutes: Int, onTick: (Int) -> Unit, onFinish: () -> Unit) {
        stop()
        remaining = Math.round(minutes * 60f).toInt()   // 三档取整秒(AC-S3.1)
        this.onTick = onTick
        this.onFinish = onFinish
        finishCount = 0
        onTick(remaining)
        val tick = object : Runnable {
            override fun run() {
                tickOnce(this)
            }
        }
        runnable = tick
        mainHandler.postDelayed(tick, TICK_MS)
    }

    fun stop() {
        runnable?.let { mainHandler.removeCallbacks(it) }
        runnable = null
        onTick = null
        onFinish = null
    }

    private fun tickOnce(r: Runnable) {
        remaining -= 1
        val tickCb = onTick
        if (remaining <= 0) {
            remaining = 0
            tickCb?.invoke(0)
            val finishCb = onFinish
            runnable = null
            onTick = null
            onFinish = null
            finishCount += 1
            finishCb?.invoke()
            return
        }
        tickCb?.invoke(remaining)
        mainHandler.postDelayed(r, TICK_MS)
    }
}
