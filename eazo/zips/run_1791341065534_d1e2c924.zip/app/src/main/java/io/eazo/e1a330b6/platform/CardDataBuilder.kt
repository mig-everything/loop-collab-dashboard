package io.eazo.e1a330b6.platform

import io.eazo.e1a330b6.core.NoisePresets
import io.eazo.e1a330b6.core.NoisePresets.ALL

/**
 * 桌面卡片数据(04-harmony-features §1.1,与鸿蒙 platform/CardDataBuilder.ets 1:1):
 * 三噪声键 + 定时快捷,预设表静态字段纯推导,零新增语义。
 */
data class CardButton(val presetId: String, val name: String)

data class CardData(val buttons: List<CardButton>, val timers: List<Int>)

object CardDataBuilder {
    fun buildCardData(): CardData {
        val buttons = ArrayList<CardButton>()
        for (p in ALL) {
            if (buttons.size >= 3) break
            if (p.kind != "noise") continue
            buttons.add(CardButton(p.presetId, p.name))
        }
        return CardData(buttons, SleepTimer.TIMER_MINUTES.take(3))
    }
}
