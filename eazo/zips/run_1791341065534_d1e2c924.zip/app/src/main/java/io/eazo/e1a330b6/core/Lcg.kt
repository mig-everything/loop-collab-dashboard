package io.eazo.e1a330b6.core

/**
 * 确定性 LCG 伪随机数发生器(Park-Miller minstd,契约 §3.0)。
 *
 * ★ 中间积上界 (M-1)×A = 3.6e13 < 2^63——Kotlin Long 全程安全(契约 §1);
 *   禁浮点、禁拆位运算技巧、禁 Int 中间截断(V2 变异被判别面捕获)。
 */
class Lcg(seed: Long) {

    var state: Long
        private set

    init {
        val s = seed % M
        state = if (s == 0L) 1L else s
    }

    /** state_{n+1} = (state_n * A) % M(乘号先于取模);返回并保存新状态。 */
    fun next(): Long {
        state = state * A % M
        return state
    }

    companion object {
        const val M = 2147483647L
        const val A = 16807L
    }
}
