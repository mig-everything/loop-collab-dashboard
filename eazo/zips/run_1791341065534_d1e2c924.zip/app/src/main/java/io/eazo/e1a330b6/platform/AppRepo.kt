package io.eazo.e1a330b6.platform

import android.content.Context
import android.content.Intent
import io.eazo.e1a330b6.core.NoisePresets.ALL
import io.eazo.e1a330b6.core.Synthesizer
import io.eazo.e1a330b6.core.NoisePreset

/**
 * 进程内单例仓储(生成器硬规则①②,与鸿蒙 platform/AppRepo.ets 1:1):
 * UI/卡片层一律经 AppRepo.getRepo(context);本 REQ 无跨日业务状态,内存态即可(契约 §2)。
 * refresh 只重读内存态;冷启动 Intent 与 onNewIntent 两路共用 applyOpenIntent。
 */
object AppRepo {

    private val synthesizer = Synthesizer()
    private val audioOutput = AudioOutput()
    private val sleepTimer = SleepTimer()
    private val listeners = HashSet<() -> Unit>()

    @Volatile var currentPresetId: String = ALL[0].presetId
        private set
    @Volatile var volume: Int = 60
        private set
    @Volatile var isPlaying: Boolean = false
        private set
    @Volatile var timerMinutes: Int = 0
        private set
    @Volatile var remainingSeconds: Int = 0
        private set

    /** 进程内单例入口(硬规则①落点)——UI/卡片层唯一获取通道。 */
    fun getRepo(@Suppress("UNUSED_PARAMETER") context: Context): AppRepo = this

    fun listPresets(): List<NoisePreset> = ALL

    fun getWaveBars(): List<Float> = audioOutput.getWaveBars()

    fun subscribe(listener: () -> Unit) { listeners.add(listener) }
    fun unsubscribe(listener: () -> Unit) { listeners.remove(listener) }

    /** 硬规则②:onResume/onPageShow 唯一入口——重读内存态并通知,不做任何持久化 load。 */
    fun refresh() = notifyChange()

    fun selectPreset(presetId: String) {
        if (!ALL.any { it.presetId == presetId }) return
        if (currentPresetId != presetId) {
            currentPresetId = presetId
            // 切换语义(契约 §3.6):旧会话丢弃,新会话从初始态起;播放中无缝切换
            if (isPlaying) {
                Thread {
                    audioOutput.stop()
                    startAudio()
                }.start()
            }
        }
        notifyChange()
    }

    fun setVolume(volume: Int) {
        val v = volume.coerceIn(0, 100)
        this.volume = v
        notifyChange()
    }

    fun play() {
        if (isPlaying) return
        isPlaying = true
        startAudio()
        notifyChange()
    }

    fun stop() {
        if (!isPlaying) return
        isPlaying = false
        Thread { audioOutput.stop() }.start()
        notifyChange()
    }

    fun startSleepTimer(minutes: Int) {
        timerMinutes = minutes
        sleepTimer.start(
            minutes,
            { remaining ->
                remainingSeconds = remaining
                notifyChange()
            },
            {
                // 到时自动停止(US-3):只触发一次(finishCount 判定面)
                remainingSeconds = 0
                timerMinutes = 0
                stop()
            }
        )
        notifyChange()
    }

    fun cancelSleepTimer() {
        sleepTimer.stop()
        timerMinutes = 0
        remainingSeconds = 0
        notifyChange()
    }

    /** 硬规则④:冷启动 onCreate(intent) 与热启动 onNewIntent(intent) 两路唯一入口。 */
    fun applyOpenIntent(intent: Intent?) {
        if (intent == null) return
        val pid = intent.getStringExtra("presetId")
        if (pid != null && PRESET_IDS.contains(pid)) selectPreset(pid)
        val timer = intent.getIntExtra("timerMinutes", 0)
        if (SleepTimer.TIMER_MINUTES.contains(timer)) startSleepTimer(timer)
        if (intent.getBooleanExtra("autoplay", false) && !isPlaying) play()
    }

    private val PRESET_IDS = ALL.map { it.presetId }

    private fun startAudio() {
        val chunk = AudioOutput.AUDIO_CHUNK
        audioOutput.start(
            { synthesizer.synthesize(currentPresetId, chunk) },
            { volume / 100.0 }
        )
    }

    private fun notifyChange() {
        synchronized(listeners) { listeners.toList() }.forEach { it() }
    }
}
