package io.eazo.e1a330b6.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.e1a330b6.core.NoisePreset
import io.eazo.e1a330b6.platform.AppRepo
import io.eazo.e1a330b6.platform.SleepTimer
import kotlinx.coroutines.delay

/**
 * 白噪音助眠器首屏(Jetpack Compose,与鸿蒙 pages/IndexPage.ets 同构):
 * 音源预设列表(5)+ 波形条可视化(AC-S4.1)+ 播放/停止 + 音量(AC-S2.2)+ 睡眠定时(US-3)。
 * BoxWithConstraints 宽屏双栏 / 窄屏单栏(600dp 断点,多端自适应)。
 */

// 夜色配色(与鸿蒙 IndexPage 同色系,不建 XML 资源)
private val BgColor = Color(0xFF0B1020)
private val CardColor = Color(0xFF161C2E)
private val CardColorHi = Color(0xFF1E2742)
private val Accent = Color(0xFF5B8DEF)
private val TextMain = Color(0xFFE8ECF6)
private val TextSub = Color(0xFF8A93AC)
private val TextDim = Color(0xFF5A6379)

private fun fmtClock(totalSeconds: Int): String =
    "%02d:%02d".format(totalSeconds / 60, totalSeconds % 60)

private fun kindLabel(p: NoisePreset): String = if (p.kind == "tone") "正弦音调" else "噪声合成"

@Composable
fun SleepScreen(repo: AppRepo) {
    var presetId by remember { mutableStateOf(repo.currentPresetId) }
    var volume by remember { mutableStateOf(repo.volume) }
    var isPlaying by remember { mutableStateOf(repo.isPlaying) }
    var timerMinutes by remember { mutableStateOf(repo.timerMinutes) }
    var remainingSeconds by remember { mutableStateOf(repo.remainingSeconds) }
    var waveBars by remember { mutableStateOf(repo.getWaveBars()) }

    // 内存态轮询:波形/倒计时即时可见(硬规则② 数据源 = 内存快照)
    LaunchedEffect(Unit) {
        while (true) {
            presetId = repo.currentPresetId
            volume = repo.volume
            isPlaying = repo.isPlaying
            timerMinutes = repo.timerMinutes
            remainingSeconds = repo.remainingSeconds
            waveBars = repo.getWaveBars()
            delay(100)
        }
    }

    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(BgColor)
    ) {
        if (maxWidth >= 600.dp) {
            Row(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Column(
                    modifier = Modifier.weight(2f).fillMaxHeight().verticalScroll(rememberScrollState()),
                ) { PresetList(repo, presetId) }
                Column(
                    modifier = Modifier.weight(3f).fillMaxHeight().verticalScroll(rememberScrollState()),
                ) { PlayControls(repo, isPlaying, volume, timerMinutes, remainingSeconds, waveBars) }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp),
            ) {
                PresetList(repo, presetId)
                Spacer(Modifier.height(16.dp))
                PlayControls(repo, isPlaying, volume, timerMinutes, remainingSeconds, waveBars)
            }
        }
    }
}

@Composable
private fun Header(isPlaying: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text("白噪音助眠器", color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("确定性合成 · 睡眠定时 · 实时波形", color = TextSub, fontSize = 13.sp)
        }
        Text(
            if (isPlaying) "播放中" else "已停止",
            color = if (isPlaying) Accent else TextDim,
            fontSize = 12.sp,
            modifier = Modifier
                .background(
                    if (isPlaying) Accent.copy(alpha = 0.16f) else CardColor,
                    RoundedCornerShape(999.dp)
                )
                .padding(horizontal = 10.dp, vertical = 5.dp),
        )
    }
}

@Composable
private fun PresetList(repo: AppRepo, presetId: String) {
    Header(repo.isPlaying)
    Text("音源预设", color = TextSub, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
    repo.listPresets().forEach { p ->
        val selected = presetId == p.presetId
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp)
                .background(
                    if (selected) CardColorHi else CardColor,
                    RoundedCornerShape(16.dp)
                )
                .clickableText { repo.selectPreset(p.presetId) }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(p.name, color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(4.dp))
                Text("${kindLabel(p)} · ${p.defaultParam}", color = TextSub, fontSize = 12.sp)
            }
            if (selected) {
                Canvas(modifier = Modifier.padding(0.dp)) {
                    drawCircle(Accent, radius = 5.dp.toPx())
                }
            }
        }
    }
}

@Composable
private fun PlayControls(
    repo: AppRepo,
    isPlaying: Boolean,
    volume: Int,
    timerMinutes: Int,
    remainingSeconds: Int,
    waveBars: List<Float>,
) {
    // 波形可视化(AC-S4.1,展示态):中线上下对称条形,数据=样本流峰值
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(170.dp)
            .background(CardColor, RoundedCornerShape(16.dp))
            .padding(8.dp)
    ) {
        val n = waveBars.size
        val mid = size.height / 2f
        if (n == 0) {
            drawLine(TextSub, Offset(12f, mid), Offset(size.width - 12f, mid), 3f, cap = StrokeCap.Round)
            return@Canvas
        }
        val slot = size.width / n
        for (i in 0 until n) {
            val bar = waveBars[i].coerceIn(0.03f, 1f)
            val x = slot * i + slot / 2f
            drawLine(
                Accent,
                Offset(x, mid - (mid - 6f) * bar),
                Offset(x, mid + (mid - 6f) * bar),
                3f,
                cap = StrokeCap.Round,
            )
        }
    }

    Spacer(Modifier.height(16.dp))

    Button(
        onClick = { if (isPlaying) repo.stop() else repo.play() },
        modifier = Modifier.fillMaxWidth().height(46.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isPlaying) Color(0xFF3A4460) else Accent,
            contentColor = Color.White,
        ),
        shape = RoundedCornerShape(23.dp),
    ) {
        Text(if (isPlaying) "停止" else "播放", fontSize = 17.sp, fontWeight = FontWeight.Medium)
    }

    Spacer(Modifier.height(16.dp))

    // 音量(AC-S2.2:gain = volume/100)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardColor, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Text("音量", color = TextSub, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text("$volume%", color = TextMain, fontSize = 14.sp)
        }
        Slider(
            value = volume.toFloat(),
            onValueChange = { repo.setVolume(it.toInt()) },
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(
                thumbColor = Accent,
                activeTrackColor = Accent,
                inactiveTrackColor = CardColorHi,
            ),
        )
    }

    Spacer(Modifier.height(16.dp))

    // 睡眠定时(US-3)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CardColor, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Text("睡眠定时", color = TextSub, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(
                if (remainingSeconds > 0) "剩余 ${fmtClock(remainingSeconds)}" else "未设定",
                color = if (remainingSeconds > 0) Accent else TextDim,
                fontSize = 14.sp,
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            SleepTimer.TIMER_MINUTES.forEach { m ->
                Text(
                    "${m} 分钟",
                    color = if (timerMinutes == m) Color.White else TextMain,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (timerMinutes == m) Accent else CardColorHi,
                            RoundedCornerShape(12.dp)
                        )
                        .clickableText {
                            if (timerMinutes == m) repo.cancelSleepTimer() else repo.startSleepTimer(m)
                        }
                        .padding(vertical = 10.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
    }
    Spacer(Modifier.height(24.dp))
}

/** Text/Row 点击修饰(foundation.clickable 扩展,无涟漪)。 */
private fun Modifier.clickableText(onClick: () -> Unit): Modifier =
    this.clickable(onClick = onClick)
