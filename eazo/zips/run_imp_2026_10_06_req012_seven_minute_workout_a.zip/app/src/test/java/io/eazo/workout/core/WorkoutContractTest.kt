package io.eazo.workout.core

import io.eazo.workout.model.TimelineSeg
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

/**
 * REQ-012 契约双端单测(Android 基线侧,02-interface-contract.md §6 全集)。
 * 期望值全部取 scripts/gen_workout_constants.py 本机重算锚点(seed/req012-anchors.json,禁手抄):
 *   12 动作 canonical SHA-256 = 2a5944b51f8cbff9c52cab7e7ea75c96d4a6f37c386687c0176fdd2c220e0067 / 369 bytes
 *   W1 终态序列化 SHA-256 = 320e3b425a8f98f33f8e789f093890171b514b7c69c2825575f3242a04ed491a / 35 bytes
 * 与鸿蒙 Hypium(WorkoutContract.test.ets)一一同源同集同期望(差分执行基准)。
 */
class WorkoutContractTest {

    private fun seg(vararg xs: Triple<String, Int, Int>): List<TimelineSeg> =
        xs.map { TimelineSeg(it.first, it.second, it.third) }

    private fun setOf(vararg ds: Int): Set<Int> = ds.toSet()

    // ---------- §6.5 数据面哈希锁 V1~V8 ----------

    /** case1:规范序列化 SHA-256 全量锁(369 bytes,错 1 字/漏 1 条/乱 1 序必 FAIL)。 */
    @Test fun `case1_exercises_canonical_sha256_lock`() {
        val canonical = WorkoutConstants.EXERCISES.joinToString("\n") {
            "${it.id}|${it.name}|${it.nameEn}|${it.durationWork}|${it.durationRest}"
        }
        assertEquals(WorkoutConstants.CANONICAL_BYTES, canonical.toByteArray(Charsets.UTF_8).size)
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { b -> "%02x".format(b) }
        assertEquals("2a5944b51f8cbff9c52cab7e7ea75c96d4a6f37c386687c0176fdd2c220e0067", digest)
        assertEquals(WorkoutConstants.CANONICAL_SHA256, digest)
    }

    /** case2:条数与 id 序(1..12 连续升序)+ 全量 30/10 + 首末条锚点。 */
    @Test fun `case2_exercises_count_id_order_fields`() {
        assertEquals(12, WorkoutConstants.EXERCISE_COUNT)
        assertEquals(12, WorkoutConstants.EXERCISES.size)
        assertEquals((1..12).toList(), WorkoutConstants.EXERCISES.map { it.id })
        assertTrue(WorkoutConstants.EXERCISES.all { it.durationWork == 30 && it.durationRest == 10 })
        assertEquals("开合跳", WorkoutConstants.EXERCISES.first().name)
        assertEquals("Jumping Jack", WorkoutConstants.EXERCISES.first().nameEn)
        assertEquals("侧平板支撑", WorkoutConstants.EXERCISES.last().name)
        assertEquals("Side Plank", WorkoutConstants.EXERCISES.last().nameEn)
    }

    /** case3:name/nameEn 无重复 + 字符域禁令(禁 |、LF、CR,TR-Req C4)。 */
    @Test fun `case3_exercises_no_dup_no_forbidden_chars`() {
        assertEquals(12, WorkoutConstants.EXERCISES.map { it.name }.toSet().size)
        assertEquals(12, WorkoutConstants.EXERCISES.map { it.nameEn }.toSet().size)
        WorkoutConstants.EXERCISES.forEach {
            listOf(it.name, it.nameEn).forEach { f ->
                assertFalse(f.contains('|')); assertFalse(f.contains('\n')); assertFalse(f.contains('\r'))
            }
        }
    }

    // ---------- §8 参数直断言 ----------

    /** case4:常量直断言(EXERCISE_COUNT/WORK_SEC/REST_SEC/ROUNDS_7MW/TOTAL_7MW/CANONICAL_BYTES)。 */
    @Test fun `case4_constants_direct`() {
        assertEquals(12, WorkoutConstants.EXERCISE_COUNT)
        assertEquals(30, WorkoutConstants.WORK_SEC)
        assertEquals(10, WorkoutConstants.REST_SEC)
        assertEquals(12, WorkoutConstants.ROUNDS_7MW)
        assertEquals(480, WorkoutConstants.TOTAL_7MW)
        assertEquals(369, WorkoutConstants.CANONICAL_BYTES)
    }

    /** case5:normalize 锚点(§8:normalize(0)==1 / normalize(-7)==1 / normalize(5)==5)。 */
    @Test fun `case5_normalize`() {
        assertEquals(1, Schedule.normalize(0))
        assertEquals(1, Schedule.normalize(-7))
        assertEquals(5, Schedule.normalize(5))
        assertEquals(1, Schedule.normalize(1))
        assertEquals(100, Schedule.normalize(100))
    }

    // ---------- §6.1 时间轴锚点 T1~T5 + INV ----------

    /** case6 T1:schedule(30,10,3) 全轴 6 段。 */
    @Test fun `case6_T1_schedule_30_10_3`() {
        val expected = seg(
            Triple("WORK", 0, 30), Triple("REST", 30, 40),
            Triple("WORK", 40, 70), Triple("REST", 70, 80),
            Triple("WORK", 80, 110), Triple("REST", 110, 120),
        )
        assertEquals(expected, Schedule.schedule(30, 10, 3))
    }

    /** case7 T2:schedule(20,10,8) 前 4 条(Tabata 量纲首轮)。 */
    @Test fun `case7_T2_schedule_20_10_8_first4`() {
        val expected = seg(
            Triple("WORK", 0, 20), Triple("REST", 20, 30),
            Triple("WORK", 30, 50), Triple("REST", 50, 60),
        )
        assertEquals(expected, Schedule.schedule(20, 10, 8).take(4))
    }

    /** case8 T2+:schedule(20,10,8) 全轴 16 段 + 末 2 条(off-by-one 判别)。 */
    @Test fun `case8_T2plus_schedule_20_10_8_full`() {
        val full = Schedule.schedule(20, 10, 8)
        assertEquals(16, full.size)
        val last2 = seg(Triple("WORK", 210, 230), Triple("REST", 230, 240))
        assertEquals(last2, full.takeLast(2))
    }

    /** case9 T3:totalSeconds 480/240。 */
    @Test fun `case9_T3_total_seconds`() {
        assertEquals(480, Schedule.totalSeconds(30, 10, 12))
        assertEquals(240, Schedule.totalSeconds(20, 10, 8))
    }

    /** case10 T4:7MW 轮 0/6/11 WORK 段 ↔ 动作 id 1/7/12(映射错位一格判别,TR-Req C2-2)。 */
    @Test fun `case10_T4_round_exercise_mapping`() {
        val tl = Schedule.schedule(30, 10, 12)
        assertEquals(24, tl.size)
        assertEquals(TimelineSeg("WORK", 0, 30), tl[0])
        assertEquals("开合跳", WorkoutConstants.EXERCISES[0].name)
        assertEquals(TimelineSeg("WORK", 240, 270), tl[12])
        assertEquals("肱三头肌撑体", WorkoutConstants.EXERCISES[6].name)
        assertEquals(7, WorkoutConstants.EXERCISES[6].id)
        assertEquals(TimelineSeg("WORK", 440, 470), tl[22])
        assertEquals("侧平板支撑", WorkoutConstants.EXERCISES[11].name)
        assertEquals(12, WorkoutConstants.EXERCISES[11].id)
        assertEquals(TimelineSeg("REST", 470, 480), tl[23])
        // §8 预置映射直断言:第 r 轮 WORK 段动作 == EXERCISES[r]
        listOf(0, 6, 11).forEach { r ->
            assertEquals(WorkoutConstants.EXERCISES[r].name, Schedule.exerciseForRound(r))
        }
    }

    /** case11 T5:入口归一四组(零长段/空轴/负起点全消灭,TR-Req C3-2)。 */
    @Test fun `case11_T5_normalize_edges`() {
        assertEquals(seg(Triple("WORK", 0, 60), Triple("REST", 60, 61)), Schedule.schedule(60, 0, 1))
        assertEquals(seg(Triple("WORK", 0, 30), Triple("REST", 30, 40)), Schedule.schedule(30, 10, 0))
        val c = Schedule.schedule(0, 10, 2)
        assertEquals(4, c.size)
        assertEquals(TimelineSeg("WORK", 0, 1), c[0])
        val d = Schedule.schedule(-30, 10, 3)
        assertEquals(6, d.size)
        assertEquals(TimelineSeg("WORK", 0, 1), d[0])
    }

    /** case12 INV:7MW 结构不变量(24 段/无缝/末段 480/段长 {30,10})。 */
    @Test fun `case12_INV_7mw_structure`() {
        val tl = Schedule.schedule(30, 10, 12)
        assertEquals(24, tl.size)
        assertEquals(12, tl.count { it.phase == "WORK" })
        assertEquals(12, tl.count { it.phase == "REST" })
        for (i in 1 until tl.size) {
            assertEquals(tl[i - 1].endSec, tl[i].startSec)
        }
        assertEquals(480, tl.last().endSec)
        assertEquals(setOf(30, 10), tl.map { it.lengthSec }.toSet())
        assertTrue(tl.zipWithNext().all { (a, b) -> if (a.phase == "WORK") b.phase == "REST" else b.phase == "WORK" })
    }

    // ---------- §6.2 streak 锚点 C1~C5 / B2 / L1~L3 / B3 / D1~D3 ----------

    /** case13 C1:今日已打连续 3 天。 */
    @Test fun `case13_C1_current_streak_3`() {
        assertEquals(3, Streak.currentStreak(setOf(198, 199, 200), 200))
    }

    /** case14 C2:今日未打不打断(从昨日往回仍 3)。 */
    @Test fun `case14_C2_unmarked_today_no_break`() {
        assertEquals(3, Streak.currentStreak(setOf(197, 198, 199), 200))
    }

    /** case15 C3:空集 = 0。 */
    @Test fun `case15_C3_empty_set`() {
        assertEquals(0, Streak.currentStreak(emptySet(), 200))
    }

    /** case16 C4:断档立即停(198,200 → 1)。 */
    @Test fun `case16_C4_gap_stops`() {
        assertEquals(1, Streak.currentStreak(setOf(198, 200), 200))
    }

    /** case17 C5:仅昨天 = 1。 */
    @Test fun `case17_C5_only_yesterday`() {
        assertEquals(1, Streak.currentStreak(setOf(199), 200))
    }

    /** case18 B2:未来日期不算(TR-Req C5-1)。 */
    @Test fun `case18_B2_future_dates_not_counted`() {
        assertEquals(0, Streak.currentStreak(setOf(205, 206), 200))
    }

    /** case19 L1/L2/L3:longest 单段/多段取最长/全不连续。 */
    @Test fun `case19_L123_longest_streak`() {
        assertEquals(3, Streak.longestStreak(setOf(198, 199, 200)))
        assertEquals(3, Streak.longestStreak(setOf(100, 101, 102, 105, 106)))
        assertEquals(1, Streak.longestStreak(setOf(5, 7, 9)))
    }

    /** case20 B3:单元素 = 1(best 初值,TR-Req C5-2)。 */
    @Test fun `case20_B3_longest_single`() {
        assertEquals(1, Streak.longestStreak(setOf(199)))
        assertEquals(0, Streak.longestStreak(emptySet()))
    }

    /** case21 D1~D3:isDoneToday。 */
    @Test fun `case21_D123_is_done_today`() {
        assertTrue(Streak.isDoneToday(setOf(100, 101), 101))
        assertFalse(Streak.isDoneToday(setOf(100, 101), 102))
        assertFalse(Streak.isDoneToday(emptySet(), 100))
    }

    /** case22:markDone 幂等(D9)。 */
    @Test fun `case22_mark_done_idempotent`() {
        val d0 = setOf(100, 101)
        val d1 = Streak.markDone(d0, 101)
        assertEquals(d0, d1)
        assertEquals(setOf(100, 101, 102), Streak.markDone(d0, 102))
    }

    // ---------- §6.3 formatTime 锚点 F1~F5 + B4 ----------

    /** case23 F1:秒补零(0/5/59)。 */
    @Test fun `case23_F1_seconds_pad`() {
        assertEquals("00:00", TimeFormat.formatTime(0))
        assertEquals("00:05", TimeFormat.formatTime(5))
        assertEquals("00:59", TimeFormat.formatTime(59))
    }

    /** case24 F2:进位 + 分钟补零(60/65)。 */
    @Test fun `case24_F2_minute_carry`() {
        assertEquals("01:00", TimeFormat.formatTime(60))
        assertEquals("01:05", TimeFormat.formatTime(65))
    }

    /** case25 F3/F4/F5:480 → 08:00;123 → 02:03(分钟不封顶);470 → 07:50。 */
    @Test fun `case25_F345_values`() {
        assertEquals("08:00", TimeFormat.formatTime(480))
        assertEquals("02:03", TimeFormat.formatTime(123))
        assertEquals("07:50", TimeFormat.formatTime(470))
    }

    /** case26 B4:负数 clamp 到 00:00(TR-Req C5-3)。 */
    @Test fun `case26_B4_negative_clamp`() {
        assertEquals("00:00", TimeFormat.formatTime(-5))
    }

    // ---------- §6.4 W1 打卡旅程主锚(AC-S6.1) ----------

    /** case27 W1:12 日旅程逐日 (current, longest) + 终态哈希(双端对账主锚)。 */
    @Test fun `case27_W1_journey_final_hash`() {
        val marked = setOf(100, 101, 102, 105, 106, 107, 108, 110, 111)
        val expectedRows = listOf(
            100 to (1 to 1), 101 to (2 to 2), 102 to (3 to 3),
            103 to (3 to 3), 104 to (0 to 3),
            105 to (1 to 3), 106 to (2 to 3), 107 to (3 to 3), 108 to (4 to 4),
            109 to (4 to 4), 110 to (1 to 4), 111 to (2 to 4),
        )
        var dates = setOf<Int>()
        for ((day, exp) in expectedRows) {
            if (day in marked) dates = Streak.markDone(dates, day)
            assertEquals("day $day current", exp.first, Streak.currentStreak(dates, day))
            assertEquals("day $day longest", exp.second, Streak.longestStreak(dates))
        }
        // 终态:current=2(110,111) / longest=4
        assertEquals(2, Streak.currentStreak(dates, 112))
        assertEquals(4, Streak.longestStreak(dates))
        // 终态序列化哈希(升序 , 连接,UTF-8)→ SHA-256 == 320e3b42...491a / 35B
        val finalStr = dates.sorted().joinToString(",")
        val bytes = finalStr.toByteArray(Charsets.UTF_8)
        assertEquals(35, bytes.size)
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { b -> "%02x".format(b) }
        assertEquals("320e3b425a8f98f33f8e789f093890171b514b7c69c2825575f3242a04ed491a", digest)
        // D9 幂等重放:连跑 2 次终态一致
        var dates2 = setOf<Int>()
        for (day in (100..111)) if (day in marked) { dates2 = Streak.markDone(dates2, day); dates2 = Streak.markDone(dates2, day) }
        assertEquals(dates.sorted(), dates2.sorted())
        assertEquals(Streak.longestStreak(dates), Streak.longestStreak(dates2))
    }

    /** case28 §8:schedule(30,10,12).last.endSec == 480(参数直断言收尾)。 */
    @Test fun `case28_schedule_7mw_last_end`() {
        val tl = Schedule.schedule(30, 10, 12)
        assertEquals(24, tl.size)
        assertEquals(480, tl.last().endSec)
        assertEquals(480, Schedule.totalSeconds(30, 10, 12))
    }
}
