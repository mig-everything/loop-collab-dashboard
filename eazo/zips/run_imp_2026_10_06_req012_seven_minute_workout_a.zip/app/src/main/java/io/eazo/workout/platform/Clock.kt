package io.eazo.workout.platform

import java.time.LocalDate

/**
 * 平台时钟端口(契约 §1 today 语义):core/ 禁读系统时钟,today 一律经此端口取
 * 整数日序号(与鸿蒙 platform/Clock.ets daysFromCivil 同口径;LocalDate.toEpochDay
 * 与 daysFromCivil 在 y≥1970 域恒等,REQ-009 先例)。
 */
object Clock {
    fun todayIndex(): Int = LocalDate.now().toEpochDay().toInt()
}
