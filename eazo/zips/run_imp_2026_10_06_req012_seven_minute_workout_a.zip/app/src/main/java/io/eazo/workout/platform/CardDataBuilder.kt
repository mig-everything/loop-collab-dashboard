package io.eazo.workout.platform

import io.eazo.workout.core.Streak

/**
 * REQ-012 卡片数据构建(纯推导,契约 04-harmony-features §1.1,与鸿蒙 CardDataBuilder.ets 1:1):
 * 「今日已练? + 连续 N 天 + 最长 M 天」——零新增契约语义。
 * (元服务卡片 AC-S4 Should;Android 侧 AppWidget 对等基线,双端特性对等纪律。)
 */
object CardDataBuilder {

    data class CardData(
        val doneToday: Boolean,
        val current: Int,
        val longest: Int,
    )

    fun buildCardData(dates: Set<Int>, today: Int): CardData = CardData(
        doneToday = Streak.isDoneToday(dates, today),
        current = Streak.currentStreak(dates, today),
        longest = Streak.longestStreak(dates),
    )
}
