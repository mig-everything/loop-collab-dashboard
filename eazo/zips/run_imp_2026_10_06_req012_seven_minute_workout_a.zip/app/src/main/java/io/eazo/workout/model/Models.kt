package io.eazo.workout.model

/**
 * REQ-012 数据模型(契约 §1,与鸿蒙 model/Models.ets 1:1)。
 */
data class Exercise(
    val id: Int,
    val name: String,
    val nameEn: String,
    val durationWork: Int,
    val durationRest: Int,
)

/** 时间轴段:phase ∈ {WORK, REST},半开区间 [startSec, endSec)。 */
data class TimelineSeg(
    val phase: String,
    val startSec: Int,
    val endSec: Int,
) {
    val lengthSec: Int get() = endSec - startSec
}

/** 打卡统计二元组。 */
data class StreakInfo(
    val current: Int,
    val longest: Int,
)
