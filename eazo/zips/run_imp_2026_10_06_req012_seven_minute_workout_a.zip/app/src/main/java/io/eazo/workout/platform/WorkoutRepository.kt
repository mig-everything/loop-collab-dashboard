package io.eazo.workout.platform

import android.content.Context
import android.content.SharedPreferences
import io.eazo.workout.core.Streak

/**
 * REQ-012 打卡日期集合仓储(进程内单例 + SharedPreferences 持久化,契约 §4 持久化口径)。
 * 写穿透内存 + 异步落盘(生成器硬规则 2「写即见」,读一律走内存)。
 */
object WorkoutRepository {

    private const val PREFS_NAME = "workout_dates"
    private const val KEY_DATES = "dates"

    private var prefs: SharedPreferences? = null
    private var dates: MutableSet<Int> = LinkedHashSet()
    private var loaded = false

    /** 冷启动恢复(进程内仅一次)。 */
    @Synchronized
    fun init(context: Context) {
        if (loaded) return
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        dates = prefs?.getString(KEY_DATES, "")
            ?.split(",")
            ?.filter { it.isNotBlank() }
            ?.map { it.trim().toInt() }
            ?.toCollection(LinkedHashSet()) ?: LinkedHashSet()
        loaded = true
    }

    /** 测试注入。 */
    @Synchronized
    fun setForTest(d: Set<Int>) {
        dates = LinkedHashSet(d)
        loaded = true
    }

    @Synchronized
    fun datesSnapshot(): Set<Int> = LinkedHashSet(dates)

    /** 打卡(幂等),写穿透内存 + 异步落盘。 */
    @Synchronized
    fun markDone(today: Int) {
        dates.add(today)
        prefs?.edit()?.putString(KEY_DATES, dates.sorted().joinToString(","))?.apply()
    }

    fun currentStreak(today: Int): Int = Streak.currentStreak(datesSnapshot(), today)
    fun longestStreak(): Int = Streak.longestStreak(datesSnapshot())
    fun isDoneToday(today: Int): Boolean = Streak.isDoneToday(datesSnapshot(), today)
}
