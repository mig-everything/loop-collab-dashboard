package io.eazo.workout.core

/**
 * REQ-012 formatTime 纯函数(契约 §3.2,与鸿蒙 core/TimeFormat.ets 1:1)。
 * mm:ss 补零,分钟不封顶;负数 clamp 到 0(B4);整数除法向下取整(禁浮点)。
 */
object TimeFormat {

    fun formatTime(totalSec: Int): String {
        var t = totalSec
        if (t < 0) t = 0
        val mm = t / 60
        val ss = t % 60
        return String.format("%02d:%02d", mm, ss)
    }
}
