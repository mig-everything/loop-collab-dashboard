package io.eazo.workout.core

import io.eazo.workout.model.Exercise

/**
 * REQ-012 12 动作常量 —— 本文件由 scripts/gen_workout_constants.py 从
 * seed/exercises-frozen.json 生成,禁手打(契约 §2.7 转录纪律,commit 2a5944b 契约 v1.0)。
 * 哈希锁:序列化(§2.3 规则)→ SHA-256 = 2a5944b51f8cbff9c52cab7e7ea75c96d4a6f37c386687c0176fdd2c220e0067(369 字节),单测 case1 断言。
 */
object WorkoutConstants {
    const val EXERCISE_COUNT = 12
    const val WORK_SEC = 30
    const val REST_SEC = 10
    const val ROUNDS_7MW = 12
    const val TOTAL_7MW = 480
    const val CANONICAL_SHA256 = "2a5944b51f8cbff9c52cab7e7ea75c96d4a6f37c386687c0176fdd2c220e0067"
    const val CANONICAL_BYTES = 369

    val EXERCISES: List<Exercise> = listOf(
        Exercise(id = 1, name = "开合跳", nameEn = "Jumping Jack", durationWork = 30, durationRest = 10),
        Exercise(id = 2, name = "靠墙静蹲", nameEn = "Wall Sit", durationWork = 30, durationRest = 10),
        Exercise(id = 3, name = "俯卧撑", nameEn = "Push-up", durationWork = 30, durationRest = 10),
        Exercise(id = 4, name = "卷腹", nameEn = "Abdominal Crunch", durationWork = 30, durationRest = 10),
        Exercise(id = 5, name = "登台阶", nameEn = "Step-up", durationWork = 30, durationRest = 10),
        Exercise(id = 6, name = "深蹲", nameEn = "Squat", durationWork = 30, durationRest = 10),
        Exercise(id = 7, name = "肱三头肌撑体", nameEn = "Triceps Dip", durationWork = 30, durationRest = 10),
        Exercise(id = 8, name = "平板支撑", nameEn = "Plank", durationWork = 30, durationRest = 10),
        Exercise(id = 9, name = "原地高抬腿", nameEn = "High Knees", durationWork = 30, durationRest = 10),
        Exercise(id = 10, name = "弓步蹲", nameEn = "Lunge", durationWork = 30, durationRest = 10),
        Exercise(id = 11, name = "俯卧撑转体", nameEn = "Push-up Rotation", durationWork = 30, durationRest = 10),
        Exercise(id = 12, name = "侧平板支撑", nameEn = "Side Plank", durationWork = 30, durationRest = 10),
    )
}
