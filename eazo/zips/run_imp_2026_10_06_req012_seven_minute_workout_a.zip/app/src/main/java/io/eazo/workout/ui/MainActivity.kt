package io.eazo.workout.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.workout.core.Schedule
import io.eazo.workout.core.TimeFormat
import io.eazo.workout.core.WorkoutConstants
import io.eazo.workout.model.TimelineSeg
import io.eazo.workout.platform.CardDataBuilder
import io.eazo.workout.platform.Clock
import io.eazo.workout.platform.WorkoutRepository
import kotlinx.coroutines.delay

/**
 * REQ-012 7分钟健身 · Android 基线(Kotlin + Jetpack Compose,零 XML 布局扇出)。
 *
 * 计时驱动口径(展示态,不入对账):段切换判定用时间轴 endSec 与已过秒数比较;
 * 目标结束时刻 - 当前时刻 差值计算剩余秒(不逐秒累加,防漂移,03-tech §3-7)。
 * 数据对账只看 schedule/streak/formatTime 纯函数输出(单测锁定)。
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WorkoutRepository.init(this)
        setContent { WorkoutApp() }
    }
}

// ---------- 主题(活力橙 × 深空蓝,与鸿蒙端同一套配色) ----------

private val WorkOrange = Color(0xFFFF7043)
private val RestBlue = Color(0xFF42A5F5)
private val DeepBg = Color(0xFF101828)
private val CardBg = Color(0xFF1B2537)
private val InkDark = Color(0xFF17203A)

private fun theme(isDark: Boolean) = if (isDark) darkColorScheme(
    primary = WorkOrange, background = DeepBg, surface = CardBg,
    onPrimary = Color.White, onBackground = Color(0xFFE7ECF5), onSurface = Color(0xFFE7ECF5),
) else lightColorScheme(
    primary = WorkOrange, background = Color(0xFFF7F5F0), surface = Color.White,
    onPrimary = Color.White, onBackground = InkDark, onSurface = InkDark,
)

// ---------- 顶层 App:主页 / 训练中 / 自定义间歇 ----------

private enum class Screen { HOME, RUNNING, SETUP }

@Composable
fun WorkoutApp() {
    val isDark = androidx.compose.foundation.isSystemInDarkTheme()
    MaterialTheme(colorScheme = theme(isDark)) {
        Surface(Modifier.fillMaxSize()) {
            var screen by remember { mutableStateOf(Screen.HOME) }
            // 自定义间歇参数(UI 层 min=1 约束,契约 §3.4 第一道防线)
            var customWork by remember { mutableIntStateOf(30) }
            var customRest by remember { mutableIntStateOf(10) }
            var customRounds by remember { mutableIntStateOf(8) }
            var activeTimeline by remember { mutableStateOf<List<TimelineSeg>>(emptyList()) }
            var activeIsPreset by remember { mutableStateOf(true) }

            val today = remember { Clock.todayIndex() }
            val card = remember { CardDataBuilder.buildCardData(WorkoutRepository.datesSnapshot(), today) }
            var streakNow by remember { mutableStateOf(card) }

            LaunchedEffect(screen) {
                if (screen == Screen.HOME) {
                    streakNow = CardDataBuilder.buildCardData(WorkoutRepository.datesSnapshot(), Clock.todayIndex())
                }
            }

            when (screen) {
                Screen.HOME -> HomeScreen(
                    card = streakNow,
                    onStartPreset = {
                        activeTimeline = Schedule.preset7mw()
                        activeIsPreset = true
                        screen = Screen.RUNNING
                    },
                    onOpenSetup = { screen = Screen.SETUP },
                )
                Screen.SETUP -> SetupScreen(
                    work = customWork, rest = customRest, rounds = customRounds,
                    onChange = { w, r, n -> customWork = w; customRest = r; customRounds = n },
                    onStart = {
                        activeTimeline = Schedule.schedule(customWork, customRest, customRounds)
                        activeIsPreset = false
                        screen = Screen.RUNNING
                    },
                    onBack = { screen = Screen.HOME },
                )
                Screen.RUNNING -> RunningScreen(
                    timeline = activeTimeline,
                    isPreset = activeIsPreset,
                    onDone = {
                        WorkoutRepository.markDone(Clock.todayIndex())
                        streakNow = CardDataBuilder.buildCardData(WorkoutRepository.datesSnapshot(), Clock.todayIndex())
                        screen = Screen.HOME
                    },
                    onAbort = { screen = Screen.HOME },
                )
            }
        }
    }
}

// ---------- 主页 ----------

@Composable
fun HomeScreen(card: CardDataBuilder.CardData, onStartPreset: () -> Unit, onOpenSetup: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(12.dp))
        Text("7 分钟健身", fontSize = 26.sp, fontWeight = FontWeight.Black)
        Text("Scientific 7-Minute Workout", fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.55f))
        Spacer(Modifier.height(16.dp))

        // 今日状态卡
        val statusColor = if (card.doneToday) Color(0xFF66BB6A) else WorkOrange
        Row(
            Modifier.fillMaxWidth().background(statusColor.copy(alpha = 0.14f), RoundedCornerShape(18.dp)).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(46.dp).background(statusColor, CircleShape), contentAlignment = Alignment.Center) {
                Text(if (card.doneToday) "✓" else "●", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(if (card.doneToday) "今日已练" else "今日未练", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text("连续 ${card.current} 天 · 最长 ${card.longest} 天", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
            }
        }
        Spacer(Modifier.height(20.dp))

        Button(
            onClick = onStartPreset,
            modifier = Modifier.fillMaxWidth().height(58.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = WorkOrange),
        ) { Text("开始 7 分钟训练", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = onOpenSetup,
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(16.dp),
        ) { Text("自定义间歇计时器", fontSize = 15.sp) }
        Spacer(Modifier.height(24.dp))

        // 动作列表(600vp/600dp 断点:宽屏双列 + 侧栏,AC-S5)
        val isWide = LocalConfiguration.current.screenWidthDp >= 600
        Text("12 个动作 · 30 秒运动 / 10 秒休息", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        Spacer(Modifier.height(10.dp))
        if (isWide) {
            Row(Modifier.fillMaxWidth()) {
                LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.weight(1.2f).height(430.dp)) {
                    items(WorkoutConstants.EXERCISES) { ExerciseCell(it) }
                }
                Spacer(Modifier.width(16.dp))
                PlanSideBar()
            }
        } else {
            WorkoutConstants.EXERCISES.forEach { ExerciseCell(it); Spacer(Modifier.height(8.dp)) }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun ExerciseCell(e: io.eazo.workout.model.Exercise) {
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(14.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(38.dp).background(WorkOrange.copy(alpha = 0.16f), CircleShape), contentAlignment = Alignment.Center) {
            Text("${e.id}", color = WorkOrange, fontWeight = FontWeight.Black, fontSize = 15.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(e.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(e.nameEn, fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
        }
        Text("${e.durationWork}s+${e.durationRest}s", fontSize = 12.sp, color = WorkOrange, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PlanSideBar(modifier: Modifier = Modifier) {
    Column(
        modifier.background(MaterialTheme.colorScheme.surface, RoundedCornerShape(14.dp)).padding(14.dp),
    ) {
        Text("训练计划", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))
        Text("总时长 8:00", fontSize = 13.sp)
        Text("12 轮 × (30s + 10s)", fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Text("科学顺序:ACSM/NYT 2013", fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
    }
}

// ---------- 自定义间歇设置 ----------

@Composable
fun SetupScreen(
    work: Int, rest: Int, rounds: Int,
    onChange: (Int, Int, Int) -> Unit,
    onStart: () -> Unit,
    onBack: () -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onBack) { Text("←") }
            Spacer(Modifier.width(12.dp))
            Text("自定义间歇计时器", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(24.dp))
        NumberPickerRow("运动时长(秒)", work, 1, 300) { onChange(it, rest, rounds) }
        Spacer(Modifier.height(14.dp))
        NumberPickerRow("休息时长(秒)", rest, 1, 300) { onChange(work, it, rounds) }
        Spacer(Modifier.height(14.dp))
        NumberPickerRow("轮数", rounds, 1, 30) { onChange(work, rest, it) }
        Spacer(Modifier.height(20.dp))
        Text(
            "预计总时长 ${TimeFormat.formatTime(Schedule.totalSeconds(work, rest, rounds))}",
            fontSize = 15.sp, fontWeight = FontWeight.Medium, color = WorkOrange,
        )
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = onStart,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = WorkOrange),
        ) { Text("开始训练", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun NumberPickerRow(label: String, value: Int, min: Int, max: Int, onValue: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(14.dp)).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, Modifier.weight(1f), fontSize = 15.sp)
        OutlinedButton(onClick = { if (value > min) onValue(value - 1) }, Modifier.width(44.dp)) { Text("−") }
        Text(
            "$value",
            Modifier.width(64.dp), textAlign = TextAlign.Center,
            fontSize = 20.sp, fontWeight = FontWeight.Black,
        )
        OutlinedButton(onClick = { if (value < max) onValue(value + 1) }, Modifier.width(44.dp)) { Text("+") }
    }
}

// ---------- 训练中 ----------

@Composable
fun RunningScreen(timeline: List<TimelineSeg>, isPreset: Boolean, onDone: () -> Unit, onAbort: () -> Unit) {
    val totalSec = timeline.lastOrNull()?.endSec ?: 0
    var elapsed by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val startAt = System.currentTimeMillis()
        while (!finished) {
            val sec = ((System.currentTimeMillis() - startAt) / 1000L).toInt()
            if (sec >= totalSec) { elapsed = totalSec; finished = true; break }
            elapsed = sec
            delay(200)
        }
    }

    val segIdx = timeline.indexOfLast { elapsed >= it.startSec && elapsed < it.endSec }.let { if (it < 0) 0 else it }
    val seg = timeline.getOrNull(segIdx) ?: TimelineSeg("WORK", 0, 0)
    val isWork = seg.phase == "WORK"
    val remaining = (seg.endSec - elapsed).coerceAtLeast(0)
    val roundTotal = timeline.size / 2
    val exerciseName = if (isPreset) WorkoutConstants.EXERCISES[(segIdx / 2) % WorkoutConstants.EXERCISE_COUNT].name else "第 ${(segIdx / 2) + 1}/$roundTotal 轮"
    val progress = animateFloatAsState(
        targetValue = if (totalSec == 0) 0f else elapsed.toFloat() / totalSec,
        animationSpec = tween(300), label = "progress",
    )
    val accent = if (isWork) WorkOrange else RestBlue

    Column(
        Modifier.fillMaxSize().background(if (isWork) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.background).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = onAbort) { Text("退出") }
            Spacer(Modifier.weight(1f))
            Text(
                if (isPreset) "7 分钟训练" else "自定义间歇",
                fontSize = 15.sp, fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.weight(1f)); Spacer(Modifier.width(72.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(if (isWork) "运动中" else "休息", fontSize = 16.sp, color = accent, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))

        Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = Stroke(width = 16f, cap = StrokeCap.Round)
                drawCircle(color = accent.copy(alpha = 0.15f), style = stroke, radius = size.minDimension / 2 - 12f)
                drawArc(
                    color = accent, startAngle = -90f,
                    sweepAngle = 360f * progress.value,
                    useCenter = false, style = stroke,
                    topLeft = Offset(12f, 12f),
                    size = androidx.compose.ui.geometry.Size(size.width - 24f, size.height - 24f),
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(TimeFormat.formatTime(remaining), fontSize = 56.sp, fontWeight = FontWeight.Black)
                Text("${seg.lengthSec}s 段", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f))
            }
        }
        Spacer(Modifier.height(18.dp))

        Text(
            if (isPreset) exerciseName else "第 ${(segIdx / 2) + 1}/$roundTotal 轮",
            fontSize = 24.sp, fontWeight = FontWeight.Bold,
        )
        if (isPreset) {
            Text(
                WorkoutConstants.EXERCISES[(segIdx / 2) % WorkoutConstants.EXERCISE_COUNT].nameEn,
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
            )
        }
        Spacer(Modifier.height(14.dp))
        Text(
            "总进度 ${TimeFormat.formatTime(elapsed)} / ${TimeFormat.formatTime(totalSec)}",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
        )
        Spacer(Modifier.height(24.dp))

        if (finished) {
            Button(
                onClick = onDone,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF66BB6A)),
            ) { Text("完成,打卡 ✓", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        } else {
            Text("坚持住,跟紧节奏!", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.45f))
        }
    }
}
