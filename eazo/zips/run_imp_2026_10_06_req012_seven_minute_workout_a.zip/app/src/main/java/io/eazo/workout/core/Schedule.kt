package io.eazo.workout.core

import io.eazo.workout.model.TimelineSeg

/**
 * REQ-012 间歇计时器纯函数(契约 §3,与鸿蒙 core/Schedule.ets 1:1)。
 * 全程整数运算(禁浮点);入口归一 normalize(v)=v>=1?v:1(TR-Req C3)。
 */
object Schedule {

    /** 入口归一:core 层对 <=0 钳 1(UI 层 min=1 是第一道防线,这里是双保险)。 */
    fun normalize(v: Int): Int = if (v >= 1) v else 1

    /**
     * 时间轴:每轮 2 段先 WORK 后 REST;半开区间 [startSec, endSec);共 2×rounds 条。
     * base = r × (workSec + restSec) —— 与动作字段无关,只由参数驱动(契约 §3.3 AD-2)。
     */
    fun schedule(workSec: Int, restSec: Int, rounds: Int): List<TimelineSeg> {
        val w = normalize(workSec)
        val r = normalize(restSec)
        val n = normalize(rounds)
        val out = ArrayList<TimelineSeg>(n * 2)
        for (i in 0 until n) {
            val base = i * (w + r)
            out.add(TimelineSeg("WORK", base, base + w))
            out.add(TimelineSeg("REST", base + w, base + w + r))
        }
        return out
    }

    /** 总时长 = rounds × (work + rest)(归一后参数)。 */
    fun totalSeconds(workSec: Int, restSec: Int, rounds: Int): Int =
        normalize(rounds) * (normalize(workSec) + normalize(restSec))

    /** 预置 7MW 时间轴(30/10/12)。 */
    fun preset7mw(): List<TimelineSeg> = schedule(30, 10, 12)

    /**
     * 第 r 轮(0-based)的段标注动作名(契约 §3.3):timeline[r*2] 是第 r 轮 WORK 段。
     * rounds > EXERCISES.size 时循环复用动作(自定义模式标注「第 N 轮」,由 UI 层处理)。
     */
    fun exerciseForRound(round: Int): String =
        WorkoutConstants.EXERCISES[round % WorkoutConstants.EXERCISE_COUNT].name
}
