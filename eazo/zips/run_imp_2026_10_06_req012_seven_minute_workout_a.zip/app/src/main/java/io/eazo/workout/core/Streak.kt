package io.eazo.workout.core

/**
 * REQ-012 打卡 streak 纯函数(契约 §4,与鸿蒙 core/Streak.ets 1:1)。
 * dates 是整数日序号集合;today 由调用方注入(core 禁读系统时钟)。
 */
object Streak {

    /**
     * 当前连续天数:从 today 往回数;today 不在集合但 today-1 在时从 today-1 往回
     * (今日未打不打断连续);未来日期天然不算。
     */
    fun currentStreak(dates: Set<Int>, today: Int): Int {
        if (dates.isEmpty()) return 0
        var d = if (dates.contains(today)) today else today - 1
        var streak = 0
        while (dates.contains(d)) {
            streak++
            d--
        }
        return streak
    }

    /** 历史最长连续段(升序遍历,run 递增;单元素 = 1)。 */
    fun longestStreak(dates: Set<Int>): Int {
        if (dates.isEmpty()) return 0
        val sorted = dates.sorted()
        var best = 1
        var run = 1
        for (i in 1 until sorted.size) {
            if (sorted[i] == sorted[i - 1] + 1) {
                run++
                if (run > best) best = run
            } else {
                run = 1
            }
        }
        return best
    }

    /** 今日已练判定(纯推导)。 */
    fun isDoneToday(dates: Set<Int>, today: Int): Boolean = dates.contains(today)

    /** 打卡 = 集合并(幂等:重复打卡同日不新增)。 */
    fun markDone(dates: Set<Int>, today: Int): Set<Int> = dates + today
}
