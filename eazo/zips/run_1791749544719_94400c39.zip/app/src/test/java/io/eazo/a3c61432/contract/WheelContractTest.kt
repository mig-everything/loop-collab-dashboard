package io.eazo.a3c61432.contract

import com.eazo.luckywheel.data.CUMULATIVE
import com.eazo.luckywheel.data.POOL_BYTES
import com.eazo.luckywheel.data.POOL_SHA256
import com.eazo.luckywheel.data.PRIZES
import com.eazo.luckywheel.data.SEED
import com.eazo.luckywheel.data.TOTAL_WEIGHT
import io.eazo.a3c61432.core.NavEvent
import io.eazo.a3c61432.core.NavOutcome
import io.eazo.a3c61432.core.NavState
import io.eazo.a3c61432.core.PhaseEvent
import io.eazo.a3c61432.core.SpinPhase
import io.eazo.a3c61432.core.WheelCore
import io.eazo.a3c61432.core.WheelUiState
import io.eazo.a3c61432.core.nextNav
import io.eazo.a3c61432.core.nextPhase
import io.eazo.a3c61432.model.DrawRecord
import io.eazo.a3c61432.model.toContractForm
import io.eazo.a3c61432.platform.AppRepo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

/**
 * REQ-020 契约锚点全集（docs/arch/req020/02-interface-contract.md §6/§8，冻结 commit a8cbb59）：
 * 哈希/序列/边界映射/PRNG 逐位/确定性/serial 语义/历史/常量直断言/结构/双状态机——
 * 锚点常量从 gen_prize_pool.py 生成物 import（禁手抄，契约 §6 引言）。
 */
class WheelContractTest {

    // ===== §6.1 奖品池整体锚点（运行时哈希自证，§4.4）=====

    @Test
    fun `contract_pool_sha256_and_bytes`() {
        val data = WheelCore.serializePrizes().toByteArray(Charsets.UTF_8)
        val sha = MessageDigest.getInstance("SHA-256").digest(data).joinToString("") { "%02x".format(it) }
        assertEquals(POOL_SHA256, sha)
        assertEquals(295, data.size)
        assertEquals(POOL_BYTES, data.size)
    }

    // ===== §6.2 drawIndex 序列锚点 =====

    @Test
    fun `contract_draw_index_sequence_12`() {
        assertEquals(listOf(5, 6, 5, 7, 3, 6, 6, 1, 6, 5, 3, 6), (1..12).map { WheelCore.drawIndex(seed = SEED, serial = it) })
    }

    @Test
    fun `contract_draw_index_first_anchor`() {
        assertEquals(5, WheelCore.drawIndex(seed = SEED, serial = 1)) // P06 六等奖·100积分
        assertEquals("P06", PRIZES[WheelCore.drawIndex(seed = SEED, serial = 1)].id)
    }

    @Test
    fun `contract_draw_index_sequence_13_24_extended`() {
        assertEquals(listOf(4, 4, 5, 6, 4, 5, 2, 5, 6, 4, 6, 7), (13..24).map { WheelCore.drawIndex(seed = SEED, serial = it) })
    }

    // ===== §6.3 weightedIndex 边界锚点 =====

    @Test
    fun `contract_weighted_index_boundary_points`() {
        // 构造点：r=0→P01、r=1..2→P02、r=3..7→P03、r=8..15→P04、r=16..27→P05、r=28..47→P06、r=48..72→P07、r=73..99→P08
        val expect = mapOf(0 to 0, 1 to 1, 2 to 1, 3 to 2, 7 to 2, 8 to 3, 15 to 3, 16 to 4, 27 to 4, 28 to 5, 47 to 5, 48 to 6, 72 to 6, 73 to 7, 99 to 7)
        expect.forEach { (r, idx) -> assertEquals("r=$r", idx, WheelCore.weightedIndex(r)) }
    }

    @Test
    fun `contract_weighted_index_full_100_points_continuous`() {
        for (r in 0..99) {
            assertEquals("r=$r 全 100 点连续无洞", CUMULATIVE.indexOfFirst { it > r }, WheelCore.weightedIndex(r))
        }
    }

    @Test
    fun `contract_interval_length_equals_weight`() {
        for (k in 0 until PRIZES.size) {
            val lo = if (k == 0) 0 else CUMULATIVE[k - 1]
            val hi = CUMULATIVE[k] - 1
            assertEquals("区间长度 == 权重 idx=$k", PRIZES[k].weight, hi - lo + 1)
        }
    }

    // ===== §6.4 PRNG 逐位锚点（★ P-1）=====

    @Test
    fun `contract_prng_bitwise_anchors`() {
        assertEquals(549735040, WheelCore.nextU32(SEED)) // 0x20C44A80
        val s2 = WheelCore.nextU32(549735040)
        assertEquals(2602030858L, s2.toLong() and 0xFFFFFFFFL) // 0x9B17D70A
        assertEquals(-1692936438, s2) // bit31 置位 → Int 视角负值
    }

    @Test
    fun `contract_kotlin_long_domain_mod_v5`() {
        // V5 判别构造：serial=2 state<0，负模变异恒中 index 0，正确 index 6
        val s2 = WheelCore.nextU32(549735040)
        assertTrue(s2 < 0)
        assertEquals(6, WheelCore.weightedIndex(s2))
        assertEquals(6, WheelCore.drawIndex(seed = SEED, serial = 2)) // §6.2 serial=2 锚点互证
    }

    @Test
    fun `contract_zero_state_self_locks`() {
        assertEquals(0, WheelCore.nextU32(0)) // 零态自锁（SEED 禁 0 的根因）
    }

    // ===== §6.5/§6.6 确定性、幂等与不可变 =====

    @Test
    fun `contract_deterministic_and_idempotent`() {
        val first = (1..20).map { WheelCore.drawIndex(seed = SEED, serial = it) }
        repeat(10) {
            assertEquals(first, (1..20).map { i -> WheelCore.drawIndex(seed = SEED, serial = i) })
        }
    }

    @Test
    fun `contract_prizes_immutable_after_draws`() {
        val snapshot = PRIZES.map { it.copy() }
        (1..100).forEach { WheelCore.drawIndex(seed = SEED, serial = it) }
        assertEquals(snapshot, PRIZES)
    }

    @Test
    fun `contract_reset_closes_idempotent_loop`() {
        AppRepo.resetForTest(null)
        AppRepo.spin()
        AppRepo.spin()
        AppRepo.reset()
        assertEquals(WheelCore.drawIndex(seed = SEED, serial = 1), AppRepo.nextDraw())
        assertEquals(5, AppRepo.nextDraw()) // reset 后再抽 == 第 1 次结果（§6.5）
    }

    // ===== §6.5 历史记录语义 =====

    @Test
    fun `contract_history_three_draws_mapping`() {
        AppRepo.resetForTest(null)
        AppRepo.spin()
        AppRepo.spin()
        AppRepo.spin()
        assertEquals("1:P06\n2:P07\n3:P06", AppRepo.list().toContractForm())
    }

    @Test
    fun `contract_reset_atomic_clear_and_serial_one`() {
        AppRepo.resetForTest(null)
        AppRepo.spin()
        AppRepo.spin()
        AppRepo.reset()
        // 原子性：历史清空与 serial 归 1 同一操作（无中间态）
        assertEquals(0, AppRepo.list().size)
        assertEquals(1, AppRepo.currentSerial())
    }

    @Test
    fun `contract_serial_semantics_one_based_monotonic`() {
        AppRepo.resetForTest(null)
        assertEquals(1, AppRepo.currentSerial()) // 1 基
        val serials = (1..5).map { AppRepo.spin().serial }
        assertEquals(listOf(1, 2, 3, 4, 5), serials) // 单调递增
        AppRepo.reset()
        assertEquals(1, AppRepo.currentSerial()) // reset 归 1
    }

    @Test
    fun `contract_store_line_round_trip`() {
        val rec = DrawRecord(3, 5, "P06", "六等奖·100积分", 1728700000000L)
        assertEquals(rec, DrawRecord.fromStoreLine(rec.toStoreLine()))
        assertEquals("3:P06", rec.toContractForm())
        assertNull(DrawRecord.fromStoreLine("bad|line"))
        assertNull(DrawRecord.fromStoreLine("0|5|P06|六等奖·100积分|1000")) // serial 0 非法
    }

    // ===== §8 常量直断言 =====

    @Test
    fun `contract_constants_direct`() {
        assertEquals(20261011, SEED)
        assertTrue(SEED != 0) // uint32 非零（零态自锁禁令）
        assertEquals(8, PRIZES.size) // PRIZE_COUNT
        assertEquals(100, TOTAL_WEIGHT)
        assertTrue(CUMULATIVE.contentEquals(intArrayOf(1, 3, 8, 16, 28, 48, 73, 100)))
        assertEquals(listOf(1, 2, 5, 8, 12, 20, 25, 27), PRIZES.map { it.weight })
        assertEquals(295, POOL_BYTES)
        assertEquals("2abf42c6cb431dd8514b36696987c29b9b56fedb9d80aeef0dbc5b11c901cd33", POOL_SHA256)
    }

    // ===== §6.6/§4.3 结构断言 =====

    @Test
    fun `contract_pool_structure_and_separator_codepoint`() {
        assertEquals(listOf("P01", "P02", "P03", "P04", "P05", "P06", "P07", "P08"), PRIZES.map { it.id }) // id 升序
        PRIZES.forEach { p ->
            assertTrue(p.id.isNotEmpty() && p.name.isNotEmpty() && p.color.isNotEmpty())
            assertFalse("字段内禁 |", p.name.contains("|"))
            assertTrue("color #RRGGBB 大写", p.color.matches(Regex("#[0-9A-F]{6}")))
        }
        // name 分隔符 U+00B7（MIDDLE DOT）×7；P08 无分隔符（V8d：错 1 码点即哈希分叉）
        assertEquals(7, PRIZES.dropLast(1).count { it.name.contains('·') })
        PRIZES.dropLast(1).forEach {
            assertTrue(it.name.contains('·'))
            assertFalse(it.name.contains('・')) // U+30FB 片假名中点是典型误源
        }
        assertFalse(PRIZES.last().name.contains('·'))
    }

    // ===== §2.5/§6.7 导航状态机封闭性（2 态 × 2 事件 = 3 有效 + 1 忽略）=====

    @Test
    fun `contract_nav_state_machine_closed_set`() {
        assertEquals(NavState.WHEEL, WheelUiState().nav) // 初始态
        val wheel = WheelUiState()

        val toHistory = nextNav(wheel, NavEvent.OPEN_HISTORY) // (wheel, openHistory) → history
        assertEquals(NavOutcome.NAVIGATE, toHistory.second)
        assertEquals(NavState.HISTORY, toHistory.first.nav)

        val backToWheel = nextNav(toHistory.first, NavEvent.BACK) // (history, back) → wheel
        assertEquals(NavOutcome.NAVIGATE, backToWheel.second)
        assertEquals(NavState.WHEEL, backToWheel.first.nav)

        assertEquals(NavOutcome.EXIT_APP, nextNav(wheel, NavEvent.BACK).second) // (wheel, back) → 退出（根态）

        val ignored = nextNav(toHistory.first, NavEvent.OPEN_HISTORY) // (history, openHistory) → 忽略
        assertEquals(NavOutcome.IGNORED, ignored.second)
        assertEquals(toHistory.first, ignored.first) // 状态原样
    }

    // ===== §2.5/§6.7 相位状态机封闭性（3 态 × 4 事件 = 5 有效 + 其余忽略）=====

    @Test
    fun `contract_phase_state_machine_closed_set`() {
        // 主链 idle→spinning→result→idle
        var s = WheelUiState()
        assertEquals(SpinPhase.IDLE, s.phase)
        s = nextPhase(s, PhaseEvent.Spin(1))
        assertEquals(SpinPhase.SPINNING, s.phase)
        assertEquals(5, s.targetIndex) // targetIndex = drawIndex(SEED, 1)
        s = nextPhase(s, PhaseEvent.Settled(s.targetIndex))
        assertEquals(SpinPhase.RESULT, s.phase)
        assertEquals(5, s.resultIndex)
        s = nextPhase(s, PhaseEvent.CloseResult)
        assertEquals(SpinPhase.IDLE, s.phase)

        // (result, spin)：弹窗不关也可连抽
        val again = nextPhase(WheelUiState(phase = SpinPhase.RESULT, resultIndex = 5), PhaseEvent.Spin(2))
        assertEquals(SpinPhase.SPINNING, again.phase)
        assertEquals(6, again.targetIndex)

        // 忽略组合：spinning+Spin（C13）、idle+Settled、idle/spinning+CloseResult
        assertEquals(SpinPhase.SPINNING, nextPhase(WheelUiState(phase = SpinPhase.SPINNING, targetIndex = 5), PhaseEvent.Spin(2)).phase)
        assertEquals(SpinPhase.IDLE, nextPhase(WheelUiState(), PhaseEvent.Settled(3)).phase)
        assertEquals(SpinPhase.IDLE, nextPhase(WheelUiState(), PhaseEvent.CloseResult).phase)
        assertEquals(SpinPhase.SPINNING, nextPhase(WheelUiState(phase = SpinPhase.SPINNING), PhaseEvent.CloseResult).phase)

        // reset 任意相位归 idle（payload 清空）
        listOf(SpinPhase.IDLE, SpinPhase.SPINNING, SpinPhase.RESULT).forEach { ph ->
            val after = nextPhase(WheelUiState(phase = ph, targetIndex = 3, resultIndex = 3), PhaseEvent.Reset)
            assertEquals(SpinPhase.IDLE, after.phase)
            assertEquals(-1, after.targetIndex)
            assertEquals(-1, after.resultIndex)
        }
    }

    // ===== §2.4 展示层停位角（弱断言：存在性/单调递减，不入对账）=====

    @Test
    fun `contract_angle_for_index_display_layer_weak`() {
        val angles = (0..7).map { WheelCore.angleForIndex(it) }
        assertEquals(8, angles.size)
        assertEquals(8, angles.toSet().size) // 8 个不同停位角
        (0..6).forEach { assertTrue(angles[it] > angles[it + 1]) } // 单调递减
        angles.forEach { assertTrue("∈ (1800, 2160]（5 圈整转 + 回转角）", it > 1800f && it <= 2160f) }
    }
}
