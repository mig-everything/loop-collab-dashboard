package io.eazo.a3c61432.contract

import com.eazo.luckywheel.data.PRIZES
import com.eazo.luckywheel.data.SEED
import io.eazo.a3c61432.core.PhaseEvent
import io.eazo.a3c61432.core.SpinPhase
import io.eazo.a3c61432.core.WheelCore
import io.eazo.a3c61432.core.WheelUiState
import io.eazo.a3c61432.core.nextPhase
import io.eazo.a3c61432.platform.AppRepo
import io.eazo.a3c61432.ui.LayoutLogic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * REQ-020 冻结功能用例集（eazo-cases-1.0.0，14 条）：
 * 用例名逐字等于 slug（平台硬约束，不得增删改/改名/合并拆分）。
 * UI 语义经数据态等价物（状态机 + AppRepo + 展示层纯函数）断言，JVM 纯逻辑。
 */
class WheelCasesTest {

    /** 内存 Store（C10 跨会话持久化模拟）。 */
    private class MemStore : AppRepo.Store {
        var value: String? = null
        override fun read(): String? = value
        override fun write(v: String) {
            value = v
        }
        override fun clear() {
            value = null
        }
    }

    private fun freshRepo(store: AppRepo.Store = MemStore()): AppRepo {
        AppRepo.resetForTest(store)
        return AppRepo
    }

    @Test
    fun `basic_lottery_main_flow`() {
        val repo = freshRepo()
        var ui = WheelUiState()
        // 点击抽奖 → 旋转中，目标扇区 = drawIndex(SEED, serial)
        val rec = repo.spin()
        ui = nextPhase(ui, PhaseEvent.Spin(rec.serial))
        assertEquals(SpinPhase.SPINNING, ui.phase)
        assertTrue(ui.targetIndex in 0..7)
        assertEquals(rec.prizeIndex, ui.targetIndex)
        // 动画结束 → 停在某奖品格并弹出中奖结果
        ui = nextPhase(ui, PhaseEvent.Settled(ui.targetIndex))
        assertEquals(SpinPhase.RESULT, ui.phase)
        assertEquals(rec.prizeIndex, ui.resultIndex)
        assertEquals(rec.prizeId, PRIZES[ui.resultIndex].id)
        assertEquals(rec.name, PRIZES[ui.resultIndex].name)
        // 关闭弹窗回 idle，完成一次完整抽奖
        ui = nextPhase(ui, PhaseEvent.CloseResult)
        assertEquals(SpinPhase.IDLE, ui.phase)
    }

    @Test
    fun `wheel_displays_eight_prizes`() {
        assertEquals(8, PRIZES.size)
        assertEquals(listOf("P01", "P02", "P03", "P04", "P05", "P06", "P07", "P08"), PRIZES.map { it.id })
        PRIZES.forEach { assertTrue("奖品名非空：${it.id}", it.name.isNotEmpty()) }
        // 均分 8 格：相邻停位角差恒 45°
        val angles = (0..7).map { WheelCore.angleForIndex(it) }
        for (i in 0..6) {
            assertEquals(45f, angles[i] - angles[i + 1], 0.0001f)
        }
    }

    @Test
    fun `same_seed_same_n_same_result`() {
        val repo = freshRepo()
        val round1 = (1..10).map { repo.spin().prizeId }
        repo.reset() // 重置（清历史 + serial 归 1）
        val round2 = (1..10).map { repo.spin().prizeId }
        assertEquals("同 seed 同次序：两轮序列完全一致", round1, round2)
        // 与 core 纯函数重算逐字一致
        val expect = (1..10).map { WheelCore.drawIndex(seed = SEED, serial = it) }
        assertEquals(expect, round1.map { id -> PRIZES.indexOfFirst { it.id == id } })
    }

    @Test
    fun `different_seed_different_result`() {
        val a = WheelCore.drawIndex(seed = SEED, serial = 5)
        val b = WheelCore.drawIndex(seed = 20261012, serial = 5)
        assertNotEquals("不同 seed 第 5 次抽奖结果应不同：$a vs $b", a, b)
    }

    @Test
    fun `weight_distribution_decreasing`() {
        val n = 10000
        val counts = IntArray(PRIZES.size)
        for (s in 1..n) {
            counts[WheelCore.drawIndex(seed = SEED, serial = s)]++
        }
        assertEquals(n, counts.sum())
        // 一等奖次数最少，谢谢参与次数最多（权重 [1..27] 递增）
        assertEquals(counts.minOrNull(), counts[0])
        assertEquals(counts.maxOrNull(), counts[7])
        for (i in 0 until PRIZES.size - 1) {
            assertTrue("权重递减分布：counts[$i]=${counts[i]} 应 < counts[${i + 1}]=${counts[i + 1]}", counts[i] < counts[i + 1])
        }
    }

    @Test
    fun `all_prizes_reachable_in_draws`() {
        val seen = mutableSetOf<Int>()
        for (seed in listOf(SEED, 20261012, 987654321, 1357924680)) {
            for (k in 1..2000) {
                seen += WheelCore.drawIndex(seed = seed, serial = k)
            }
        }
        assertEquals("全部 8 格奖品均可被抽到：$seen", 8, seen.size)
    }

    @Test
    fun `history_records_in_chronological_order`() {
        val repo = freshRepo()
        repeat(5) { repo.spin() }
        val list = repo.list()
        assertEquals(5, list.size)
        assertEquals(listOf(1, 2, 3, 4, 5), list.map { it.serial })
        assertTrue("时间戳单调非降", list.map { it.timeMillis }.zipWithNext().all { (a, b) -> a <= b })
    }

    @Test
    fun `wheel_stop_position_matches_result`() {
        for (idx in 0..7) {
            val rot = WheelCore.angleForIndex(idx)
            assertEquals("停位角逆映射应指回原扇区 idx=$idx", idx, WheelCore.sectorAtPointer(rot))
            // 从任意中间角度出发的正向旋转同样对齐
            val from = 1234.5f
            val target = WheelCore.targetRotation(from, idx)
            assertTrue("目标角必须正向前进", target > from)
            assertEquals(idx, WheelCore.sectorAtPointer(target))
        }
    }

    @Test
    fun `consecutive_draws_function_normally`() {
        val repo = freshRepo()
        val results = (1..10).map { repo.spin() }
        assertEquals(10, results.size)
        assertEquals((1..10).toList(), results.map { it.serial })
        results.forEach { rec ->
            assertTrue(rec.prizeIndex in 0..7)
            assertEquals(rec.prizeIndex, WheelCore.drawIndex(seed = SEED, serial = rec.serial))
        }
        assertEquals(11, repo.currentSerial())
        assertEquals(10, repo.list().size)
    }

    @Test
    fun `history_persists_across_sessions`() {
        val store = MemStore()
        val repo = freshRepo(store)
        repo.spin()
        repo.spin()
        repo.spin()
        assertEquals(3, repo.list().size)
        // 模拟退出 App 再重新进入：内存态清空，同一 Store 冷启动一次性加载
        AppRepo.resetForTest(store)
        val reloaded = repo.list()
        assertEquals("跨会话历史保留 3 条完整记录", 3, reloaded.size)
        assertEquals(listOf(1, 2, 3), reloaded.map { it.serial })
        assertEquals("P06", reloaded[0].prizeId)
        assertEquals("P07", reloaded[1].prizeId)
        assertEquals(4, repo.currentSerial())
    }

    @Test
    fun `history_entry_has_complete_fields`() {
        val repo = freshRepo()
        val before = System.currentTimeMillis()
        val rec = repo.spin()
        val after = System.currentTimeMillis()
        assertNotNull(rec)
        assertEquals(1, rec.serial)
        assertTrue(rec.prizeId in PRIZES.map { it.id })
        assertTrue(rec.name.isNotBlank())
        assertTrue("时间字段完整且落在抽奖瞬间窗口内", rec.timeMillis in before..after)
        assertEquals(PRIZES[rec.prizeIndex].id, rec.prizeId)
        assertEquals(PRIZES[rec.prizeIndex].name, rec.name)
    }

    @Test
    fun `responsive_layout_across_devices`() {
        // 手机 / 平板 / 折叠屏展开三档
        val phone = LayoutLogic.wheelDiameter(360f, 740f)
        val tablet = LayoutLogic.wheelDiameter(800f, 1280f)
        val fold = LayoutLogic.wheelDiameter(673f, 841f)
        listOf(phone to 360f, tablet to 800f, fold to 673f).forEach { (d, w) ->
            assertTrue("转盘直径在夹取区间：$d", d in LayoutLogic.MIN_WHEEL_DP..LayoutLogic.MAX_WHEEL_DP)
            assertTrue("转盘完整可见（直径 ≤ 屏宽）", d <= w)
        }
        assertTrue("随屏伸缩：手机 < 平板", phone < tablet)
        assertEquals(560f, LayoutLogic.contentMaxWidth(800f))
        assertEquals(360f, LayoutLogic.contentMaxWidth(360f))
    }

    @Test
    fun `draw_button_disabled_during_animation`() {
        val repo = freshRepo()
        var ui = WheelUiState()
        val r1 = repo.spin()
        ui = nextPhase(ui, PhaseEvent.Spin(r1.serial))
        assertEquals(SpinPhase.SPINNING, ui.phase)
        // 复刻 UI 点击守卫：spinning 期间点击 → 忽略，不触发新抽奖
        val guardedClick = {
            if (ui.phase != SpinPhase.SPINNING) {
                val rec = repo.spin()
                ui = nextPhase(ui, PhaseEvent.Spin(rec.serial))
                rec
            } else {
                null
            }
        }
        assertNull("动画期间第二次点击被忽略", guardedClick())
        assertEquals(SpinPhase.SPINNING, ui.phase)
        assertEquals("serial 未被无效点击推进", 2, repo.currentSerial())
        assertEquals("历史只有第一次抽奖一条", 1, repo.list().size)
        // 状态机层面同样忽略（双保险）
        assertEquals(ui, nextPhase(ui, PhaseEvent.Spin(repo.currentSerial())))
    }

    @Test
    fun `history_recorded_after_popup_dismissed`() {
        val repo = freshRepo()
        var ui = WheelUiState()
        val rec = repo.spin()
        ui = nextPhase(ui, PhaseEvent.Spin(rec.serial))
        ui = nextPhase(ui, PhaseEvent.Settled(ui.targetIndex))
        assertEquals(SpinPhase.RESULT, ui.phase)
        // 弹窗尚在展示时，历史已记录该次抽奖（spin 与落史同一原子操作）
        assertEquals(1, repo.list().size)
        assertEquals(rec.serial, repo.list().first().serial)
        // 关闭结果弹窗后查看历史：记录仍在
        ui = nextPhase(ui, PhaseEvent.CloseResult)
        assertEquals(SpinPhase.IDLE, ui.phase)
        assertEquals(1, repo.list().size)
        assertEquals(rec.prizeId, repo.list().first().prizeId)
    }
}
