package io.eazo.a3c61432.core

/**
 * REQ-020 页面导航与交互状态机（契约 §2.5，数据态可测）：
 * 导航 2 态 × 2 事件（3 有效 + 1 忽略）+ 相位 3 态 × 4 事件（5 有效 + 其余忽略），
 * 未列出的组合一律忽略（禁崩溃、禁隐式跳转）。路由字符串与鸿蒙字面一致。
 */

/** 导航态：wheel | history（结果弹窗为 wheel 页覆盖层，非独立页）。 */
enum class NavState(val route: String) {
    WHEEL("wheel"),
    HISTORY("history"),
}

/** 导航事件。 */
enum class NavEvent { OPEN_HISTORY, BACK }

/** 导航转移结果：跳转 / 退出 App（根态）/ 忽略。 */
enum class NavOutcome { NAVIGATE, EXIT_APP, IGNORED }

/** 交互相位：idle | spinning | result（动画为展示态，相位本身数据态可测）。 */
enum class SpinPhase { IDLE, SPINNING, RESULT }

/** 交互层可见的页面聚合态（payload 只携带对账需要的最小字段）。 */
data class WheelUiState(
    val nav: NavState = NavState.WHEEL,
    val phase: SpinPhase = SpinPhase.IDLE,
    /** spinning 期间的目标扇区（= drawIndex(SEED, serial)，进入 spinning 时锁定）。 */
    val targetIndex: Int = -1,
    /** result 期间的中奖扇区（settled 到达时锁定）。 */
    val resultIndex: Int = -1,
)

/** 相位事件（spin 携带本次 serial；settled 仅在 targetIndex 到达时发出）。 */
sealed interface PhaseEvent {
    data class Spin(val serial: Int) : PhaseEvent
    data class Settled(val index: Int) : PhaseEvent
    data object CloseResult : PhaseEvent
    data object Reset : PhaseEvent
}

/** 导航状态机：next(state, event) → (新态, 结果)；无效组合返回原态 + IGNORED。 */
fun nextNav(state: WheelUiState, event: NavEvent): Pair<WheelUiState, NavOutcome> = when (state.nav) {
    NavState.WHEEL -> when (event) {
        NavEvent.OPEN_HISTORY -> state.copy(nav = NavState.HISTORY, phase = SpinPhase.IDLE) to NavOutcome.NAVIGATE
        NavEvent.BACK -> state to NavOutcome.EXIT_APP
    }
    NavState.HISTORY -> when (event) {
        NavEvent.BACK -> state.copy(nav = NavState.WHEEL, phase = SpinPhase.IDLE) to NavOutcome.NAVIGATE
        NavEvent.OPEN_HISTORY -> state to NavOutcome.IGNORED
    }
}

/**
 * 相位状态机：nextPhase(state, event) → 新态；无效组合返回原态（null 语义由调用方判 same）。
 * reset 从 wheel 页任意相位归 idle（历史清空 + serial 归 1 由 AppRepo 原子完成）。
 */
fun nextPhase(state: WheelUiState, event: PhaseEvent): WheelUiState = when (event) {
    is PhaseEvent.Spin -> when (state.phase) {
        SpinPhase.IDLE -> state.copy(
            phase = SpinPhase.SPINNING,
            targetIndex = WheelCore.drawIndex(serial = event.serial),
            resultIndex = -1,
        )
        // 弹窗不关也可连抽（serial 已 +1，契约 §2.5）
        SpinPhase.RESULT -> state.copy(
            phase = SpinPhase.SPINNING,
            targetIndex = WheelCore.drawIndex(serial = event.serial),
            resultIndex = -1,
        )
        SpinPhase.SPINNING -> state // 动画期间重复点击被忽略（C13）
    }
    is PhaseEvent.Settled -> when (state.phase) {
        SpinPhase.SPINNING -> state.copy(phase = SpinPhase.RESULT, resultIndex = event.index)
        else -> state
    }
    PhaseEvent.CloseResult -> when (state.phase) {
        SpinPhase.RESULT -> state.copy(phase = SpinPhase.IDLE, resultIndex = -1)
        else -> state
    }
    PhaseEvent.Reset -> state.copy(phase = SpinPhase.IDLE, targetIndex = -1, resultIndex = -1)
}
