package io.eazo.a3c61432.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.a3c61432.model.DrawRecord
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 中奖历史页：serial 升序（时间顺序，C07），条目含奖品名/时间/序号（C11）。 */
@Composable
fun HistoryPage(
    history: List<DrawRecord>,
    onBack: () -> Unit,
    onReset: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PaletteBg)
            .statusBarsPadding(),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回", tint = Color.White)
            }
            Text(
                "中奖历史",
                modifier = Modifier.weight(1f),
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
            )
            TextButton(onClick = onReset) {
                Text("清空重置", color = PaletteTextDim, fontSize = 13.sp)
            }
        }

        if (history.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 120.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("🎰", fontSize = 44.sp)
                Spacer(Modifier.size(10.dp))
                Text("暂无抽奖记录", color = PaletteTextDim, fontSize = 15.sp)
                Text("回到转盘抽一次吧", color = PaletteTextDim.copy(alpha = 0.7f), fontSize = 12.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(history, key = { it.serial }) { rec ->
                    HistoryCard(rec)
                }
            }
        }
    }
}

@Composable
private fun HistoryCard(rec: DrawRecord) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = PaletteSurface,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(hexToColor(prizeColorOf(rec)), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(rankLabelOf(rec.prizeId), color = labelColorOn(prizeColorOf(rec)), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.size(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(rec.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(formatTime(rec.timeMillis), color = PaletteTextDim, fontSize = 12.sp)
            }
            Surface(shape = RoundedCornerShape(50), color = PaletteGold.copy(alpha = 0.16f)) {
                Text(
                    "第 ${rec.serial} 次",
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    color = PaletteGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

/** 展示态辅助：历史条目回查奖品色/奖级标签（prizeId → 奖品池）。 */
private fun prizeColorOf(rec: DrawRecord): String =
    com.eazo.luckywheel.data.PRIZES.firstOrNull { it.id == rec.prizeId }?.color ?: "#808080"

private fun rankLabelOf(prizeId: String): String = when (prizeId) {
    "P01" -> "一"
    "P02" -> "二"
    "P03" -> "三"
    "P04" -> "四"
    "P05" -> "五"
    "P06" -> "六"
    "P07" -> "七"
    else -> "🙏"
}

private val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
private fun formatTime(millis: Long): String = timeFormat.format(Date(millis))
