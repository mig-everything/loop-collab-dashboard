package io.eazo.a3c61432.platform

import android.content.Context
import com.eazo.luckywheel.data.PRIZES
import com.eazo.luckywheel.data.SEED
import io.eazo.a3c61432.core.WheelCore
import io.eazo.a3c61432.model.DrawRecord

/**
 * 骨架模板平台层：AppRepo 进程内单例（生成器硬规则 ①——UI/卡片层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * AppRepo 本身即进程内单例（Kotlin object）；会话按需求把业务仓储/持久化
 * 作为本 object 的成员挂接（参照基线工程 Platform.kt：object AppRepo 持有
 * repo 实例，getRepo() 双检锁构造），保持 getRepo(context) 单例入口不变。
 */
object AppRepo {

    /** 持久化端口：生产 SharedPreferences 实现 + 测试内存实现（C10 跨会话可测）。 */
    interface Store {
        fun read(): String?
        fun write(value: String)
        fun clear()
    }

    private class PrefsStore(context: Context) : Store {
        private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        override fun read(): String? = prefs.getString(KEY_HISTORY, null)
        override fun write(value: String) = prefs.edit().putString(KEY_HISTORY, value).apply()
        override fun clear() = prefs.edit().remove(KEY_HISTORY).apply()
    }

    private const val PREFS_NAME = "lucky_wheel_state"
    private const val KEY_HISTORY = "history"

    private val lock = Any()
    private var store: Store? = null
    private var loaded = false
    private val history = mutableListOf<DrawRecord>()
    private var serial = 1

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo {
        synchronized(lock) {
            if (store == null) {
                store = PrefsStore(context.applicationContext)
            }
            ensureLoadedLocked()
        }
        return this
    }

    /** 会话按需求扩展：内存态持有 + 持久化读写（读写分离，list() 只读内存态）。 */
    fun refresh() {
        // 硬规则 ②：refresh 只重读内存态，禁止从持久化 load()——内存态即唯一真源，
        // 持久化只在冷启动首触(getRepo)一次性 load + 每次 spin/reset 写透。
        synchronized(lock) { /* list() 每次调用都重读内存快照，此处无额外动作 */ }
    }

    /** 历史列表（时间顺序 = serial 升序；每次调用重读内存态）。 */
    fun list(): List<DrawRecord> {
        synchronized(lock) {
            ensureLoadedLocked()
            return history.sortedBy { it.serial }
        }
    }

    /** 下一次抽奖序号（1 基，只读）。 */
    fun currentSerial(): Int {
        synchronized(lock) {
            ensureLoadedLocked()
            return serial
        }
    }

    /** 下一抽预览（不推进 serial）：nextDraw() == drawIndex(SEED, serial)。 */
    fun nextDraw(): Int {
        synchronized(lock) {
            ensureLoadedLocked()
            return WheelCore.drawIndex(seed = SEED, serial = serial)
        }
    }

    /**
     * 点击抽奖（契约 §3 serial 推进链）：推进 serial 与历史 append 在同一原子操作内
     * （用 serial 抽 → 落历史 → serial+1，禁先抽后 +1 的竞态窗口），随后写透持久化。
     */
    fun spin(): DrawRecord = synchronized(lock) {
        ensureLoadedLocked()
        val s = serial
        val idx = WheelCore.drawIndex(seed = SEED, serial = s)
        val prize = PRIZES[idx]
        val rec = DrawRecord(s, idx, prize.id, prize.name, System.currentTimeMillis())
        history.add(rec)
        serial = s + 1
        store?.write(history.joinToString("\n") { it.toStoreLine() })
        rec
    }

    /** reset（契约 §2.5/§6.5 原子语义）：清历史 + serial 归 1 + 持久化清空，同一操作。 */
    fun reset() = synchronized(lock) {
        history.clear()
        serial = 1
        store?.clear()
    }

    /** 测试钩子：重绑 Store 并清内存态（模拟进程重启后冷加载，C10 用）。 */
    fun resetForTest(testStore: Store?) = synchronized(lock) {
        store = testStore
        loaded = false
        history.clear()
        serial = 1
    }

    /** 冷启动一次性 load（store 就绪且未加载时）；warm resume 永不触发（硬规则 ②）。 */
    private fun ensureLoadedLocked() {
        val s = store ?: return
        if (loaded) return
        loaded = true
        s.read()?.takeIf { it.isNotBlank() }?.let { raw ->
            history.clear()
            history.addAll(raw.split("\n").mapNotNull { DrawRecord.fromStoreLine(it) })
        }
        serial = history.size + 1
    }
}
