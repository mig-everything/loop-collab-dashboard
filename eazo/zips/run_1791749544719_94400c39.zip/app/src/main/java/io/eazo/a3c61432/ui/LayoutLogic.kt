package io.eazo.a3c61432.ui

/**
 * 布局自适应纯函数（C12，JVM 可测，无 Compose 依赖）：
 * 转盘直径 = 可用区短边 * 0.82，夹在 [220, 460] dp——手机/平板/折叠屏均完整可见。
 */
object LayoutLogic {

    const val MIN_WHEEL_DP = 220f
    const val MAX_WHEEL_DP = 460f

    /** 转盘直径（dp）：随短边伸缩并夹取上下限，恒 ≤ 短边（完整可见）。 */
    fun wheelDiameter(widthDp: Float, heightDp: Float): Float {
        val short = minOf(widthDp, heightDp)
        return (short * 0.82f).coerceIn(MIN_WHEEL_DP, maxOf(MIN_WHEEL_DP, minOf(MAX_WHEEL_DP, short)))
    }

    /** 宽屏（平板/折叠屏展开 ≥600dp）时内容列收窄居中，避免拉伸失比。 */
    fun contentMaxWidth(widthDp: Float): Float = if (widthDp >= 600f) 560f else widthDp
}
