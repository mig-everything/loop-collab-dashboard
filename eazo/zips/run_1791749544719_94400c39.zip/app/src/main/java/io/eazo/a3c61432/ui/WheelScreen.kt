package io.eazo.a3c61432.ui

import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eazo.luckywheel.data.PRIZES
import io.eazo.a3c61432.core.NavEvent
import io.eazo.a3c61432.core.NavState
import io.eazo.a3c61432.core.PhaseEvent
import io.eazo.a3c61432.core.SpinPhase
import io.eazo.a3c61432.core.WheelCore
import io.eazo.a3c61432.core.WheelUiState
import io.eazo.a3c61432.core.nextNav
import io.eazo.a3c61432.core.nextPhase
import io.eazo.a3c61432.model.DrawRecord
import io.eazo.a3c61432.platform.AppRepo
import kotlin.math.cos
import kotlin.math.sin

// ============ 配色（展示态，与奖品池 sector 色区分的界面基色） ============
internal val PaletteBg = Color(0xFF17122E)
internal val PaletteSurface = Color(0xFF241C46)
internal val PaletteGold = Color(0xFFFFC83D)
internal val PaletteDeepGold = Color(0xFF3A2A00)
internal val PaletteTextDim = Color(0xFFB9B4D6)

internal fun hexToColor(hex: String): Color = Color(0xFF000000L or hex.removePrefix("#").toLong(16))

/** 展示态辅助：按扇区底色亮度选标签字色（浅底深字/深底白字）。 */
internal fun labelColorOn(hex: String): Color {
    val c = hexToColor(hex)
    return if (0.299f * c.red + 0.587f * c.green + 0.114f * c.blue > 0.62f) PaletteDeepGold else Color.White
}

/**
 * 根组件：内存态唯一入口 AppRepo.getRepo（硬规则 ①）；导航/相位走契约 §2.5 状态机。
 */
@Composable
fun LuckyWheelApp(activity: ComponentActivity) {
    val repo = remember { AppRepo.getRepo(activity) }
    var ui by remember { mutableStateOf(WheelUiState()) }
    var history by remember { mutableStateOf<List<DrawRecord>>(emptyList()) }
    var lastRecord by remember { mutableStateOf<DrawRecord?>(null) }
    LaunchedEffect(Unit) { history = repo.list() }

    val onSpin: () -> Unit = {
        if (ui.phase != SpinPhase.SPINNING) { // C13：动画期间重复点击被忽略
            val rec = repo.spin() // 原子推进 serial + 落历史（C14：弹窗出现前已记录）
            lastRecord = rec
            ui = nextPhase(ui, PhaseEvent.Spin(rec.serial))
            history = repo.list()
        }
    }
    val openHistory = {
        ui = nextNav(ui, NavEvent.OPEN_HISTORY).first
        history = repo.list()
    }
    val backToWheel = { ui = nextNav(ui, NavEvent.BACK).first }
    val doReset = {
        repo.reset() // 原子：清历史 + serial 归 1（契约 §2.5 reset）
        ui = nextPhase(ui, PhaseEvent.Reset)
        history = repo.list()
        lastRecord = null
    }

    BackHandler(enabled = ui.nav == NavState.HISTORY) { backToWheel() }

    when (ui.nav) {
        NavState.WHEEL -> WheelPage(
            ui = ui,
            historySize = history.size,
            onSpin = onSpin,
            onOpenHistory = openHistory,
            onSettled = { idx -> ui = nextPhase(ui, PhaseEvent.Settled(idx)) },
        )
        NavState.HISTORY -> HistoryPage(history = history, onBack = backToWheel, onReset = doReset)
    }

    if (ui.nav == NavState.WHEEL && ui.phase == SpinPhase.RESULT && ui.resultIndex >= 0) {
        ResultDialog(
            record = lastRecord,
            prizeIndex = ui.resultIndex,
            onAgain = onSpin,
            onClose = { ui = nextPhase(ui, PhaseEvent.CloseResult) },
        )
    }
}

@Composable
private fun WheelPage(
    ui: WheelUiState,
    historySize: Int,
    onSpin: () -> Unit,
    onOpenHistory: () -> Unit,
    onSettled: (Int) -> Unit,
) {
    val spinning = ui.phase == SpinPhase.SPINNING
    val rotation = remember { Animatable(0f) }

    // 旋转动画（展示态）：到停位角后发 settled——相位在动画期间锁 SPINNING（C13）
    LaunchedEffect(ui) {
        if (ui.phase == SpinPhase.SPINNING && ui.targetIndex >= 0) {
            val target = WheelCore.targetRotation(rotation.value, ui.targetIndex)
            rotation.animateTo(
                targetValue = target,
                animationSpec = tween(durationMillis = 3600, easing = CubicBezierEasing(0.12f, 0.72f, 0.16f, 1f)),
            )
            onSettled(ui.targetIndex)
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(PaletteBg)
            .statusBarsPadding(),
    ) {
        val wheelDp = LayoutLogic.wheelDiameter(maxWidth.value, maxHeight.value)
        val contentMax = LayoutLogic.contentMaxWidth(maxWidth.value).dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = contentMax)
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 14.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("幸运大转盘", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Lucky Wheel · 幸运8格", color = PaletteGold, fontSize = 12.sp)
                }
                Surface(shape = RoundedCornerShape(50), color = PaletteGold.copy(alpha = 0.16f)) {
                    Text(
                        "已抽 $historySize 次",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        color = PaletteGold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            Box(modifier = Modifier.size(wheelDp.dp), contentAlignment = Alignment.Center) {
                WheelCanvas(rotationValue = rotation.value, modifier = Modifier.fillMaxSize())
                PointerOverlay(modifier = Modifier.fillMaxSize())
                HubButton(spinning = spinning, onSpin = onSpin, modifier = Modifier.size(86.dp))
            }

            Spacer(Modifier.height(22.dp))

            Button(
                onClick = onSpin,
                enabled = !spinning,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(27.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PaletteGold,
                    contentColor = PaletteDeepGold,
                    disabledContainerColor = Color(0xFF494258),
                    disabledContentColor = Color(0xFFC9C4DD),
                ),
            ) {
                if (spinning) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFFC9C4DD))
                    Spacer(Modifier.size(10.dp))
                    Text("转盘旋转中…", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                } else {
                    Text("立即抽奖", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                }
            }

            Spacer(Modifier.height(12.dp))

            TextButton(onClick = onOpenHistory) {
                Text("中奖历史（$historySize）", color = PaletteGold, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

/** 转盘本体：8 扇区 + 分隔线 + 灯珠外圈 + 径向奖品标签（扇区 i = 12 点钟起顺时针第 i+1 格）。 */
@Composable
private fun WheelCanvas(rotationValue: Float, modifier: Modifier) {
    val measurer = rememberTextMeasurer()
    val labelCache = remember { arrayOfNulls<TextLayoutResult?>(PRIZES.size) }
    val subCache = remember { arrayOfNulls<TextLayoutResult?>(PRIZES.size) }

    Canvas(modifier = modifier.rotate(rotationValue)) {
        val r = size.minDimension / 2f
        val cx = center.x
        val cy = center.y
        val sector = 360f / PRIZES.size

        PRIZES.forEachIndexed { i, prize ->
            drawArc(
                color = hexToColor(prize.color),
                startAngle = -90f + i * sector,
                sweepAngle = sector,
                useCenter = true,
            )
        }
        // 扇区分隔线
        for (i in PRIZES.indices) {
            rotate(degrees = -90f + i * sector, pivot = center) {
                drawLine(
                    color = Color.White.copy(alpha = 0.9f),
                    start = Offset(cx, cy),
                    end = Offset(cx + r, cy),
                    strokeWidth = 2.dp.toPx(),
                )
            }
        }
        // 双层描边外圈
        drawCircle(PaletteGold, radius = r - 2.dp.toPx(), style = Stroke(width = 6.dp.toPx()))
        drawCircle(Color.White, radius = r - 9.dp.toPx(), style = Stroke(width = 1.5.dp.toPx()))
        // 外圈灯珠（扇区交界处）
        for (i in PRIZES.indices) {
            val ang = Math.toRadians((-90f + i * sector).toDouble())
            drawCircle(
                color = Color.White.copy(alpha = 0.95f),
                radius = 2.6.dp.toPx(),
                center = Offset(
                    cx + (r - 6.dp.toPx()) * cos(ang).toFloat(),
                    cy + (r - 6.dp.toPx()) * sin(ang).toFloat(),
                ),
            )
        }
        // 径向标签：name 按 U+00B7 拆主/副两行贴扇区角平分线
        PRIZES.forEachIndexed { i, prize ->
            val parts = prize.name.split("·")
            val styleMain = TextStyle(color = labelColorOn(prize.color), fontSize = 13.sp, fontWeight = FontWeight.Bold)
            if (labelCache[i] == null) {
                labelCache[i] = measurer.measure(parts.last(), styleMain)
            }
            if (parts.size > 1 && subCache[i] == null) {
                subCache[i] = measurer.measure(
                    parts.first(),
                    styleMain.copy(fontSize = 11.sp, fontWeight = FontWeight.SemiBold),
                )
            }
            val main = labelCache[i]!!
            val sub = subCache[i]
            rotate(degrees = -90f + i * sector + sector / 2f, pivot = center) {
                if (sub != null) {
                    drawText(sub, topLeft = Offset(cx - sub.size.width / 2f, cy - r * 0.97f))
                    drawText(main, topLeft = Offset(cx - main.size.width / 2f, cy - r * 0.97f + 15.dp.toPx()))
                } else {
                    drawText(main, topLeft = Offset(cx - main.size.width / 2f, cy - r * 0.90f))
                }
            }
        }
        // 中心毂底座
        drawCircle(Color.White, radius = 46.dp.toPx())
        drawCircle(PaletteGold, radius = 46.dp.toPx(), style = Stroke(width = 3.dp.toPx()))
    }
}

/** 顶部指针（固定不随转盘旋转，展示态）。 */
@Composable
private fun PointerOverlay(modifier: Modifier) {
    Canvas(modifier = modifier) {
        val half = 20.dp.toPx()
        val tip = 30.dp.toPx()
        val cx = size.width / 2f
        val path = Path().apply {
            moveTo(cx - half, 2.dp.toPx())
            lineTo(cx + half, 2.dp.toPx())
            lineTo(cx, tip)
            close()
        }
        drawPath(path, color = PaletteGold)
        drawPath(path, color = Color.White, style = Stroke(width = 2.dp.toPx()))
    }
}

/** 中心 GO 按钮（与底部按钮同为抽奖入口，spinning 期间禁用）。 */
@Composable
private fun HubButton(spinning: Boolean, onSpin: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        onClick = onSpin,
        enabled = !spinning,
        modifier = modifier,
        shape = CircleShape,
        color = Color.White,
        border = BorderStroke(3.dp, PaletteGold),
        shadowElevation = 10.dp,
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (spinning) {
                CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 3.dp, color = PaletteGold)
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("GO", color = PaletteGold, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text("抽奖", color = PaletteTextDim, fontSize = 11.sp)
                }
            }
        }
    }
}

/** 中奖结果弹窗（wheel 页覆盖层，非独立页——契约 §2.5）。 */
@Composable
private fun ResultDialog(
    record: DrawRecord?,
    prizeIndex: Int,
    onAgain: () -> Unit,
    onClose: () -> Unit,
) {
    val prize = PRIZES[prizeIndex.coerceIn(0, PRIZES.size - 1)]
    val isThanks = prize.id == "P08"
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = PaletteSurface,
        title = {
            Text(
                if (isThanks) "差一点就中了！" else "🎉 恭喜中奖",
                color = if (isThanks) PaletteTextDim else PaletteGold,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp,
            )
        },
        text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .background(hexToColor(prize.color), CircleShape)
                        .border(BorderStroke(2.dp, Color.White.copy(alpha = 0.7f)), CircleShape),
                )
                Spacer(Modifier.size(14.dp))
                Column {
                    Text(prize.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    if (record != null) {
                        Text("第 ${record.serial} 次抽奖", color = PaletteTextDim, fontSize = 13.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onAgain,
                colors = ButtonDefaults.buttonColors(containerColor = PaletteGold, contentColor = PaletteDeepGold),
            ) { Text("再来一次", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onClose) { Text("知道了", color = PaletteTextDim) }
        },
    )
}
