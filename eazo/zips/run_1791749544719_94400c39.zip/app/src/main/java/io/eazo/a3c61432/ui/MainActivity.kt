package io.eazo.a3c61432.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import io.eazo.a3c61432.platform.AppRepo

/**
 * 骨架模板主界面：单 Activity + Jetpack Compose（UI 锁死声明式——与鸿蒙 ArkUI
 * 声明式对称，禁止 XML 布局/drawable 扇出；图标用 material-icons，主题用
 * Compose MaterialTheme）。
 *
 * 会话只替换 Screen 内容实现本需求 UI；硬规则 ②：onResume 只 refresh()
 * （重读内存态），禁止从持久化 load()。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Screen(this@MainActivity)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(this).refresh()
    }
}

/** 骨架默认主题（REQ-020 会话改配色：节日暗紫 + 鎏金主色，不另建 XML 主题）。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = PaletteGold,
            onPrimary = PaletteDeepGold,
            secondary = Color(0xFFFF8C42),
            background = PaletteBg,
            onBackground = Color.White,
            surface = PaletteSurface,
            onSurface = Color.White,
        ),
        content = content,
    )
}

/** REQ-020 首屏：抽奖转盘（导航/相位由 LuckyWheelApp 内状态机驱动）。 */
@Composable
private fun Screen(activity: ComponentActivity) {
    LuckyWheelApp(activity = activity)
}
