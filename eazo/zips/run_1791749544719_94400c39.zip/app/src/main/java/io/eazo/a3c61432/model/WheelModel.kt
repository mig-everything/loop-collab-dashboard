package io.eazo.a3c61432.model

/**
 * REQ-020 中奖历史条目（契约 §1.1 DrawRecord + §4.3 序列化）。
 * 字段与鸿蒙 1:1：serial（1 基序号）/prizeIndex（扇区号）/prizeId/name/timeMillis；
 * timeMillis 由 platform 层落戳（core/data 层禁时钟，D8）。
 */
data class DrawRecord(
    val serial: Int,
    val prizeIndex: Int,
    val prizeId: String,
    val name: String,
    val timeMillis: Long,
) {
    /** 持久化行（platform 层 Store 读写）：serial|prizeIndex|prizeId|name|timeMillis。 */
    fun toStoreLine(): String = "$serial|$prizeIndex|$prizeId|$name|$timeMillis"

    /** 契约对账形式（§4.3）：serial:prizeId，如 "1:P06"。 */
    fun toContractForm(): String = "$serial:$prizeId"

    companion object {
        fun fromStoreLine(line: String): DrawRecord? {
            val p = line.split("|")
            if (p.size != 5) return null
            val serial = p[0].toIntOrNull() ?: return null
            val prizeIndex = p[1].toIntOrNull() ?: return null
            val time = p[4].toLongOrNull() ?: return null
            if (serial < 1 || prizeIndex !in 0..7 || p[2].isEmpty() || p[3].isEmpty()) return null
            return DrawRecord(serial, prizeIndex, p[2], p[3], time)
        }
    }
}

/** 历史列表契约序列化（§4.3）：serial:prizeId 逐行 LF 连接（对账辅助，非哈希锁）。 */
fun List<DrawRecord>.toContractForm(): String = joinToString("\n") { it.toContractForm() }
