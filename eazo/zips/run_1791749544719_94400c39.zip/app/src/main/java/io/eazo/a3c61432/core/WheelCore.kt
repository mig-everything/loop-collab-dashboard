package io.eazo.a3c61432.core

import com.eazo.luckywheel.data.CUMULATIVE
import com.eazo.luckywheel.data.PRIZES
import com.eazo.luckywheel.data.SEED
import com.eazo.luckywheel.data.TOTAL_WEIGHT

/**
 * REQ-020 确定性核心（契约 §2，对账主战场）：
 * 纯函数族，禁 IO/网络/随机/时钟/UI API（D8 静态检查口径）。
 * 位型与取模语义逐行对齐契约——Int 承载 uint32 位型，选取取模必须 Long 域。
 */
object WheelCore {

    /** xorshift32（§2.1）：Marsagla 三异或对 13/17/5，Int 位型天然 32 位域。 */
    fun nextU32(state: Int): Int {
        var x = state
        x = x xor (x shl 13)
        x = x xor (x ushr 17)
        x = x xor (x shl 5)
        return x
    }

    /** 带权选取（§2.2）：整数取模（禁浮点归一化）+ 严格大于；Kotlin 必须 Long 域取模（V5）。 */
    fun weightedIndex(u32: Int, cumulative: IntArray = CUMULATIVE): Int {
        val r = ((u32.toLong() and 0xFFFFFFFFL) % TOTAL_WEIGHT).toInt()
        for (k in cumulative.indices) {
            if (cumulative[k] > r) return k
        }
        return cumulative.size - 1 // 不可达（末项 == TOTAL_WEIGHT > r 恒真）
    }

    /** 第 serial 次抽奖（§2.3）：serial 1 基，从 seed 推进 serial 次后带权选取，幂等。 */
    fun drawIndex(seed: Int = SEED, serial: Int): Int {
        var state = seed
        for (k in 1..serial) {
            state = nextU32(state)
        }
        return weightedIndex(state)
    }

    /** 转盘停位角（§2.4 展示层，唯一允许浮点）：第 index 扇区中心对齐顶部指针。 */
    fun angleForIndex(index: Int, count: Int = 8, fullSpins: Int = 5): Float {
        val sector = 360.0f / count
        val center = index * sector + sector / 2.0f
        return fullSpins * 360.0f + ((360.0f - center) % 360.0f)
    }

    /** 展示层辅助：angleForIndex 的逆映射——给定旋转角求指针所指扇区。 */
    fun sectorAtPointer(rotation: Float, count: Int = 8): Int {
        val sector = 360.0f / count
        val fromTop = (360.0f - (rotation % 360.0f) + 360.0f) % 360.0f
        return (fromTop / sector).toInt()
    }

    /** 展示层辅助：从当前旋转角到 index 停位角的前进目标（保证正向多圈旋转）。 */
    fun targetRotation(current: Float, index: Int, fullSpins: Int = 5): Float {
        val forward = fullSpins * 360.0f - 360.0f
        val mod = ((angleForIndex(index) % 360.0f) - (current % 360.0f) + 720.0f) % 360.0f
        return current + forward + mod
    }

    /** 奖品池规范序列化（§4.1）：id|name|weight|color，id 升序 LF 连接、行尾无换行。 */
    fun serializePrizes(): String =
        PRIZES.sortedBy { it.id }.joinToString("\n") { "${it.id}|${it.name}|${it.weight}|${it.color}" }
}
