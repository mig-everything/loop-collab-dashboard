package io.eazo.counter.core

import io.eazo.counter.model.CounterSnapshot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 点击计数器契约单测（Android 侧，JUnit）——与鸿蒙侧同集断言（生成器硬规则 ③ 双端 1:1）。
 *
 * 覆盖面：
 * - 需求主链路：「+1」数字加一 / 「清零」回到 0（含连续点击、清零后再 +1）；
 * - 读档防御：损坏负值回落 0；
 * - ★ 规则 ④ 严格布尔锚点：openReset 仅 Boolean true 判真，字符串 "true"/"1"、数字 1 一律拒绝；
 * - ★ 规则 ①/② 结构性自检：仓储写后内存态即时可见、同 store 重建等价冷启动、无公开 load/reload 出口；
 * - 常量锁死：INITIAL_COUNT=0 / STEP=1 / OPEN_PARAM_RESET="openReset"。
 */
class CounterContractTest {

    // ---------- 需求主链路（纯函数） ----------

    @Test fun `us1_increment_from_zero`() {
        assertEquals(1, CounterLogic.increment(0))            // 初始 0，点一次「+1」→ 1
    }

    @Test fun `us1_increment_accumulates`() {
        var c = 0
        assertEquals(1, CounterLogic.increment(c).also { c = it })
        assertEquals(2, CounterLogic.increment(c).also { c = it })
        assertEquals(3, CounterLogic.increment(c).also { c = it })
    }

    @Test fun `us2_reset_returns_zero_from_any`() {
        assertEquals(0, CounterLogic.reset())
        assertEquals(0, CounterLogic.reset().let { CounterLogic.reset() })
    }

    @Test fun `us2_reset_then_increment_restart`() {
        val afterReset = CounterLogic.reset()                 // 清零 → 0
        assertEquals(1, CounterLogic.increment(afterReset))   // 再点「+1」→ 1（重新计数）
    }

    // ---------- 读档防御 ----------

    @Test fun `sanitize_negative_falls_back_to_zero`() {
        assertEquals(0, CounterLogic.sanitize(-1))
        assertEquals(0, CounterLogic.sanitize(-100))
    }

    @Test fun `sanitize_keeps_valid_values`() {
        assertEquals(0, CounterLogic.sanitize(0))
        assertEquals(7, CounterLogic.sanitize(7))
        assertEquals(12345, CounterLogic.sanitize(12345))
    }

    // ---------- ★ 规则 ④：严格布尔判定（openReset） ----------

    @Test fun `r4_strictTrue_only_boolean_true`() {
        assertTrue(CounterLogic.strictTrue(true))
        assertFalse(CounterLogic.strictTrue(false))
        assertFalse(CounterLogic.strictTrue("true"))   // 字符串 'true' 拒绝
        assertFalse(CounterLogic.strictTrue("1"))      // 字符串 '1' 拒绝
        assertFalse(CounterLogic.strictTrue(1))        // 数字 1 拒绝
        assertFalse(CounterLogic.strictTrue(1.0))      // 数字 1.0 拒绝
        assertFalse(CounterLogic.strictTrue(0))
        assertFalse(CounterLogic.strictTrue(null))
    }

    @Test fun `r4_openReset_same_semantics_as_strictTrue`() {
        assertTrue(CounterLogic.openReset(true))
        assertFalse(CounterLogic.openReset("true"))
        assertFalse(CounterLogic.openReset(1))
        assertFalse(CounterLogic.openReset(null))
    }

    // ---------- 仓储行为（MemStore 注入；规则 ①/② 落点） ----------

    private class MemStore(var value: Int = 0) : CounterStore {
        override fun loadCount(): Int = value
        override fun saveCount(count: Int) { value = count }
    }

    @Test fun `repo_increment_updates_memory_and_persists`() {
        val store = MemStore(0)
        val repo = CounterRepository(store)
        assertEquals(CounterSnapshot(1), repo.increment())
        assertEquals(CounterSnapshot(2), repo.increment())
        assertEquals(2, store.value)                   // 写后已落盘
        assertEquals(CounterSnapshot(2), repo.snapshot())   // ★ 规则②：内存态即时可见
    }

    @Test fun `repo_reset_updates_memory_and_persists`() {
        val store = MemStore(0)
        val repo = CounterRepository(store)
        repo.increment(); repo.increment(); repo.increment()
        assertEquals(CounterSnapshot(0), repo.reset())
        assertEquals(0, store.value)
        assertEquals(CounterSnapshot(0), repo.snapshot())
    }

    @Test fun `repo_construct_loads_persisted_count_once`() {
        val store = MemStore(41)
        val repo = CounterRepository(store)
        assertEquals(CounterSnapshot(41), repo.snapshot())   // 冷启动：构造时一次性读档
        assertEquals(CounterSnapshot(42), repo.increment())
    }

    @Test fun `repo_construct_sanitizes_corrupt_value`() {
        val repo = CounterRepository(MemStore(-9))           // 损坏负值 → 回落 0
        assertEquals(CounterSnapshot(0), repo.snapshot())
    }

    @Test fun `repo_rebuild_from_same_store_equals_cold_restart`() {
        val store = MemStore(0)
        val first = CounterRepository(store)
        first.increment(); first.increment(); first.increment()
        val second = CounterRepository(store)                // 模拟进程被杀后冷启动重建
        assertEquals(CounterSnapshot(3), second.snapshot())  // 落盘值经同 store 复原
    }

    // ---------- ★ 规则 ② 结构性自检：仓储无公开 load/reload 出口 ----------

    @Test fun `r2_repository_has_no_public_load_or_reload`() {
        val forbidden = CounterRepository::class.java.methods
            .map { it.name }
            .filter { it == "load" || it == "reload" || it.startsWith("load") }
        assertEquals(emptyList<String>(), forbidden)   // 页面层无从触持久化重载
    }

    // ---------- 常量锁死（双端 1:1 锚点） ----------

    @Test fun `constants_locked`() {
        assertEquals(0, CounterConstants.INITIAL_COUNT)
        assertEquals(1, CounterConstants.STEP)
        assertEquals("openReset", CounterConstants.OPEN_PARAM_RESET)
    }
}
