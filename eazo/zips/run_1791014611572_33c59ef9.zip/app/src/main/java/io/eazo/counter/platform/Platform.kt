package io.eazo.counter.platform

import android.content.Context
import android.content.SharedPreferences
import io.eazo.counter.core.CounterConstants
import io.eazo.counter.core.CounterRepository
import io.eazo.counter.core.CounterStore

/**
 * SharedPreferences 持久化（与鸿蒙 PreferencesStore 1:1，存储键双端一致）：
 * prefs 文件 "counter"，键 "counter_count"（int）。损坏数据不崩溃（try/catch → 初始值）。
 */
class PreferencesStore(context: Context) : CounterStore {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("counter", Context.MODE_PRIVATE)

    override fun loadCount(): Int =
        try {
            prefs.getInt(KEY, CounterConstants.INITIAL_COUNT)
        } catch (e: Exception) {
            CounterConstants.INITIAL_COUNT   // 键被改成非 int 等损坏场景：回落初始值，不崩溃
        }

    override fun saveCount(count: Int) {
        prefs.edit().putInt(KEY, count).apply()
    }

    companion object {
        private const val KEY = "counter_count"
    }
}

/**
 * ★ 进程内单例仓储入口（生成器硬规则 ① / IPD-39 修复口径）：
 * UI 与卡片层**禁止** `CounterRepository(...)` 直构，一律 `AppRepo.getRepo(context)`。
 * @Volatile 双检锁——全进程共享同一内存态，是「写后即时可见」的前提。
 */
object AppRepo {
    @Volatile
    private var repo: CounterRepository? = null

    fun getRepo(context: Context): CounterRepository =
        repo ?: synchronized(this) {
            repo ?: CounterRepository(PreferencesStore(context.applicationContext)).also { repo = it }
        }
}
