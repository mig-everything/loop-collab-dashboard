package io.eazo.counter.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.counter.R
import io.eazo.counter.core.CounterConstants
import io.eazo.counter.core.CounterLogic
import io.eazo.counter.platform.AppRepo

/**
 * 点击计数器主界面（极简）：页面中央大数字 + 「+1」/「清零」。
 *
 * ★ 生成器硬规则 ④（两路路由）：冷启动 onCreate(intent) 与热启动 onNewIntent(intent)
 *   （鸿蒙 onCreate(want)/onNewWant(want)）都只做一件事——取原始参数值
 *   `intent.extras?.get("openReset")`，同走纯函数 CounterLogic.openReset（严格布尔）。
 *   launchMode=singleTask 保证重入拉起走 onNewIntent 热启动路径；
 *   两路都从「当前 intent」读取，不依赖上一次生命周期残留成员变量（竞态防护）。
 * ★ 生成器硬规则 ②：onResume 只 refreshFromRepo()（重读单例内存态），绝不触持久化 load。
 * ★ 生成器硬规则 ①：仓储一律 AppRepo.getRepo(this)，全类 0 处 new CounterRepository。
 */
class MainActivity : ComponentActivity() {

    private var count by mutableStateOf(CounterConstants.INITIAL_COUNT)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        routeFromWant(intent)                     // ★ 冷启动路径
        setContent { CounterScreen() }
    }

    override fun onNewIntent(intent: Intent) {    // ★ 热启动路径（singleTask 重入）
        super.onNewIntent(intent)
        setIntent(intent)
        routeFromWant(intent)
    }

    /** 冷/热启动共用：原始参数值 → openReset 纯函数（规则 ④ 唯一入口，严格 === true 判定）。 */
    private fun routeFromWant(intent: Intent?) {
        val raw = intent?.extras?.get(CounterConstants.OPEN_PARAM_RESET)
        if (CounterLogic.openReset(raw)) {
            AppRepo.getRepo(this).reset()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshFromRepo()                         // ★ 规则②：仅重读内存态
    }

    /** refresh 出口（规则②）：单例内存读，无任何持久化 load。 */
    private fun refreshFromRepo() {
        count = AppRepo.getRepo(this).snapshot().count
    }

    private fun onIncrement() {
        AppRepo.getRepo(this).increment()         // ★ 规则①：单例写
        refreshFromRepo()
    }

    private fun onReset() {
        AppRepo.getRepo(this).reset()             // ★ 规则①：单例写
        refreshFromRepo()
    }

    @Composable
    fun CounterScreen() {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF6F8FB))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // 页面中央大数字（需求 SC1）
            Text(
                count.toString(),
                fontSize = 112.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFF1A2340)
            )
            Spacer(Modifier.height(44.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(
                    onClick = { onIncrement() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B6FE0))
                ) { Text(getString(R.string.button_plus), fontSize = 20.sp) }
                OutlinedButton(onClick = { onReset() }) {
                    Text(getString(R.string.button_reset), fontSize = 20.sp, color = Color(0xFF5A6B85))
                }
            }
        }
    }
}
