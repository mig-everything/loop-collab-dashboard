package io.eazo.counter.core

import io.eazo.counter.model.CounterSnapshot

/** 持久化端口（测试可注入内存实现）。 */
interface CounterStore {
    fun loadCount(): Int
    fun saveCount(count: Int)
}

/**
 * 点击计数器状态仓储（与鸿蒙 CounterRepository.ets 1:1）。
 *
 * ★ 生成器硬规则 ①：进程内单例——UI 层禁止 `CounterRepository(...)` 直构，
 *   一律经 platform/AppRepo.getRepo(context) 获取（双检锁缓存，全进程共享同一内存态）。
 * ★ 生成器硬规则 ②：构造时一次性读档，此后全内存读写；
 *   **无公开 load/reload 出口**（结构性自检见 CounterContractTest），
 *   页面 onResume/onPageShow 只能经 snapshot() 重读内存态。
 */
class CounterRepository(private val store: CounterStore) {

    private var count: Int = CounterLogic.sanitize(store.loadCount())

    /** 读当前值（规则 ②：内存态读，无持久化 load）。 */
    fun snapshot(): CounterSnapshot = CounterSnapshot(count)

    /** 「+1」写入口：更新内存态并落盘。 */
    fun increment(): CounterSnapshot {
        count = CounterLogic.increment(count)
        store.saveCount(count)
        return snapshot()
    }

    /** 「清零」写入口：回到 INITIAL_COUNT 并落盘。 */
    fun reset(): CounterSnapshot {
        count = CounterLogic.reset()
        store.saveCount(count)
        return snapshot()
    }
}
