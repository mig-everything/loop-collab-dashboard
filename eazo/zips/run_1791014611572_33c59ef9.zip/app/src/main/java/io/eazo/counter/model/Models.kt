package io.eazo.counter.model

/**
 * 点击计数器数据模型（与鸿蒙 model/Models.ets 1:1，生成器硬规则 ③）。
 * 字段名 / 类型 / 默认值 / 校验规则双端完全一致，仅语言语法不同。
 */

/** 计数器状态快照（唯一状态载体；count 为非负整数，默认 0）。 */
data class CounterSnapshot(
    val count: Int = 0
)
