package io.eazo.counter.core

/**
 * 点击计数器纯函数（与鸿蒙 CounterLogic.ets 逐行等价，生成器硬规则 ③）。
 * core 无系统时间 / random / 网络依赖；对任意输入不抛异常。
 */
object CounterLogic {

    /** 「+1」：count + STEP（US-1）。 */
    fun increment(count: Int): Int = count + CounterConstants.STEP

    /** 「清零」：恒返 INITIAL_COUNT（US-2）。 */
    fun reset(): Int = CounterConstants.INITIAL_COUNT

    /** 读档防御（契约校验规则 1:1）：负数等损坏值回落 INITIAL_COUNT，合法值原样保留。 */
    fun sanitize(raw: Int): Int = if (raw < CounterConstants.INITIAL_COUNT) CounterConstants.INITIAL_COUNT else raw

    // ---------- 生成器硬规则 ④（冷/热启动同源路由） ----------

    /** ★ 严格布尔判定（附则口径）：仅 Boolean true 为真；字符串 "true"/"1"、数字 1、null 一律拒绝。 */
    fun strictTrue(v: Any?): Boolean = v is Boolean && v == true

    /** 冷启动 onCreate(intent) 与热启动 onNewIntent(intent)（鸿蒙 onNewWant(want)）两路同源。 */
    fun openReset(rawOpenReset: Any?): Boolean = strictTrue(rawOpenReset)
}
