package io.eazo.counter.core

/**
 * 点击计数器常量集中（与鸿蒙 CounterConstants.ets 同值 1:1，生成器硬规则 ③）。
 * 单测 constants_locked 锁死取值，双端改值必须同步改锚点。
 */
object CounterConstants {
    /** 初始值 = 清零落点（需求：「清零」回到 0）。 */
    const val INITIAL_COUNT: Int = 0
    /** 「+1」步长（需求：点击 +1 数字加一）。 */
    const val STEP: Int = 1
    /** 生成器硬规则 ④ intent/want 布尔参数名（双端同字面量；严格布尔判定）。 */
    const val OPEN_PARAM_RESET: String = "openReset"
}
