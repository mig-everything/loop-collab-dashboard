package io.eazo.todolist.model

/**
 * 待办优先级（AC5.1）：高/中/低，默认 MEDIUM。
 * ordinal 用于排序：HIGH=0, MEDIUM=1, LOW=2（升序 = 高在前），与鸿蒙 TodoPriority 1:1。
 */
enum class TodoPriority(val displayName: String) {
    HIGH("高"),
    MEDIUM("中"),
    LOW("低")
}
