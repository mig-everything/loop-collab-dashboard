package io.eazo.todolist.core

import io.eazo.todolist.model.Todo

/**
 * 持久化接口（契约 02 §3）。全量 JSON 序列化，双端仅存储实现不同。
 */
interface TodoStore {
    fun load(): List<Todo>
    fun save(todos: List<Todo>)
}
