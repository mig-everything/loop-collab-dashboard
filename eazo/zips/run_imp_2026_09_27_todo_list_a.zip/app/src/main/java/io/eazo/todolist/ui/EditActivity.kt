package io.eazo.todolist.ui

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import io.eazo.todolist.core.CreateResult
import io.eazo.todolist.model.Todo
import io.eazo.todolist.model.TodoPriority
import io.eazo.todolist.platform.AppRepo

/**
 * 新建 / 编辑待办（US-1 快速新建 / US-4 编辑与删除 / US-5 优先级与分类）。
 */
class EditActivity : Activity() {

    companion object {
        const val EXTRA_ID = "todo_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = AppRepo.get(this)
        val id = intent.getStringExtra(EXTRA_ID)
        val existing: Todo? = id?.let { repo.getById(it) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 72, 32, 32)
        }

        root.addView(
            TextView(this).apply {
                text = if (existing == null) "新建待办" else "编辑待办"
                textSize = 24f
                gravity = Gravity.CENTER
            }
        )

        val input = EditText(this).apply {
            hint = "待办标题（1~200 字）"
            textSize = 17f
            setText(existing?.title ?: "")
        }
        root.addView(input)

        // 优先级（US-5 / AC5.1）
        root.addView(
            TextView(this).apply { text = "优先级"; textSize = 15f }
        )
        var selectedPriority = existing?.priority ?: TodoPriority.MEDIUM
        val priRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val priButtons = mutableMapOf<TodoPriority, Button>()
        for (p in TodoPriority.entries) {
            priButtons[p] = Button(this).apply {
                text = p.displayName
                setOnClickListener {
                    selectedPriority = p
                    highlightPri(priButtons, p)
                }
            }
            priRow.addView(priButtons[p])
        }
        root.addView(priRow)

        // 分类（US-5 / AC5.2）
        root.addView(
            TextView(this).apply { text = "分类"; textSize = 15f }
        )
        val catInput = EditText(this).apply {
            hint = "默认分类"
            textSize = 16f
            setText(existing?.category ?: "")
        }
        root.addView(catInput)

        val saveBtn = Button(this).apply {
            text = "保存"
            textSize = 17f
            setOnClickListener {
                val titleText = input.text.toString()
                val cat = catInput.text.toString()
                if (existing == null) {
                    when (val r = repo.create(titleText, selectedPriority, cat)) {
                        is CreateResult.Err ->
                            Toast.makeText(
                                this@EditActivity,
                                if (r.reason == "empty") "标题不能为空" else "标题过长（≤200 字）",
                                Toast.LENGTH_SHORT
                            ).show()
                        is CreateResult.Ok -> finish()
                    }
                } else {
                    val updated = repo.update(existing.id, titleText, selectedPriority, cat)
                    if (updated == null) {
                        Toast.makeText(this@EditActivity, "标题不能为空或过长（≤200 字）", Toast.LENGTH_SHORT).show()
                    } else {
                        finish()
                    }
                }
            }
        }
        root.addView(saveBtn)

        if (existing != null) {
            val delBtn = Button(this).apply {
                text = "删除此待办"
                textSize = 16f
                setOnClickListener {
                    repo.remove(existing.id)
                    finish()
                }
            }
            root.addView(delBtn)
        }

        setContentView(root)
        highlightPri(priButtons, selectedPriority)
    }

    private fun highlightPri(buttons: Map<TodoPriority, Button>, selected: TodoPriority) {
        for ((p, b) in buttons) {
            b.setBackgroundColor(
                if (p == selected) android.graphics.Color.parseColor("#3F51B5")
                else android.graphics.Color.parseColor("#E0E0E0")
            )
            b.setTextColor(
                if (p == selected) android.graphics.Color.WHITE
                else android.graphics.Color.BLACK
            )
        }
    }
}
