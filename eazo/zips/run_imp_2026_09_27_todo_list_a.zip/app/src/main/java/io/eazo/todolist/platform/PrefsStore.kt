package io.eazo.todolist.platform

import android.content.Context
import android.content.SharedPreferences
import io.eazo.todolist.core.TodoStore
import io.eazo.todolist.model.Todo
import io.eazo.todolist.model.TodoPriority
import org.json.JSONArray
import org.json.JSONObject

/**
 * SharedPreferences 持久化实现（契约 02 §6）。全量 JSON 序列化，键为 "todos"。
 */
class PrefsStore(context: Context) : TodoStore {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("todos", Context.MODE_PRIVATE)

    override fun load(): List<Todo> {
        val json = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Todo(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    priority = TodoPriority.valueOf(o.getString("priority")),
                    category = o.optString("category", Todo.DEFAULT_CATEGORY),
                    done = o.getBoolean("done"),
                    createdAt = o.getLong("createdAt"),
                    updatedAt = o.getLong("updatedAt")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    override fun save(todos: List<Todo>) {
        val arr = JSONArray()
        todos.forEach { t ->
            arr.put(
                JSONObject().apply {
                    put("id", t.id)
                    put("title", t.title)
                    put("priority", t.priority.name)
                    put("category", t.category)
                    put("done", t.done)
                    put("createdAt", t.createdAt)
                    put("updatedAt", t.updatedAt)
                }
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    companion object {
        private const val KEY = "todos"
    }
}
