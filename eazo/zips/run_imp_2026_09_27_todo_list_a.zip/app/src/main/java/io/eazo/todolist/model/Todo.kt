package io.eazo.todolist.model

/**
 * 待办实体（契约 02 §1）。字段名/默认值与鸿蒙 Todo 1:1。
 */
data class Todo(
    val id: String,
    val title: String,
    val priority: TodoPriority = TodoPriority.MEDIUM,
    val category: String = DEFAULT_CATEGORY,
    val done: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
) {
    companion object {
        const val DEFAULT_CATEGORY = "默认"
    }
}
