package io.eazo.todolist.model

/**
 * 完成状态筛选（AC6.1）：全部 / 未完成 / 已完成。
 */
enum class TodoFilter { ALL, ACTIVE, DONE }
