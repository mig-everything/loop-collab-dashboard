package io.eazo.todolist.platform

import android.content.Context
import io.eazo.todolist.core.TodoRepository

/**
 * 进程内仓储单例（对标鸿蒙 platform/AppRepo.ets 的 getRepo 缓存）：
 * 列表页（MainActivity）与编辑页（EditActivity）共享同一 TodoRepository 实例，
 * 避免「各自 new TodoRepository 导致跨 Activity 状态不同步」的 P0 刷新缺陷（IPD-39）。
 */
object AppRepo {

    @Volatile
    private var repo: TodoRepository? = null

    fun get(context: Context): TodoRepository {
        return repo ?: synchronized(this) {
            repo ?: TodoRepository(PrefsStore(context.applicationContext)).also { repo = it }
        }
    }
}
