package io.eazo.todolist.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import io.eazo.todolist.core.TodoRepository
import io.eazo.todolist.model.Todo
import io.eazo.todolist.model.TodoFilter
import io.eazo.todolist.model.TodoPriority
import io.eazo.todolist.model.TodoSort
import io.eazo.todolist.platform.AppRepo

/**
 * 待办列表（US-2 列表 / US-3 勾选 / US-6 筛选排序）。
 */
class MainActivity : Activity() {

    private lateinit var repo: TodoRepository
    private lateinit var listContainer: LinearLayout
    private var filter: TodoFilter = TodoFilter.ALL
    private var sort: TodoSort = TodoSort.DEFAULT
    private lateinit var sortBtn: Button
    private lateinit var filterButtons: Map<TodoFilter, Button>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = AppRepo.get(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 72, 32, 32)
        }

        val title = TextView(this).apply {
            text = "待办清单"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#1A1A1A"))
        }
        root.addView(title)

        val addBtn = Button(this).apply {
            text = "＋ 新建待办"
            textSize = 17f
            setOnClickListener {
                startActivity(Intent(this@MainActivity, EditActivity::class.java))
            }
        }
        root.addView(addBtn)

        // 筛选行（US-6 / AC6.1）
        val filterRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val fb = HashMap<TodoFilter, Button>()
        val labels = listOf(TodoFilter.ALL to "全部", TodoFilter.ACTIVE to "未完成", TodoFilter.DONE to "已完成")
        for ((f, label) in labels) {
            val b = Button(this).apply {
                text = label
                setOnClickListener {
                    filter = f
                    highlightFilter()
                    refresh()
                }
            }
            fb[f] = b
            filterRow.addView(b)
        }
        filterButtons = fb
        root.addView(filterRow)

        // 排序行（US-6 / AC6.2）
        val sortRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        sortBtn = Button(this).apply {
            text = "排序：默认"
            setOnClickListener {
                sort = if (sort == TodoSort.DEFAULT) TodoSort.PRIORITY else TodoSort.DEFAULT
                text = "排序：${if (sort == TodoSort.DEFAULT) "默认" else "优先级"}"
                refresh()
            }
        }
        sortRow.addView(sortBtn)
        root.addView(sortRow)

        val scroll = ScrollView(this)
        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listContainer)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)
        highlightFilter()
        refresh()
    }

    private fun highlightFilter() {
        for ((f, b) in filterButtons) {
            b.setBackgroundColor(
                if (f == filter) Color.parseColor("#3F51B5") else Color.parseColor("#E0E0E0")
            )
            b.setTextColor(if (f == filter) Color.WHITE else Color.BLACK)
        }
    }

    private fun refresh() {
        listContainer.removeAllViews()
        val todos = repo.list(filter, sort)
        if (todos.isEmpty()) {
            listContainer.addView(
                TextView(this).apply {
                    text = "暂无待办\n点击「新建待办」开始记录"
                    textSize = 16f
                    gravity = Gravity.CENTER
                    setPadding(0, 96, 0, 96)
                    setTextColor(Color.parseColor("#9E9E9E"))
                }
            )
            return
        }
        for (todo in todos) {
            listContainer.addView(buildRow(todo))
        }
    }

    private fun buildRow(todo: Todo): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 20, 8, 20)
        }

        val check = CheckBox(this).apply {
            isChecked = todo.done
            setOnClickListener {
                repo.toggle(todo.id)
                refresh()
            }
        }

        val label = TextView(this).apply {
            text = buildText(todo)
            textSize = 17f
            setTextColor(if (todo.done) Color.parseColor("#9E9E9E") else Color.parseColor("#1A1A1A"))
            setOnClickListener {
                val i = Intent(this@MainActivity, EditActivity::class.java)
                i.putExtra(EditActivity.EXTRA_ID, todo.id)
                startActivity(i)
            }
        }

        val del = Button(this).apply {
            text = "删除"
            textSize = 14f
            setOnClickListener {
                repo.remove(todo.id)
                refresh()
            }
        }

        row.addView(
            check,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )
        row.addView(
            label,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        row.addView(del)
        return row
    }

    private fun buildText(todo: Todo): String {
        val mark = if (todo.done) "✓" else "○"
        val pri = when (todo.priority) {
            TodoPriority.HIGH -> "高"
            TodoPriority.MEDIUM -> "中"
            TodoPriority.LOW -> "低"
        }
        return "$mark [$pri·${todo.category}] ${todo.title}"
    }

    override fun onResume() {
        super.onResume()
        if (::repo.isInitialized) refresh()
    }
}
