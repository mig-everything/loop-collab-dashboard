package io.eazo.todolist.core

import io.eazo.todolist.model.Todo
import io.eazo.todolist.model.TodoFilter
import io.eazo.todolist.model.TodoPriority
import io.eazo.todolist.model.TodoSort
import java.util.UUID

/**
 * create 返回值（契约 02 §2）：成功携带 Todo，失败携带原因。
 */
sealed class CreateResult {
    data class Ok(val todo: Todo) : CreateResult()
    data class Err(val reason: String) : CreateResult() // "empty" | "too_long"
}

/**
 * 待办仓储（纯逻辑，无 UI、无平台 API）。持久化通过 TodoStore 注入，时钟可注入便于测试。
 *
 * 确定性契约（契约 02 §4，双端 1:1）：
 * 1. 先 filter 后 sort。
 * 2. sort=DEFAULT：主键 done 升序（未完成在前），次键 createdAt 降序（新建置顶），id 字典序兜底。
 * 3. sort=PRIORITY：主键 priority ordinal 升序（高>中>低），次键 createdAt 降序，id 字典序兜底。
 */
class TodoRepository(
    private val store: TodoStore,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    private val todos: MutableList<Todo> = store.load().toMutableList()

    fun create(
        title: String,
        priority: TodoPriority = TodoPriority.MEDIUM,
        category: String = Todo.DEFAULT_CATEGORY
    ): CreateResult {
        val trimmed = title.trim()
        return when {
            trimmed.isEmpty() -> CreateResult.Err("empty")
            trimmed.length > 200 -> CreateResult.Err("too_long")
            else -> {
                val now = clock()
                val todo = Todo(
                    id = UUID.randomUUID().toString(),
                    title = trimmed,
                    priority = priority,
                    category = category.ifBlank { Todo.DEFAULT_CATEGORY },
                    done = false,
                    createdAt = now,
                    updatedAt = now
                )
                todos.add(todo)
                persist()
                CreateResult.Ok(todo)
            }
        }
    }

    fun update(
        id: String,
        title: String? = null,
        priority: TodoPriority? = null,
        category: String? = null
    ): Todo? {
        val idx = todos.indexOfFirst { it.id == id }
        if (idx < 0) return null
        var t = todos[idx]
        if (title != null) {
            val trimmed = title.trim()
            if (trimmed.isEmpty() || trimmed.length > 200) return null
            t = t.copy(title = trimmed)
        }
        if (priority != null) t = t.copy(priority = priority)
        if (category != null) t = t.copy(category = category.ifBlank { Todo.DEFAULT_CATEGORY })
        t = t.copy(updatedAt = clock())
        todos[idx] = t
        persist()
        return t
    }

    fun remove(id: String): Boolean {
        val before = todos.size
        todos.removeAll { it.id == id }
        val removed = todos.size < before
        if (removed) persist()
        return removed
    }

    fun toggle(id: String): Todo? {
        val idx = todos.indexOfFirst { it.id == id }
        if (idx < 0) return null
        val t = todos[idx].copy(done = !todos[idx].done, updatedAt = clock())
        todos[idx] = t
        persist()
        return t
    }

    fun list(filter: TodoFilter, sort: TodoSort): List<Todo> {
        val filtered = when (filter) {
            TodoFilter.ALL -> todos.toList()
            TodoFilter.ACTIVE -> todos.filter { !it.done }
            TodoFilter.DONE -> todos.filter { it.done }
        }
        return when (sort) {
            TodoSort.DEFAULT -> filtered.sortedWith(
                compareBy<Todo> { it.done }                    // false(未完成) 在前
                    .thenByDescending { it.createdAt }          // 新建在前
                    .thenBy { it.id }                            // id 字典序兜底
            )
            TodoSort.PRIORITY -> filtered.sortedWith(
                compareBy<Todo> { it.priority.ordinal }          // HIGH=0 在前
                    .thenByDescending { it.createdAt }
                    .thenBy { it.id }
            )
        }
    }

    fun getById(id: String): Todo? = todos.find { it.id == id }

    fun all(): List<Todo> = todos.toList()

    private fun persist() {
        store.save(todos.toList())
    }
}
