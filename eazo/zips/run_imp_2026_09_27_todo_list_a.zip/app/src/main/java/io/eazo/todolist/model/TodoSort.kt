package io.eazo.todolist.model

/**
 * 排序方式（AC6.2）：默认（未完成在前 + 新建置顶）/ 按优先级（高>中>低）。
 */
enum class TodoSort { DEFAULT, PRIORITY }
