// Top-level build file. Plugin versions pinned per 工具链锁死口径（jdk21+gradle8.9+agp8.5.2+kotlin1.9.10+compileSdk34，零漂移）。
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.10" apply false
}
