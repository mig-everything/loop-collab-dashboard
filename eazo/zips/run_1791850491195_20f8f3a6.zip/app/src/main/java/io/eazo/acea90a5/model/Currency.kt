package io.eazo.acea90a5.model

/**
 * REQ-024 货币换算器 · 数据面（契约 §1.1 ★冻结，唯一权威）：
 * RATE = 整数 rate×10^6，锚定 CNY 直接标价（1 单位外币 = RATE[code]/10^6 CNY）。
 * 固定顺序 USD/EUR/JPY/CNY/GBP/HKD（需求一句话所列顺序，序列化与 UI 列表均用此序）。
 * 禁手抄派生小数常量（§7.6）；转录纪律由 §4 哈希断言兜底。
 */
object Currency {

    /** §1.1 RATE 表（全偶数——roundHalfUp 分母 b//2 精确前提）。 */
    val RATE: Map<String, Long> = linkedMapOf(
        "USD" to 7_200_000L,
        "EUR" to 7_800_000L,
        "JPY" to 48_000L,
        "CNY" to 1_000_000L,
        "GBP" to 9_100_000L,
        "HKD" to 920_000L,
    )

    /** 固定顺序六币种（C02 锚点：UI 下拉与序列化共用此序）。 */
    val CODES: List<String> = RATE.keys.toList()

    /** CNY 基座 rate（§5.4 结构锚点）。 */
    const val CNY_BASE: Long = 1_000_000L

    /**
     * §4 规范序列化：每行 `code|rate`，固定顺序，LF 连接、行尾无换行、UTF-8。
     * 期望 SHA-256 = 9d7ba769…86f29b，字节数 68（6 行 63B + 5 LF）——测试断言兜底。
     */
    fun serializeRate(): String = RATE.keys.joinToString("\n") { "$it|${RATE[it]}" }
}
