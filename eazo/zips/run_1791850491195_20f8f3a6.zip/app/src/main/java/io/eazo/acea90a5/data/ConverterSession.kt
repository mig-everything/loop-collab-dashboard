package io.eazo.acea90a5.data

import io.eazo.acea90a5.core.ConvertCore
import io.eazo.acea90a5.model.Currency

/**
 * REQ-024 会话单态（契约 §9 data 层）：state(amount_cents, src, dst) + 展示层触发的
 * set/swap。§2.4：swap 只交换 src/dst 引用 + 用当前 amount_cents 重算（走同一
 * convert 纯函数），不承载任何换算逻辑。§2.5：单态联动——任一变化立即重算，
 * result 永远由当前 state 派生，无残留旧值。纯 Kotlin 无 Context，JVM 可测。
 */
class ConverterSession(
    amountCents: Long = ConvertCore.DEFAULT_AMOUNT_CENTS,
    src: String = "USD",
    dst: String = "CNY",
) {
    var amountCents: Long = amountCents
        private set
    var src: String = src
        private set
    var dst: String = dst
        private set

    /** 派生结果（每次读取现算，保证 AC-S4.1 实时无残留）。 */
    val resultCents: Long
        get() = ConvertCore.convert(amountCents, src, dst)

    /** 金额变化（展示层已解析为合法整数分）。 */
    fun setAmount(amountCents: Long) {
        this.amountCents = if (amountCents in 0..ConvertCore.MAX_AMOUNT_CENTS) {
            amountCents
        } else {
            ConvertCore.DEFAULT_AMOUNT_CENTS
        }
    }

    fun setSrc(code: String) {
        if (code in Currency.CODES) src = code
    }

    fun setDst(code: String) {
        if (code in Currency.CODES) dst = code
    }

    /** §2.4 方向反转：仅交换 src/dst 引用（A1↔A8 对偶由同一 convert 兜底）。 */
    fun swap() {
        val t = src
        src = dst
        dst = t
    }
}
