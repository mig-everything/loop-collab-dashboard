package io.eazo.acea90a5.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import io.eazo.acea90a5.core.ConvertCore
import io.eazo.acea90a5.model.Currency
import io.eazo.acea90a5.platform.AppRepo

/**
 * REQ-024 货币换算器主界面：币种下拉×2 + 金额输入 + 换算结果卡片 + 方向切换按钮。
 * 硬规则 ①：session 经 AppRepo.getRepo(context) 获取；硬规则 ②：onResume 只
 * refresh()（重读内存态，本 REQ 无持久化）。
 *
 * UI 视觉硬约束落点：结果卡片深靛蓝渐变 + 纯白大号数字（对比度 ≥3:1）；
 * 换向按钮主色实底圆形 + 白色图标 + elevation（视觉主导）；币种下拉折叠态
 * 2dp 强调色边框 + 右侧 ✓ 图标（显式选中强调）。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ConverterScreen()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(this).refresh()
    }
}

// ===== 配色（浅底 + 靛蓝主色；结果卡深渐变白字）=====
private val Indigo900 = Color(0xFF1A237E)
private val Indigo700 = Color(0xFF303F9F)
private val Indigo600 = Color(0xFF3949AB)
private val Amber300 = Color(0xFFFFD54F)
private val PageBg = Color(0xFFEEF1F8)
private val InkGray = Color(0xFF4A5568)
private val LabelGray = Color(0xFF6B7280)

/** 币种中文名（纯展示层文案，不入数据面）。 */
private val CODE_CN: Map<String, String> = mapOf(
    "USD" to "美元", "EUR" to "欧元", "JPY" to "日元",
    "CNY" to "人民币", "GBP" to "英镑", "HKD" to "港币",
)

/** 骨架主题扩展：本需求配色（不另建 XML 主题）。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Indigo600,
            background = PageBg,
            surface = Color.White,
            secondary = Amber300,
        ),
        content = content,
    )
}

/** 首屏：单态联动（C11）——金额/币种/换向任一变化立即重算，无残留旧值。 */
@Composable
private fun ConverterScreen() {
    val context = LocalContext.current
    val session = remember { AppRepo.getRepo(context).converter }
    var amountText by remember { mutableStateOf(ConvertCore.formatFen(session.amountCents)) }
    var rev by remember { mutableIntStateOf(0) }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(PageBg)
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        val wide = ConvertCore.isWideLayout(maxWidth.value.toInt())
        Column(modifier = Modifier.fillMaxSize()) {
            Text(
                text = "货币换算器",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Indigo900,
            )
            Text(
                text = "内置固定汇率 · 离线确定性换算",
                style = MaterialTheme.typography.bodySmall,
                color = LabelGray,
            )
            Spacer(modifier = Modifier.height(20.dp))

            if (wide) {
                // 平板/横屏：双列布局（C14）
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    SourceCard(
                        code = session.src,
                        amountText = amountText,
                        onSelect = { session.setSrc(it); rev++ },
                        onAmount = {
                            amountText = it
                            session.setAmount(ConvertCore.parseToFen(it))
                            rev++
                        },
                        modifier = Modifier.weight(1f),
                    )
                    SwapButton(onSwap = { session.swap(); rev++ })
                    ResultCard(
                        src = session.src,
                        dst = session.dst,
                        resultCents = session.resultCents,
                        onSelect = { session.setDst(it); rev++ },
                        modifier = Modifier.weight(1f),
                    )
                }
            } else {
                // 手机竖屏：单列布局（C14）
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    SourceCard(
                        code = session.src,
                        amountText = amountText,
                        onSelect = { session.setSrc(it); rev++ },
                        onAmount = {
                            amountText = it
                            session.setAmount(ConvertCore.parseToFen(it))
                            rev++
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    SwapButton(onSwap = { session.swap(); rev++ })
                    Spacer(modifier = Modifier.height(4.dp))
                    ResultCard(
                        src = session.src,
                        dst = session.dst,
                        resultCents = session.resultCents,
                        onSelect = { session.setDst(it); rev++ },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}

/** 源侧卡片：源币种下拉 + 金额输入（浅色卡）。 */
@Composable
private fun SourceCard(
    code: String,
    amountText: String,
    onSelect: (String) -> Unit,
    onAmount: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        shadowElevation = 2.dp,
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("源币种", style = MaterialTheme.typography.labelMedium, color = LabelGray)
            Spacer(modifier = Modifier.height(6.dp))
            CurrencyField(code = code, onDark = false, onSelect = onSelect)
            Spacer(modifier = Modifier.height(14.dp))
            Text("金额", style = MaterialTheme.typography.labelMedium, color = LabelGray)
            Spacer(modifier = Modifier.height(6.dp))
            TextField(
                value = amountText,
                onValueChange = onAmount,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("输入金额") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(12.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = PageBg,
                    unfocusedContainerColor = PageBg,
                    focusedTextColor = Color(0xFF1A1C1E),
                    unfocusedTextColor = Color(0xFF1A1C1E),
                    focusedIndicatorColor = Indigo600,
                    unfocusedIndicatorColor = Color(0xFFC5CAE9),
                ),
            )
        }
    }
}

/** 结果卡片：目标币种下拉 + 大号换算结果（深靛蓝渐变 + 纯白数字，对比度 ≥3:1）。 */
@Composable
private fun ResultCard(
    src: String,
    dst: String,
    resultCents: Long,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val gradient = Brush.linearGradient(listOf(Indigo900, Indigo700))
    Box(
        modifier = modifier
            .shadow(6.dp, RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .background(gradient)
            .padding(20.dp),
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                "目标币种",
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.75f),
            )
            Spacer(modifier = Modifier.height(6.dp))
            CurrencyField(code = dst, onDark = true, onSelect = onSelect)
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                "目标金额",
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = 0.75f),
            )
            Spacer(modifier = Modifier.height(4.dp))
            // 约束①：深色渐变上一律纯白大号数字（两端点对比度 9:1+）
            Text(
                text = "${ConvertCore.formatFen(resultCents)} $dst",
                fontSize = 40.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "1 $src = ${ConvertCore.formatFen(ConvertCore.convert(100L, src, dst))} $dst",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.85f),
            )
        }
    }
}

/** 方向切换按钮（约束②：主色实底 + 白色图标 + elevation，视觉主导）。 */
@Composable
private fun SwapButton(onSwap: () -> Unit) {
    Box(
        modifier = Modifier
            .shadow(6.dp, CircleShape)
            .clip(CircleShape)
            .background(Indigo600)
            .size(56.dp)
            .clickable(onClick = onSwap),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "换向", tint = Color.White, modifier = Modifier.size(22.dp))
            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
    }
}

/**
 * 币种下拉选择器（约束③：折叠态 2dp 强调色边框 + 右侧 ✓ 图标——折叠后仍可见
 * 选中强调；6 币种固定顺序，C02）。onDark 控制深色卡上的配色分支。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CurrencyField(
    code: String,
    onDark: Boolean,
    onSelect: (String) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val accent = if (onDark) Amber300 else Indigo600
    val fieldShape = RoundedCornerShape(12.dp)
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it },
    ) {
        OutlinedTextField(
            readOnly = true,
            value = code,
            onValueChange = {},
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
                .background(Color.Transparent)
                .padding(0.dp)
                .border(2.dp, accent, fieldShape),
            trailingIcon = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.Check,
                        contentDescription = "已选中",
                        tint = accent,
                        modifier = Modifier.size(18.dp),
                    )
                    Icon(Icons.Filled.ArrowDropDown, contentDescription = null, tint = accent)
                }
            },
            singleLine = true,
            shape = fieldShape,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = if (onDark) Color.White else Color(0xFF1A1C1E),
                unfocusedTextColor = if (onDark) Color.White else Color(0xFF1A1C1E),
                focusedBorderColor = accent,
                unfocusedBorderColor = accent,
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                cursorColor = accent,
            ),
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
        ) {
            Currency.CODES.forEach { c ->
                DropdownMenuItem(
                    text = { Text("$c · ${CODE_CN[c]}") },
                    onClick = {
                        onSelect(c)
                        expanded = false
                    },
                    leadingIcon = if (c == code) {
                        { Icon(Icons.Filled.Check, contentDescription = null, tint = Indigo600) }
                    } else {
                        null
                    },
                )
            }
        }
    }
}
