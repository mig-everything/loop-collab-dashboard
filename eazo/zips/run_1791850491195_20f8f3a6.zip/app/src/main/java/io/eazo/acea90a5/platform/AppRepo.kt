package io.eazo.acea90a5.platform

import android.content.Context
import io.eazo.acea90a5.data.ConverterSession

/**
 * 骨架模板平台层：AppRepo 进程内单例（生成器硬规则 ①——UI/卡片层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * REQ-024：本需求无持久化/网络（契约 §3 零网络、§2.5 无持久化需求），
 * AppRepo 只挂内存态 ConverterSession 单态；refresh() 只重读内存态。
 */
object AppRepo {

    /** REQ-024 换算会话单态（data 层纯类，进程内唯一）。 */
    val converter: ConverterSession = ConverterSession()

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo = this

    /** 硬规则 ②：refresh 只重读内存态，禁止从持久化 load()（本 REQ 无持久化）。 */
    fun refresh() {
        // ConverterSession.resultCents 每次 get 现算，内存态即权威态
    }
}
