package io.eazo.acea90a5.core

import io.eazo.acea90a5.model.Currency

/**
 * REQ-024 换算核心（契约 §2 ★冻结纯函数，全整数零浮点）。
 * 禁用清单（§7）：Math.round(Double) 浮点路径、Int 承载中间积（≤7.8e14 超 int32）、
 * core 层出现随机/时钟/网络。中间量一律 Long（上界 7.8×10^14 < 2^53 < int64）。
 */
object ConvertCore {

    /** §2.1 roundHalfUp（仅正数域，a≥0、b 偶数）：(a + b/2) / b，Long 整除，零浮点。 */
    fun roundHalfUp(a: Long, b: Long): Long = (a + b / 2L) / b

    /** §2.2 convert：两步经 CNY 基座，src==dst 早退恒等（A13）。 */
    fun convert(amountCents: Long, src: String, dst: String): Long {
        if (src == dst) return amountCents
        val rateSrc = Currency.RATE.getValue(src)
        val rateDst = Currency.RATE.getValue(dst)
        val cnyCents = roundHalfUp(amountCents * rateSrc, 1_000_000L)
        val dstCents = roundHalfUp(cnyCents * 1_000_000L, rateDst)
        return dstCents
    }

    // ===== 展示层辅助（§2.3，不入对账断言；convert 禁调用本段 =====

    /** 分 → "元.分"（720→"7.20"，15000→"150.00"）；展示层唯一允许的除法点。 */
    fun formatFen(fen: Long): String = "%d.%02d".format(fen / 100L, fen % 100L)

    /**
     * 金额文本 → 整数分（定点解析，禁 parseFloat/浮点）：
     * 接受非负十进制（小数 ≤2 位）；负数/非数字/超界（>10^8 分）回退默认 100（§2.5）。
     */
    fun parseToFen(text: String): Long {
        val t = text.trim()
        val m = Regex("^(\\d{1,9})(?:\\.(\\d{1,2}))?$").find(t) ?: return DEFAULT_AMOUNT_CENTS
        val whole = m.groupValues[1].toLong()
        val frac = m.groupValues[2].let { if (it.isEmpty()) "00" else it.padEnd(2, '0') }
        val cents = whole * 100L + frac.toLong()
        return if (cents in 0..MAX_AMOUNT_CENTS) cents else DEFAULT_AMOUNT_CENTS
    }

    /** 多端自适应断点（§3：600dp/vp 单列↔双列，C14 Should 可降级）。 */
    fun isWideLayout(widthDp: Int): Boolean = widthDp >= 600

    /** §1.2 输入域：amount_cents ∈ [0, 100_000_000]；非法回退默认 100（= 1 USD）。 */
    const val MAX_AMOUNT_CENTS: Long = 100_000_000L
    const val DEFAULT_AMOUNT_CENTS: Long = 100L
}
