package io.eazo.acea90a5.contract

import io.eazo.acea90a5.core.ConvertCore
import io.eazo.acea90a5.data.ConverterSession
import io.eazo.acea90a5.model.Currency
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

/**
 * REQ-024 货币换算器契约测试（cases-frozen eazo-cases-1.0.0，14 条 slug 逐字）。
 * 锚点全集 = 契约 §5：A1~A14 换算锚点 + B1/B2 边界 + E1~E3/A15~A18 判别锚点 +
 * F4a/F4b 浮点判别 + §4 哈希锁（SHA-256/68B）+ §5.4 结构锚点——全部落断言。
 * 纯 JVM（不 import pages，§7.8；不依赖 Android 框架）。
 */
class CurrencyConverterContractTest {

    // ===== C01 amount_input_range ｜金额输入非负到分，非法回退默认 100 =====
    @Test
    fun `amount_input_range`() {
        // 合法：非负定点文本 → 整数分
        assertEquals(720L, ConvertCore.parseToFen("7.20"))
        assertEquals(720L, ConvertCore.parseToFen("7.2"))
        assertEquals(1200L, ConvertCore.parseToFen("12"))
        assertEquals(0L, ConvertCore.parseToFen("0"))
        assertEquals(5L, ConvertCore.parseToFen("0.05"))
        // 非法：非数字/负数/超界（>10^8 分）/空 → 回退默认 100（§2.5）
        assertEquals(100L, ConvertCore.parseToFen("abc"))
        assertEquals(100L, ConvertCore.parseToFen("-5"))
        assertEquals(100L, ConvertCore.parseToFen("1000000.01")) // 10^8+1 分超界
        assertEquals(100L, ConvertCore.parseToFen(""))
        assertEquals(100L, ConvertCore.parseToFen("1.234")) // 小数超 2 位
    }

    // ===== C02 currency_selector_six ｜6 币种固定顺序 =====
    @Test
    fun `currency_selector_six`() {
        assertEquals(listOf("USD", "EUR", "JPY", "CNY", "GBP", "HKD"), Currency.CODES)
        assertEquals(6, Currency.CODES.size)
        assertEquals(6, Currency.CODES.distinct().size)
    }

    // ===== C03 rate_table_constant ｜固定汇率表常量数据面（§1.1 + §5.4 结构锚点）=====
    @Test
    fun `rate_table_constant`() {
        val expected = linkedMapOf(
            "USD" to 7_200_000L, "EUR" to 7_800_000L, "JPY" to 48_000L,
            "CNY" to 1_000_000L, "GBP" to 9_100_000L, "HKD" to 920_000L,
        )
        assertEquals(expected, Currency.RATE)
        assertEquals(Currency.CNY_BASE, Currency.RATE.getValue("CNY")) // CNY 基座
        assertTrue(Currency.RATE.values.all { it % 2L == 0L }) // 全偶数（b//2 精确前提）
        // 中间积上界 10^8 × 7.8e6 = 7.8e14 < 2^53（ArkTS number 精确界，双端无溢出）
        assertTrue(100_000_000L * 7_800_000L < (1L shl 53))
    }

    // ===== C04 convert_deterministic ｜两步经 CNY 基座，A1~A14 全锚点 =====
    @Test
    fun `convert_deterministic`() {
        assertEquals(720L, ConvertCore.convert(100L, "USD", "CNY")) // A1
        assertEquals(92L, ConvertCore.convert(100L, "USD", "EUR")) // A2
        assertEquals(15000L, ConvertCore.convert(100L, "USD", "JPY")) // A3
        assertEquals(79L, ConvertCore.convert(100L, "USD", "GBP")) // A4
        assertEquals(783L, ConvertCore.convert(100L, "USD", "HKD")) // A5
        assertEquals(108L, ConvertCore.convert(100L, "EUR", "USD")) // A6
        assertEquals(5L, ConvertCore.convert(100L, "JPY", "CNY")) // A7
        assertEquals(100L, ConvertCore.convert(720L, "CNY", "USD")) // A8
        assertEquals(104L, ConvertCore.convert(5L, "CNY", "JPY")) // A9
        assertEquals(989L, ConvertCore.convert(100L, "GBP", "HKD")) // A10
        assertEquals(72000L, ConvertCore.convert(10000L, "USD", "CNY")) // A11
        assertEquals(92L, ConvertCore.convert(100L, "HKD", "CNY")) // A12
        assertEquals(12345L, ConvertCore.convert(12345L, "CNY", "CNY")) // A13
        assertEquals(720000000L, ConvertCore.convert(100000000L, "USD", "CNY")) // A14
    }

    // ===== C05 round_half_up_boundary ｜B1 half-up vs floor + E1~E3 half-even 判别 =====
    @Test
    fun `round_half_up_boundary`() {
        assertEquals(46L, ConvertCore.convert(5L, "GBP", "CNY")) // B1：floor 给 45
        assertEquals(0L, ConvertCore.convert(0L, "USD", "EUR")) // B2：零值边界
        assertEquals(137L, ConvertCore.convert(15L, "GBP", "CNY")) // E1：half-even 136
        assertEquals(3L, ConvertCore.convert(2L, "GBP", "USD")) // E2：half-even 2
        assertEquals(63L, ConvertCore.convert(3L, "HKD", "JPY")) // E3：half-even 62
        // 舍入原语：整数分数 half-up（(a+b/2)/b）
        assertEquals(1L, ConvertCore.roundHalfUp(5L, 10L)) // 0.5 → 1
        assertEquals(0L, ConvertCore.roundHalfUp(4L, 10L)) // 0.4 → 0
        assertEquals(2L, ConvertCore.roundHalfUp(15L, 10L)) // 1.5 → 2（half-even 亦 2，仅原语口径）
    }

    // ===== C06 same_currency_identity ｜src==dst 早退恒等（A13）=====
    @Test
    fun `same_currency_identity`() {
        assertEquals(12345L, ConvertCore.convert(12345L, "CNY", "CNY")) // A13
        assertEquals(100L, ConvertCore.convert(100L, "USD", "USD"))
        assertEquals(999L, ConvertCore.convert(999L, "HKD", "HKD"))
    }

    // ===== C07 bidirectional_convert ｜双向走同一纯函数（A1 ↔ A8 对偶）=====
    @Test
    fun `bidirectional_convert`() {
        val forward = ConvertCore.convert(100L, "USD", "CNY") // A1
        val backward = ConvertCore.convert(720L, "CNY", "USD") // A8
        assertEquals(720L, forward)
        assertEquals(100L, backward)
        assertEquals(forward, ConvertCore.convert(100L, "USD", "CNY")) // 确定性复算一致
    }

    // ===== C08 rate_serialization_hash ｜§4 哈希锁（SHA-256 + 68B + 规范序列化）=====
    @Test
    fun `rate_serialization_hash`() {
        val serialized = Currency.serializeRate()
        assertEquals(
            "USD|7200000\nEUR|7800000\nJPY|48000\nCNY|1000000\nGBP|9100000\nHKD|920000",
            serialized,
        )
        val bytes = serialized.toByteArray(Charsets.UTF_8)
        assertEquals(68, bytes.size) // 6 行 63B + 5 LF
        assertFalse(serialized.endsWith("\n")) // 行尾无换行
        assertEquals(6, serialized.split("\n").size)
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        val hex = digest.joinToString("") { "%02x".format(it) }
        assertEquals("9d7ba769f11778c65193bba36603ab95eb7a85fee29e4eefa5ef20840c86f29b", hex)
    }

    // ===== C09 no_network_rate ｜固定常量数据面，无联网/实时汇率（§3 零网络）=====
    @Test
    fun `no_network_rate`() {
        // 常量数据面：两次序列化全等（无时钟/随机/网络源引入方差）
        assertEquals(Currency.serializeRate(), Currency.serializeRate())
        // 常量面静态锁定：条目数与值域恒定，无运行时派生
        assertEquals(6, Currency.RATE.size)
        assertTrue(Currency.RATE.values.all { it > 0L })
        // 展示层文案亦不含任何网络协议痕迹（数据面唯一出处 = §1.1 表）
        assertFalse(Currency.serializeRate().contains("http"))
    }

    // ===== C10 swap_direction ｜反转只交换 src/dst 引用 + 结果重算（A8 兜底）=====
    @Test
    fun `swap_direction`() {
        val session = ConverterSession(amountCents = 720L, src = "CNY", dst = "USD")
        assertEquals(100L, session.resultCents) // A8
        session.swap()
        assertEquals("USD", session.src)
        assertEquals("CNY", session.dst)
        assertEquals(720L, session.amountCents) // 金额不随换向变
        assertEquals(ConvertCore.convert(720L, "USD", "CNY"), session.resultCents) // 同一纯函数重算
        session.swap()
        assertEquals(100L, session.resultCents) // 再换向回 A8
    }

    // ===== C11 realtime_update ｜单态联动：任一变化立即重算，无残留旧值 =====
    @Test
    fun `realtime_update`() {
        val session = ConverterSession() // 默认 (100, USD, CNY)
        assertEquals(720L, session.resultCents) // A1
        session.setAmount(10000L)
        assertEquals(72000L, session.resultCents) // A11，金额变化即时刷新
        session.setSrc("EUR")
        assertEquals(ConvertCore.convert(10000L, "EUR", "CNY"), session.resultCents) // 换源即时
        session.setDst("JPY")
        assertEquals(ConvertCore.convert(10000L, "EUR", "JPY"), session.resultCents) // 换目标即时
        assertEquals(78000L, ConvertCore.convert(10000L, "EUR", "CNY")) // 换源一步值锚定（100 EUR→CNY=78000 分）
    }

    // ===== C12 result_card_display ｜分 → 格式化展示（720 → "7.20"）=====
    @Test
    fun `result_card_display`() {
        assertEquals("7.20", ConvertCore.formatFen(720L))
        assertEquals("150.00", ConvertCore.formatFen(15000L))
        assertEquals("0.00", ConvertCore.formatFen(0L))
        assertEquals("0.05", ConvertCore.formatFen(5L))
        assertEquals("1000000.00", ConvertCore.formatFen(100000000L))
    }

    // ===== C13 convert_no_float ｜全整数零浮点（F4a/F4b 判别 + 安全界）=====
    @Test
    fun `convert_no_float`() {
        assertEquals(319L, ConvertCore.convert(35L, "GBP", "CNY")) // F4a：浮点链给 318（318.4999…）
        assertEquals(2048L, ConvertCore.convert(225L, "GBP", "CNY")) // F4b：浮点链给 2047
        // 值域内最大中间积仍为精确整数（Long，禁 Int/浮点承载）
        assertEquals(720000000L, ConvertCore.convert(100000000L, "USD", "CNY")) // A14 复锚
        assertTrue(ConvertCore.roundHalfUp(780_000_000_000_000L, 1_000_000L) == 780_000_000L)
    }

    // ===== C14 multiscreen_adaptive ｜600dp 断点单列/双列（Should，纯函数口径）=====
    @Test
    fun `multiscreen_adaptive`() {
        assertFalse(ConvertCore.isWideLayout(320)) // 手机竖屏 → 单列
        assertFalse(ConvertCore.isWideLayout(599))
        assertTrue(ConvertCore.isWideLayout(600)) // ≥600dp → 双列
        assertTrue(ConvertCore.isWideLayout(840)) // 平板横屏
    }
}
