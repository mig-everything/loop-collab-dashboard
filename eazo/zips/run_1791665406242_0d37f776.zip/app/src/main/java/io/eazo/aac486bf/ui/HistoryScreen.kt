package io.eazo.aac486bf.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import io.eazo.aac486bf.data.PRIZES
import io.eazo.aac486bf.model.DrawRecord
import io.eazo.aac486bf.platform.AppRepo

/**
 * REQ-020 history 页：中奖历史列表（serial 升序 = append 序，与 §4.4 序列化同序——双端 1:1）。
 * 跨页面写操作即时可见：每次进入重读 AppRepo 内存态 listHistory()（硬规则 ② refresh 口径）。
 * ≥600dp 双列网格（多端自适应 Should，契约 §3 600vp 口径对齐）。
 */
@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { AppRepo.getRepo(context) } // 硬规则 ①：单例通道
    val history = remember { mutableStateOf(repo.listHistory()) }

    // 进入/回显只 refresh 重读内存态（硬规则 ②：禁止从持久化 load()）
    LaunchedEffect(Unit) { history.value = repo.listHistory() }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回", tint = Color(0xFFFFD54F))
            }
            Text(text = "中奖历史", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "共 ${history.value.size} 次",
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFFFFD54F),
                modifier = Modifier.padding(end = 12.dp),
            )
        }

        if (history.value.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Filled.Star,
                        contentDescription = null,
                        tint = Color(0x55FFFFFF),
                        modifier = Modifier.size(56.dp),
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "还没有抽奖记录，快去转一转吧",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0x99FFFFFF),
                    )
                }
            }
        } else {
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                if (maxWidth >= 600.dp) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(history.value.size) { i -> HistoryCard(history.value[i]) }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(history.value) { rec -> HistoryCard(rec) }
                    }
                }
            }
        }
    }
}

/** 单条历史卡片：serial 徽标 + 奖项色点 + 奖品名（prizeId 查 PRIZES，双端同表）。 */
@Composable
private fun HistoryCard(rec: DrawRecord) {
    val prize = PRIZES.first { it.id == rec.prizeId }
    val color = parseHexColor(prize.color)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF31255C)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(Color(0xFFFFC107), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "${rec.serial}",
                    color = Color(0xFF4E342E),
                    fontWeight = FontWeight.Black,
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .background(color, CircleShape),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = prize.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = color,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = "第 ${rec.serial} 次抽奖 · ${rec.prizeId}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0x99FFFFFF),
                )
            }
        }
    }
}

/** 与 WheelScreen 同源的 #RRGGBB 解析（展示层）。 */
private fun parseHexColor(hex: String): Color {
    val v = hex.removePrefix("#").toLong(16)
    return Color(((v and 0xFF0000L) shr 16).toInt(), ((v and 0xFF00L) shr 8).toInt(), (v and 0xFFL).toInt())
}
