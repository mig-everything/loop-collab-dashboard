package io.eazo.aac486bf.core

import io.eazo.aac486bf.data.SEED

/**
 * REQ-020 页面导航与交互双状态机（契约 §2.5，数据态可测；动画/渲染为展示态）。
 *
 * 路由/相位/事件字符串字面量与鸿蒙端 1:1（"wheel"/"history"、
 * "idle"/"spinning"/"result"、openHistory/back/closeResult/reset/spin/settled）。
 * 封闭性：未列出的 (state, event) 组合 = 无效转移，忽略（禁崩溃、禁隐式跳转）。
 */

/** 导航态：双页面（结果弹窗为 wheel 页覆盖层，非独立页）。 */
enum class NavState(val route: String) {
    WHEEL("wheel"),
    HISTORY("history"),
}

/** 导航事件。 */
enum class NavEvent(val literal: String) {
    OPEN_HISTORY("openHistory"),
    BACK("back"),
}

/** 导航转移结果：页面态 / 退出 App（根态）/ 忽略。 */
enum class NavOutcome(val route: String?) {
    WHEEL(NavState.WHEEL.route),
    HISTORY(NavState.HISTORY.route),
    EXIT_APP(null), // ("wheel","back") → 退出 App（根态，UI 层 finish）
    IGNORED(null),
}

/** wheel 页内三相位。 */
enum class SpinPhase(val literal: String) {
    IDLE("idle"),
    SPINNING("spinning"),
    RESULT("result"),
}

/** 交互相位事件。 */
enum class PhaseEvent(val literal: String) {
    SPIN("spin"),
    SETTLED("settled"),
    CLOSE_RESULT("closeResult"),
    RESET("reset"),
}

/**
 * 交互相位机可测载荷：
 * spinning 携 targetIndex（spin 时由 drawIndex(SEED, serial) 算得）；
 * result 携 prizeIndex（settled 仅在 targetIndex 到达时发出）。
 */
data class PhaseState(
    val phase: SpinPhase,
    val serial: Int? = null,
    val targetIndex: Int? = null,
    val prizeIndex: Int? = null,
) {
    companion object {
        val INITIAL = PhaseState(SpinPhase.IDLE)
    }
}

object WheelStateMachine {

    /** 导航转移 next(state, event)（契约 §2.5）：3 有效 + 1 忽略（根态 back 退出）。 */
    fun nextNav(state: NavState, event: NavEvent): NavOutcome = when (state to event) {
        NavState.WHEEL to NavEvent.OPEN_HISTORY -> NavOutcome.HISTORY
        NavState.HISTORY to NavEvent.BACK -> NavOutcome.WHEEL
        NavState.WHEEL to NavEvent.BACK -> NavOutcome.EXIT_APP
        else -> NavOutcome.IGNORED // (history, openHistory) 无效组合：忽略
    }

    /**
     * 交互相位转移 nextPhase(phase, event, payload)（契约 §2.5）：5 有效 + 其余忽略。
     * - (idle, spin, {serial}) → spinning{targetIndex = drawIndex(SEED, serial)}
     * - (spinning, settled, {index}) → result{prizeIndex = index}（settled 仅在 targetIndex 到达时发出）
     * - (result, closeResult) → idle；弹窗不关也可连抽（result+spin，serial 已 +1）
     * - (任意相位, reset) → idle（清历史 + serial 归 1 的原子副作用在 AppRepo.reset 落地）
     */
    fun nextPhase(
        state: PhaseState,
        event: PhaseEvent,
        serial: Int? = null,
        settledIndex: Int? = null,
    ): PhaseState? {
        if (event == PhaseEvent.RESET) return PhaseState(SpinPhase.IDLE) // 任意相位 reset → idle
        return when (state.phase to event) {
            SpinPhase.IDLE to PhaseEvent.SPIN ->
                PhaseState(SpinPhase.SPINNING, serial = serial, targetIndex = WheelCore.drawIndex(SEED, requireNotNull(serial)))
            SpinPhase.SPINNING to PhaseEvent.SETTLED ->
                PhaseState(SpinPhase.RESULT, prizeIndex = settledIndex)
            SpinPhase.RESULT to PhaseEvent.CLOSE_RESULT ->
                PhaseState(SpinPhase.IDLE)
            SpinPhase.RESULT to PhaseEvent.SPIN ->
                PhaseState(SpinPhase.SPINNING, serial = serial, targetIndex = WheelCore.drawIndex(SEED, requireNotNull(serial)))
            else -> null // 未列出组合（含 spinning 中再 spin、idle 中 settled 等）= 无效转移，忽略
        }
    }
}
