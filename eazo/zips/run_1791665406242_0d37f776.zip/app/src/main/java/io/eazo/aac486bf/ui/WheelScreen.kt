package io.eazo.aac486bf.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.aac486bf.data.PRIZES
import io.eazo.aac486bf.core.PhaseEvent
import io.eazo.aac486bf.core.PhaseState
import io.eazo.aac486bf.core.SpinPhase
import io.eazo.aac486bf.core.WheelCore
import io.eazo.aac486bf.core.WheelStateMachine
import io.eazo.aac486bf.model.DrawRecord
import io.eazo.aac486bf.platform.AppRepo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** REQ-020 wheel 页：Canvas 转盘 + 抽奖按钮 + 相位状态机 + 结果弹窗（展示态，契约 §1.4）。 */
@Composable
fun WheelScreen(onOpenHistory: () -> Unit) {
    val context = LocalContext.current
    val repo = remember { AppRepo.getRepo(context) } // 硬规则 ①：经 AppRepo.getRepo(context) 单例获取
    var phaseState by remember { mutableStateOf(PhaseState.INITIAL) }
    var record by remember { mutableStateOf<DrawRecord?>(null) }
    val rotation = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    /** 点击抽奖：spin 事件（serial 取推进前值）→ AppRepo.draw() 原子落账 → 动画 → settled。 */
    fun spin() {
        if (phaseState.phase == SpinPhase.SPINNING) return // spinning 中再 spin = 无效转移，忽略
        val serial = repo.currentSerial()
        val next = WheelStateMachine.nextPhase(phaseState, PhaseEvent.SPIN, serial = serial) ?: return
        val rec = repo.draw() // 原子：抽取 + 历史 append + serial 推进（prizeIndex == next.targetIndex，契约幂等）
        record = rec
        phaseState = next
        scope.launch {
            // 停位角（契约 §2.4）：转盘顺时针转 R 后扇区 i 中心回到顶部指针 ⇔ R ≡ angleForIndex(i) (mod 360)。
            // 连抽单调递增：在契约基准角上叠加整圈，保持 ≥5 圈且不回退。
            val base = WheelCore.angleForIndex(rec.prizeIndex)
            val cur = rotation.value
            val delta = (((base - cur) % 360f) + 360f) % 360f + 5 * 360f
            rotation.animateTo(cur + delta, tween(durationMillis = 4200, easing = FastOutSlowInEasing))
            delay(280) // 停位定格片刻再弹结果（展示态节奏）
            phaseState = WheelStateMachine.nextPhase(
                phaseState, PhaseEvent.SETTLED, settledIndex = rec.prizeIndex,
            ) ?: phaseState
        }
    }

    /** reset 事件（wheel 页任意相位）：AppRepo 原子清历史 + serial 归 1 → 相位归 idle。 */
    fun reset() {
        scope.launch { rotation.stop() } // 中断进行中的动画（数据态不受影响）
        repo.reset()
        record = null
        phaseState = WheelStateMachine.nextPhase(phaseState, PhaseEvent.RESET) ?: phaseState
    }

    Column(modifier = Modifier.fillMaxSize()) {
        WheelTopBar(
            serial = repo.currentSerial(),
            onOpenHistory = onOpenHistory,
            onReset = ::reset,
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center,
        ) {
            WheelBoard(
                rotation = rotation.value,
                spinning = phaseState.phase == SpinPhase.SPINNING,
                onSpin = ::spin,
            )
        }
        Spacer(modifier = Modifier.height(24.dp))
    }

    // 结果弹窗（wheel 页覆盖层，非独立页——契约 §2.5）
    val rec = record
    if (phaseState.phase == SpinPhase.RESULT && rec != null) {
        val prize = PRIZES[rec.prizeIndex]
        val won = rec.prizeIndex != PRIZES.size - 1 // P08 谢谢参与
        ResultDialog(
            title = if (won) "恭喜中奖" else "很遗憾",
            prizeName = prize.name,
            prizeColor = parseHexColor(prize.color),
            won = won,
            onClose = {
                phaseState = WheelStateMachine.nextPhase(phaseState, PhaseEvent.CLOSE_RESULT) ?: phaseState
            },
            onAgain = ::spin, // result 相位连抽：弹窗不关也可再抽（serial 已 +1，契约 §2.5）
        )
    }
}

@Composable
private fun WheelTopBar(serial: Int, onOpenHistory: () -> Unit, onReset: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "抽奖转盘",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(start = 10.dp),
        )
        Spacer(modifier = Modifier.weight(1f))
        IconButton(onClick = onOpenHistory) {
            Icon(Icons.AutoMirrored.Filled.List, contentDescription = "中奖历史", tint = Color(0xFFFFD54F))
        }
        IconButton(onClick = onReset) { // reset：wheel 页任意相位均有效（契约 §2.5）
            Icon(Icons.Filled.Refresh, contentDescription = "重置", tint = Color(0xFFFFD54F))
        }
        Text(
            text = "第 $serial 抽 · SEED=20261011",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0x99FFFFFF),
            modifier = Modifier.padding(end = 12.dp),
        )
    }
}

/** 转盘主体：外圈灯环 + 8 扇区 Canvas（graphicsLayer 旋转）+ 顶部指针 + 中心抽奖按钮。 */
@Composable
private fun WheelBoard(rotation: Float, spinning: Boolean, onSpin: () -> Unit) {
    val textMeasurer = rememberTextMeasurer()
    val sectorTexts = remember(textMeasurer) {
        PRIZES.map {
            textMeasurer.measure(
                it.name,
                TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White),
            )
        }
    }
    val bulbPulse = rememberInfiniteTransition(label = "bulbPulse")
    val bulbAlpha by bulbPulse.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(if (spinning) 240 else 900)),
        label = "bulbAlpha",
    )

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
        val wheelSize = if (maxWidth >= 600.dp) 460.dp else maxWidth - 40.dp // 多端自适应（Should）
        Box(modifier = Modifier.size(wheelSize), contentAlignment = Alignment.Center) {
            // 光晕背景（展示态装饰）
            Box(
                modifier = Modifier
                    .size(wheelSize)
                    .graphicsLayer { alpha = 0.28f }
                    .background(
                        Brush.radialGradient(listOf(Color(0xFFFFD700), Color.Transparent)),
                        CircleShape,
                    ),
            )
            WheelCanvas(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { rotationZ = rotation },
                sectorTexts = sectorTexts,
            )
            WheelBulbs(
                modifier = Modifier.fillMaxSize(),
                alpha = bulbAlpha,
            )
            Pointer(modifier = Modifier.align(Alignment.TopCenter))
            CenterButton(
                spinning = spinning,
                onSpin = onSpin,
                modifier = Modifier.align(Alignment.Center),
            )
        }
    }
}

/** 8 扇区转盘：index i 扇区 [i*45°, (i+1)*45°]（从 12 点钟顺时针，契约 §1.1 Index↔扇区几何）。 */
@Composable
private fun WheelCanvas(modifier: Modifier, sectorTexts: List<androidx.compose.ui.text.TextLayoutResult>) {
    val density = LocalDensity.current
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val outer = size.minDimension / 2f
        val ring = with(density) { 10.dp.toPx() }
        val radius = outer - ring * 2f
        val sector = 360f / PRIZES.size

        // 金色外环 + 深色底盘
        drawCircle(Color(0xFFFFD700), radius = outer, center = Offset(cx, cy))
        drawCircle(Color(0xFF2A1E4F), radius = outer - ring, center = Offset(cx, cy))

        // 扇区：drawArc 以 3 点钟为 0°，12 点钟 = -90°；扇区 i 自 12 点钟起顺时针第 i 格
        val topLeft = Offset(cx - radius, cy - radius)
        val arcSize = Size(radius * 2f, radius * 2f)
        PRIZES.forEachIndexed { i, prize ->
            drawArc(
                color = parseHexColor(prize.color).copy(alpha = 0.92f),
                startAngle = i * sector - 90f,
                sweepAngle = sector,
                useCenter = true,
                topLeft = topLeft,
                size = arcSize,
            )
        }
        // 扇区分隔线（金色细线）
        PRIZES.forEachIndexed { i, _ ->
            val angle = i * sector - 90f
            val rad = Math.toRadians(angle.toDouble())
            drawLine(
                color = Color(0xFFFFD700),
                start = Offset(cx, cy),
                end = Offset(cx + (radius * Math.cos(rad)).toFloat(), cy + (radius * Math.sin(rad)).toFloat()),
                strokeWidth = with(density) { 1.5.dp.toPx() },
            )
        }
        // 扇区名：旋转到扇区中心角，沿径向从中心向外排布
        val inner = radius * 0.42f
        sectorTexts.forEachIndexed { i, text ->
            val centerAngle = i * sector + sector / 2f - 90f
            rotate(centerAngle, pivot = Offset(cx, cy)) {
                drawText(
                    textLayoutResult = text,
                    topLeft = Offset(cx + inner, cy - text.size.height / 2f),
                    alpha = 0.96f,
                )
            }
        }
        // 内圈描边
        drawCircle(
            Color(0xFFFFD700),
            radius = radius,
            center = Offset(cx, cy),
            style = Stroke(width = with(density) { 2.dp.toPx() }),
        )
    }
}

/** 外圈灯泡环（spinning 时快闪——展示态）。 */
@Composable
private fun WheelBulbs(modifier: Modifier, alpha: Float) {
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = size.minDimension / 2f - 6.dp.toPx()
        repeat(16) { k ->
            val rad = Math.toRadians((k * 360f / 16).toDouble())
            val pos = Offset(cx + (r * Math.cos(rad)).toFloat(), cy + (r * Math.sin(rad)).toFloat())
            drawCircle(
                color = if (k % 2 == 0) Color(0xFFFFF176).copy(alpha = alpha) else Color(0xFFFFD700),
                radius = 4.dp.toPx(),
                center = pos,
            )
        }
    }
}

/** 顶部指针（固定不随转盘旋转——契约 §1.1：指针初始位 = index 0 扇区角平分线）。 */
@Composable
private fun Pointer(modifier: Modifier) {
    Canvas(modifier = modifier.size(36.dp, 42.dp).offset(y = (-10).dp)) {
        val path = Path().apply {
            moveTo(size.width / 2f - 14f, 0f)
            lineTo(size.width / 2f + 14f, 0f)
            lineTo(size.width / 2f, size.height * 0.62f)
            close()
        }
        drawPath(path, Color(0xFFFF5252))
        drawCircle(Color(0xFFFFD700), radius = 9f, center = Offset(size.width / 2f, 6f))
    }
}

/** 中心抽奖按钮。 */
@Composable
private fun CenterButton(spinning: Boolean, onSpin: () -> Unit, modifier: Modifier) {
    Column(
        modifier = modifier
            .size(104.dp)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(listOf(Color(0xFFFFF8E1), Color(0xFFFFC107), Color(0xFFFF8F00))),
            )
            .clickable(enabled = !spinning) { onSpin() }
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            Icons.Filled.Star,
            contentDescription = null,
            tint = Color(0xFF5D4037),
            modifier = Modifier.size(26.dp),
        )
        Text(
            text = if (spinning) "旋转中" else "开始抽奖",
            style = MaterialTheme.typography.labelLarge,
            color = Color(0xFF4E342E),
            fontWeight = FontWeight.Black,
        )
        if (!spinning) {
            Text(
                text = "点我",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0x8A4E342E),
            )
        }
    }
}

/** 中奖结果弹窗（覆盖层：恭喜中奖 / 很遗憾·谢谢参与）。 */
@Composable
private fun ResultDialog(
    title: String,
    prizeName: String,
    prizeColor: Color,
    won: Boolean,
    onClose: () -> Unit,
    onAgain: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onClose,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.Star,
                    contentDescription = null,
                    tint = if (won) Color(0xFFFFC107) else Color(0xFF9E9E9E),
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(text = title, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column {
                Text(text = if (won) "获得奖品" else "本次未中奖")
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = prizeName,
                    style = MaterialTheme.typography.headlineSmall,
                    color = prizeColor,
                    fontWeight = FontWeight.Black,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onAgain) { Text("再来一次") }
        },
        dismissButton = {
            TextButton(onClick = onClose) { Text("收下啦") }
        },
    )
}

/** #RRGGBB（大写，契约 §1.1）→ Compose Color（展示层解析）。 */
private fun parseHexColor(hex: String): Color {
    val v = hex.removePrefix("#").toLong(16)
    return Color(((v and 0xFF0000L) shr 16).toInt(), ((v and 0xFF00L) shr 8).toInt(), (v and 0xFFL).toInt())
}
