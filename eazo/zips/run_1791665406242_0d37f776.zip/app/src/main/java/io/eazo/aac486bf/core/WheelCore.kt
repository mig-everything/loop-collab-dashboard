package io.eazo.aac486bf.core

import io.eazo.aac486bf.data.CUMULATIVE
import io.eazo.aac486bf.data.SEED
import io.eazo.aac486bf.data.TOTAL_WEIGHT

/**
 * REQ-020 确定性核心（契约 §2，对账主战场）。
 *
 * ★ 禁 IO/网络/随机/时钟/UI API（契约 §8 禁用清单，D8 静态检查）：
 * 全函数纯确定性——同 seed 同 serial 恒同结果，可脱离 UI 单测。
 * 整数位运算/整数取模全程零浮点；angleForIndex 是唯一允许浮点的展示层函数。
 */
object WheelCore {

    /**
     * xorshift32：32 位无符号整数域，Marsaglia 三异或对 13/17/5（契约 §2.1）。
     *
     * Kotlin Int 承载 uint32 位型：shl/ushr/xor 天然 32 位域，无需掩码。
     * 第 2 步必须 ushr（逻辑右移）——shr 在负数 state 上符号位扩展 → 序列分叉（V1a）。
     * 逐位锚点：nextU32(20261011) = 549735040 (0x20C44A80)（契约 §6.4）。
     */
    fun nextU32(state: Int): Int {
        var x = state
        x = x xor (x shl 13)
        x = x xor (x ushr 17)
        x = x xor (x shl 5)
        return x
    }

    /**
     * 带权选取：整数取模 + 严格大于（契约 §2.2）。
     *
     * ★ Long 域取模（V5）：state bit31 置位时 Int 为负，Int 域 `%` 结果为负
     * → 首个 cumulative[k] > r 恒命中 k=0。必须 (u32.toLong() and 0xFFFFFFFFL) % TOTAL_WEIGHT。
     * ★ 严格大于（>）非 >=（V4：r=1 时 > 语义 index=1，>= 语义 index=0）。
     * 禁浮点归一化 int(u32/2^32*100)（V1b：映射不同，前 6 项全 7）。
     */
    fun weightedIndex(u32: Int, cumulative: IntArray = CUMULATIVE): Int {
        val r = ((u32.toLong() and 0xFFFFFFFFL) % TOTAL_WEIGHT).toInt() // r ∈ [0,99]
        for (k in cumulative.indices) {
            if (cumulative[k] > r) return k
        }
        return cumulative.size - 1 // 不可达（末项 == TOTAL_WEIGHT > r 恒真）
    }

    /**
     * 确定性抽奖纯函数（契约 §2.3）：第 serial 次抽奖（★ 1 基）= seed 推进 serial 次后带权选取。
     * 同 seed 同 serial → 同 index（幂等，无状态残留——state 从 seed 重算）。
     * serial=1..12 序列锚点 [5,6,5,7,3,6,6,1,6,5,3,6]（契约 §6.2）。
     */
    fun drawIndex(seed: Int = SEED, serial: Int): Int {
        var state = seed
        for (k in 1..serial) { // serial 1 基：drawIndex(SEED,1) = seed 推进 1 次
            state = nextU32(state)
        }
        return weightedIndex(state)
    }

    /**
     * 转盘停位角：第 index 扇区中心对齐顶部指针（契约 §2.4 展示层，不入对账断言）。
     * index=0..7 → [2137.5, 2092.5, 2047.5, 2002.5, 1957.5, 1912.5, 1867.5, 1822.5]。
     */
    fun angleForIndex(index: Int, count: Int = 8, fullSpins: Int = 5): Float {
        val sector = 360.0f / count
        val center = index * sector + sector / 2.0f
        return fullSpins * 360.0f + ((360.0f - center) % 360.0f)
    }
}
