package io.eazo.aac486bf.platform

import android.content.Context
import io.eazo.aac486bf.core.WheelCore
import io.eazo.aac486bf.data.PRIZES
import io.eazo.aac486bf.data.SEED
import io.eazo.aac486bf.model.DrawRecord

/**
 * 骨架模板平台层：AppRepo 进程内单例（生成器硬规则 ①——UI/卡片层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * REQ-020 落地（契约 §3）：serial 唯一来源 = 本入口（点击抽奖事件推进）；
 * 历史 append 与 serial 推进在同一原子操作内（禁先抽后 +1 的竞态窗口）；
 * reset 原子（清历史 + serial 归 1，无中间态）。历史为运行时内存数据
 * （契约 §4.4），无持久化数据面——refresh 即重读内存态。
 */
object AppRepo {

    /** 待抽序号（1 基 = 下一次抽奖的 serial；初始 1，reset 归 1——契约 §1.1/§6.5）。 */
    private var serial: Int = 1

    /** 中奖历史（append 序 = serial 升序；进程内内存态）。 */
    private val history = mutableListOf<DrawRecord>()

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo = this

    /** 当前待抽序号（第 N 次抽奖的 N；serial 语义锚点：1 基、单调递增、reset 归 1）。 */
    @Synchronized
    fun currentSerial(): Int = serial

    /** 预览下一次抽奖结果（不推进、不落账）= drawIndex(SEED, serial)（契约 §3/§6.5）。 */
    @Synchronized
    fun nextDraw(): Int = WheelCore.drawIndex(SEED, serial)

    /**
     * 点击抽奖的原子操作：抽取 + 历史 append + serial 推进（同一 @Synchronized 内，
     * 契约 §3 serial 推进链——禁先抽后 +1 的竞态窗口）。
     *
     * @return 本次中奖记录（prizeIndex == drawIndex(SEED, 本次 serial)，幂等可复算）
     */
    @Synchronized
    fun draw(): DrawRecord {
        val s = serial
        val idx = WheelCore.drawIndex(SEED, s)
        val rec = DrawRecord(serial = s, prizeIndex = idx, prizeId = PRIZES[idx].id)
        history.add(rec)
        serial = s + 1
        return rec
    }

    /** 历史快照（serial 升序 = append 序；跨页面读即时可见——硬规则 ② 内存态 list()）。 */
    @Synchronized
    fun listHistory(): List<DrawRecord> = history.toList()

    /** 原子重置：清历史 + serial 归 1 同一操作（契约 §6.5：无「历史空但 serial>1」中间态）。 */
    @Synchronized
    fun reset() {
        history.clear()
        serial = 1
    }

    /** 硬规则 ②：refresh 只重读内存态，禁止从持久化 load()（本需求历史无持久化面）。 */
    fun refresh() {
        // 内存态单源：listHistory()/currentSerial() 直读，无需额外动作
    }
}
