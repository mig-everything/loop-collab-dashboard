package io.eazo.aac486bf.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import io.eazo.aac486bf.core.NavState
import io.eazo.aac486bf.platform.AppRepo

/**
 * 骨架模板主界面：单 Activity + Jetpack Compose（UI 锁死声明式——与鸿蒙 ArkUI
 * 声明式对称，禁止 XML 布局/drawable 扇出；图标用 material-icons，主题用
 * Compose MaterialTheme）。
 *
 * REQ-020 双页导航（契约 §2.5 NavState：wheel ↔ history；结果弹窗为 wheel 页
 * 覆盖层）：(history, back) → wheel 由 BackHandler 承接；(wheel, back) → 系统
 * 默认退出（根态）。硬规则 ②：onResume 只 refresh()（重读内存态），禁止从持久化 load()。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Screen()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(this).refresh()
    }
}

/** 骨架默认主题（REQ-020 定制：夜幕紫 + 幸运金）。会话按需求在此改配色，不另建 XML 主题。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(
            primary = Color(0xFFFFD700),
            onPrimary = Color(0xFF4E342E),
            secondary = Color(0xFFFFC107),
            onSecondary = Color(0xFF4E342E),
            tertiary = Color(0xFFB39DDB),
            background = Color(0xFF1A1033),
            onBackground = Color(0xFFF3EFFF),
            surface = Color(0xFF241845),
            onSurface = Color(0xFFF3EFFF),
            surfaceVariant = Color(0xFF31255C),
            onSurfaceVariant = Color(0xFFD8CCFF),
        ),
        content = content,
    )
}

/** 双页路由（契约 §2.5）：wheel ↔ history；夜幕渐变背景。 */
@Composable
private fun Screen() {
    var nav by remember { mutableStateOf(NavState.WHEEL) } // 初始态 wheel / idle
    BackHandler(enabled = nav == NavState.HISTORY) {
        nav = NavState.WHEEL // ("history","back") → ("wheel", idle)
    } // ("wheel","back") 未拦截 → 系统返回退出 App（根态）
    androidx.compose.foundation.layout.Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF241845), Color(0xFF1A1033), Color(0xFF12092B)),
                ),
            ),
    ) {
        when (nav) {
            NavState.WHEEL -> WheelScreen(onOpenHistory = { nav = NavState.HISTORY })
            NavState.HISTORY -> HistoryScreen(onBack = { nav = NavState.WHEEL })
        }
    }
}
