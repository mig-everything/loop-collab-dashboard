package io.eazo.aac486bf.model

/**
 * 中奖历史条目（契约 §1.1 struct DrawRecord { serial, prizeIndex, prizeId }——字段名双端 1:1）。
 *
 * 序列化 `serial:prizeId`（如 `1:P06`，契约 §4.4 对账辅助口径，非哈希锁；
 * 历史是运行时数据，长度无界，进程内内存态即可——不入持久化数据面）。
 */
data class DrawRecord(
    val serial: Int,
    val prizeIndex: Int,
    val prizeId: String,
) {
    fun serialize(): String = "$serial:$prizeId"

    companion object {
        /** 历史列表整体 LF 连接（契约 §4.4，双端截图对照 / NL 留证用）。 */
        fun serializeAll(records: List<DrawRecord>): String =
            records.joinToString("\n") { it.serialize() }
    }
}
