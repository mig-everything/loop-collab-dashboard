package io.eazo.aac486bf.contract

import io.eazo.aac486bf.core.NavEvent
import io.eazo.aac486bf.core.NavOutcome
import io.eazo.aac486bf.core.NavState
import io.eazo.aac486bf.core.PhaseEvent
import io.eazo.aac486bf.core.PhaseState
import io.eazo.aac486bf.core.SpinPhase
import io.eazo.aac486bf.core.WheelCore
import io.eazo.aac486bf.core.WheelStateMachine
import io.eazo.aac486bf.data.CUMULATIVE
import io.eazo.aac486bf.data.POOL_BYTES
import io.eazo.aac486bf.data.POOL_SHA256
import io.eazo.aac486bf.data.PRIZES
import io.eazo.aac486bf.data.SEED
import io.eazo.aac486bf.data.TOTAL_WEIGHT
import io.eazo.aac486bf.model.DrawRecord
import io.eazo.aac486bf.platform.AppRepo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

/**
 * REQ-020 契约回归用例（契约 §6 锚点全集；slug 逐字 == cases-frozen.json 14 条——口径 14）。
 *
 * 全部 JVM 纯逻辑：锚点常量从 gen_prize_pool.py 生成物 import（禁手抄，契约 §6 序）。
 * 期望值权威源 = docs/arch/req020/02-interface-contract.md v1.0（commit a8cbb59）。
 */
class WheelContractTest {

    // ---------- 奖品池结构（§6.6/§6.8 结构断言 8 条） ----------

    /** slug: prize_pool_8_items —— 8 项 / id 升序 / 字段非空无 | / #RRGGBB 大写 / 权重面 / 分隔符 U+00B7。 */
    @Test
    fun `prize_pool_8_items`() {
        assertEquals(8, PRIZES.size)
        assertEquals(PRIZES.map { it.id }, PRIZES.map { it.id }.sorted()) // id 升序（P01..P08）
        PRIZES.forEach { p ->
            assertTrue(p.id.isNotEmpty())
            assertTrue(p.name.isNotEmpty())
            assertTrue(p.weight > 0)
            assertTrue("字段内禁 |：${p.id}/${p.name}", "|" !in p.id && "|" !in p.name && "|" !in p.color)
            assertTrue("color #RRGGBB 大写：${p.color}", Regex("^#[0-9A-F]{6}$").matches(p.color))
        }
        assertEquals(listOf(1, 2, 5, 8, 12, 20, 25, 27), PRIZES.map { it.weight }) // 权重面（§6.6）
        assertEquals(7, PRIZES.count { "·" in it.name }) // name 分隔符 U+00B7 恰 7 个奖项；P08 谢谢参与无分隔符
        assertTrue("P08 谢谢参与无分隔符", "·" !in PRIZES.last().name)
        assertEquals("谢谢参与", PRIZES.last().name)
        // 每个含分隔符的 name 的中点是 U+00B7（非 U+30FB——V8d 码点判别）
        PRIZES.dropLast(1).forEach { p ->
            assertTrue(p.name.contains('·') && !p.name.contains('・'))
        }
    }

    /** slug: prize_pool_serialization_hash —— 运行时重算序列化 → SHA-256 + 字节数（V8a~V8d/V9）。 */
    @Test
    fun `prize_pool_serialization_hash`() {
        val canonical = PRIZES
            .sortedBy { it.id } // id 升序逐行
            .joinToString("\n") { "${it.id}|${it.name}|${it.weight}|${it.color}" } // LF 连接、行尾无换行
        val bytes = canonical.toByteArray(Charsets.UTF_8)
        assertEquals(POOL_BYTES.toLong(), bytes.size.toLong()) // 295B（8 行 288B + 7 LF）
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }
        assertEquals(POOL_SHA256, digest) // 2abf42c6…c901cd33
    }

    /** slug: seed_constant —— SEED==20261011 且 uint32 非零（零态自锁禁令 V7b）。 */
    @Test
    fun `seed_constant`() {
        assertEquals(20261011, SEED.toLong())
        assertTrue(SEED.toLong() and 0xFFFFFFFFL != 0L) // 非零（uint32 位型视角）
        // 常量直断言（§8）：PRIZE_COUNT/TOTAL_WEIGHT/CUMULATIVE/POOL_BYTES
        assertEquals(8, PRIZES.size)
        assertEquals(100, TOTAL_WEIGHT)
        assertTrue(CUMULATIVE.contentEquals(intArrayOf(1, 3, 8, 16, 28, 48, 73, 100))) // 前缀和
        assertEquals(295, POOL_BYTES)
        assertEquals(100, PRIZES.sumOf { it.weight }) // 权重和 == TOTAL_WEIGHT
        assertEquals(TOTAL_WEIGHT, CUMULATIVE.last()) // 末项 == TOTAL_WEIGHT
    }

    // ---------- 确定性核心（§2.1~2.3 + §6.2/§6.4） ----------

    /** slug: deterministic_first_draw —— drawIndex(SEED,1) == 5（P06 六等奖·100积分）。 */
    @Test
    fun `deterministic_first_draw`() {
        assertEquals(5, WheelCore.drawIndex(SEED, serial = 1))
        assertEquals("P06", PRIZES[WheelCore.drawIndex(SEED, 1)].id)
    }

    /** slug: deterministic_draw_sequence —— serial=1..12 主锚点 + 13..24 扩展锚点（V10 防窗口拟合）。 */
    @Test
    fun `deterministic_draw_sequence`() {
        val expected = listOf(5, 6, 5, 7, 3, 6, 6, 1, 6, 5, 3, 6) // §6.2
        assertEquals(expected, (1..12).map { WheelCore.drawIndex(SEED, it) })
        val extended = listOf(4, 4, 5, 6, 4, 5, 2, 5, 6, 4, 6, 7) // §6.2 扩展（serial=13..24）
        assertEquals(extended, (13..24).map { WheelCore.drawIndex(SEED, it) })
    }

    /** slug: draw_advances_state —— 状态推进使不同 serial 结果可不同（5 个不同奖品）。 */
    @Test
    fun `draw_advances_state`() {
        val seq = (1..12).map { WheelCore.drawIndex(SEED, it) }
        assertEquals(5, seq.distinct().size) // P02/P04/P06/P07/P08（§2.3 注 3）
        assertEquals(setOf(1, 3, 5, 6, 7), seq.distinct().toSet())
        // PRNG 逐位锚点（§6.4，★ P-1）：nextU32(20261011)=549735040；serial=2 state bit31 置位
        assertEquals(549735040L, WheelCore.nextU32(SEED).toLong() and 0xFFFFFFFFL)
        val s2 = WheelCore.nextU32(549735040)
        assertEquals(2602030858L, s2.toLong() and 0xFFFFFFFFL) // 0x9B17D70A
        assertEquals(-1692936438, s2) // Kotlin Int 位型视角（bit31 置位 → 负值）
        // V5 构造判别：bit31 置位 state 经 Long 域取模 → 正确 index 6（负模变异恒 0）
        assertEquals(6, WheelCore.weightedIndex(s2))
    }

    /** slug: weighted_pick_boundary —— r 构造点 + 区间长度==权重（§6.3 全 100 点连续无洞）。 */
    @Test
    fun `weighted_pick_boundary`() {
        // 10 构造点（§6.8）：r=0→0（一等奖）、r=1→1（V4 严格大于判别点）、r=2→1、r=3→2、r=7→2、
        // r=8→3、r=27→4、r=28→5、r=73→7、r=99→7（谢谢参与）
        assertEquals(0, WheelCore.weightedIndex(0))
        assertEquals(1, WheelCore.weightedIndex(1))
        assertEquals(1, WheelCore.weightedIndex(2))
        assertEquals(2, WheelCore.weightedIndex(3))
        assertEquals(2, WheelCore.weightedIndex(7))
        assertEquals(3, WheelCore.weightedIndex(8))
        assertEquals(4, WheelCore.weightedIndex(27))
        assertEquals(5, WheelCore.weightedIndex(28))
        assertEquals(7, WheelCore.weightedIndex(73))
        assertEquals(7, WheelCore.weightedIndex(99))
        // 区间长度 == 权重：r=0..99 全 100 点逐点归类，8 区间长度 == [1,2,5,8,12,20,25,27]
        val counts = IntArray(PRIZES.size)
        for (r in 0..99) counts[WheelCore.weightedIndex(r)]++
        assertEquals(listOf(1, 2, 5, 8, 12, 20, 25, 27), counts.toList())
        // 全域非负且落界内（Long 域取模防负模——V5）
        for (r in 0..99) assertTrue(WheelCore.weightedIndex(r) in 0..7)
    }

    /** slug: no_random_source —— 确定性/幂等：同 seed 同 serial 重算恒等（零随机/零时间源；D8 静态检查另归 Tester）。 */
    @Test
    fun `no_random_source`() {
        repeat(100) {
            assertEquals(5, WheelCore.drawIndex(SEED, 1))
            assertEquals(6, WheelCore.drawIndex(SEED, 2))
        }
        // 幂等：连续调用互不扰动（无状态残留——state 从 seed 重算）
        val a = (1..12).map { WheelCore.drawIndex(SEED, it) }
        val b = (1..12).map { WheelCore.drawIndex(SEED, it) }
        assertEquals(a, b)
        // V6 判别注记：0 基实现（推进 serial-1 次）序列左移——此处断言 1 基正确性
        assertNotEquals(WheelCore.drawIndex(SEED, 1), run {
            var state = SEED
            repeat(0) { state = WheelCore.nextU32(state) } // 0 基变异等价形态
            WheelCore.weightedIndex(state)
        })
    }

    /** slug: prize_pool_immutable —— 多次 drawIndex 后 PRIZES 逐字段不变（§6.6）。 */
    @Test
    fun `prize_pool_immutable`() {
        val before = PRIZES.map { listOf(it.id, it.name, it.weight.toString(), it.color) }
        (1..50).forEach { WheelCore.drawIndex(SEED, it) }
        AppRepo.reset()
        repeat(5) { AppRepo.draw() }
        WheelCore.weightedIndex(-1692936438) // 负位型输入也不改常量表
        val after = PRIZES.map { listOf(it.id, it.name, it.weight.toString(), it.color) }
        assertEquals(before, after) // 深比较逐字段
    }

    /** slug: wheel_render_8_sectors —— §1.1 Index↔扇区几何：8 扇区均分 360° 连续无洞（渲染本体走 Tester UI 实测截图）。 */
    @Test
    fun `wheel_render_8_sectors`() {
        val sector = 360f / PRIZES.size
        assertEquals(45f, sector, 1e-6f) // 均分 8 格
        val centers = (0 until PRIZES.size).map { it * sector + sector / 2f } // i*45+22.5（从 12 点钟顺时针）
        assertEquals(8, centers.distinct().size)
        centers.forEach { assertTrue(it >= 0f && it < 360f) }
        val sorted = centers.sorted() // 连续无洞：相邻中心差恒 45°，环形首尾闭合
        (1 until sorted.size).forEach { assertEquals(sector, sorted[it] - sorted[it - 1], 1e-4f) }
        assertEquals(sector, sorted.first() + 360f - sorted.last(), 1e-4f)
        assertEquals(8, PRIZES.map { it.color }.distinct().size) // 8 色互异（扇区渲染辨识度，展示态弱断言）
    }

    /** slug: wheel_angle_display_layer —— 展示层弱断言：8 停位角存在、单调递减、∈(1800,2160]（不入对账）。 */
    @Test
    fun `wheel_angle_display_layer`() {
        val angles = (0..7).map { WheelCore.angleForIndex(it) }
        assertEquals(8, angles.size)
        assertEquals(8, angles.distinct().size) // 存在性：8 个不同停位角
        assertEquals(angles.sortedDescending(), angles) // 单调递减（§2.4 锚点序列形状）
        angles.forEach { assertTrue(it > 1800f && it <= 2160f) } // 5 圈整转 + 回转角范围
    }

    // ---------- 平台层语义（§3 AppRepo + §6.5） ----------

    /** slug: history_record_draw —— 连抽 3 次 [1:P06, 2:P07, 3:P06] + serial 单调 1 基推进。 */
    @Test
    fun `history_record_draw`() {
        AppRepo.reset() // object 单例：每用例自净起点
        assertEquals(1, AppRepo.currentSerial()) // 1 基（reset 归 1）
        assertEquals(5, AppRepo.nextDraw()) // 预览 == drawIndex(SEED,1)，不落账
        assertTrue(AppRepo.listHistory().isEmpty()) // nextDraw 未推进未落账
        val rec1 = AppRepo.draw()
        val rec2 = AppRepo.draw()
        val rec3 = AppRepo.draw()
        assertEquals(1, rec1.serial); assertEquals(5, rec1.prizeIndex); assertEquals("P06", rec1.prizeId)
        assertEquals(2, rec2.serial); assertEquals(6, rec2.prizeIndex); assertEquals("P07", rec2.prizeId)
        assertEquals(3, rec3.serial); assertEquals(5, rec3.prizeIndex); assertEquals("P06", rec3.prizeId)
        assertEquals(listOf("1:P06", "2:P07", "3:P06"), AppRepo.listHistory().map { it.serialize() }) // §6.5
        assertEquals("1:P06\n2:P07\n3:P06", DrawRecord.serializeAll(AppRepo.listHistory())) // LF 连接
        assertEquals(4, AppRepo.currentSerial()) // 单调递增（每抽一次 +1）
    }

    /** slug: reset_draw_history —— 原子清历史 + serial 归 1 + 幂等闭环（再抽 == 第 1 次结果）。 */
    @Test
    fun `reset_draw_history`() {
        AppRepo.reset()
        repeat(3) { AppRepo.draw() } // 污染状态
        assertTrue(AppRepo.listHistory().isNotEmpty())
        AppRepo.reset() // 原子：历史清空与 serial 归 1 同一操作（无「历史空但 serial>1」中间态）
        assertTrue(AppRepo.listHistory().isEmpty())
        assertEquals(1, AppRepo.currentSerial())
        assertEquals(5, AppRepo.nextDraw()) // reset 后 nextDraw() == drawIndex(SEED,1) == 5
        val after = AppRepo.draw()
        assertEquals(5, after.prizeIndex) // 幂等闭环：与第 1 次结果相同
        assertEquals(1, after.serial)
        assertEquals("1:P06", AppRepo.listHistory().single().serialize())
    }

    /** slug: spin_draw_prize —— §2.5 双状态机封闭性：导航 3 有效 + 1 忽略；相位 5 有效 + 忽略；AppRepo 对账。 */
    @Test
    fun `spin_draw_prize`() {
        // 导航状态机全集（§6.7：2 态 × 2 事件 = 3 有效 + 1 忽略）
        assertEquals(NavOutcome.HISTORY, WheelStateMachine.nextNav(NavState.WHEEL, NavEvent.OPEN_HISTORY))
        assertEquals(NavOutcome.WHEEL, WheelStateMachine.nextNav(NavState.HISTORY, NavEvent.BACK))
        assertEquals(NavOutcome.EXIT_APP, WheelStateMachine.nextNav(NavState.WHEEL, NavEvent.BACK)) // 根态退出
        assertEquals(NavOutcome.IGNORED, WheelStateMachine.nextNav(NavState.HISTORY, NavEvent.OPEN_HISTORY)) // 忽略
        // 路由字面量双端 1:1（"wheel"/"history"）
        assertEquals("wheel", NavState.WHEEL.route)
        assertEquals("history", NavState.HISTORY.route)

        // 相位状态机主链：idle→spinning（targetIndex = drawIndex(SEED, serial)）→result→idle
        AppRepo.reset()
        val s1 = WheelStateMachine.nextPhase(PhaseState.INITIAL, PhaseEvent.SPIN, serial = 1)
        assertEquals(SpinPhase.SPINNING, s1?.phase)
        assertEquals(5, s1?.targetIndex) // == drawIndex(SEED,1)（§2.5 payload 契约）
        assertEquals(1, s1?.serial)
        val settled = WheelStateMachine.nextPhase(s1!!, PhaseEvent.SETTLED, settledIndex = 5)
        assertEquals(SpinPhase.RESULT, settled?.phase)
        assertEquals(5, settled?.prizeIndex) // settled 仅在 targetIndex 到达时发出
        val idle = WheelStateMachine.nextPhase(settled!!, PhaseEvent.CLOSE_RESULT)
        assertEquals(SpinPhase.IDLE, idle?.phase)

        // 连抽（result 相位 spin：弹窗不关也可再抽，serial 已 +1）
        val s2 = WheelStateMachine.nextPhase(settled, PhaseEvent.SPIN, serial = 2)
        assertEquals(SpinPhase.SPINNING, s2?.phase)
        assertEquals(6, s2?.targetIndex) // drawIndex(SEED,2)

        // reset 任意相位归 idle（spinning/result 中 reset 均有效）
        assertEquals(SpinPhase.IDLE, WheelStateMachine.nextPhase(s1, PhaseEvent.RESET)?.phase)
        assertEquals(SpinPhase.IDLE, WheelStateMachine.nextPhase(settled, PhaseEvent.RESET)?.phase)
        assertEquals(SpinPhase.IDLE, WheelStateMachine.nextPhase(PhaseState.INITIAL, PhaseEvent.RESET)?.phase)

        // 忽略组合（未列出 = 无效转移 → null，禁崩溃禁隐式跳转）
        assertNull(WheelStateMachine.nextPhase(s1, PhaseEvent.SPIN, serial = 2)) // spinning 中再 spin
        assertNull(WheelStateMachine.nextPhase(PhaseState.INITIAL, PhaseEvent.SETTLED, settledIndex = 0)) // idle 中 settled
        assertNull(WheelStateMachine.nextPhase(PhaseState.INITIAL, PhaseEvent.CLOSE_RESULT)) // idle 中 closeResult
        assertNull(WheelStateMachine.nextPhase(s1, PhaseEvent.CLOSE_RESULT)) // spinning 中 closeResult

        // 相位/事件字面量双端 1:1
        assertEquals("idle", SpinPhase.IDLE.literal)
        assertEquals("spinning", SpinPhase.SPINNING.literal)
        assertEquals("result", SpinPhase.RESULT.literal)
        assertEquals(listOf("spin", "settled", "closeResult", "reset"),
            listOf(PhaseEvent.SPIN, PhaseEvent.SETTLED, PhaseEvent.CLOSE_RESULT, PhaseEvent.RESET).map { it.literal })
    }
}
