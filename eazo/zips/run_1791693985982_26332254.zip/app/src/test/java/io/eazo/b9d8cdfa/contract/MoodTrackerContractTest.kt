package io.eazo.b9d8cdfa.contract

import io.eazo.b9d8cdfa.core.MoodCore
import io.eazo.b9d8cdfa.core.MoodCore.NavEvent
import io.eazo.b9d8cdfa.core.MoodCore.NavState
import io.eazo.b9d8cdfa.core.MoodCore.PickEvent
import io.eazo.b9d8cdfa.core.MoodCore.PickPhase
import io.eazo.b9d8cdfa.data.MOOD_IDS
import io.eazo.b9d8cdfa.data.MOOD_TAGS
import io.eazo.b9d8cdfa.data.TAGS_BYTES
import io.eazo.b9d8cdfa.data.TAGS_SHA256
import io.eazo.b9d8cdfa.model.MOOD_COUNT
import io.eazo.b9d8cdfa.platform.MoodRepository
import io.eazo.b9d8cdfa.platform.MoodStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.security.MessageDigest
import java.util.Locale

/**
 * REQ-021 契约用例（eazo-cases-1.0.0，14 条 slug 逐字；锚点全集 = 契约 §6 同集展开）。
 * 全部 JVM 纯逻辑：仓储注入内存假件 + 固定日期（20737 等），零 Android 框架依赖。
 */
class MoodTrackerContractTest {

    /** 内存假件存储（重启 = 同 store 新建仓储实例）。 */
    private class InMemoryStore : MoodStore {
        var lines: List<String> = emptyList()
        override fun readLines(): List<String> = lines
        override fun writeLines(lines: List<String>) { this.lines = lines }
    }

    private fun repo(today: Int = 20737, store: MoodStore = InMemoryStore()): MoodRepository =
        MoodRepository(store, today, 2026, 10, 11)

    // C01 mood_pick_save｜选择心情标签保存 → 保存当天记录（按日期存档）+ 覆写幂等/单日顶替/状态机
    @Test
    fun mood_pick_save() {
        val r = repo(today = 20737)
        assertEquals(PickPhase.NONE, r.phase)
        r.pick("M01")
        assertEquals(PickPhase.PICKED, r.phase)
        assertEquals("M01", r.selected)
        val rec = r.save("今天很好")
        assertEquals("20737|M01", rec!!.key)
        assertEquals(20737, rec.dateEpochDay)
        assertEquals("M01", rec.moodId)
        assertEquals(1, r.records.size)
        assertEquals(PickPhase.SAVED, r.phase)
        r.save("换个说法") // 同键覆盖写：幂等，仍 1 条
        assertEquals(1, r.records.size)
        assertEquals("换个说法", r.records[0].note)
        r.pick("M03") // saved→picked 再打卡
        assertEquals(PickPhase.PICKED, r.phase)
        r.save("改记录")
        assertEquals(1, r.records.size) // 单日一条：同日换标签顶替旧记录
        assertEquals("20737|M03", r.records[0].key)
        r.resetSelection() // reset 只清选择不清库
        assertEquals(PickPhase.NONE, r.phase)
        assertEquals(1, r.records.size)
        // §2.5 状态机封闭性：导航 3 有效 + 1 忽略；相位 4 有效 + 忽略
        assertEquals(NavState.HISTORY, MoodCore.nextNav(NavState.HOME, NavEvent.OPEN_HISTORY))
        assertEquals(NavState.HOME, MoodCore.nextNav(NavState.HISTORY, NavEvent.BACK))
        assertEquals(NavState.HOME, MoodCore.nextNav(NavState.HOME, NavEvent.BACK))
        assertEquals(NavState.HISTORY, MoodCore.nextNav(NavState.HISTORY, NavEvent.OPEN_HISTORY)) // 忽略原态
        assertEquals(PickPhase.PICKED, MoodCore.nextPhase(PickPhase.NONE, PickEvent.PICK))
        assertEquals(PickPhase.PICKED, MoodCore.nextPhase(PickPhase.PICKED, PickEvent.PICK))
        assertEquals(PickPhase.SAVED, MoodCore.nextPhase(PickPhase.PICKED, PickEvent.SAVE))
        assertEquals(PickPhase.PICKED, MoodCore.nextPhase(PickPhase.SAVED, PickEvent.PICK))
        assertEquals(PickPhase.NONE, MoodCore.nextPhase(PickPhase.SAVED, PickEvent.RESET))
        assertEquals(PickPhase.NONE, MoodCore.nextPhase(PickPhase.NONE, PickEvent.SAVE)) // 忽略
    }

    // C02 mood_tags_5_items｜5 个固定标签（开心/平静/难过/生气/疲惫）
    @Test
    fun mood_tags_5_items() {
        assertEquals(5, MOOD_TAGS.size)
        assertEquals(MOOD_COUNT, MOOD_TAGS.size)
        assertEquals(listOf("M01", "M02", "M03", "M04", "M05"), MOOD_TAGS.map { it.id })
        assertEquals(listOf("开心", "平静", "难过", "生气", "疲惫"), MOOD_TAGS.map { it.name })
        assertEquals(MOOD_IDS, MOOD_TAGS.map { it.id })
    }

    // C03 mood_note_optional｜一句话可选：可空、可填
    @Test
    fun mood_note_optional() {
        val r = repo(today = 20737)
        r.pick("M01")
        assertEquals("", r.save("")!!.note) // 可空
        assertEquals(1, r.records.size)
        r.pick("M01")
        assertEquals("开心的一天", r.save("开心的一天")!!.note) // 可填
        assertEquals(1, r.records.size) // 同键覆写，仍 1 条
        val long = "长".repeat(300)
        r.pick("M01")
        assertEquals(200, r.save(long)!!.note.length) // ≤200 业务建议截断
    }

    // C04 deterministic_record_key｜同日期同标签 → 同键（3 锚点 + 3 性质）
    @Test
    fun deterministic_record_key() {
        assertEquals("20737|M01", MoodCore.moodRecordKey(20737, "M01"))
        assertEquals("20737|M03", MoodCore.moodRecordKey(20737, "M03"))
        assertEquals("20738|M01", MoodCore.moodRecordKey(20738, "M01"))
        // 性质：同输入两次相等；同日期不同标签不等；不同日期同标签不等
        assertEquals(MoodCore.moodRecordKey(20737, "M02"), MoodCore.moodRecordKey(20737, "M02"))
        assertTrue(MoodCore.moodRecordKey(20737, "M01") != MoodCore.moodRecordKey(20737, "M02"))
        assertTrue(MoodCore.moodRecordKey(20737, "M01") != MoodCore.moodRecordKey(20738, "M01"))
        assertFalse(MoodCore.moodRecordKey(20737, "M01").contains('｜')) // 半角竖线，禁全角 U+FF5C
        assertFalse(MoodCore.moodRecordKey(20737, "M01").contains(',')) // 禁千分位/locale 格式化
    }

    // C05 date_epoch_day｜daysFromCivil 8 锚点 + 强化锚点 + 逆变换 roundtrip
    @Test
    fun date_epoch_day() {
        assertEquals(0, MoodCore.daysFromCivil(1970, 1, 1))
        assertEquals(20454, MoodCore.daysFromCivil(2026, 1, 1))
        assertEquals(20727, MoodCore.daysFromCivil(2026, 10, 1))
        assertEquals(20737, MoodCore.daysFromCivil(2026, 10, 11))
        assertEquals(20757, MoodCore.daysFromCivil(2026, 10, 31))
        assertEquals(19782, MoodCore.daysFromCivil(2024, 2, 29))
        assertEquals(19417, MoodCore.daysFromCivil(2023, 2, 29)) // 平年 2/29 归一化不抛异常
        assertEquals(MoodCore.daysFromCivil(2023, 3, 1), MoodCore.daysFromCivil(2023, 2, 29))
        // 强化锚点（P-1）：闰年差 1 / 世纪规则 / 400 年周期
        assertEquals(19783, MoodCore.daysFromCivil(2024, 3, 1))
        assertEquals(1, MoodCore.daysFromCivil(2100, 3, 1) - MoodCore.daysFromCivil(2100, 2, 28))
        assertEquals(2, MoodCore.daysFromCivil(2400, 3, 1) - MoodCore.daysFromCivil(2400, 2, 28))
        assertEquals(146097, MoodCore.daysFromCivil(2370, 1, 1) - MoodCore.daysFromCivil(1970, 1, 1))
        // 逆变换 roundtrip（展示辅助兜底）
        assertEquals(Triple(2026, 10, 11), MoodCore.civilFromEpochDay(20737))
        assertEquals(Triple(1970, 1, 1), MoodCore.civilFromEpochDay(0))
        for ((y, m, d) in listOf(Triple(2024, 2, 29), Triple(2023, 3, 1), Triple(2100, 2, 28))) {
            assertEquals(Triple(y, m, d), MoodCore.civilFromEpochDay(MoodCore.daysFromCivil(y, m, d)))
        }
    }

    // C06 distribution_count｜样本 A/B 计数 + 边界（空/域外跳过）
    @Test
    fun distribution_count() {
        // 样本 A：2026-10 整月 31 条（PRD §11 固定序列口径：10/16/3/1/1）
        val sampleA = List(10) { "M01" } + List(16) { "M02" } + List(3) { "M03" } +
            listOf("M04", "M05")
        val a = MoodCore.moodDistribution(sampleA)
        assertEquals(10, a.counts["M01"])
        assertEquals(16, a.counts["M02"])
        assertEquals(3, a.counts["M03"])
        assertEquals(1, a.counts["M04"])
        assertEquals(1, a.counts["M05"])
        assertEquals(31, a.total)
        assertEquals(a.counts.values.sum(), a.total) // sum == total
        val sampleB = listOf("M01", "M01", "M01", "M01", "M02", "M02", "M02", "M02", "M02",
            "M03", "M03", "M03", "M04", "M05") // 14 条：4/5/3/1/1
        val b = MoodCore.moodDistribution(sampleB)
        assertEquals(listOf(4, 5, 3, 1, 1), MOOD_IDS.map { b.counts[it] })
        assertEquals(14, b.total)
        val empty = MoodCore.moodDistribution(emptyList()) // 空样本全 0
        assertEquals(0, empty.total)
        assertTrue(empty.counts.values.all { it == 0 })
        val outlier = MoodCore.moodDistribution(listOf("M01", "XX", "M01")) // 域外跳过
        assertEquals(2, outlier.total)
        assertEquals(2, outlier.counts["M01"])
    }

    // C07 distribution_permille｜千分比锚点（整数域 floor 除法）
    @Test
    fun distribution_permille() {
        val a = MoodCore.moodDistribution(List(10) { "M01" } + List(16) { "M02" } +
            List(3) { "M03" } + listOf("M04", "M05"))
        assertEquals(322, a.permille["M01"]) // 10*1000/31=322.58 → floor 322
        assertEquals(516, a.permille["M02"])
        assertEquals(96, a.permille["M03"]) // 96.77 → 96（round 97 错，V2）
        assertEquals(32, a.permille["M04"])
        assertEquals(32, a.permille["M05"])
        assertEquals(998, a.permille.values.sum()) // floor 合计域 [996,1000]
        val b = MoodCore.moodDistribution(List(4) { "M01" } + List(5) { "M02" } +
            List(3) { "M03" } + listOf("M04", "M05"))
        assertEquals(listOf(285, 357, 214, 71, 71), MOOD_IDS.map { b.permille[it] })
        val single = MoodCore.moodDistribution(listOf("M02")) // 单条样本 1000
        assertEquals(1000, single.permille["M02"])
        assertEquals(0, MoodCore.moodDistribution(emptyList()).permille["M01"]) // 空全 0
        val uniform = MoodCore.moodDistribution(List(3) { "M01" } + List(3) { "M02" } +
            List(3) { "M03" } + List(3) { "M04" } + List(3) { "M05" }) // 均匀 200×5 恰 1000
        assertTrue(uniform.permille.values.all { it == 200 })
        assertEquals(1000, uniform.permille.values.sum())
    }

    // C08 mood_tags_serialization_hash｜运行时哈希自证（SHA-256 + 119B）
    @Test
    fun mood_tags_serialization_hash() {
        val serialized = MoodCore.serializeMoodTags()
        val bytes = serialized.toByteArray(Charsets.UTF_8)
        assertEquals(TAGS_BYTES, bytes.size)
        assertEquals(119, bytes.size)
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        val hex = digest.joinToString("") { String.format(Locale.ROOT, "%02x", it) }
        assertEquals(TAGS_SHA256, hex)
        assertEquals("fc4fbbd6239d87a801cdaf5f1e7374ebf1579e3a8ebb36ccf9e55a126237fc97", hex)
        assertFalse(serialized.contains('\r')) // LF 而非 CRLF
        assertFalse(serialized.endsWith("\n")) // 行尾无换行
        assertTrue(serialized.contains('|') && !serialized.contains('｜')) // 半角竖线
    }

    // C09 calendar_heatmap_color｜moodColorForId 查表 ×5（数据态）
    @Test
    fun calendar_heatmap_color() {
        assertEquals("#FFD93D", MoodCore.moodColorForId("M01"))
        assertEquals("#6BCB77", MoodCore.moodColorForId("M02"))
        assertEquals("#4D96FF", MoodCore.moodColorForId("M03"))
        assertEquals("#FF6B6B", MoodCore.moodColorForId("M04"))
        assertEquals("#9B9B9B", MoodCore.moodColorForId("M05"))
        assertNull(MoodCore.moodColorForId("M99")) // 非法禁崩溃
    }

    // C10 month_calendar_render｜月历数据面：31 槽位 + 首日偏移（2026-10-01 星期四）+ 日→标签映射
    @Test
    fun month_calendar_render() {
        val (offset, days) = MoodCore.monthGrid(2026, 10)
        assertEquals(31, days)
        assertEquals(4, offset) // 星期四（周日=0 起）
        assertEquals(31, MoodCore.monthGrid(2026, 1).second)
        assertEquals(28, MoodCore.monthGrid(2023, 2).second) // 平年 2 月
        assertEquals(29, MoodCore.monthGrid(2024, 2).second) // 闰年 2 月
        val store = InMemoryStore()
        val r1 = MoodRepository(store, todayEpochDay = 20737, todayY = 2026, todayM = 10, todayD = 11)
        r1.pick("M01"); r1.save("今天")
        val r2 = MoodRepository(store, todayEpochDay = 20727, todayY = 2026, todayM = 10, todayD = 1)
        r2.pick("M02"); r2.save("月初")
        val byDay = r2.recordsByMonth(2026, 10)
        assertEquals(2, byDay.size)
        assertEquals("M01", byDay[20737])
        assertEquals("M02", byDay[20727])
        assertTrue(byDay.keys.all { it in 20727..20757 }) // 月域界内
        assertTrue(r2.recordsByMonth(2026, 9).isEmpty()) // 邻月不相干
    }

    // C11 mood_tags_immutable｜标签 5 项名称/颜色/emoji 恒定不变
    @Test
    fun mood_tags_immutable() {
        val snapshot = MOOD_TAGS.map { listOf(it.id, it.name, it.color, it.emoji) }
        repeat(3) {
            MoodCore.moodDistribution(listOf("M01", "M02"))
            MoodCore.moodColorForId("M03")
            MoodCore.serializeMoodTags()
            val r = repo(today = 20737 + it)
            r.pick("M05"); r.save("第${it}次")
        }
        assertEquals(snapshot, MOOD_TAGS.map { listOf(it.id, it.name, it.color, it.emoji) }) // 深比较不变
        assertSame(MOOD_TAGS, MOOD_TAGS) // 同一引用（只读常量）
        assertEquals(listOf("M01", "M02", "M03", "M04", "M05"), MOOD_IDS) // 升序恒定
        assertEquals(MoodCore.serializeMoodTags(), MoodCore.serializeMoodTags()) // 序列化稳定
    }

    // C12 no_random_source｜core/data/model 层无真随机源/无时间源（D8 静态检查）
    @Test
    fun no_random_source() {
        val banned = listOf(
            "Math.random", "java.util.Random", "kotlin.random",
            "System.currentTimeMillis", "System.nanoTime", "SystemClock",
            "java.util.Date", "LocalDate", "Calendar", "Thread.sleep", "UUID",
        )
        val base = File("src/main/java/io/eazo/b9d8cdfa")
        assertTrue("源码根应存在（工作目录=app 模块）: ${base.absolutePath}", base.isDirectory)
        val dirs = listOf("core", "data", "model")
        var scanned = 0
        for (d in dirs) {
            val dir = File(base, d)
            assertTrue("$d 目录应存在", dir.isDirectory)
            for (f in dir.listFiles()!!.filter { it.name.endsWith(".kt") }) {
                val src = f.readText()
                for (token in banned) {
                    assertFalse("${f.name} 含禁用 API：$token", src.contains(token))
                }
                scanned++
            }
        }
        assertEquals(3, scanned) // core/data/model 各 1 文件
    }

    // C13 local_storage_persist｜打卡 → 重启（新仓储实例同 store）记录仍在
    @Test
    fun local_storage_persist() {
        val store = InMemoryStore()
        val day1 = MoodRepository(store, todayEpochDay = 20737, todayY = 2026, todayM = 10, todayD = 11)
        day1.pick("M01"); day1.save("第一天")
        val day2 = MoodRepository(store, todayEpochDay = 20738, todayY = 2026, todayM = 10, todayD = 12)
        day2.pick("M02"); day2.save("第二天")
        val restarted = MoodRepository(store, todayEpochDay = 20739, todayY = 2026, todayM = 10, todayD = 13)
        assertEquals(2, restarted.records.size) // 重启记录仍在
        assertEquals(listOf(20738, 20737), restarted.records.map { it.dateEpochDay }) // 降序主键
        assertEquals("第一天", restarted.records.first { it.dateEpochDay == 20737 }.note)
        restarted.pick("M05")
        restarted.resetSelection() // reset 只清选择不清库
        assertNull(restarted.selected)
        assertEquals(2, restarted.records.size)
    }

    // C14 multiscreen_adaptive｜600dp 单列 ↔ 双列阈值（Should，纯函数判定）
    @Test
    fun multiscreen_adaptive() {
        assertEquals(600, MoodCore.TWO_PANE_MIN_DP)
        assertFalse(MoodCore.isTwoPane(599)) // 手机竖屏 → 单列
        assertTrue(MoodCore.isTwoPane(600)) // 平板横屏 → 双列
        assertTrue(MoodCore.isTwoPane(800))
        assertFalse(MoodCore.isTwoPane(360))
    }
}
