package io.eazo.b9d8cdfa.model

/**
 * REQ-021 数据模型（契约 §1.1，与鸿蒙 ArkTS 端 1:1——字段名/类型语义完全一致）。
 *
 * 排序契约（生成器硬规则 ③，双端一致）：records 列表按
 * dateEpochDay 降序（近日常在前）为主键、moodId 字典序升序为次键兜底。
 */
data class MoodRecord(
    val key: String,          // = moodRecordKey(dateEpochDay, moodId)，如 "20737|M01"
    val dateEpochDay: Int,    // 自 1970-01-01 起天数（daysFromCivil 产出）
    val moodId: String,       // "M01".."M05"
    val note: String          // 一句话可选记录：自由文本，不入对账口径/不入哈希
)

/** 心情分布统计结果（契约 §2.3，整数域——零浮点）。 */
data class Distribution(
    val counts: Map<String, Int>,     // moodId → 次数（仅合法 5 标签键）
    val total: Int,                   // 合法标签计数合计
    val permille: Map<String, Int>    // moodId → 千分比 0..1000（floor(count*1000/total)）
)

const val MOOD_COUNT = 5
