package io.eazo.b9d8cdfa.core

import io.eazo.b9d8cdfa.data.MOOD_IDS
import io.eazo.b9d8cdfa.data.MOOD_TAGS
import io.eazo.b9d8cdfa.model.Distribution

/**
 * REQ-021 确定性核心（契约 §2）——纯函数族，对账主战场。
 * 禁 IO/网络/随机/时钟/UI API（契约 §8 禁用清单，D8 静态检查域）。
 * 双端等价：Kotlin Int 整除天然向零截断，与 ArkTS Math.trunc 全等（正值域）。
 */
object MoodCore {

    // ===== §2.1 daysFromCivil(y0, m, d) → EpochDay（Howard Hinnant 纯整数算法）=====
    // 输入域 y ≥ 1970；平年 2/29 天然归一化到 3/1 不抛异常（V5）；4 处除法全部向零截断。
    fun daysFromCivil(y0: Int, m: Int, d: Int): Int {
        val y = if (m <= 2) y0 - 1 else y0
        val era = y / 400
        val yoe = y - era * 400
        val doy = (153 * (m + (if (m > 2) -3 else 9)) + 2) / 5 + d - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146097 + doe - 719468
    }

    // ===== §2.2 moodRecordKey(dateEpochDay, moodId)——同日期+同标签 → 同键 → 同记录 =====
    // 分隔符 U+007C 半角竖线；epoch-day 十进制在前；无 locale/千分位。
    fun moodRecordKey(d: Int, id: String): String = "$d|$id"

    // ===== §2.3 moodDistribution(moodIds)——整数域计数 + floor 千分比（零浮点）=====
    // 域外标签跳过；total==0 时 permille 全 0（禁除零异常）。
    fun moodDistribution(moodIds: List<String>): Distribution {
        val counts = linkedMapOf<String, Int>()
        for (id in MOOD_IDS) counts[id] = 0
        for (id in moodIds) {
            if (counts.containsKey(id)) counts[id] = counts[id]!! + 1
        }
        var total = 0
        for (v in counts.values) total += v
        val permille = linkedMapOf<String, Int>()
        for (id in MOOD_IDS) {
            permille[id] = if (total == 0) 0 else counts[id]!! * 1000 / total
        }
        return Distribution(counts, total, permille)
    }

    // ===== §2.4 moodColorForId(moodId)——纯查表（数据态可测；渲染为展示态）=====
    // 非法 moodId 返回 null（禁崩溃；本域内不发生）。
    fun moodColorForId(moodId: String): String? =
        MOOD_TAGS.firstOrNull { it.id == moodId }?.color

    // ===== §4 标签规范序列化：id|name|color|emoji 按 id 升序 LF 连接、行尾无换行 UTF-8 =====
    // 运行时哈希自证用（双端单测各断言一次）；字段内禁 |。
    fun serializeMoodTags(): String =
        MOOD_TAGS.sortedBy { it.id }.joinToString("\n") { "${it.id}|${it.name}|${it.color}|${it.emoji}" }

    // ===== §3 月历数据面辅助：monthGrid(y, m) → (首日星期偏移, 当月天数) =====
    // 偏移以周日=0 起（1970-01-01 星期四 → (0+4)%7==4）；2026-10-01 == 20727 → 偏移 4。
    fun monthGrid(y: Int, m: Int): Pair<Int, Int> {
        val first = daysFromCivil(y, m, 1)
        val nextFirst = if (m == 12) daysFromCivil(y + 1, 1, 1) else daysFromCivil(y, m + 1, 1)
        val offset = (first + 4) % 7
        return Pair(offset, nextFirst - first)
    }

    // ===== 展示辅助：civilFromEpochDay——daysFromCivil 逆变换（Hinnant civil_from_days）=====
    // 纯整数；UI 历史列表日期显示用（不入对账锚点，roundtrip 由单测兜底）。
    fun civilFromEpochDay(z0: Int): Triple<Int, Int, Int> {
        val z = z0 + 719468
        val era = z / 146097
        val doe = z - era * 146097
        val yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365
        var y = yoe + era * 400
        val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
        val mp = (5 * doy + 2) / 153
        val d = doy - (153 * mp + 2) / 5 + 1
        val m = if (mp < 10) mp + 3 else mp - 9
        if (m <= 2) y += 1
        return Triple(y, m, d)
    }

    // ===== §2.5 打卡状态机（数据态，双端单测封闭性断言）=====
    enum class NavState { HOME, HISTORY }
    enum class NavEvent { OPEN_HISTORY, BACK }
    enum class PickPhase { NONE, PICKED, SAVED }
    enum class PickEvent { PICK, SAVE, RESET }

    /** 导航：2 态 × 2 事件 = 3 有效转移；(HISTORY, OPEN_HISTORY) 未列出 = 忽略（原态）。 */
    fun nextNav(state: NavState, event: NavEvent): NavState = when (state to event) {
        NavState.HOME to NavEvent.OPEN_HISTORY -> NavState.HISTORY
        NavState.HISTORY to NavEvent.BACK -> NavState.HOME
        NavState.HOME to NavEvent.BACK -> NavState.HOME // UI 层据此退出 App（根态）
        else -> state // 无效转移忽略（禁崩溃、禁隐式跳转）
    }

    /** 相位：3 态 × 3 事件 = 4 有效转移 + 忽略组合；(NONE, SAVE) 忽略保持 NONE。 */
    fun nextPhase(phase: PickPhase, event: PickEvent): PickPhase = when (event) {
        PickEvent.RESET -> PickPhase.NONE // 只清选择不清库
        PickEvent.PICK -> PickPhase.PICKED
        PickEvent.SAVE -> when (phase) {
            PickPhase.PICKED -> PickPhase.SAVED
            else -> phase // NONE/SAVED 下 SAVE 无效 → 忽略
        }
    }

    // ===== AC-S7.1 多端自适应阈值（C14，Should 可降级）：600dp 单列 ↔ 双列 =====
    const val TWO_PANE_MIN_DP = 600

    fun isTwoPane(maxWidthDp: Int): Boolean = maxWidthDp >= TWO_PANE_MIN_DP
}
