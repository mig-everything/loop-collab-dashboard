package io.eazo.b9d8cdfa.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import io.eazo.b9d8cdfa.platform.AppRepo

/**
 * REQ-021 主界面：单 Activity + Jetpack Compose（声明式，与鸿蒙 ArkUI 对称）。
 * 硬规则 ①：UI 经 AppRepo.getRepo(this) 取单例仓储；硬规则 ②：onResume 只
 * refresh()（重读内存态），禁止从持久化 load()。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = AppRepo.getRepo(this)
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MoodApp(repo)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(this).refresh()
    }
}

/** 主题（骨架位替换配色）：暖米底 + 琥珀主色，标签色板承载情绪语义（展示态）。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFFF57C2E),
            onPrimary = Color(0xFFFFFFFF),
            background = Color(0xFFFAF6F0),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFF0E9DF),
            onSurface = Color(0xFF3B3229),
            onSurfaceVariant = Color(0xFF8A7F72),
            outline = Color(0xFFE2D8C9),
        ),
        content = content,
    )
}
