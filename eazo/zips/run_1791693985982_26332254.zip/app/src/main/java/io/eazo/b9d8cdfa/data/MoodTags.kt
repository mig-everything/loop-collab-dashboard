// ⚠️ 本文件由 gen_mood_tags.py 生成（docs/arch/req021/scripts/gen_mood_tags.py --lang kt）——禁手改；
// 改动 = 契约变更升 v1.1。数据源：PRD v1.0 §11（三源对撞见 sa_req021_design_verify.py 组C）。
// 契约：docs/arch/req021/02-interface-contract.md §1/§4/§6.1
// package 行适配本工程命名空间 io.eazo.b9d8cdfa（数据面零手改，仍由脚本再生成时以此行为唯一差异）
package io.eazo.b9d8cdfa.data

data class MoodTag(
    val id: String,    // "M01".."M05"
    val name: String,  // 开心/平静/难过/生气/疲惫
    val color: String, // #RRGGBB 大写（月历热力图色块，展示层）
    val emoji: String  // 单码点 NFC
)

val MOOD_TAGS: List<MoodTag> = listOf(
    MoodTag("M01", "开心", "#FFD93D", "😊"),
    MoodTag("M02", "平静", "#6BCB77", "😌"),
    MoodTag("M03", "难过", "#4D96FF", "😢"),
    MoodTag("M04", "生气", "#FF6B6B", "😠"),
    MoodTag("M05", "疲惫", "#9B9B9B", "😪")
)

val MOOD_IDS: List<String> = listOf("M01", "M02", "M03", "M04", "M05")

// 常量数据面哈希全量锁（序列化 id|name|color|emoji，id 升序 LF 行尾无换行 UTF-8）
const val TAGS_SHA256: String = "fc4fbbd6239d87a801cdaf5f1e7374ebf1579e3a8ebb36ccf9e55a126237fc97"
const val TAGS_BYTES: Int = 119
