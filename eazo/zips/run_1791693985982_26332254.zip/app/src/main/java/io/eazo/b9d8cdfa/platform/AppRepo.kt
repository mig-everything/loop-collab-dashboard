package io.eazo.b9d8cdfa.platform

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import io.eazo.b9d8cdfa.core.MoodCore
import io.eazo.b9d8cdfa.data.MOOD_IDS
import io.eazo.b9d8cdfa.model.MoodRecord

/**
 * REQ-021 平台层（契约 §3）：AppRepo 进程内单例（生成器硬规则 ①——UI/卡片层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * 日期注入链（契约 §3 ★防状态分叉）：系统日期唯一取用点 = 本 object 的 getRepo 接线
 * （Calendar 取一次 → daysFromCivil → 构造注入 MoodRepository）；core 纯函数零时间源。
 * 持久化：SharedPreferences（存储格式双端可异构，不入对账口径——契约 §6.5 S3）。
 */

/** 持久化端口：行式读写（Android 实现用 SharedPreferences；JVM 单测注入内存假件）。 */
interface MoodStore {
    fun readLines(): List<String>
    fun writeLines(lines: List<String>)
}

/** Android 实现：单键字符串存储（行 LF 连接）。 */
class SharedPrefsStore(context: Context) : MoodStore {
    private val prefs = context.getSharedPreferences("mood_tracker", Context.MODE_PRIVATE)
    override fun readLines(): List<String> =
        prefs.getString("records", "")!!.split('\n').filter { it.isNotBlank() }
    override fun writeLines(lines: List<String>) {
        prefs.edit().putString("records", lines.joinToString("\n")).apply()
    }
}

/**
 * 业务仓储（UI 经 AppRepo.getRepo 获取；JVM 单测直构注入固定日期与假件存储）。
 * 状态语义：§2.5 相位机（none/picked/saved）+ 同键覆盖写幂等 + 单日一条顶替
 * （换标签 = 改当日记录，契约 §6.5 两种口径键确定性不变）。
 * 排序（硬规则 ③）：dateEpochDay 降序主键、moodId 字典序升序次键。
 */
class MoodRepository(
    private val store: MoodStore,
    val todayEpochDay: Int,
    val todayY: Int,
    val todayM: Int,
    val todayD: Int,
) {
    private val recordsMap = LinkedHashMap<String, MoodRecord>()

    /** Compose 观察口：任何内存态变更/refresh 自增，UI 读它驱动重渲。 */
    var version by mutableStateOf(0)
        private set

    var selected: String? = null
        private set
    private var savedKey: String? = null

    val phase: MoodCore.PickPhase
        get() = when {
            savedKey != null -> MoodCore.PickPhase.SAVED
            selected != null -> MoodCore.PickPhase.PICKED
            else -> MoodCore.PickPhase.NONE
        }

    init { // 持久化装载仅构造时一次（硬规则 ②：refresh 绝不 load）
        for (line in store.readLines()) {
            val rec = parseLine(line) ?: continue
            recordsMap[rec.key] = rec
        }
    }

    fun isValidMoodId(id: String): Boolean = id in MOOD_IDS

    /** 相位机 (任意, pick) → picked（选择/改选，5 选 1 单选覆盖）。 */
    fun pick(moodId: String) {
        if (!isValidMoodId(moodId)) return
        selected = moodId
        savedKey = null
        version++
    }

    /**
     * 相位机 (picked, save) → saved：写库返回记录；未选择返回 null。
     * 覆写幂等（★契约 §6.5）：同键再存 → 仍 1 条；单日一条：同日旧标签记录被顶替。
     */
    fun save(note: String): MoodRecord? {
        val sel = selected ?: return null
        if (!isValidMoodId(sel)) return null
        val day = todayEpochDay
        val key = MoodCore.moodRecordKey(day, sel)
        val it = recordsMap.entries.iterator()
        while (it.hasNext()) { // 单日一条顶替：移除同日其它标签记录
            val e = it.next()
            if (e.value.dateEpochDay == day && e.key != key) it.remove()
        }
        val rec = MoodRecord(key, day, sel, sanitizeNote(note))
        recordsMap[key] = rec
        persist()
        savedKey = key
        version++
        return rec
    }

    /** 相位机 (任意, reset) → none：只清选择不清库（契约 §6.7）。 */
    fun resetSelection() {
        selected = null
        savedKey = null
        version++
    }

    /** 硬规则 ②：refresh 只重读内存态重发布（自增 version），禁止从持久化 load()。 */
    fun refresh() {
        version++
    }

    /** 记录列表（内存态，确定性排序）。 */
    val records: List<MoodRecord>
        get() = recordsMap.values.sortedWith(
            compareByDescending<MoodRecord> { it.dateEpochDay }.thenBy { it.moodId }
        )

    /** 月历数据面（契约 §3/§6.5）：该月 epochDay → moodId 映射（单日一条保证无冲突）。 */
    fun recordsByMonth(y: Int, m: Int): Map<Int, String> {
        val (_, days) = MoodCore.monthGrid(y, m)
        val first = MoodCore.daysFromCivil(y, m, 1)
        val map = LinkedHashMap<Int, String>()
        for (rec in recordsMap.values) {
            val delta = rec.dateEpochDay - first
            if (delta >= 0 && delta < days) map[rec.dateEpochDay] = rec.moodId
        }
        return map
    }

    /** 分布统计 scope 数据面（默认与月历同集：该月各记录 moodId 序列）。 */
    fun monthMoodIds(y: Int, m: Int): List<String> =
        recordsByMonth(y, m).values.toList()

    // ----- 存储（格式：epochDay\tmoodId\tnote；不入对账口径） -----

    private fun sanitizeNote(note: String): String =
        note.filterNot { it == '\t' || it == '\n' || it == '\r' }.take(NOTE_MAX_CHARS)

    private fun persist() {
        store.writeLines(recordsMap.values.sortedWith(
            compareByDescending<MoodRecord> { it.dateEpochDay }.thenBy { it.moodId }
        ).map { "${it.dateEpochDay}\t${it.moodId}\t${it.note}" })
    }

    companion object {
        const val NOTE_MAX_CHARS = 200 // 契约 §1.3 业务建议
        fun parseLine(line: String): MoodRecord? {
            val parts = line.split('\t', limit = 3)
            if (parts.size < 2) return null
            val day = parts[0].toIntOrNull() ?: return null
            val moodId = parts[1]
            val note = if (parts.size == 3) parts[2] else ""
            return MoodRecord(MoodCore.moodRecordKey(day, moodId), day, moodId, note)
        }
    }
}

/** 进程内单例接线（生成器硬规则 ① 落点；系统日期唯一取用点——取一次缓存 epoch-day）。 */
object AppRepo {
    @Volatile
    private var repo: MoodRepository? = null

    fun getRepo(context: Context): MoodRepository {
        repo?.let { return it }
        return synchronized(this) {
            repo ?: createRepo(context.applicationContext).also { repo = it }
        }
    }

    private fun createRepo(context: Context): MoodRepository {
        val cal = java.util.Calendar.getInstance()
        val y = cal.get(java.util.Calendar.YEAR)
        val m = cal.get(java.util.Calendar.MONTH) + 1
        val d = cal.get(java.util.Calendar.DAY_OF_MONTH)
        return MoodRepository(
            store = SharedPrefsStore(context),
            todayEpochDay = MoodCore.daysFromCivil(y, m, d),
            todayY = y, todayM = m, todayD = d,
        )
    }
}
