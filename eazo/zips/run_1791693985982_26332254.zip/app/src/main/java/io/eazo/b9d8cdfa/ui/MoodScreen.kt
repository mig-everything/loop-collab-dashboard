package io.eazo.b9d8cdfa.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.b9d8cdfa.core.MoodCore
import io.eazo.b9d8cdfa.core.MoodCore.NavEvent
import io.eazo.b9d8cdfa.core.MoodCore.NavState
import io.eazo.b9d8cdfa.data.MOOD_TAGS
import io.eazo.b9d8cdfa.model.Distribution
import io.eazo.b9d8cdfa.model.MoodRecord
import io.eazo.b9d8cdfa.platform.MoodRepository

/**
 * REQ-021 展示层（契约 §3 pages/ui，展示态——不入对账断言）。
 * HomePage：5 标签选择 + 可选一句话 + 月历热力图 + 分布统计；
 * HistoryPage：记录列表；600dp 单列 ↔ 双列自适应（AC-S7.1，C14 Should）。
 * 导航走 MoodCore.nextNav 纯函数（§2.5 状态机）；日期注入 = repo 构造时的一次系统日期。
 */
@Composable
fun MoodApp(repo: MoodRepository) {
    var nav by remember { mutableStateOf(NavState.HOME) }
    when (nav) {
        NavState.HOME -> HomePage(
            repo = repo,
            onOpenHistory = { nav = MoodCore.nextNav(nav, NavEvent.OPEN_HISTORY) },
        )
        NavState.HISTORY -> HistoryPage(
            repo = repo,
            onBack = { nav = MoodCore.nextNav(nav, NavEvent.BACK) },
        )
    }
}

// ============================ HomePage ============================

@Composable
private fun HomePage(repo: MoodRepository, onOpenHistory: () -> Unit) {
    repo.version // 订阅内存态变更（硬规则 ②：refresh 只重读内存态）
    var note by remember { mutableStateOf("") }
    var monthY by remember { mutableStateOf(repo.todayY) }
    var monthM by remember { mutableStateOf(repo.todayM) }

    val checkin: @Composable () -> Unit = {
        CheckinCard(
            repo, note,
            onNoteChange = { if (it.length <= 200) note = it },
            onOpenHistory = onOpenHistory,
        )
    }
    val calendar: @Composable () -> Unit = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            MonthCalendarCard(repo, monthY, monthM, onShift = { dy, dm ->
                var y = monthY + dy
                var m = monthM + dm
                if (m < 1) { y -= 1; m = 12 } else if (m > 12) { y += 1; m = 1 }
                monthY = y; monthM = m
            })
            DistributionCard(repo, monthY, monthM)
        }
    }

    BoxWithConstraints {
        if (MoodCore.isTwoPane(maxWidth.value.toInt())) { // 平板横屏：双列
            Row(
                Modifier.fillMaxSize().padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Box(Modifier.weight(1f)) { checkin() }
                Box(Modifier.weight(1f).verticalScroll(rememberScrollState())) { calendar() }
            }
        } else { // 手机竖屏：单列
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                checkin()
                calendar()
            }
        }
    }
}

/** 顶栏（两页共用样式）：标题 + 动作。 */
@Composable
private fun TopBar(title: String, action: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        action()
    }
}

@Composable
private fun CheckinCard(
    repo: MoodRepository,
    note: String,
    onNoteChange: (String) -> Unit,
    onOpenHistory: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TopBar("心情打卡") {
            IconButton(onClick = onOpenHistory) { Icon(Icons.Filled.List, "记录") }
        }
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "今天 · ${repo.todayY}年${repo.todayM}月${repo.todayD}日",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TagRow(repo)
                OutlinedTextField(
                    value = note,
                    onValueChange = onNoteChange,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("一句话记录（可选）") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                    ),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { repo.save(note); },
                        enabled = repo.selected != null,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                        ),
                    ) {
                        Icon(Icons.Filled.Check, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("保存今日心情")
                    }
                    Spacer(Modifier.width(12.dp))
                    val phase = repo.phase
                    if (phase == MoodCore.PickPhase.SAVED && repo.selected != null) {
                        val tag = MOOD_TAGS.first { it.id == repo.selected }
                        Text(
                            "${tag.emoji} 已存档",
                            color = Color(0xFF6BCB77),
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                }
            }
        }
    }
}

/** 5 固定标签单选（选择/改选覆盖——相位机 pick 转移）。 */
@Composable
private fun TagRow(repo: MoodRepository) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (tag in MOOD_TAGS) {
            val selected = repo.selected == tag.id
            val tint = hexColor(tag.color)
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (selected) tint.copy(alpha = 0.22f)
                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                border = if (selected) BorderStroke(2.dp, tint) else null,
                modifier = Modifier
                    .weight(1f)
                    .clickable { repo.pick(tag.id) },
            ) {
                Column(
                    Modifier.padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(tag.emoji, fontSize = 26.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        tag.name,
                        fontSize = 13.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    )
                }
            }
        }
    }
}

/** 月历热力图（31 槽位色块——monthGrid 偏移 + recordsByMonth 数据面）。 */
@Composable
private fun MonthCalendarCard(
    repo: MoodRepository,
    y: Int,
    m: Int,
    onShift: (Int, Int) -> Unit,
) {
    val (offset, days) = MoodCore.monthGrid(y, m)
    val byDay = repo.recordsByMonth(y, m)
    val first = MoodCore.daysFromCivil(y, m, 1)
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("心情日历", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { onShift(0, -1) }) { Text("‹", fontSize = 20.sp) }
                Text(
                    "$y 年 $m 月",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(onClick = { onShift(0, 1) }) { Text("›", fontSize = 20.sp) }
            }
            Row(Modifier.fillMaxWidth()) {
                for (w in listOf("日", "一", "二", "三", "四", "五", "六")) {
                    Text(
                        w,
                        Modifier.weight(1f),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    )
                }
            }
            val cells = offset + days
            for (weekStart in 0 until cells step 7) {
                Row(Modifier.fillMaxWidth()) {
                    for (i in weekStart until weekStart + 7) {
                        if (i < offset || i >= cells) {
                            Spacer(Modifier.weight(1f))
                        } else {
                            val day = i - offset + 1
                            val epochDay = first + day - 1
                            val moodId = byDay[epochDay]
                            // IPD-460 Dev 修复:此处原误传 moodId 给 hexColor(月历色块 parseColor
                            // 抛 IllegalArgumentException: Unknown color → 保存打卡后月历重渲必崩)。
                            // 正确链路 = moodId → moodColorForId 查表(契约 §2.4)→ hexColor(展示层)。
                            // 查表返回 null(域外)时 DayCell 走无色占位,color 传 null 即可。
                            val dayColor = moodId?.let { MoodCore.moodColorForId(it) }
                            DayCell(day, dayColor?.let { hexColor(it) }, epochDay == repo.todayEpochDay, Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(day: Int, color: Color?, isToday: Boolean, modifier: Modifier = Modifier) {
    Box(modifier.aspectRatio(1f).padding(2.dp), contentAlignment = Alignment.Center) {
        Surface(
            shape = CircleShape,
            color = color ?: MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
            border = if (isToday) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "$day",
                    fontSize = 13.sp,
                    fontWeight = if (color != null) FontWeight.Bold else FontWeight.Normal,
                )
            }
        }
    }
}

/** 心情分布统计（counts + permille 整数域；条形宽度为展示态比例渲染）。 */
@Composable
private fun DistributionCard(repo: MoodRepository, y: Int, m: Int) {
    val dist: Distribution = MoodCore.moodDistribution(repo.monthMoodIds(y, m))
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("心情分布", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text(
                    "本月打卡 ${dist.total} 天",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            for (tag in MOOD_TAGS) {
                val count = dist.counts[tag.id] ?: 0
                val permille = dist.permille[tag.id] ?: 0
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(tag.emoji, fontSize = 16.sp)
                        Spacer(Modifier.width(6.dp))
                        Text(tag.name, fontSize = 14.sp)
                        Spacer(Modifier.weight(1f))
                        Text(
                            "$count 次 · $permille‰",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .background(
                                hexColor(tag.color).copy(alpha = 0.25f),
                                RoundedCornerShape(4.dp),
                            ),
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth(permille / 1000f)
                                .height(8.dp)
                                .background(hexColor(tag.color), RoundedCornerShape(4.dp)),
                        )
                    }
                }
            }
        }
    }
}

// ============================ HistoryPage ============================

@Composable
private fun HistoryPage(repo: MoodRepository, onBack: () -> Unit) {
    repo.version // 硬规则 ②：跨页返回即时可见（重读内存态）
    val records: List<MoodRecord> = repo.records
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "返回") }
            Text("心情记录", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(
                "共 ${records.size} 条",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (records.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("还没有记录，去打个卡吧 ✨", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(records) { rec ->
                    val tag = MOOD_TAGS.first { it.id == rec.moodId }
                    val (y, m, d) = MoodCore.civilFromEpochDay(rec.dateEpochDay)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = hexColor(tag.color).copy(alpha = 0.2f),
                                border = BorderStroke(1.5.dp, hexColor(tag.color)),
                            ) {
                                Box(Modifier.size(44.dp), contentAlignment = Alignment.Center) {
                                    Text(tag.emoji, fontSize = 22.sp)
                                }
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(
                                    "$y-${pad2(m)}-${pad2(d)} · ${tag.name}",
                                    fontWeight = FontWeight.SemiBold,
                                )
                                if (rec.note.isNotEmpty()) {
                                    Text(
                                        rec.note,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 13.sp,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================ helpers ============================

/** "#RRGGBB" → Compose Color（标签色查表渲染，展示态）。 */
private fun hexColor(hex: String): Color = Color(android.graphics.Color.parseColor(hex))

/** 展示态两位补零（历史列表日期显示）。 */
private fun pad2(v: Int): String = if (v < 10) "0$v" else "$v"
