package io.eazo.aa75e12b.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import io.eazo.aa75e12b.platform.Today

/**
 * 添加倒数日弹层(US-2):标题输入 + Material3 日期选择(默认今天);
 * 校验口径与 core Anniversary.create 同源(空标题拦截,日期恒合法)。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAnniversaryDialog(
    today: String,
    onDismiss: () -> Unit,
    onConfirm: (title: String, date: String) -> Unit,
) {
    var title by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(today) }
    var showPicker by remember { mutableStateOf(false) }
    var titleBlank by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = "添加倒数日") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        titleBlank = false
                    },
                    label = { Text("标题") },
                    placeholder = { Text("如：领证纪念日") },
                    singleLine = true,
                    isError = titleBlank,
                    supportingText = { if (titleBlank) Text("标题不能为空") },
                )
                OutlinedTextField(
                    value = date,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("日期") },
                    singleLine = true,
                    trailingIcon = {
                        IconButton(onClick = { showPicker = true }) {
                            Icon(Icons.Filled.DateRange, contentDescription = "选择日期")
                        }
                    },
                    supportingText = { Text("默认今天，点右侧图标改日期") },
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (title.isNotBlank()) onConfirm(title.trim(), date) else titleBlank = true
                },
            ) { Text("添加") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        },
    )

    if (showPicker) {
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = Today.isoToUtcMillis(date))
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        pickerState.selectedDateMillis?.let { date = Today.utcMillisToIso(it) }
                        showPicker = false
                    },
                ) { Text("确定") }
            },
            dismissButton = {
                TextButton(onClick = { showPicker = false }) { Text("取消") }
            },
        ) {
            DatePicker(state = pickerState)
        }
    }
}
