package io.eazo.aa75e12b.core

/**
 * 持久化编解码(契约 §4):纯函数行协议(RecordSep=U+001E / UnitSep=U+001F),
 * 不引 org.json、JVM 可直测;标题中的分隔符先消毒为空格,杜绝注入破坏记录边界。
 */
object AnniversaryCodec {

    private const val LINE = '\u001E'
    private const val FIELD = '\u001F'

    fun encode(items: List<Anniversary>): String =
        items.joinToString(LINE.toString()) { item ->
            listOf(item.id, sanitize(item.title), item.date, item.pinned.toString())
                .joinToString(FIELD.toString())
        }

    /** 畸形行(字段数≠4 / 日期非法 / pinned 非 true|false)静默跳过,绝不抛出。 */
    fun decode(text: String): List<Anniversary> =
        if (text.isBlank()) {
            emptyList()
        } else {
            text.split(LINE).mapNotNull { line ->
                val f = line.split(FIELD)
                if (f.size != 4) return@mapNotNull null
                val pinned = when (f[3]) {
                    "true" -> true
                    "false" -> false
                    else -> return@mapNotNull null
                }
                try {
                    Anniversary.create(f[0], f[1], f[2], pinned)
                } catch (_: IllegalArgumentException) {
                    null
                }
            }
        }

    private fun sanitize(title: String): String =
        title.replace(LINE, ' ').replace(FIELD, ' ').trim()
}
