package io.eazo.aa75e12b.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import io.eazo.aa75e12b.R
import io.eazo.aa75e12b.core.Anniversary
import io.eazo.aa75e12b.core.AnniversaryFormat
import io.eazo.aa75e12b.platform.AppRepo
import io.eazo.aa75e12b.platform.Today
import io.eazo.aa75e12b.ui.MainActivity

/**
 * 桌面卡片(US-5,与鸿蒙 widget 对等位):显示"最近一个倒数日"
 * (|距今天数| 最近、忽略置顶——与 core AnniversaryStore.nearestComparator 同口径);
 * 点卡片深链 MainActivity 定位该条(focusId),点 + 深链直开添加弹层(openAdd=true)。
 * 硬规则①:只经 AppRepo.getRepo(context);硬规则②:只读内存态。
 */
class CountdownWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val repo = AppRepo.getRepo(context)
        val nearest = repo.nearest(Today.current())
        val views = buildViews(context, nearest)
        ids.forEach { id -> manager.updateAppWidget(id, views) }
    }

    companion object {

        private const val RC_ROOT = 41
        private const val RC_ADD = 43

        /** 数据变更后由 AppRepo 调用,即时刷新全部实例(跨页写操作即时可见)。 */
        fun push(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, CountdownWidgetProvider::class.java))
            if (ids.isEmpty()) return
            val views = buildViews(context, AppRepo.getRepo(context).nearest(Today.current()))
            ids.forEach { id -> manager.updateAppWidget(id, views) }
        }

        internal fun buildViews(context: Context, nearest: Anniversary?): RemoteViews =
            RemoteViews(context.packageName, R.layout.widget_countdown).apply {
                if (nearest == null) {
                    setTextViewText(R.id.widget_item_title, "还没有倒数日")
                    setTextViewText(R.id.widget_days, "点 + 添加")
                    setTextViewText(R.id.widget_sub, "添加后这里显示最近一个")
                    setOnClickPendingIntent(R.id.widget_root, deepLink(context, null, true))
                } else {
                    val days = nearest.daysFrom(Today.current())
                    setTextViewText(R.id.widget_item_title, nearest.title)
                    setTextViewText(R.id.widget_days, AnniversaryFormat.daysText(days))
                    setTextViewText(
                        R.id.widget_sub,
                        AnniversaryFormat.dateText(nearest.date) + " · " + AnniversaryFormat.weekdayText(nearest.date),
                    )
                    setOnClickPendingIntent(R.id.widget_root, deepLink(context, nearest.id, false))
                }
                setOnClickPendingIntent(R.id.widget_add, deepLink(context, null, true))
            }

        /** 深链:f focusId / openAdd(严格 Boolean,与应用内 readOpenCreate 同一解析口径)。 */
        private fun deepLink(context: Context, focusId: String?, openAdd: Boolean): PendingIntent {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                if (focusId != null) putExtra("focusId", focusId)
                if (openAdd) putExtra("openAdd", true)
            }
            return PendingIntent.getActivity(
                context,
                if (openAdd) RC_ADD else RC_ROOT,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
        }
    }
}
