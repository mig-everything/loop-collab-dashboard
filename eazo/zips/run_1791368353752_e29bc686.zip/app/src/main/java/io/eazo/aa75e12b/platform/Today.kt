package io.eazo.aa75e12b.platform

import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * 当前本地日期(yyyy-MM-dd)唯一出口:Calendar(默认时区)+ Locale.US 数字格式,
 * 供 UI / AppRepo / 桌面卡片统一取"今天";core 层永远以 today 字符串入参保持纯函数。
 */
object Today {

    fun current(): String {
        val c = Calendar.getInstance()
        return format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    /** yyyy-MM-dd ↔ DatePicker 的 UTC 毫秒(DatePicker 以 UTC 定日界)。 */
    fun isoToUtcMillis(iso: String): Long {
        val p = iso.split("-")
        val c = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        c.clear()
        c.set(p[0].toInt(), p[1].toInt() - 1, p[2].toInt())
        return c.timeInMillis
    }

    fun utcMillisToIso(millis: Long): String {
        val c = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        c.timeInMillis = millis
        return format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    private fun format(y: Int, m: Int, d: Int): String = String.format(Locale.US, "%04d-%02d-%02d", y, m, d)
}
