package io.eazo.aa75e12b.core

import kotlin.math.abs

/**
 * 纯内存仓储(契约 §3,JVM 可直测;Android 侧由 platform/AppRepo 持有并做持久化读写)。
 *
 * 确定性排序口径(生成器硬规则③,与鸿蒙完全一致):
 *   列表   = pinned 降序(置顶最前) → |距今天数| 升序(离今天最近优先) → date 升序 → id 字典序兜底;
 *   最近   = 忽略 pinned,|距今天数| 升序 → date 升序 → id 字典序兜底(桌面卡片口径)。
 */
class AnniversaryStore {

    private val items = LinkedHashMap<String, Anniversary>()

    fun size(): Int = items.size

    fun snapshot(): List<Anniversary> = items.values.toList()

    fun get(id: String): Anniversary? = items[id]

    /** upsert 语义:同 id 整体覆盖。 */
    fun insert(item: Anniversary) {
        items[item.id] = item
    }

    fun remove(id: String): Boolean = items.remove(id) != null

    fun setPinned(id: String, pinned: Boolean): Boolean {
        val old = items[id] ?: return false
        if (old.pinned == pinned) return true
        items[id] = old.copy(pinned = pinned)
        return true
    }

    /** 列表(每次按 today 确定性排序)。 */
    fun list(today: String): List<Anniversary> = snapshot().sortedWith(listComparator(today))

    /** 最近一个倒数日(桌面卡片口径,忽略置顶)。 */
    fun nearest(today: String): Anniversary? = snapshot().minWithOrNull(nearestComparator(today))

    companion object {
        fun listComparator(today: String): Comparator<Anniversary> =
            compareByDescending<Anniversary> { it.pinned }
                .thenBy { abs(it.daysFrom(today)) }
                .thenBy { it.date }
                .thenBy { it.id }

        fun nearestComparator(today: String): Comparator<Anniversary> =
            compareBy<Anniversary> { abs(it.daysFrom(today)) }
                .thenBy { it.date }
                .thenBy { it.id }
    }
}
