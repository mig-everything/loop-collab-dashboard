package io.eazo.aa75e12b.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.BorderStroke
import io.eazo.aa75e12b.core.Anniversary
import io.eazo.aa75e12b.core.AnniversaryFormat
import io.eazo.aa75e12b.platform.AppRepo
import io.eazo.aa75e12b.platform.Today
import kotlinx.coroutines.delay

/**
 * 首屏(US-1~4):卡片式倒数日列表——置顶最前、离今天最近优先(与鸿蒙同口径),
 * 卡内支持置顶切换与删除,FAB 弹层添加;桌面卡片深链 focusId 定位高亮。
 * 硬规则①:只经 AppRepo.getRepo(context);硬规则②:tick 变化即重读内存态 list()。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CountdownScreen(
    tick: Int,
    openAddRequest: Boolean,
    focusId: String?,
    onConsumeOpenAdd: () -> Unit,
    onConsumeFocus: () -> Unit,
) {
    val repo = AppRepo.getRepo(LocalContext.current) // 硬规则①
    val today = Today.current()
    val list = remember(tick, today) { repo.list(today) } // 硬规则②:重读内存态
    var addOpen by remember { mutableStateOf(false) }
    var highlightId by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()

    LaunchedEffect(openAddRequest) {
        if (openAddRequest) {
            addOpen = true
            onConsumeOpenAdd()
        }
    }
    LaunchedEffect(focusId, tick) {
        val fid = focusId ?: return@LaunchedEffect
        val index = list.indexOfFirst { it.id == fid }
        if (index >= 0) {
            listState.animateScrollToItem(index)
            highlightId = fid
            onConsumeFocus()
            delay(1600)
            if (highlightId == fid) highlightId = null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "倒数日纪念日",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            "${list.size} 个纪念 · 最近优先",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { addOpen = true }) {
                Icon(Icons.Filled.Add, contentDescription = "添加倒数日")
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            if (list.isEmpty()) {
                EmptyState(onAdd = { addOpen = true })
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(list, key = { it.id }) { item ->
                        AnniversaryCard(
                            item = item,
                            today = today,
                            highlighted = highlightId == item.id,
                            onTogglePin = { repo.setPinned(item.id, !item.pinned) },
                            onRemove = { repo.remove(item.id) },
                        )
                    }
                }
            }
        }
    }

    if (addOpen) {
        AddAnniversaryDialog(
            today = today,
            onDismiss = { addOpen = false },
            onConfirm = { title, date ->
                addOpen = false
                repo.add(title, date)
            },
        )
    }
}

/** 倒数日卡片:标题行(标题+置顶+删除) + 底行(日期星期 | 大号天数状态块)。 */
@Composable
private fun AnniversaryCard(
    item: Anniversary,
    today: String,
    highlighted: Boolean,
    onTogglePin: () -> Unit,
    onRemove: () -> Unit,
) {
    val days = remember(item.date, today) { item.daysFrom(today) }
    val stateColor = when {
        days == 0L -> MaterialTheme.colorScheme.tertiary
        days > 0 -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.secondary
    }
    val container = when {
        highlighted -> MaterialTheme.colorScheme.tertiaryContainer
        item.pinned -> MaterialTheme.colorScheme.primaryContainer
        else -> MaterialTheme.colorScheme.surface
    }
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = container),
        border = if (!item.pinned && !highlighted) {
            BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        } else {
            null
        },
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                if (item.pinned) {
                    Spacer(modifier = Modifier.size(4.dp))
                    Icon(
                        imageVector = Icons.Filled.Favorite,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp),
                    )
                }
                IconButton(onClick = onTogglePin, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = if (item.pinned) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = if (item.pinned) "取消置顶" else "置顶",
                        tint = if (item.pinned) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp),
                    )
                }
                IconButton(onClick = onRemove, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Filled.Delete,
                        contentDescription = "删除",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
            Spacer(modifier = Modifier.size(8.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = AnniversaryFormat.dateText(item.date),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        text = if (item.pinned) "已置顶 · ${AnniversaryFormat.weekdayText(item.date)}"
                        else AnniversaryFormat.weekdayText(item.date),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline,
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = AnniversaryFormat.stateLabel(days),
                        style = MaterialTheme.typography.labelSmall,
                        color = stateColor,
                    )
                    Row {
                        Text(
                            text = AnniversaryFormat.dayNumber(days),
                            style = MaterialTheme.typography.displaySmall,
                            fontWeight = FontWeight.Black,
                            color = stateColor,
                            modifier = Modifier.alignByBaseline(),
                        )
                        if (days != 0L) {
                            Text(
                                text = " 天",
                                style = MaterialTheme.typography.titleMedium,
                                color = stateColor,
                                modifier = Modifier.alignByBaseline(),
                            )
                        }
                    }
                }
            }
        }
    }
}

/** 空态:整屏可点,引导添加。 */
@Composable
private fun EmptyState(onAdd: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .clickable { onAdd() },
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            imageVector = Icons.Filled.DateRange,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.outlineVariant,
            modifier = Modifier.size(56.dp),
        )
        Spacer(modifier = Modifier.size(12.dp))
        Text(
            "还没有倒数日",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            "点这里或右下角 + 添加一个",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.outline,
        )
    }
}
