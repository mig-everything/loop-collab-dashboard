package io.eazo.aa75e12b.core

/**
 * 冷/热启动 Intent 统一解析结果(生成器硬规则④,与鸿蒙 readOpenCreate(want) 纯函数对等位):
 * Android 侧 onCreate(intent) 与 onNewIntent(intent) 两路都收敛到 readOpenCreate,
 * 不允许各路散解析。
 *
 * 深链参数(桌面卡片携带):focusId(String,定位到该条) / openAdd(Boolean 严格判定)。
 */
data class OpenCreate(
    val focusId: String?,
    val openAdd: Boolean,
) {
    companion object {
        val NONE = OpenCreate(null, false)
    }
}

/** 纯函数:入参为 Bundle 转出的原始 Map(平台胶水层转换),core 不触碰 Android 类型。 */
fun readOpenCreate(extras: Map<String, Any?>?): OpenCreate {
    if (extras == null || extras.isEmpty()) return OpenCreate.NONE
    val focusId = (extras["focusId"] as? String)?.takeIf { it.isNotBlank() }
    // 布尔严格判定:镜像鸿蒙 typeof v === 'boolean' && v === true
    val v = extras["openAdd"]
    val openAdd = v is Boolean && v == true
    return OpenCreate(focusId, openAdd)
}
