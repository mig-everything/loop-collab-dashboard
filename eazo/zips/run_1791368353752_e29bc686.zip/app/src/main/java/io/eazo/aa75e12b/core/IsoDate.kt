package io.eazo.aa75e12b.core

import java.util.Locale
import kotlin.math.abs

/**
 * 纯 ISO 日期(yyyy-MM-dd)数学——不依赖 java.time(兼容 minSdk 24 无 desugaring),
 * 不依赖任何 Android 框架 API,JVM 单测可直测(契约 §1)。
 *
 * 算法:Howard Hinnant days_from_civil(公历→儒略日),确定性、无时区参与;
 * 与鸿蒙侧同一算法逐行对齐(双端字段/枚举/排序 1:1,生成器硬规则③)。
 */
object IsoDate {

    const val PATTERN = "\\d{4}-\\d{2}-\\d{2}"

    /** 星期文案(0=周日);1970-01-01 为周四。 */
    val WEEKDAY_NAMES = arrayOf("周日", "周一", "周二", "周三", "周四", "周五", "周六")

    /** 严格校验:形如 yyyy-MM-dd 且为真实存在的公历日期。 */
    fun isValid(text: String): Boolean {
        if (!Regex(PATTERN).matches(text)) return false
        val parts = text.split("-")
        val year = parts[0].toInt()
        val month = parts[1].toInt()
        val day = parts[2].toInt()
        if (month < 1 || month > 12) return false
        return day in 1..daysInMonth(year, month)
    }

    fun isLeap(year: Int): Boolean = year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)

    fun daysInMonth(year: Int, month: Int): Int = when (month) {
        1, 3, 5, 7, 8, 10, 12 -> 31
        4, 6, 9, 11 -> 30
        2 -> if (isLeap(year)) 29 else 28
        else -> 0
    }

    /** 儒略日(自 1970-01-01 起的天数);调用前须已通过 isValid(仓储层守恒不变量)。 */
    fun days(text: String): Long {
        val parts = text.split("-")
        return daysFromCivil(parts[0].toInt(), parts[1].toInt(), parts[2].toInt())
    }

    /** 星期序号(0=周日)。 */
    fun weekday(text: String): Int = Math.floorMod(days(text) + 4L, 7).toInt()

    /** Howard Hinnant days_from_civil:儒略历锚定、跨 0 年/闰世纪皆正确。 */
    private fun daysFromCivil(year0: Int, month: Int, day: Int): Long {
        val y = if (month <= 2) year0 - 1 else year0
        val era = Math.floorDiv(y, 400)
        val yoe = y - era * 400
        val doy = (153L * (if (month > 2) month - 3 else month + 9) + 2) / 5 + day - 1
        val doe = yoe * 365L + yoe / 4 - yoe / 100 + doy
        return era * 146097L + doe - 719468L
    }
}

/** 展示文案口径(UI 与桌面卡片共用同一函数,双端逐字对齐,契约 §5)。 */
object AnniversaryFormat {

    /** 距今天数整句:"还有 N 天" / "已过 N 天" / "就是今天"。 */
    fun daysText(days: Long): String = when {
        days == 0L -> "就是今天"
        days > 0 -> "还有 $days 天"
        else -> "已过 ${abs(days)} 天"
    }

    /** 状态小标签。 */
    fun stateLabel(days: Long): String = when {
        days == 0L -> "今天"
        days > 0 -> "还有"
        else -> "已过"
    }

    /** 大号数字(天数绝对值;今天无数字)。 */
    fun dayNumber(days: Long): String = if (days == 0L) "今天" else abs(days).toString()

    /** "2026年10月7日"。 */
    fun dateText(date: String): String {
        val p = date.split("-")
        return String.format(Locale.US, "%d年%d月%d日", p[0].toInt(), p[1].toInt(), p[2].toInt())
    }

    /** "周三"。 */
    fun weekdayText(date: String): String = IsoDate.WEEKDAY_NAMES[IsoDate.weekday(date)]
}
