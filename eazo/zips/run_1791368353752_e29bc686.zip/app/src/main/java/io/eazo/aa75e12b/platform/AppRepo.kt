package io.eazo.aa75e12b.platform

import android.content.Context
import android.content.SharedPreferences
import io.eazo.aa75e12b.core.Anniversary
import io.eazo.aa75e12b.core.AnniversaryCodec
import io.eazo.aa75e12b.core.AnniversaryStore
import io.eazo.aa75e12b.widget.CountdownWidgetProvider

/**
 * 进程内单例仓储(生成器硬规则①②,与鸿蒙 platform/AppRepo.ets 1:1):
 * UI/桌面卡片层一律经 AppRepo.getRepo(context) 获取,禁止 new 仓储。
 *
 * 生命周期:首次 getRepo 冷启动装配(持久化→内存态一次),此后一切读只走内存态;
 * 写操作 add/setPinned/remove 同步落盘 SharedPreferences 并即时推桌面卡片。
 * refresh 只重读内存态,禁止再 load(硬规则②)。
 */
object AppRepo {

    private const val PREFS_NAME = "countdown_repo"
    private const val KEY_ITEMS = "items_v1"

    private val store = AnniversaryStore()
    private val listeners = HashSet<() -> Unit>()
    private var appContext: Context? = null
    private var booted = false
    private var seq = 0L

    /** 进程内单例入口(硬规则①落点)——UI/卡片层唯一获取通道;首次调用完成冷启动装配。 */
    fun getRepo(context: Context): AppRepo {
        ensureBoot(context)
        return this
    }

    fun subscribe(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun unsubscribe(listener: () -> Unit) {
        listeners.remove(listener)
    }

    /** 硬规则②:onResume/onPageShow 唯一入口——重读内存态并通知,不做任何持久化 load。 */
    fun refresh() = notifyChange()

    fun size(): Int = store.size()

    fun list(today: String): List<Anniversary> = store.list(today)

    fun nearest(today: String): Anniversary? = store.nearest(today)

    fun get(id: String): Anniversary? = store.get(id)

    /** 新增(标题/日期经 create 校验闸口);非法入参返回 null,不落盘不通知。 */
    fun add(title: String, date: String): Anniversary? {
        val item = try {
            Anniversary.create(newId(), title, date)
        } catch (_: IllegalArgumentException) {
            return null
        }
        store.insert(item)
        onMutated()
        return item
    }

    /** 置顶/取消置顶。 */
    fun setPinned(id: String, pinned: Boolean): Boolean {
        val ok = store.setPinned(id, pinned)
        if (ok) onMutated()
        return ok
    }

    /** 删除。 */
    fun remove(id: String): Boolean {
        val ok = store.remove(id)
        if (ok) onMutated()
        return ok
    }

    private fun onMutated() {
        persist()
        notifyChange()
        pushWidget()
    }

    private fun newId(): String = "cd-${System.currentTimeMillis()}-${++seq}"

    private fun ensureBoot(context: Context) {
        if (booted) return
        synchronized(this) {
            if (booted) return
            appContext = context.applicationContext
            val saved = prefs().getString(KEY_ITEMS, null)
            if (!saved.isNullOrEmpty()) {
                AnniversaryCodec.decode(saved).forEach { store.insert(it) }
            }
            booted = true
        }
    }

    private fun prefs(): SharedPreferences =
        appContext!!.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun persist() {
        val ctx = appContext ?: return
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_ITEMS, AnniversaryCodec.encode(store.snapshot()))
            .apply()
    }

    private fun pushWidget() {
        val ctx = appContext ?: return
        CountdownWidgetProvider.push(ctx)
    }

    private fun notifyChange() {
        synchronized(listeners) { listeners.toList() }.forEach { it() }
    }
}
