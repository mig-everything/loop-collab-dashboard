package io.eazo.aa75e12b.core

/**
 * 倒数日/纪念日实体(契约 §2,双端字段 1:1):id / title / date / pinned。
 * - date 恒为合法 yyyy-MM-dd(create 为唯一校验闸口);
 * - id 由平台层生成("cd-<时间戳>-<序号>"),仅作字典序兜底键(生成器硬规则③)。
 */
data class Anniversary(
    val id: String,
    val title: String,
    val date: String,
    val pinned: Boolean = false,
) {
    /** date - today 的整天数:正=剩余,负=已过,0=就是今天。 */
    fun daysFrom(today: String): Long = IsoDate.days(date) - IsoDate.days(today)

    companion object {
        /** 实体唯一构造闸口:标题 trim 后非空 + 日期严格合法。 */
        fun create(id: String, title: String, date: String, pinned: Boolean = false): Anniversary {
            val trimmed = title.trim()
            require(trimmed.isNotEmpty()) { "标题不能为空" }
            require(IsoDate.isValid(date)) { "日期非法: $date" }
            return Anniversary(id, trimmed, date, pinned)
        }
    }
}
