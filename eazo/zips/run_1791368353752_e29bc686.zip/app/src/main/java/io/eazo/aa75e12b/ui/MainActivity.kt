package io.eazo.aa75e12b.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import io.eazo.aa75e12b.core.readOpenCreate
import io.eazo.aa75e12b.platform.AppRepo

/**
 * 单 Activity + Jetpack Compose(UI 锁死声明式——与鸿蒙 ArkUI 声明式对称)。
 *
 * 冷启动 onCreate(intent) 与热启动 onNewIntent(intent) 两路(生成器硬规则④)
 * 都收敛到同一 readOpenCreate 纯函数解析深链(focusId/openAdd);
 * onResume 只 render()(硬规则②:重读内存态,禁止从持久化 load)。
 */
class MainActivity : ComponentActivity() {

    /** 内存态刷新刻度:refresh/写操作通知 → +1 → Screen 重读 list()(硬规则②)。 */
    private val tick = mutableIntStateOf(0)
    private val openAddRequest = mutableStateOf(false)
    private val focusId = mutableStateOf<String?>(null)

    private val repoListener: () -> Unit = { tick.intValue += 1 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AppRepo.getRepo(this).subscribe(repoListener) // 冷启动装配:持久化→内存态一次
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CountdownScreen(
                        tick = tick.intValue,
                        openAddRequest = openAddRequest.value,
                        focusId = focusId.value,
                        onConsumeOpenAdd = { openAddRequest.value = false },
                        onConsumeFocus = { focusId.value = null },
                    )
                }
            }
        }
        if (savedInstanceState == null) {
            applyOpen(intent) // 硬规则④:冷启动路
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyOpen(intent) // 硬规则④:热启动路(singleTop 桌面卡片深链)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onDestroy() {
        AppRepo.getRepo(this).unsubscribe(repoListener)
        super.onDestroy()
    }

    /** 硬规则②:onResume 只重读内存态刷新(经 AppRepo.refresh 通知),绝不从持久化 load。 */
    private fun render() {
        AppRepo.getRepo(this).refresh()
    }

    /** 冷/热启动统一入口:readOpenCreate 纯函数,布尔严格判定(is Boolean && == true)。 */
    private fun applyOpen(intent: Intent?) {
        if (intent == null) return
        val extras = intent.extras
        val open = readOpenCreate(extras?.keySet()?.associateWith { extras.get(it) })
        if (open.openAdd) openAddRequest.value = true
        if (open.focusId != null) focusId.value = open.focusId
    }
}

/** 主题:暖白底 + 松绿主色;陶土棕=已过、琥珀=今天、松绿=剩余(卡片式排版配色源)。 */
private val LightScheme = lightColorScheme(
    primary = Color(0xFF3E6B4F),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD9EBDD),
    onPrimaryContainer = Color(0xFF0B2914),
    secondary = Color(0xFF8A5A3B),
    onSecondary = Color(0xFFFFFFFF),
    tertiary = Color(0xFFA85B1F),
    background = Color(0xFFF7F5F0),
    onBackground = Color(0xFF1B1F1D),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1B1F1D),
    surfaceVariant = Color(0xFFEDEAE3),
    onSurfaceVariant = Color(0xFF55605A),
    outline = Color(0xFF7C8A80),
    outlineVariant = Color(0xFFDCE0DA),
)

/** 应用主题(骨架位保留,仅注入本需求配色;不另建 XML 主题)。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightScheme, content = content)
}
