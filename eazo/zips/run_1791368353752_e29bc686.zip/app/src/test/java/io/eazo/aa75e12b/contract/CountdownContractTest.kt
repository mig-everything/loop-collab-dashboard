package io.eazo.aa75e12b.contract

import io.eazo.aa75e12b.core.Anniversary
import io.eazo.aa75e12b.core.AnniversaryCodec
import io.eazo.aa75e12b.core.AnniversaryFormat
import io.eazo.aa75e12b.core.AnniversaryStore
import io.eazo.aa75e12b.core.IsoDate
import io.eazo.aa75e12b.core.OpenCreate
import io.eazo.aa75e12b.core.readOpenCreate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 倒数日纪念日提醒 契约用例(JVM 纯逻辑,与鸿蒙 Hypium 同集同断言口径):
 * A 日期数学 / B 实体+排序 / C 最近一个(桌面卡片) / D 仓储+持久化 / E 深链解析 / F 文案口径。
 */
class CountdownContractTest {

    /** 固定"今天"锚点(确定性断言基准)。 */
    private val today = "2026-10-07"

    private fun delta(date: String): Long = IsoDate.days(date) - IsoDate.days(today)

    private fun item(id: String, date: String, pinned: Boolean = false, title: String = "T") =
        Anniversary.create(id, title, date, pinned)

    // ---------- A. 日期数学(契约 §1) ----------

    @Test
    fun `A1 日期校验 合法与非法`() {
        assertTrue(IsoDate.isValid("2026-10-07"))
        assertTrue(IsoDate.isValid("1999-12-31"))
        assertTrue(IsoDate.isValid("2026-04-30"))
        assertTrue(IsoDate.isValid("2100-02-28"))
        listOf(
            "",            // 空
            "2026-10-7",   // 日未补零
            "2026-1-07",   // 月未补零
            "26-10-07",    // 年非四位
            "2026/10/07",  // 分隔符
            "2026-13-01",  // 月超界
            "2026-00-10",  // 月为零
            "2026-10-00",  // 日为零
            "2026-10-32",  // 日超界
            "2026-09-31",  // 小月 31 日
            "2026-04-31",  // 小月 31 日
            "2026-02-30",  // 二月 30 日
            "abcd-ef-gh",  // 非数字
            "2026-10-07 ", // 尾随空格
        ).forEach { assertFalse("应判非法: $it", IsoDate.isValid(it)) }
    }

    @Test
    fun `A2 闰年规则`() {
        listOf(2024, 2000, 1600).forEach { assertTrue("应闰: $it", IsoDate.isLeap(it)) }
        listOf(2025, 2026, 1900, 2100).forEach { assertFalse("应平: $it", IsoDate.isLeap(it)) }
        assertEquals(29, IsoDate.daysInMonth(2024, 2))
        assertEquals(28, IsoDate.daysInMonth(2025, 2))
        assertEquals(28, IsoDate.daysInMonth(2100, 2))
        assertEquals(31, IsoDate.daysInMonth(2026, 10))
        assertEquals(30, IsoDate.daysInMonth(2026, 9))
        assertTrue(IsoDate.isValid("2024-02-29"))
        assertTrue(IsoDate.isValid("2000-02-29"))
        assertFalse(IsoDate.isValid("2025-02-29"))
        assertFalse(IsoDate.isValid("1900-02-29"))
    }

    @Test
    fun `A3 儒略日锚点`() {
        assertEquals(0L, IsoDate.days("1970-01-01"))
        assertEquals(365L, IsoDate.days("1971-01-01"))
        assertEquals(1L, IsoDate.days("2024-02-29") - IsoDate.days("2024-02-28"))
        assertEquals(20733L, IsoDate.days("2026-10-07")) // 双端共用锚点
        assertEquals(4, IsoDate.weekday("1970-01-01"))   // 周四
        assertEquals(3, IsoDate.weekday("2026-10-07"))   // 周三
    }

    @Test
    fun `A4 距今天数 未来过去今天`() {
        assertEquals(1L, delta("2026-10-08"))
        assertEquals(0L, delta("2026-10-07"))
        assertEquals(-1L, delta("2026-10-06"))
        assertEquals(25L, delta("2026-11-01"))   // 跨月
        assertEquals(-7L, delta("2026-09-30"))   // 跨月回望
        assertEquals(145L, delta("2027-03-01"))  // 跨年(2027 平年)
        assertEquals(365L, delta("2027-10-07"))
        assertEquals(-365L, delta("2025-10-07"))
        // 闰日落在区间内:+1(2024-02-29 ∈ [2024-01-01, 2025-01-01))
        assertEquals(366L, IsoDate.days("2025-01-01") - IsoDate.days("2024-01-01"))
        assertEquals(365L, IsoDate.days("2025-03-01") - IsoDate.days("2024-03-01"))
    }

    // ---------- B. 实体与列表排序(契约 §2/§3,硬规则③) ----------

    @Test
    fun `B1 实体字段契约与校验闸口`() {
        val a = Anniversary.create("cd-1", "  生日 ", "2026-12-25")
        assertEquals("生日", a.title) // 标题 trim
        assertEquals("2026-12-25", a.date)
        assertFalse(a.pinned) // 默认未置顶
        assertTrue(Anniversary.create("cd-1", "x", "2026-12-25", true).pinned)
        // 非法标题/日期必须被闸口拒绝
        assertFails { Anniversary.create("cd-1", "", "2026-12-25") }
        assertFails { Anniversary.create("cd-1", "   ", "2026-12-25") }
        assertFails { Anniversary.create("cd-1", "标题", "2026-12-5") }
        assertFails { Anniversary.create("cd-1", "标题", "2026-13-01") }
    }

    @Test
    fun `B2 列表排序 置顶优先`() {
        val store = AnniversaryStore()
        store.insert(item("a", "2027-01-15"))          // +100 远
        store.insert(item("b", "2026-10-06", true))    // -1 且置顶
        store.insert(item("c", "2026-10-09"))          // +2 近
        assertEquals(listOf("b", "c", "a"), store.list(today).map { it.id })
    }

    @Test
    fun `B3 列表排序 距今天数绝对值升序`() {
        val store = AnniversaryStore()
        store.insert(item("a", "2026-10-02")) // -5 → |5|
        store.insert(item("b", "2026-11-06")) // +30 → |30|
        store.insert(item("c", "2026-10-06")) // -1 → |1|
        store.insert(item("d", "2026-10-09")) // +2 → |2|
        assertEquals(listOf("c", "d", "a", "b"), store.list(today).map { it.id })
    }

    @Test
    fun `B4 列表排序 同距按日期升序`() {
        val store = AnniversaryStore()
        store.insert(item("a", "2026-10-10")) // +3
        store.insert(item("b", "2026-10-04")) // -3,同 |3| 且日期在前
        assertEquals(listOf("b", "a"), store.list(today).map { it.id })
    }

    @Test
    fun `B5 列表排序 id字典序兜底`() {
        val store = AnniversaryStore()
        store.insert(item("cd-9", "2026-12-25"))
        store.insert(item("cd-2", "2026-12-25"))
        store.insert(item("cd-10", "2026-12-25"))
        assertEquals(listOf("cd-10", "cd-2", "cd-9"), store.list(today).map { it.id })
    }

    // ---------- C. 最近一个(桌面卡片口径,契约 §6) ----------

    @Test
    fun `C1 最近一个 忽略置顶`() {
        val store = AnniversaryStore()
        store.insert(item("far", "2027-01-15", true)) // 置顶但 +100
        store.insert(item("nearFuture", "2026-10-09"))
        store.insert(item("nearPast", "2026-10-06"))  // |1| 最近
        assertEquals("nearPast", store.nearest(today)?.id)
        // 同 |days| 平手 → 日期升序(过去侧在前)
        val tie = AnniversaryStore()
        tie.insert(item("f", "2026-10-10"))
        tie.insert(item("p", "2026-10-04"))
        assertEquals("p", tie.nearest(today)?.id)
    }

    @Test
    fun `C2 最近一个 空态与单条`() {
        val empty = AnniversaryStore()
        assertNull(empty.nearest(today))
        val single = AnniversaryStore()
        single.insert(item("only", "2030-01-01", true))
        assertEquals("only", single.nearest(today)?.id)
    }

    // ---------- D. 仓储与持久化(契约 §3/§4) ----------

    @Test
    fun `D1 增删改查与置顶切换`() {
        val store = AnniversaryStore()
        store.insert(item("a", "2026-10-09"))
        store.insert(item("b", "2027-01-15"))
        store.insert(item("c", "2026-10-06"))
        assertEquals(3, store.size())
        assertEquals("c", store.get("c")?.id)
        // 置顶 → 升到列表头;取消 → 回到 |days| 序
        assertTrue(store.setPinned("b", true))
        assertEquals(listOf("b", "c", "a"), store.list(today).map { it.id })
        assertTrue(store.setPinned("b", false))
        assertEquals(listOf("c", "a", "b"), store.list(today).map { it.id })
        // 删除
        assertTrue(store.remove("c"))
        assertFalse(store.remove("c"))
        assertFalse(store.remove("不存在的id"))
        assertEquals(listOf("a", "b"), store.list(today).map { it.id })
        // 同 id 再 insert = 整体覆盖(upsert)
        store.insert(item("a", "2026-10-06", title = "改期"))
        assertEquals(2, store.size())
        assertEquals("改期", store.get("a")?.title)
        // 幂等置顶(状态未变)也返回 true
        assertTrue(store.setPinned("a", false))
    }

    @Test
    fun `D2 持久化编解码往返与容错`() {
        val items = listOf(
            item("cd-1", "2026-12-25", true, "领证纪念日"),
            item("cd-2", "2027-02-14", false, "情人节"),
        )
        val encoded = AnniversaryCodec.encode(items)
        assertEquals(
            "cd-1\u001F领证纪念日\u001F2026-12-25\u001Ftrue\u001Ecd-2\u001F情人节\u001F2027-02-14\u001Ffalse",
            encoded,
        )
        // 往返:集合与顺序完全一致
        assertEquals(items, AnniversaryCodec.decode(encoded))
        // 空串
        assertTrue(AnniversaryCodec.decode("").isEmpty())
        // 畸形行静默跳过:坏日期 / 字段数不足 / pinned 非法 / 整行垃圾,好行保留
        val dirty = listOf(
            "cd-1\u001F坏日期\u001F2026-13-01\u001Ftrue",
            "cd-2\u001F字段不足\u001F2026-11-11",
            "cd-3\u001F坏布尔\u001F2026-11-11\u001Fyes",
            "整行垃圾",
            "cd-4\u001F好行\u001F2026-11-11\u001Ffalse",
        ).joinToString("\u001E")
        val decoded = AnniversaryCodec.decode(dirty)
        assertEquals(listOf("cd-4"), decoded.map { it.id })
        // 标题含分隔符 → 消毒为空格,不破坏记录边界
        val tricky = AnniversaryCodec.encode(listOf(item("cd-9", "2026-10-07", title = "正常\u001F标题\u001E里")))
        assertEquals(1, AnniversaryCodec.decode(tricky).size)
        assertEquals("正常 标题 里", AnniversaryCodec.decode(tricky)[0].title)
    }

    // ---------- E. 深链解析(硬规则④) ----------

    @Test
    fun `E1 readOpenCreate 严格布尔与深链参数`() {
        assertEquals(OpenCreate.NONE, readOpenCreate(null))
        assertEquals(OpenCreate.NONE, readOpenCreate(emptyMap()))
        // openAdd 仅接受严格 Boolean true
        assertTrue(readOpenCreate(mapOf("openAdd" to true)).openAdd)
        assertFalse(readOpenCreate(mapOf("openAdd" to "true")).openAdd)   // 字符串
        assertFalse(readOpenCreate(mapOf("openAdd" to 1)).openAdd)        // 整型
        assertFalse(readOpenCreate(mapOf("openAdd" to false)).openAdd)
        assertFalse(readOpenCreate(mapOf<String, Any?>("focusId" to "cd-1")).openAdd)
        // focusId 仅接受非空白 String
        assertEquals("cd-1", readOpenCreate(mapOf("focusId" to "cd-1")).focusId)
        assertNull(readOpenCreate(mapOf("focusId" to "  ")).focusId)
        assertNull(readOpenCreate(mapOf<String, Any?>("focusId" to 123)).focusId)
        assertNull(readOpenCreate(mapOf<String, Any?>("focusId" to null)).focusId)
        // 组合
        val combo = readOpenCreate(mapOf("focusId" to "cd-9", "openAdd" to true, "noise" to "x"))
        assertEquals(OpenCreate("cd-9", true), combo)
    }

    @Test
    fun `E2 端到端 列表与最近口径联动`() {
        val store = AnniversaryStore()
        store.insert(item("far", "2027-01-15", true)) // 置顶 +100
        store.insert(item("near", "2026-10-06"))      // -1
        store.insert(item("mid", "2026-11-06"))       // +30
        // 列表头=置顶,最近(卡片口径)=忽略置顶的 near
        assertEquals("far", store.list(today).first().id)
        assertEquals("near", store.nearest(today)?.id)
        // 删掉最近 → 卡片切到 mid
        store.remove("near")
        assertEquals("mid", store.nearest(today)?.id)
        // 把 mid 置顶 → 列表头换人,最近不变(仍是 mid)
        store.setPinned("mid", true)
        assertEquals("mid", store.list(today).first().id)
        assertEquals("mid", store.nearest(today)?.id)
        // far 取消置顶 → 按 |days| 回到队尾
        store.setPinned("far", false)
        assertEquals(listOf("mid", "far"), store.list(today).map { it.id })
    }

    // ---------- F. 展示文案口径(契约 §5,UI/卡片共用) ----------

    @Test
    fun `F 展示文案口径`() {
        assertEquals("还有 366 天", AnniversaryFormat.daysText(366))
        assertEquals("还有 1 天", AnniversaryFormat.daysText(1))
        assertEquals("已过 400 天", AnniversaryFormat.daysText(-400))
        assertEquals("已过 1 天", AnniversaryFormat.daysText(-1))
        assertEquals("就是今天", AnniversaryFormat.daysText(0))
        assertEquals("还有", AnniversaryFormat.stateLabel(9))
        assertEquals("已过", AnniversaryFormat.stateLabel(-9))
        assertEquals("今天", AnniversaryFormat.stateLabel(0))
        assertEquals("366", AnniversaryFormat.dayNumber(366))
        assertEquals("400", AnniversaryFormat.dayNumber(-400))
        assertEquals("今天", AnniversaryFormat.dayNumber(0))
        assertEquals("2026年10月7日", AnniversaryFormat.dateText("2026-10-07"))
        assertEquals("周三", AnniversaryFormat.weekdayText("2026-10-07"))
        assertEquals("周四", AnniversaryFormat.weekdayText("1970-01-01"))
    }

    private fun assertFails(block: () -> Unit) {
        var threw = false
        try {
            block()
        } catch (_: IllegalArgumentException) {
            threw = true
        }
        assertTrue("应抛 IllegalArgumentException", threw)
    }
}
