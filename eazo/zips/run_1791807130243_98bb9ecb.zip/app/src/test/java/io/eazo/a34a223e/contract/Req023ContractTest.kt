package io.eazo.a34a223e.contract

import io.eazo.a34a223e.core.PasswordCore
import io.eazo.a34a223e.core.PasswordCore.buildCharset
import io.eazo.a34a223e.core.PasswordCore.entropyBits
import io.eazo.a34a223e.core.PasswordCore.generatePassword
import io.eazo.a34a223e.core.PasswordCore.lcgStates
import io.eazo.a34a223e.core.PasswordCore.poolSize
import io.eazo.a34a223e.core.PasswordCore.strengthLabel
import io.eazo.a34a223e.model.AMBIGUOUS
import io.eazo.a34a223e.model.CS_BYTES
import io.eazo.a34a223e.model.CS_SHA256
import io.eazo.a34a223e.model.DIGITS
import io.eazo.a34a223e.model.LOWERCASE
import io.eazo.a34a223e.model.SYMBOLS
import io.eazo.a34a223e.model.UPPERCASE
import io.eazo.a34a223e.ui.twoColumns
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.security.MessageDigest

/**
 * REQ-023 契约测试（02-interface-contract v1.0@55989d2）——slug 逐字等于
 * cases-frozen.json 14 条；锚点 = §6 全集（哈希2 + poolSize10 + 熵20 + 强度13
 * + 密码6 + LCG状态1 + 域收敛4 + 常量直断言 + 判别面 C09/C10/C12/C13/C14）。
 */
class Req023ContractTest {

    private fun sha256(b: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }

    // ---------- C01 长度 4~32 整数，越界收敛 ----------
    @Test
    fun `length_adjust_range`() {
        assertEquals(4, PasswordCore.clampLength(3))    // §6.6
        assertEquals(4, PasswordCore.clampLength(4))
        assertEquals(32, PasswordCore.clampLength(32))
        assertEquals(32, PasswordCore.clampLength(33))
        // 整数域全收敛
        for (l in -10..100) assertTrue(PasswordCore.clampLength(l) in 4..32)
    }

    // ---------- C02 四开关可组合（至少选一守卫） ----------
    @Test
    fun `charset_toggle_select`() {
        // 15 个非空组合均可产出非空字符集（§2.6 守卫 + §6.2 值域）
        var combos = 0
        for (u in listOf(true, false)) for (l in listOf(true, false))
        for (d in listOf(true, false)) for (s in listOf(true, false)) {
            if (!(u || l || d || s)) continue           // 全 false 由运行层拒绝
            combos++
            assertTrue(buildCharset(u, l, d, s, false).isNotEmpty())
        }
        assertEquals(15, combos)
        // 守卫纯语义：全 false → 守卫触发（AppRepo.setFlag 同语义，不产生空集）
        assertTrue(!(false || false || false || false))
    }

    // ---------- C03 排除易混淆：生成密码不含 0O1lI ----------
    @Test
    fun `exclude_ambiguous_toggle`() {
        // poolSize 排除变体锚点（§6.2 右列）
        assertEquals(65, poolSize(upper = true, lower = true, digit = true, symbol = true, excl = true))
        assertEquals(57, poolSize(upper = true, lower = true, digit = true, symbol = false, excl = true))
        assertEquals(33, poolSize(upper = false, lower = true, digit = true, symbol = false, excl = true))
        assertEquals(25, poolSize(upper = false, lower = true, digit = false, symbol = false, excl = true))
        assertEquals(5, AMBIGUOUS.length)               // 排除表恰 5 字符
        // 字符级校验：多 seed 生成均不含 0O1lI
        for (seed in 1..20) {
            val pw = generatePassword(seed, 32, buildCharset(true, true, true, true, true))
            for (c in AMBIGUOUS) assertFalse("seed=$seed 含 $c", pw.contains(c))
        }
    }

    // ---------- C04 拼接确定性：lower→upper→digit→symbol 固定顺序 ----------
    @Test
    fun `charset_build_deterministic`() {
        val full = buildCharset(true, true, true, true, false)
        assertEquals(LOWERCASE + UPPERCASE + DIGITS + SYMBOLS, full)
        assertEquals(70, full.length)
        // 顺序锚点：小写段 < 大写段 < 数字段 < 符号段（V8 判别面）
        assertTrue(full.indexOf('a') < full.indexOf('A'))
        assertTrue(full.indexOf('A') < full.indexOf('0'))
        assertTrue(full.indexOf('0') < full.indexOf('!'))
        // 过滤锚点：excl 逐字符剔除 0O1lI（拼后作用）
        val filtered = buildCharset(true, true, true, true, true)
        assertEquals(65, filtered.length)
        for (c in AMBIGUOUS) assertFalse(filtered.contains(c))
        assertEquals("abcdefghijkmnopqrstuvwxyz", buildCharset(false, true, false, false, true))
    }

    // ---------- C05 池大小十组锚点 ----------
    @Test
    fun `pool_size_deterministic`() {
        assertEquals(70, poolSize(true, true, true, true, false))     // 全四集
        assertEquals(62, poolSize(true, true, true, false, false))    // 大小写+数字
        assertEquals(36, poolSize(false, true, true, false, false))   // 小写+数字
        assertEquals(26, poolSize(false, true, false, false, false))  // 仅小写
        assertEquals(10, poolSize(false, false, true, false, false))  // 仅数字
        assertEquals(8, poolSize(false, false, false, true, false))   // 仅符号
        assertEquals(65, poolSize(true, true, true, true, true))      // 全四集·排易混
        assertEquals(57, poolSize(true, true, true, false, true))
        assertEquals(33, poolSize(false, true, true, false, true))
        assertEquals(25, poolSize(false, true, false, false, true))
    }

    // ---------- C06 熵位数二十锚点（half-up） ----------
    @Test
    fun `entropy_bits_deterministic`() {
        val a = listOf(
            Triple(16, 70, 98), Triple(12, 70, 74), Triple(8, 70, 49), Triple(4, 70, 25),
            Triple(16, 62, 95), Triple(12, 62, 71), Triple(8, 62, 48), Triple(16, 36, 83),
            Triple(12, 36, 62), Triple(8, 36, 41), Triple(4, 36, 21), Triple(16, 26, 75),
            Triple(8, 26, 38), Triple(4, 26, 19), Triple(16, 65, 96), Triple(8, 57, 47),
            Triple(16, 10, 53), Triple(8, 33, 40), Triple(8, 8, 24), Triple(4, 25, 19),
        )
        for ((l, p, e) in a) assertEquals("l=$l p=$p", e, entropyBits(l, p))
        // 判别点复核：4×26=18.75→19（floor 分叉）、8×8=24（精确整数）
        assertEquals(19, entropyBits(4, 26))
        assertEquals(24, entropyBits(8, 8))
    }

    // ---------- C07 强度分级十三锚点（整数阈值） ----------
    @Test
    fun `strength_label_classify`() {
        val expect = mapOf(
            19 to "weak", 38 to "weak", 39 to "weak",
            40 to "fair", 49 to "fair", 59 to "fair",
            60 to "strong", 74 to "strong", 79 to "strong",
            80 to "very_strong", 83 to "very_strong", 95 to "very_strong", 98 to "very_strong",
        )
        for ((e, label) in expect) assertEquals("e=$e", label, strengthLabel(e))
    }

    // ---------- C08 密码生成确定性六锚点 + LCG 状态 ----------
    @Test
    fun `generate_password_deterministic`() {
        assertEquals("MwOvDAZ2chORWjwj",
            generatePassword(20261012, 16, buildCharset(true, true, true, true, false)))
        assertEquals("cMoHJaXseFKt",
            generatePassword(20261012, 12, buildCharset(true, true, true, false, false)))
        assertEquals("ZNkXEwre!sRtZ*CK",
            generatePassword(20261012, 16, buildCharset(true, true, true, true, true)))
        assertEquals("gtrlcvru",
            generatePassword(42, 8, buildCharset(false, true, true, false, false)))
        assertEquals("lrfk",
            generatePassword(1, 4, buildCharset(false, true, false, false, false)))
        assertEquals("82019614",
            generatePassword(20261012, 8, buildCharset(false, false, true, false, false)))
        // 同 seed 复跑恒等（A7.1）+ LCG 状态八条（§6.5）
        val cs = buildCharset(true, true, true, true, false)
        assertEquals(generatePassword(20261012, 16, cs), generatePassword(20261012, 16, cs))
        assertEquals(
            listOf(1224412458L, 1511876052L, 1074294660L, 1775330291L,
                838409419L, 1506897166L, 1146019891L, 375478094L),
            lcgStates(20261012, 8),
        )
        // 常量直断言（§1.2）
        assertEquals(2147483647L, PasswordCore.M_LCG)
        assertEquals(16807L, PasswordCore.A_LCG)
        assertEquals(20261012, PasswordCore.DEFAULT_SEED)
        // 负 seed 归正（§2.3 注5 语言中立式）：-1 ≡ M-1 → 与 seed=M-1 同密码
        assertEquals(generatePassword(2147483646, 8, cs), generatePassword(-1, 8, cs))
    }

    // ---------- C09 生成字符均在所选字符集内（D4 全量范式：50 seed × 6 配置） ----------
    @Test
    fun `generate_password_in_charset`() {
        val cfgs = listOf(
            arrayOf(true, true, true, true), arrayOf(true, true, true, false),
            arrayOf(false, true, true, false), arrayOf(false, true, false, false),
            arrayOf(false, false, true, false), arrayOf(false, false, false, true),
        )
        for (f in cfgs) {
            val charset = buildCharset(f[0], f[1], f[2], f[3], excl = false)
            for (seed in 1..50) {
                val pw = generatePassword(seed, 32, charset)
                assertEquals(32, pw.length)
                for (c in pw) assertTrue("seed=$seed c=$c", c in charset)
            }
        }
    }

    // ---------- C10 不同 seed 生成不同密码 ----------
    @Test
    fun `generate_password_differs_by_seed`() {
        val cs = buildCharset(true, true, true, true, false)
        val a = generatePassword(20261012, 16, cs)
        val b = generatePassword(42, 16, cs)
        assertFalse(a == b)
        // 201 seed 稳定/互异抽样（组D D2 范式缩样）
        val set = HashSet<String>()
        for (seed in 1..200) set.add(generatePassword(seed, 16, cs))
        assertTrue(set.size > 190)
    }

    // ---------- C11 字符集常量序列化哈希 ----------
    @Test
    fun `charset_constant_serialization_hash`() {
        val ser = "LOWERCASE|$LOWERCASE\nUPPERCASE|$UPPERCASE\nDIGITS|$DIGITS\nSYMBOLS|$SYMBOLS\nAMBIGUOUS|$AMBIGUOUS"
        val bytes = ser.toByteArray(Charsets.UTF_8)
        assertEquals(124, bytes.size)
        assertEquals(CS_BYTES, bytes.size)
        assertEquals(CS_SHA256, sha256(bytes))
        // 数据面结构直断言：5 项定长
        assertEquals(26, LOWERCASE.length); assertEquals(26, UPPERCASE.length)
        assertEquals(10, DIGITS.length); assertEquals(8, SYMBOLS.length)
    }

    // ---------- C12 无非确定性随机源（core 纯函数层静态 grep 零命中） ----------
    @Test
    fun `no_math_random`() {
        val candidates = listOf(
            File("src/main/java/io/eazo/a34a223e/core/PasswordCore.kt"),
            File("app/src/main/java/io/eazo/a34a223e/core/PasswordCore.kt"),
        )
        val src = candidates.firstOrNull { it.exists() }?.readText()
            ?: error("PasswordCore.kt not found: ${candidates.map { it.absolutePath }}")
        val banned = listOf("Math.random", "kotlin.random", "SecureRandom", "java.util.Random",
            "Date", "System.currentTimeMillis", "SystemClock", "setInterval")
        for (b in banned) assertFalse("core 命中禁用项 $b", src.contains(b))
    }

    // ---------- C13 一键复制：当前密码即剪贴板载荷 ----------
    @Test
    fun `copy_to_clipboard`() {
        // 剪贴板端口 = Compose LocalClipboardManager.setText(AnnotatedString(password))（§3）
        // 写入成功即 PASS；此处断言载荷 = 当前态确定性密码（UI 复制按钮写入的同一字符串）
        val payload = generatePassword(20261012, 16, buildCharset(true, true, true, true, false))
        assertTrue(payload.isNotEmpty())
        assertEquals("MwOvDAZ2chORWjwj", payload)
    }

    // ---------- C14 多端自适应：600dp 单列/双列（Should，可降级） ----------
    @Test
    fun `multiscreen_adaptive`() {
        assertFalse(twoColumns(599f))   // 手机竖屏 → 单列
        assertTrue(twoColumns(600f))    // 平板横屏 → 双列
        assertTrue(twoColumns(840f))
    }
}
