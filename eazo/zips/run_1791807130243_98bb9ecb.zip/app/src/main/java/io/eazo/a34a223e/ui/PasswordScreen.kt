package io.eazo.a34a223e.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.a34a223e.core.PasswordCore
import io.eazo.a34a223e.platform.AppRepo

/** 强度档视觉映射（展示态——值断言用英文枚举，色彩不入对账面）。 */
private fun strengthColor(label: String): Color = when (label) {
    "weak" -> Color(0xFFE53935)
    "fair" -> Color(0xFFFB8C00)
    "strong" -> Color(0xFF1E88E5)
    else -> Color(0xFF43A047)
}

private fun strengthCn(label: String): String = when (label) {
    "weak" -> "弱"; "fair" -> "中"; "strong" -> "强"; else -> "很强"
}

/** C14 多端自适应阈值（04 §1 第 14 次复用：≥600dp 双列，否则单列）——纯函数可单测。 */
internal fun twoColumns(maxWidthDp: Float): Boolean = maxWidthDp >= 600f

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PasswordScreen(repo: AppRepo) {
    val st = repo.state   // Compose 快照读取——AppRepo.state 变更自动重组
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    var seedText by remember(st.seed) { mutableStateOf(st.seed.toString()) }

    val password = with(st) {
        PasswordCore.generatePassword(seed, length, PasswordCore.buildCharset(upper, lower, digit, symbol, excl))
    }
    val pool = with(st) { PasswordCore.poolSize(upper, lower, digit, symbol, excl) }
    val entropy = PasswordCore.entropyBits(st.length, pool)
    val label = PasswordCore.strengthLabel(entropy)
    val color = strengthColor(label)

    // C14 多端自适应：≥600dp 双列（平板横屏），否则单列（手机竖屏）
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val twoCol = twoColumns(maxWidth.value)
        val resultCard: @Composable () -> Unit = {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("当前密码", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        password,
                        fontFamily = FontFamily.Monospace,
                        fontSize = if (st.length > 24) 18.sp else 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp, 10.dp).background(color, CircleShape))
                        Spacer(Modifier.width(8.dp))
                        Text("${entropy} bits · ${strengthCn(label)}", color = color, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(6.dp))
                    Box(
                        Modifier.fillMaxWidth().height(6.dp)
                            .background(color.copy(alpha = 0.25f), RoundedCornerShape(3.dp))
                    ) {
                        Box(Modifier.fillMaxWidth(entropy.coerceIn(0, 190) / 190f).height(6.dp).background(color, RoundedCornerShape(3.dp)))
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { clipboard.setText(AnnotatedString(password)); copied = true }, modifier = Modifier.weight(1f)) {
                            if (copied) { Icon(Icons.Filled.Check, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)) }
                            Text(if (copied) "已复制" else "复制")
                        }
                        OutlinedButton(onClick = { repo.regenerate(); copied = false }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Refresh, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("重新生成")
                        }
                    }
                }
            }
        }
        val settingsCard: @Composable () -> Unit = {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(1.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("长度", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.weight(1f))
                        OutlinedButton(onClick = { repo.setLength(st.length - 1) }, enabled = st.length > 4) {
                            Text("−", fontSize = 18.sp)
                        }
                        Text("${st.length}", Modifier.padding(horizontal = 14.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        OutlinedButton(onClick = { repo.setLength(st.length + 1) }, enabled = st.length < 32) {
                            Text("+", fontSize = 18.sp)
                        }
                    }
                    Slider(
                        value = st.length.toFloat(),
                        onValueChange = { repo.setLength(it.toInt()) },
                        valueRange = 4f..32f,
                        steps = 27,
                    )
                    Text("4 ~ 32 · 池大小 $pool", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Spacer(Modifier.height(16.dp))
                    Text("字符集", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(st.upper, { repo.setFlag(upper = !st.upper) }, label = { Text("大写 A-Z") }, modifier = Modifier.weight(1f))
                        FilterChip(st.lower, { repo.setFlag(lower = !st.lower) }, label = { Text("小写 a-z") }, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                        FilterChip(st.digit, { repo.setFlag(digit = !st.digit) }, label = { Text("数字 0-9") }, modifier = Modifier.weight(1f))
                        FilterChip(st.symbol, { repo.setFlag(symbol = !st.symbol) }, label = { Text("符号 !@#") }, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("排除易混淆字符", style = MaterialTheme.typography.bodyMedium)
                            Text("0 O 1 l I", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(st.excl, { repo.setExcl(it) })
                    }

                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = seedText,
                        onValueChange = { v ->
                            seedText = v
                            if (!repo.setSeed(v)) { /* 非法输入回退当前 seed，不清空 */ }
                        },
                        label = { Text("种子（同 seed 同规则 → 同密码）") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("密码生成器", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            if (twoCol) Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) { settingsCard() }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) { resultCard() }
            } else {
                resultCard(); settingsCard()
            }
        }
    }
}
