package io.eazo.a34a223e.core

import io.eazo.a34a223e.model.AMBIGUOUS
import io.eazo.a34a223e.model.DIGITS
import io.eazo.a34a223e.model.LOWERCASE
import io.eazo.a34a223e.model.SYMBOLS
import io.eazo.a34a223e.model.UPPERCASE
import kotlin.math.log2

/**
 * REQ-023 确定性核心（契约 §2 纯函数族，v1.0@55989d2）。
 * 零随机、零时钟、零 IO（§8 D8：本文件禁用清单所列随机/时钟类 API 全部零引用，
 * 唯一随机取用点在 platform/AppRepo 重新生成路径）。
 */
object PasswordCore {

    const val M_LCG = 2147483647L          // Park-Miller 模（2^31−1）
    const val A_LCG = 16807L               // Park-Miller 乘子
    const val DEFAULT_SEED = 20261012
    const val LEN_MIN = 4
    const val LEN_MAX = 32

    /** §2.1 字符集拼接——固定顺序 lowercase→uppercase→digits→symbols，excl 逐字符剔除 0O1lI。 */
    fun buildCharset(upper: Boolean, lower: Boolean, digit: Boolean, symbol: Boolean, excl: Boolean): String {
        var s = ""
        if (lower) s += LOWERCASE
        if (upper) s += UPPERCASE
        if (digit) s += DIGITS
        if (symbol) s += SYMBOLS
        if (excl) s = s.filter { it !in AMBIGUOUS }
        return s
    }

    /** §2.4 poolSize = buildCharset(...).length（整数域）。 */
    fun poolSize(upper: Boolean, lower: Boolean, digit: Boolean, symbol: Boolean, excl: Boolean): Int =
        buildCharset(upper, lower, digit, symbol, excl).length

    /** §2.2 熵位数——round half-up（正数域 floor(x+0.5)），禁 half-even/浮点 floor。 */
    fun entropyBits(len: Int, pool: Int): Int = Math.round(len * log2(pool.toDouble())).toInt()

    /** §2.4 强度分级——整数阈值 39|40 / 59|60 / 79|80。 */
    fun strengthLabel(e: Int): String = when {
        e < 40 -> "weak"
        e < 60 -> "fair"
        e < 80 -> "strong"
        else -> "very_strong"
    }

    /** §2.4 长度域收敛——越界收敛到边界。 */
    fun clampLength(l: Int): Int = maxOf(LEN_MIN, minOf(LEN_MAX, l))

    /**
     * §2.3 密码合成——Park-Miller LCG（M=2147483647, A=16807）。
     * Kotlin 必须 Long（中间积 ≤ 3.6e13 < 2^53，禁 Int 溢出）；
     * 负 seed 归正 `((seed % M) + M) % M` 语言中立式；无「每集保底」。
     */
    fun generatePassword(seed: Int, length: Int, charset: String): String {
        if (charset.isEmpty()) return ""                    // R4 除零防线
        var state = (seed.toLong() % M_LCG).let { if (it < 0) it + M_LCG else it }
        if (state == 0L) state = 1L
        val sb = StringBuilder()
        repeat(length) {
            state = (state * A_LCG) % M_LCG
            sb.append(charset[(state % charset.length).toInt()])
        }
        return sb.toString()
    }

    /** §6.5 LCG 状态序列（seed=20261012，state_1..n）——测试锚点辅助。 */
    fun lcgStates(seed: Int, n: Int): List<Long> {
        var state = (seed.toLong() % M_LCG).let { if (it < 0) it + M_LCG else it }
        if (state == 0L) state = 1L
        val out = ArrayList<Long>(n)
        repeat(n) {
            state = (state * A_LCG) % M_LCG
            out.add(state)
        }
        return out
    }
}
