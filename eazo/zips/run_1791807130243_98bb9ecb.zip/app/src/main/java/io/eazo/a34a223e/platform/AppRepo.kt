package io.eazo.a34a223e.platform

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import io.eazo.a34a223e.core.PasswordCore
import java.security.SecureRandom

/**
 * 平台层：AppRepo 进程内单例（硬规则 ①——UI/卡片层一律经 AppRepo.getRepo(context) 获取）。
 *
 * 内存态为唯一数据源：控件 → AppRepo.state → core 纯函数 → 密码/强度 → UI（单向数据流，
 * 契约 §2.5）；持久化只在 init 落一次 load、变更时 write（§3 SharedPreferences 同键）。
 *
 * 随机源唯一取用点 = regenerate()（契约 §2.5/§8：SecureRandom 仅派生新 seed 触发重算，
 * 不承载确定性）；core/data 层零随机零时钟。
 */
object AppRepo {

    /** 运行层状态（契约 §1.1 GeneratorState）。 */
    data class GeneratorState(
        val length: Int = 16,
        val upper: Boolean = true,
        val lower: Boolean = true,
        val digit: Boolean = true,
        val symbol: Boolean = true,
        val excl: Boolean = false,
        val seed: Int = PasswordCore.DEFAULT_SEED,
    )

    @Volatile private var inited = false
    private val prefs by lazy { appContext.getSharedPreferences("req023_prefs", Context.MODE_PRIVATE) }
    private lateinit var appContext: Context

    /** 内存态（Compose 快照——UI 订阅自动重组）。 */
    var state by mutableStateOf(GeneratorState())
        private set

    private val rng = SecureRandom()

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo {
        if (!inited) {
            synchronized(this) {
                if (!inited) {
                    appContext = context.applicationContext
                    load()
                    inited = true
                }
            }
        }
        return this
    }

    /** 硬规则 ②：refresh 只重读内存态，禁止从持久化 load()。 */
    fun refresh() {
        // state 即内存态快照，无持久化读取
    }

    /** 当前密码（单态联动：任何变更后以当前 seed 立即重算，契约 §2.6）。 */
    fun currentPassword(): String = with(state) {
        PasswordCore.generatePassword(seed, length, PasswordCore.buildCharset(upper, lower, digit, symbol, excl))
    }

    /** 当前熵位数。 */
    fun currentEntropyBits(): Int = with(state) {
        PasswordCore.entropyBits(length, PasswordCore.poolSize(upper, lower, digit, symbol, excl))
    }

    fun setLength(l: Int) {
        mutate { it.copy(length = PasswordCore.clampLength(l)) }
    }

    /** §2.6「至少一集」守卫：取消最后一个开启的开关 → 拒绝该次变更。 */
    fun setFlag(upper: Boolean? = null, lower: Boolean? = null, digit: Boolean? = null, symbol: Boolean? = null) {
        mutate { s ->
            val n = s.copy(
                upper = upper ?: s.upper, lower = lower ?: s.lower,
                digit = digit ?: s.digit, symbol = symbol ?: s.symbol,
            )
            if (n.upper || n.lower || n.digit || n.symbol) n else s
        }
    }

    fun setExcl(excl: Boolean) {
        mutate { it.copy(excl = excl) }
    }

    /** §2.6：种子输入非法（非整数/空）→ 回退当前 seed（不崩溃、不清空）。 */
    fun setSeed(raw: String): Boolean {
        val v = raw.trim().toIntOrNull() ?: return false
        mutate { it.copy(seed = v) }
        return true
    }

    /** 重新生成 → 新随机 seed（§2.5 唯一随机取用点）→ 单态重算。 */
    fun regenerate() {
        mutate { it.copy(seed = rng.nextInt(100_000_000)) }
    }

    private fun mutate(f: (GeneratorState) -> GeneratorState) {
        state = f(state)
        persist()
    }

    /** §3 持久化：last_length/last_flags/last_seed（+last_excl），重启恢复 + 域校验。 */
    private fun persist() {
        with(state) {
            prefs.edit()
                .putInt("last_length", length)
                .putString("last_flags", "${if (upper) "1" else "0"}${if (lower) "1" else "0"}${if (digit) "1" else "0"}${if (symbol) "1" else "0"}")
                .putBoolean("last_excl", excl)
                .putInt("last_seed", seed)
                .apply()
        }
    }

    private fun load() {
        val l = PasswordCore.clampLength(prefs.getInt("last_length", 16))
        val fb = prefs.getString("last_flags", "1111") ?: "1111"
        var st = GeneratorState(
            length = l,
            upper = fb.getOrNull(0) == '1', lower = fb.getOrNull(1) == '1',
            digit = fb.getOrNull(2) == '1', symbol = fb.getOrNull(3) == '1',
            excl = prefs.getBoolean("last_excl", false),
            seed = prefs.getInt("last_seed", PasswordCore.DEFAULT_SEED),
        )
        // 域校验：全 false 兜底回默认四开
        if (!(st.upper || st.lower || st.digit || st.symbol)) st = st.copy(upper = true, lower = true, digit = true, symbol = true)
        state = st
    }
}
