package io.eazo.d2ba9433.platform

import android.content.Context
import io.eazo.d2ba9433.core.ConvertCore
import io.eazo.d2ba9433.model.Currency

/**
 * 平台层仓储：AppRepo 进程内单例（生成器硬规则 ①——UI/卡片层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * 本 REQ 契约 §2.5：单态 state(amount_cents, src, dst) + swap()，无持久化
 * （重启回默认 1 USD→CNY 属可接受行为）；无 want/intent 数据入口
 * （冷/热启动均落默认态，与鸿蒙端 readOpenCreate 空载语义一致）。
 * refresh 只重读内存态（硬规则 ②）。
 */
object AppRepo {

    // ===== 单态内存态（契约 §2.5 控件状态机；默认 = 1 USD → CNY）=====
    private var amountFen: Long = ConvertCore.DEFAULT_AMOUNT_FEN
    private var src: String = "USD"
    private var dst: String = "CNY"

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo = this

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化 load（本 REQ 无持久化，空实现）。 */
    fun refresh() {
        // 内存态即权威，无持久化可 load（契约 §2.5）
    }

    // ===== 读（UI 单态联动：每次变化后调 resultFen() 立即重算，无残留旧值）=====
    fun amountFen(): Long = amountFen
    fun src(): String = src
    fun dst(): String = dst

    /** 当前换算结果（分）：走同一 ConvertCore.convert 纯函数（契约 §2.2）。 */
    fun resultFen(): Long = ConvertCore.convert(amountFen, src, dst)

    // ===== 写（立即重算 = 读侧 resultFen() 纯函数派生，状态机单态联动 C11）=====
    fun setAmountFen(fen: Long) {
        amountFen = if (fen < 0 || fen > ConvertCore.MAX_AMOUNT_FEN) ConvertCore.DEFAULT_AMOUNT_FEN else fen
    }

    fun setSrc(code: String) {
        if (Currency.CODES.contains(code)) src = code
    }

    fun setDst(code: String) {
        if (Currency.CODES.contains(code)) dst = code
    }

    /**
     * 快速反转兑换方向（契约 §2.4）：仅交换 src/dst 引用 + 当前 amount 重算；
     * 不承载任何换算逻辑（§7.7 禁第二条换算公式）。
     */
    fun swap() {
        val t = src
        src = dst
        dst = t
    }
}
