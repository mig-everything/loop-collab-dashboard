package io.eazo.d2ba9433.model

/**
 * 币种与固定汇率表常量数据面（契约 §1.1 ★ 冻结——唯一权威出处，禁手抄派生值）。
 *
 * - rate 语义：1 单位外币 = RATE[code] / 10^6 CNY（整数 rate×10^6，锚定 CNY 直接标价，零浮点）。
 * - 固定顺序 USD/EUR/JPY/CNY/GBP/HKD（需求一句话所列顺序，序列化与 UI 列表均用此序）。
 * - 全 6 个 rate 均为偶数（roundHalfUp 分母 b//2 精确前提，契约 §1.1）。
 * - 常量数据面锁定：无联网/实时汇率（C09）；单测以 §4 哈希断言兜底（错 1 币种/漏 1 行/乱 1 序必 FAIL）。
 */
object Currency {

    /** 汇率表（LinkedHashMap 保序，契约 §8 Kotlin 写法）。 */
    val RATE: Map<String, Long> = linkedMapOf(
        "USD" to 7_200_000L,   // 1 USD = 7.200000 CNY
        "EUR" to 7_800_000L,   // 1 EUR = 7.800000 CNY
        "JPY" to 48_000L,      // 1 JPY = 0.048000 CNY
        "CNY" to 1_000_000L,   // 1 CNY = 1.000000 CNY（基座）
        "GBP" to 9_100_000L,   // 1 GBP = 9.100000 CNY
        "HKD" to 920_000L,     // 1 HKD = 0.920000 CNY
    )

    /** 6 币种固定顺序（C02：币种选择器列表顺序）。 */
    val CODES: List<String> = RATE.keys.toList()

    /**
     * 规范序列化（契约 §4）：每行 `code|rate`（| 分隔，整数无千分位），
     * 固定顺序、LF 连接、行尾无换行、UTF-8——
     * "USD|7200000\nEUR|7800000\nJPY|48000\nCNY|1000000\nGBP|9100000\nHKD|920000"（68 字节）。
     */
    fun serializeRate(): String =
        RATE.keys.joinToString("\n") { "$it|${RATE[it]}" }
}
