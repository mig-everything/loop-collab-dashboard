package io.eazo.d2ba9433.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.d2ba9433.core.ConvertCore
import io.eazo.d2ba9433.model.Currency
import io.eazo.d2ba9433.platform.AppRepo

/**
 * 主界面：单 Activity + Jetpack Compose（UI 锁死声明式——与鸿蒙 ArkUI 声明式对称，
 * 禁止 XML 布局/drawable 扇出；图标用 material-icons，主题用 Compose MaterialTheme）。
 *
 * 布局 = 币种下拉×2 + 金额输入 + 换算结果卡片 + 方向切换按钮（NL Must 集）；
 * 仓储一律经 AppRepo.getRepo(context)（硬规则 ①）；单态联动：金额/币种/反转任一
 * 变化立即经 ConvertCore.convert 纯函数重算，无残留旧值（契约 §2.5/C11）。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Screen()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(this).refresh()
    }
}

/** 多端自适应断点（契约 §3：600 单位——手机竖屏单列 / 平板横屏双列，C14）。 */
private val ADAPTIVE_BREAKPOINT_DP = 600.dp

/** 结果卡片渐变（蓝→青，视觉装饰，不入对账面）。 */
private val ResultGradient = Brush.linearGradient(listOf(Color(0xFF1565C0), Color(0xFF00897B)))

/** 币种显示名（UI 装饰层；code 与固定顺序以 Currency.RATE 为准）。 */
private val CURRENCY_NAMES = mapOf(
    "USD" to "美元", "EUR" to "欧元", "JPY" to "日元",
    "CNY" to "人民币", "GBP" to "英镑", "HKD" to "港币",
)

/** 主题：蓝青双主色浅色方案（在此改配色，不另建 XML 主题）。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.lightColorScheme(
            primary = Color(0xFF00695C),
            onPrimary = Color(0xFFFFFFFF),
            secondary = Color(0xFF283593),
            tertiary = Color(0xFF00897B),
            background = Color(0xFFF5FAF9),
            surface = Color(0xFFFFFFFF),
        ),
        content = content,
    )
}

/** 货币换算器首屏：单态联动 + 600 断点单/双列自适应。 */
@Composable
private fun Screen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val repo = remember { AppRepo.getRepo(context) }
    var amountText by remember { mutableStateOf(ConvertCore.formatFen(repo.amountFen())) }
    var src by remember { mutableStateOf(repo.src()) }
    var dst by remember { mutableStateOf(repo.dst()) }

    fun syncFromRepo() {
        src = repo.src()
        dst = repo.dst()
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFFEAF4F3), MaterialTheme.colorScheme.background))
            )
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        val wide = maxWidth >= ADAPTIVE_BREAKPOINT_DP
        if (wide) {
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    ConverterHeader()
                    SourceCard(amountText, src, onAmount = { amountText = it; repo.setAmountFen(ConvertCore.parseToFen(it)) }, onSrc = { repo.setSrc(it); syncFromRepo() })
                    SwapButton { repo.swap(); syncFromRepo() }
                    DestinationCard(dst, onDst = { repo.setDst(it); syncFromRepo() })
                }
                ResultCard(modifier = Modifier.weight(1f), repo = repo, src = src, dst = dst)
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                ConverterHeader()
                SourceCard(amountText, src, onAmount = { amountText = it; repo.setAmountFen(ConvertCore.parseToFen(it)) }, onSrc = { repo.setSrc(it); syncFromRepo() })
                SwapButton { repo.swap(); syncFromRepo() }
                DestinationCard(dst, onDst = { repo.setDst(it); syncFromRepo() })
                ResultCard(modifier = Modifier.fillMaxWidth(), repo = repo, src = src, dst = dst)
            }
        }
    }
}

@Composable
private fun ConverterHeader() {
    Column {
        Text("货币换算器", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(2.dp))
        Text("内置固定汇率 · 离线换算 · 六币种 USD/EUR/JPY/CNY/GBP/HKD", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
    }
}

/** 源币种下拉 + 金额输入（解析容错回退 100 分，契约 §2.5）。 */
@Composable
private fun SourceCard(
    amountText: String,
    src: String,
    onAmount: (String) -> Unit,
    onSrc: (String) -> Unit,
) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            CurrencyDropdown(label = "源币种", selected = src, onSelect = onSrc)
            OutlinedTextField(
                value = amountText,
                onValueChange = onAmount,
                label = { Text("金额（元，两位小数）") },
                placeholder = { Text("0.00") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

/** 目标币种下拉。 */
@Composable
private fun DestinationCard(dst: String, onDst: (String) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp)) {
            CurrencyDropdown(label = "目标币种", selected = dst, onSelect = onDst)
        }
    }
}

/** 方向切换按钮（契约 §2.4：仅触发 repo.swap() 交换引用 + 重算）。 */
@Composable
private fun SwapButton(onSwap: () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        FilledTonalIconButton(onClick = onSwap, modifier = Modifier.size(56.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "反转兑换方向", modifier = Modifier.size(20.dp))
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null, modifier = Modifier.size(20.dp))
            }
        }
    }
}

/** 换算结果卡片：目标金额（分→格式化）+ 输入回显 + 参考汇率行（C12）。 */
@Composable
private fun ResultCard(modifier: Modifier, repo: AppRepo, src: String, dst: String) {
    val resultFen = repo.resultFen()   // 单态联动：任一变化重算（同一 convert 纯函数）
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
    ) {
        Box(modifier = Modifier.background(ResultGradient).padding(22.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("换算结果", style = MaterialTheme.typography.labelLarge, color = Color(0xCCFFFFFF))
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(ConvertCore.formatFen(resultFen), fontSize = 44.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(dst, style = MaterialTheme.typography.titleLarge, color = Color(0xCCFFFFFF), modifier = Modifier.padding(bottom = 6.dp))
                }
                HorizontalDivider(color = Color(0x33FFFFFF))
                Text("${ConvertCore.formatFen(repo.amountFen())} $src → ${ConvertCore.formatFen(resultFen)} $dst", style = MaterialTheme.typography.bodyMedium, color = Color(0xE6FFFFFF))
                Text("1 $src ≈ ${ConvertCore.formatFen(ConvertCore.convert(100, src, dst))} $dst（固定汇率）", style = MaterialTheme.typography.bodySmall, color = Color(0xB3FFFFFF))
            }
        }
    }
}

/** 币种下拉选择器（6 币种固定顺序，C02）。 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CurrencyDropdown(label: String, selected: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.fillMaxWidth().menuAnchor(),
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            Currency.CODES.forEach { code ->
                DropdownMenuItem(
                    text = { Text("$code · ${CURRENCY_NAMES[code] ?: code}") },
                    onClick = { onSelect(code); expanded = false },
                )
            }
        }
    }
}
