package io.eazo.d2ba9433.core

import io.eazo.d2ba9433.model.Currency

/**
 * 换算核心纯函数（契约 §2 双端等价伪代码逐行对照，全整数零浮点）。
 *
 * - 禁用清单（§7）：浮点舍入路径与 half-even 一律禁用；禁 Int 承载中间积
 *   （≤7.8×10^14 超 int32）——中间量一律 Long（上界 10^8×7.8e6 = 7.8×10^14 < Long.MAX）。
 * - core/data 层零随机零时钟零网络（§3/§7.5）。
 */
object ConvertCore {

    /** 默认金额 100 分（= 1 USD，非法输入回退值，契约 §1.2/§2.5）。 */
    const val DEFAULT_AMOUNT_FEN: Long = 100L

    /** 金额域上界 100_000_000 分（= 100 万元，契约 §1.2）。 */
    const val MAX_AMOUNT_FEN: Long = 100_000_000L

    /** CNY 基座标度（rate×10^6 的 10^6，整数运算分母）。 */
    private const val SCALE: Long = 1_000_000L

    /**
     * 四舍五入 half-up（契约 §2.1 ★ 锁死：仅正数域 a≥0、b 偶数，全整数零浮点）。
     * Kotlin 写法（§8）：`(a + b / 2L) / b` Long 整除 = 正值域 floor。
     */
    fun roundHalfUp(a: Long, b: Long): Long = (a + b / 2L) / b

    /**
     * 换算（契约 §2.2：两步经 CNY 基座，src==dst 早退恒等，双向走同一纯函数）。
     * step1: roundHalfUp(amount_cents × RATE[src], 10^6)——src → CNY（分）
     * step2: roundHalfUp(cny_cents × 10^6, RATE[dst])——CNY → dst（分）
     */
    fun convert(amountCents: Long, src: String, dst: String): Long {
        if (src == dst) return amountCents   // 同币种恒等（A13，早退不做无谓舍入）
        val cnyCents = roundHalfUp(amountCents * Currency.RATE.getValue(src), SCALE)
        return roundHalfUp(cnyCents * SCALE, Currency.RATE.getValue(dst))
    }

    /**
     * 分 → "元.分" 字符串（契约 §2.3 展示层，不入对账断言；
     * 展示层唯一除法点，core 换算链路禁调用）。JPY 亦 2 位小数口径（§1.2）。
     * 如 720 → "7.20"、15000 → "150.00"。
     */
    fun formatFen(fen: Long): String = "%d.%02d".format(fen / 100, fen % 100)

    /**
     * 展示层金额解析：UI 输入字符串（元，≤2 位小数）→ 整数分（契约 §2.3/§8）。
     * 全整数解析零浮点；非法（负数/非数字/超 2 位小数/超 10^8）回退默认 100 分（C01）。
     */
    fun parseToFen(text: String): Long {
        val s = text.trim()
        if (s.isEmpty()) return DEFAULT_AMOUNT_FEN
        val parts = s.split(".")
        if (parts.size > 2) return DEFAULT_AMOUNT_FEN
        val yuan = parts[0].toLongOrNull() ?: return DEFAULT_AMOUNT_FEN
        val decimals = if (parts.size == 2) parts[1] else ""
        if (decimals.length > 2) return DEFAULT_AMOUNT_FEN
        if (decimals.isNotEmpty() && decimals.toLongOrNull() == null) return DEFAULT_AMOUNT_FEN
        val fen = if (decimals.isEmpty()) {
            yuan * 100L
        } else if (decimals.length == 1) {
            yuan * 100L + decimals.toLong() * 10L
        } else {
            yuan * 100L + decimals.toLong()
        }
        return if (fen < 0 || fen > MAX_AMOUNT_FEN) DEFAULT_AMOUNT_FEN else fen
    }
}
