package io.eazo.d2ba9433.contract

import io.eazo.d2ba9433.core.ConvertCore
import io.eazo.d2ba9433.core.ConvertCore.convert
import io.eazo.d2ba9433.core.ConvertCore.parseToFen
import io.eazo.d2ba9433.core.ConvertCore.roundHalfUp
import io.eazo.d2ba9433.model.Currency
import io.eazo.d2ba9433.platform.AppRepo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import kotlin.math.abs

/**
 * REQ-024 货币换算器契约用例（JUnit4，JVM 纯逻辑）：
 * 14 条 slug 与 cases-frozen.json（eazo-cases-1.0.0）逐字一致，不得增删改名；
 * 锚点全集按冻结契约 docs/arch/req024/02-interface-contract.md @13ef840
 * §5（A1~A18/B1/B2/E1~E3/F4a/F4b + round-trip 分源界）+ §4 哈希锁逐条断言。
 */
class Req024ContractTest {

    // ---------- C01 amount_input_range ----------
    @Test
    fun `amount_input_range`() {
        // 合法：非负整数分（元字符串 ≤2 位小数 → 分）
        assertEquals(0L, parseToFen("0"))
        assertEquals(100L, parseToFen("1"))
        assertEquals(123L, parseToFen("1.23"))
        assertEquals(150L, parseToFen("1.5"))
        assertEquals(720L, parseToFen("7.20"))
        assertEquals(505L, parseToFen(" 5.05 "))
        assertEquals(100_000_000L, parseToFen("1000000.00"))   // 域上界（=100 万元）
        // 非法回退默认 100：负数 / 非数字 / 空 / 超 2 位小数 / 超界
        assertEquals(100L, parseToFen("-5"))
        assertEquals(100L, parseToFen("abc"))
        assertEquals(100L, parseToFen(""))
        assertEquals(100L, parseToFen("1.234"))
        assertEquals(100L, parseToFen("1.2.3"))
        assertEquals(100L, parseToFen("1000000.01"))           // 100_000_001 分超界
    }

    // ---------- C02 currency_selector_six ----------
    @Test
    fun `currency_selector_six`() {
        assertEquals(listOf("USD", "EUR", "JPY", "CNY", "GBP", "HKD"), Currency.CODES)
        assertEquals(6, Currency.RATE.size)
    }

    // ---------- C03 rate_table_constant ----------
    @Test
    fun `rate_table_constant`() {
        assertEquals(7_200_000L, Currency.RATE["USD"])
        assertEquals(7_800_000L, Currency.RATE["EUR"])
        assertEquals(48_000L, Currency.RATE["JPY"])
        assertEquals(1_000_000L, Currency.RATE["CNY"])
        assertEquals(9_100_000L, Currency.RATE["GBP"])
        assertEquals(920_000L, Currency.RATE["HKD"])
        // §5.4 结构锚点：全偶数 + CNY 基座 = 10^6
        Currency.RATE.values.forEach { assertTrue("rate 偶数: $it", it % 2L == 0L) }
        assertEquals(1_000_000L, Currency.RATE["CNY"])
    }

    // ---------- C04 convert_deterministic ----------
    @Test
    fun `convert_deterministic`() {
        // §5.1 换算锚点 A1~A14（金额单位：分）
        assertEquals(720L, convert(100, "USD", "CNY"))        // A1
        assertEquals(92L, convert(100, "USD", "EUR"))         // A2
        assertEquals(15000L, convert(100, "USD", "JPY"))      // A3
        assertEquals(79L, convert(100, "USD", "GBP"))         // A4
        assertEquals(783L, convert(100, "USD", "HKD"))        // A5
        assertEquals(108L, convert(100, "EUR", "USD"))        // A6
        assertEquals(5L, convert(100, "JPY", "CNY"))          // A7
        assertEquals(100L, convert(720, "CNY", "USD"))        // A8
        assertEquals(104L, convert(5, "CNY", "JPY"))          // A9
        assertEquals(989L, convert(100, "GBP", "HKD"))        // A10
        assertEquals(72000L, convert(10000, "USD", "CNY"))    // A11
        assertEquals(92L, convert(100, "HKD", "CNY"))         // A12
        assertEquals(12345L, convert(12345, "CNY", "CNY"))    // A13
        assertEquals(720_000_000L, convert(100_000_000, "USD", "CNY"))  // A14
        // §5.3 round-trip 分源界（按原始币种 c1 断言：USD/EUR/GBP≤1，CNY/HKD≤6，JPY≤127）
        val bound = mapOf("USD" to 1L, "EUR" to 1L, "GBP" to 1L, "CNY" to 6L, "HKD" to 6L, "JPY" to 127L)
        val amounts = longArrayOf(1, 7, 42, 100, 999, 844, 12345, 100000)
        for (c1 in Currency.CODES) for (c2 in Currency.CODES) if (c1 != c2) for (a in amounts) {
            val back = convert(convert(a, c1, c2), c2, c1)
            assertTrue("round-trip $c1→$c2→$c1 a=$a back=$back", abs(back - a) <= bound.getValue(c1))
        }
    }

    // ---------- C05 round_half_up_boundary ----------
    @Test
    fun `round_half_up_boundary`() {
        assertEquals(46L, convert(5, "GBP", "CNY"))    // B1：half-up vs floor（floor=45）
        assertEquals(137L, convert(15, "GBP", "CNY"))  // E1：half-even=136
        assertEquals(3L, convert(2, "GBP", "USD"))     // E2：half-even=2
        assertEquals(63L, convert(3, "HKD", "JPY"))    // E3：half-even=62
        // 直测舍入原语：半值进位、不足半舍去
        assertEquals(1L, roundHalfUp(5, 10))
        assertEquals(0L, roundHalfUp(4, 10))
        assertEquals(2L, roundHalfUp(15, 10))
    }

    // ---------- C06 same_currency_identity ----------
    @Test
    fun `same_currency_identity`() {
        assertEquals(12345L, convert(12345, "CNY", "CNY"))  // A13
        for (c in Currency.CODES) for (a in longArrayOf(0, 100, 12345)) {
            assertEquals("src==dst 早退恒等 $c", a, convert(a, c, c))
        }
    }

    // ---------- C07 bidirectional_convert ----------
    @Test
    fun `bidirectional_convert`() {
        assertEquals(720L, convert(100, "USD", "CNY"))   // A1：1 USD → 7.20 CNY
        assertEquals(100L, convert(720, "CNY", "USD"))   // A8：对偶反向
        assertEquals(989L, convert(100, "GBP", "HKD"))   // A10
        assertEquals(100L, convert(989, "HKD", "GBP"))   // A10 反向（round-trip 界内回 100）
    }

    // ---------- C08 rate_serialization_hash ----------
    @Test
    fun `rate_serialization_hash`() {
        val expected = "USD|7200000\nEUR|7800000\nJPY|48000\nCNY|1000000\nGBP|9100000\nHKD|920000"
        assertEquals(expected, Currency.serializeRate())   // 规范序列化（行尾无换行）
        val bytes = Currency.serializeRate().toByteArray(Charsets.UTF_8)
        assertEquals(68L, bytes.size.toLong())             // 68 字节（6 行 63B + 5 LF）
        val sha = java.security.MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }
        assertEquals("9d7ba769f11778c65193bba36603ab95eb7a85fee29e4eefa5ef20840c86f29b", sha)
    }

    // ---------- C09 no_network_rate ----------
    @Test
    fun `no_network_rate`() {
        val srcMain = sequenceOf(File("src/main"), File("app/src/main")).first { it.isDirectory }
        // 源码零网络痕迹：固定常量数据面（§3），任何 http/socket/okhttp 取数路径即 FAIL
        srcMain.walkTopDown().filter { it.extension == "kt" }.forEach { f ->
            val lower = f.readText().lowercase()
            listOf("http://", "https://", "socket", "okhttp", "urlconnection").forEach { tok ->
                assertTrue("${f.name} 含网络痕迹 $tok", !lower.contains(tok))
            }
        }
        // Manifest 无网络权限（xmlns 命名空间 URI 不计）
        val manifest = File(srcMain, "AndroidManifest.xml").readText()
        assertTrue("Manifest 禁 uses-permission", !manifest.contains("uses-permission"))
        assertTrue("Manifest 禁 INTERNET 权限", !manifest.uppercase().contains("INTERNET"))
    }

    // ---------- C10 swap_direction ----------
    @Test
    fun `swap_direction`() {
        val repo = AppRepo   // 进程内单例（getRepo(context) 的 UI 通道同指此对象，硬规则 ①）
        repo.setAmountFen(100); repo.setSrc("USD"); repo.setDst("CNY")
        assertEquals(720L, repo.resultFen())               // A1：100 分 USD→CNY
        repo.swap()                                        // 仅交换 src/dst 引用（§2.4）
        assertEquals("CNY", repo.src())
        assertEquals("USD", repo.dst())
        assertEquals(convert(100, "CNY", "USD"), repo.resultFen())  // 结果重算（同一纯函数）
        assertEquals(14L, repo.resultFen())
        // A8 口径：720 分 CNY→USD = 100（换向后方向的可逆对）
        repo.setAmountFen(720); repo.setSrc("CNY"); repo.setDst("USD")
        assertEquals(100L, repo.resultFen())
        repo.swap(); repo.swap()                           // 双反还原
        assertEquals("CNY", repo.src()); assertEquals("USD", repo.dst())
    }

    // ---------- C11 realtime_update ----------
    @Test
    fun `realtime_update`() {
        val repo = AppRepo
        repo.setAmountFen(100); repo.setSrc("USD"); repo.setDst("CNY")
        assertEquals(720L, repo.resultFen())               // 基态
        repo.setAmountFen(200)                             // 金额变化 → 立即重算
        assertEquals(1440L, repo.resultFen())
        repo.setSrc("EUR")                                 // 源币种变化 → 立即重算
        assertEquals(1560L, repo.resultFen())
        repo.setDst("USD")                                 // 目标币种变化 → 立即重算
        assertEquals(217L, repo.resultFen())
        repo.setAmountFen(-5)                              // 非法金额 → 回退 100，无残留旧值
        assertEquals(100L, repo.amountFen())
        assertEquals(108L, repo.resultFen())
    }

    // ---------- C12 result_card_display ----------
    @Test
    fun `result_card_display`() {
        assertEquals("7.20", ConvertCore.formatFen(720))
        assertEquals("150.00", ConvertCore.formatFen(15000))
        assertEquals("0.00", ConvertCore.formatFen(0))
        assertEquals("0.05", ConvertCore.formatFen(5))
        assertEquals("123.45", ConvertCore.formatFen(12345))
        // 端到端：convert(100,USD,CNY)=720 → 展示 "7.20"
        assertEquals("7.20", ConvertCore.formatFen(convert(100, "USD", "CNY")))
    }

    // ---------- C13 convert_no_float ----------
    @Test
    fun `convert_no_float`() {
        assertEquals(319L, convert(35, "GBP", "CNY"))    // F4a：浮点元链路=318
        assertEquals(2048L, convert(225, "GBP", "CNY"))  // F4b：浮点元链路=2047
        // 静态走查：core/model 源码禁浮点舍入/浮点转型痕迹（§7）
        val srcMain = sequenceOf(File("src/main"), File("app/src/main")).first { it.isDirectory }
        listOf("ConvertCore.kt", "Currency.kt").forEach { name ->
            val text = srcMain.walkTopDown().filter { it.name == name }.first().readText()
            listOf("Math.round", "toDouble", "toFloat", " as Double", " as Float", "Math.random", "Date(").forEach { tok ->
                assertTrue("$name 禁浮点痕迹 $tok", !text.contains(tok))
            }
        }
    }

    // ---------- C14 multiscreen_adaptive ----------
    @Test
    fun `multiscreen_adaptive`() {
        // 可降级（Should）：静态证据——600 断点 + BoxWithConstraints 单/双列分支
        val main = File("src/main").takeIf { it.isDirectory } ?: File("app/src/main")
        val text = main.walkTopDown().filter { it.name == "MainActivity.kt" }.first().readText()
        assertTrue("600 断点常量", text.contains("ADAPTIVE_BREAKPOINT_DP") && text.contains("600.dp"))
        assertTrue("BoxWithConstraints 自适应容器", text.contains("BoxWithConstraints"))
        assertTrue("宽屏双列 Row / 窄屏单列 Column 分支", text.contains("maxWidth >= ADAPTIVE_BREAKPOINT_DP"))
    }
}
