// ===== REQ-015 锚点常量表(脚本生成,禁手打)=====
// 生成:docs/arch/req015/scripts/gen_mortgage_tables.py --lang kt(IPD-357)
// 权威输入:PRD §5 案例 A(100万/4.9%/30年)+ 案例 B(10万/4.9%/1年)
object Req015Anchors {
    // ---- 计划表 SHA-256(D1~D4)----
    const val TABLE_A_ET_SHA256: String = "24a599d6e677b3640572c56fd47a6d0873315691c9b885e6e12197e2df229cb3"
    const val TABLE_A_ET_BYTES: Int = 12049
    const val TABLE_A_EP_SHA256: String = "9a2435d72dbc3913e5d7b0910315d629ec3fc53621e2fd665240f996fb4b506c"
    const val TABLE_A_EP_BYTES: Int = 11989
    const val TABLE_B_ET_SHA256: String = "e21a83c02f6b0bde1f092d1e2929d431906fe4db9101dfa7296705737c2bc34f"
    const val TABLE_B_ET_BYTES: Int = 353
    const val TABLE_B_EP_SHA256: String = "fea3c55c4c8fccacfd2a59695c4c21fac7edeecef2e3853f5f9352a6be64725c"
    const val TABLE_B_EP_BYTES: Int = 353

    // ---- 案例A 等额本息 ----
    const val CA_ET_M: Long = 530727L
    const val CA_ET_TOTAL_PAY: Long = 191061512L
    const val CA_ET_TOTAL_INT: Long = 91061512L
    // 期1: 月供530727 本金122394 利息408333 剩余99877606
    val CA_ET_M1: LongArray = longArrayOf(530727L, 122394L, 408333L, 99877606L)
    // 期2: 月供530727 本金122893 利息407834 剩余99754713
    val CA_ET_M2: LongArray = longArrayOf(530727L, 122893L, 407834L, 99754713L)
    // 期6: 月供530727 本金124913 利息405814 剩余99258101
    val CA_ET_M6: LongArray = longArrayOf(530727L, 124913L, 405814L, 99258101L)
    // 期12: 月供530727 本金128005 利息402722 剩余98497839
    val CA_ET_M12: LongArray = longArrayOf(530727L, 128005L, 402722L, 98497839L)
    // 期359: 月供530727 本金526420 利息4307 剩余528362
    val CA_ET_M359: LongArray = longArrayOf(530727L, 526420L, 4307L, 528362L)
    // 期360: 月供530519 本金528362 利息2157 剩余0
    val CA_ET_M360: LongArray = longArrayOf(530519L, 528362L, 2157L, 0L)

    // ---- 案例A 等额本金 ----
    const val CA_EP_BASE: Long = 277778L
    const val CA_EP_TOTAL_PAY: Long = 173704108L
    const val CA_EP_TOTAL_INT: Long = 73704108L
    // 期1: 月供686111 本金277778 利息408333 剩余99722222
    val CA_EP_M1: LongArray = longArrayOf(686111L, 277778L, 408333L, 99722222L)
    // 期2: 月供684977 本金277778 利息407199 剩余99444444
    val CA_EP_M2: LongArray = longArrayOf(684977L, 277778L, 407199L, 99444444L)
    // 期6: 月供680440 本金277778 利息402662 剩余98333332
    val CA_EP_M6: LongArray = longArrayOf(680440L, 277778L, 402662L, 98333332L)
    // 期12: 月供673634 本金277778 利息395856 剩余96666664
    val CA_EP_M12: LongArray = longArrayOf(673634L, 277778L, 395856L, 96666664L)
    // 期359: 月供280046 本金277778 利息2268 剩余277698
    val CA_EP_M359: LongArray = longArrayOf(280046L, 277778L, 2268L, 277698L)
    // 期360: 月供278832 本金277698 利息1134 剩余0
    val CA_EP_M360: LongArray = longArrayOf(278832L, 277698L, 1134L, 0L)

    // ---- 案例B 等额本息 ----
    const val CB_ET_M: Long = 855617L
    const val CB_ET_TOTAL_PAY: Long = 10267399L
    const val CB_ET_TOTAL_INT: Long = 267399L
    // 期1: 月供855617 本金814784 利息40833 剩余9185216
    val CB_ET_M1: LongArray = longArrayOf(855617L, 814784L, 40833L, 9185216L)
    // 期2: 月供855617 本金818111 利息37506 剩余8367105
    val CB_ET_M2: LongArray = longArrayOf(855617L, 818111L, 37506L, 8367105L)
    // 期3: 月供855617 本金821451 利息34166 剩余7545654
    val CB_ET_M3: LongArray = longArrayOf(855617L, 821451L, 34166L, 7545654L)
    // 期4: 月供855617 本金824806 利息30811 剩余6720848
    val CB_ET_M4: LongArray = longArrayOf(855617L, 824806L, 30811L, 6720848L)
    // 期5: 月供855617 本金828174 利息27443 剩余5892674
    val CB_ET_M5: LongArray = longArrayOf(855617L, 828174L, 27443L, 5892674L)
    // 期6: 月供855617 本金831555 利息24062 剩余5061119
    val CB_ET_M6: LongArray = longArrayOf(855617L, 831555L, 24062L, 5061119L)
    // 期7: 月供855617 本金834951 利息20666 剩余4226168
    val CB_ET_M7: LongArray = longArrayOf(855617L, 834951L, 20666L, 4226168L)
    // 期8: 月供855617 本金838360 利息17257 剩余3387808
    val CB_ET_M8: LongArray = longArrayOf(855617L, 838360L, 17257L, 3387808L)
    // 期9: 月供855617 本金841783 利息13834 剩余2546025
    val CB_ET_M9: LongArray = longArrayOf(855617L, 841783L, 13834L, 2546025L)
    // 期10: 月供855617 本金845221 利息10396 剩余1700804
    val CB_ET_M10: LongArray = longArrayOf(855617L, 845221L, 10396L, 1700804L)
    // 期11: 月供855617 本金848672 利息6945 剩余852132
    val CB_ET_M11: LongArray = longArrayOf(855617L, 848672L, 6945L, 852132L)
    // 期12: 月供855612 本金852132 利息3480 剩余0
    val CB_ET_M12: LongArray = longArrayOf(855612L, 852132L, 3480L, 0L)

    // ---- 案例B 等额本金 ----
    const val CB_EP_BASE: Long = 833333L
    const val CB_EP_TOTAL_PAY: Long = 10265417L
    const val CB_EP_TOTAL_INT: Long = 265417L
    // 期1: 月供874166 本金833333 利息40833 剩余9166667
    val CB_EP_M1: LongArray = longArrayOf(874166L, 833333L, 40833L, 9166667L)
    // 期2: 月供870764 本金833333 利息37431 剩余8333334
    val CB_EP_M2: LongArray = longArrayOf(870764L, 833333L, 37431L, 8333334L)
    // 期3: 月供867361 本金833333 利息34028 剩余7500001
    val CB_EP_M3: LongArray = longArrayOf(867361L, 833333L, 34028L, 7500001L)
    // 期4: 月供863958 本金833333 利息30625 剩余6666668
    val CB_EP_M4: LongArray = longArrayOf(863958L, 833333L, 30625L, 6666668L)
    // 期5: 月供860555 本金833333 利息27222 剩余5833335
    val CB_EP_M5: LongArray = longArrayOf(860555L, 833333L, 27222L, 5833335L)
    // 期6: 月供857152 本金833333 利息23819 剩余5000002
    val CB_EP_M6: LongArray = longArrayOf(857152L, 833333L, 23819L, 5000002L)
    // 期7: 月供853750 本金833333 利息20417 剩余4166669
    val CB_EP_M7: LongArray = longArrayOf(853750L, 833333L, 20417L, 4166669L)
    // 期8: 月供850347 本金833333 利息17014 剩余3333336
    val CB_EP_M8: LongArray = longArrayOf(850347L, 833333L, 17014L, 3333336L)
    // 期9: 月供846944 本金833333 利息13611 剩余2500003
    val CB_EP_M9: LongArray = longArrayOf(846944L, 833333L, 13611L, 2500003L)
    // 期10: 月供843541 本金833333 利息10208 剩余1666670
    val CB_EP_M10: LongArray = longArrayOf(843541L, 833333L, 10208L, 1666670L)
    // 期11: 月供840139 本金833333 利息6806 剩余833337
    val CB_EP_M11: LongArray = longArrayOf(840139L, 833333L, 6806L, 833337L)
    // 期12: 月供836740 本金833337 利息3403 剩余0
    val CB_EP_M12: LongArray = longArrayOf(836740L, 833337L, 3403L, 0L)
}
