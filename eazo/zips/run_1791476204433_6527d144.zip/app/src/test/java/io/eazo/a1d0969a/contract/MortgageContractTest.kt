package io.eazo.a1d0969a.contract

import io.eazo.a1d0969a.core.MortgageCore
import io.eazo.a1d0969a.core.MortgageMath
import io.eazo.a1d0969a.model.Mode
import io.eazo.a1d0969a.model.MortgageInput
import io.eazo.a1d0969a.model.PlanRow
import io.eazo.a1d0969a.platform.CardDataBuilder
import io.eazo.a1d0969a.platform.OpenInput
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * REQ-015 契约回归（§6.7 双端同集同断言，锚点常量全部 import 生成物
 * Req015Anchors——禁手抄；期望语义 = 02-interface-contract.md v1.0 @33c1d8c）。
 *
 * 覆盖：标量锚点 / 计划表哈希 D1~D4 / 参数直断言 §8 / 结构断言 §6.5 /
 * 输入校验回退 §6.6 / 对比差值 / 卡片推导 / 启动参数严格解析。
 */
class MortgageContractTest {

    // ---- 固定案例 ----
    private val caseA = MortgageInput(1000000.0, 4.9, 30, Mode.ET)
    private val caseB = MortgageInput(100000.0, 4.9, 1, Mode.ET)

    private fun sha256(text: String): String =
        java.security.MessageDigest.getInstance("SHA-256")
            .digest(text.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private fun assertRow(anchor: LongArray, row: PlanRow) {
        assertEquals(anchor[0], row.payment)
        assertEquals(anchor[1], row.principal)
        assertEquals(anchor[2], row.interest)
        assertEquals(anchor[3], row.remaining)
    }

    // ===== §6.7-1 输入派生（案例 A/B：P_分 / R4 / n）=====

    @Test
    fun `输入派生_定点转换`() {
        assertEquals(100000000L, MortgageMath.toPFen(caseA.principalYuan))
        assertEquals(49000L, MortgageMath.toR4(caseA.ratePercent))
        assertEquals(360, MortgageMath.toMonths(caseA.years))
        assertEquals(10000000L, MortgageMath.toPFen(caseB.principalYuan))
        assertEquals(49000L, MortgageMath.toR4(caseB.ratePercent))
        assertEquals(12, MortgageMath.toMonths(caseB.years))
    }

    // ===== §6.7-1 标量锚点 · 案例 A =====

    @Test
    fun `案例A_ET_标量锚点`() {
        val r = MortgageCore.calc(caseA)
        assertEquals(Req015Anchors.CA_ET_M, r.mFen)
        assertEquals(Req015Anchors.CA_ET_TOTAL_PAY, r.summary.totalPayment)
        assertEquals(Req015Anchors.CA_ET_TOTAL_INT, r.summary.totalInterest)
        assertEquals(Req015Anchors.CA_ET_M, r.summary.monthly)
        assertRow(Req015Anchors.CA_ET_M1, r.rows[0])
        assertRow(Req015Anchors.CA_ET_M2, r.rows[1])
        assertRow(Req015Anchors.CA_ET_M6, r.rows[5])
        assertRow(Req015Anchors.CA_ET_M12, r.rows[11])
        assertRow(Req015Anchors.CA_ET_M359, r.rows[358])
        assertRow(Req015Anchors.CA_ET_M360, r.rows[359])
    }

    @Test
    fun `案例A_EP_标量锚点`() {
        val r = MortgageCore.calc(caseA.copy(mode = Mode.EP))
        assertEquals(Req015Anchors.CA_EP_BASE, r.baseFen)
        assertEquals(Req015Anchors.CA_EP_TOTAL_PAY, r.summary.totalPayment)
        assertEquals(Req015Anchors.CA_EP_TOTAL_INT, r.summary.totalInterest)
        assertEquals(Req015Anchors.CA_EP_M1[0], r.summary.monthly) // EP monthly = 首月月供（§3.5）
        assertRow(Req015Anchors.CA_EP_M1, r.rows[0])
        assertRow(Req015Anchors.CA_EP_M2, r.rows[1])
        assertRow(Req015Anchors.CA_EP_M6, r.rows[5])
        assertRow(Req015Anchors.CA_EP_M12, r.rows[11])
        assertRow(Req015Anchors.CA_EP_M359, r.rows[358])
        assertRow(Req015Anchors.CA_EP_M360, r.rows[359])
    }

    // ===== §6.7-1 标量锚点 · 案例 B（全 12 行）=====

    @Test
    fun `案例B_ET_全12行`() {
        val r = MortgageCore.calc(caseB)
        assertEquals(Req015Anchors.CB_ET_M, r.mFen)
        assertEquals(Req015Anchors.CB_ET_TOTAL_PAY, r.summary.totalPayment)
        assertEquals(Req015Anchors.CB_ET_TOTAL_INT, r.summary.totalInterest)
        val anchors = listOf(
            Req015Anchors.CB_ET_M1, Req015Anchors.CB_ET_M2, Req015Anchors.CB_ET_M3,
            Req015Anchors.CB_ET_M4, Req015Anchors.CB_ET_M5, Req015Anchors.CB_ET_M6,
            Req015Anchors.CB_ET_M7, Req015Anchors.CB_ET_M8, Req015Anchors.CB_ET_M9,
            Req015Anchors.CB_ET_M10, Req015Anchors.CB_ET_M11, Req015Anchors.CB_ET_M12,
        )
        anchors.forEachIndexed { i, a -> assertRow(a, r.rows[i]) }
    }

    @Test
    fun `案例B_EP_全12行`() {
        val r = MortgageCore.calc(caseB.copy(mode = Mode.EP))
        assertEquals(Req015Anchors.CB_EP_BASE, r.baseFen)
        assertEquals(Req015Anchors.CB_EP_TOTAL_PAY, r.summary.totalPayment)
        assertEquals(Req015Anchors.CB_EP_TOTAL_INT, r.summary.totalInterest)
        val anchors = listOf(
            Req015Anchors.CB_EP_M1, Req015Anchors.CB_EP_M2, Req015Anchors.CB_EP_M3,
            Req015Anchors.CB_EP_M4, Req015Anchors.CB_EP_M5, Req015Anchors.CB_EP_M6,
            Req015Anchors.CB_EP_M7, Req015Anchors.CB_EP_M8, Req015Anchors.CB_EP_M9,
            Req015Anchors.CB_EP_M10, Req015Anchors.CB_EP_M11, Req015Anchors.CB_EP_M12,
        )
        anchors.forEachIndexed { i, a -> assertRow(a, r.rows[i]) }
    }

    // ===== §3.5 compare 差值锚点（AC-S6.1）=====

    @Test
    fun `对比_总利息差_案例A`() {
        val cmp = MortgageCore.compare(caseA)
        assertEquals(Req015Anchors.CA_ET_TOTAL_INT, cmp.et.totalInterest)
        assertEquals(Req015Anchors.CA_EP_TOTAL_INT, cmp.ep.totalInterest)
        assertEquals(17357404L, cmp.totalInterestDiff)
    }

    // ===== §6.7-2 计划表哈希 D1~D4（SHA-256 + 字节数）=====

    @Test
    fun `计划表哈希_D1~D4`() {
        val d1 = MortgageMath.serializeRows(MortgageCore.calc(caseA).rows)
        val d2 = MortgageMath.serializeRows(MortgageCore.calc(caseA.copy(mode = Mode.EP)).rows)
        val d3 = MortgageMath.serializeRows(MortgageCore.calc(caseB).rows)
        val d4 = MortgageMath.serializeRows(MortgageCore.calc(caseB.copy(mode = Mode.EP)).rows)

        assertEquals(Req015Anchors.TABLE_A_ET_SHA256, sha256(d1))
        assertEquals(Req015Anchors.TABLE_A_ET_BYTES, d1.toByteArray(Charsets.UTF_8).size)
        assertEquals(Req015Anchors.TABLE_A_EP_SHA256, sha256(d2))
        assertEquals(Req015Anchors.TABLE_A_EP_BYTES, d2.toByteArray(Charsets.UTF_8).size)
        assertEquals(Req015Anchors.TABLE_B_ET_SHA256, sha256(d3))
        assertEquals(Req015Anchors.TABLE_B_ET_BYTES, d3.toByteArray(Charsets.UTF_8).size)
        assertEquals(Req015Anchors.TABLE_B_EP_SHA256, sha256(d4))
        assertEquals(Req015Anchors.TABLE_B_EP_BYTES, d4.toByteArray(Charsets.UTF_8).size)
    }

    // ===== §6.7-3 参数直断言（契约 §8 全部）=====

    @Test
    fun `参数直断言_契约§8`() {
        assertEquals(12000000L, MortgageMath.RATE_DENOM)
        assertEquals(6000000L, MortgageMath.HALF_RATE_DENOM)
        assertEquals(1000000.0, MortgageMath.DEFAULT_P_YUAN, 0.0)
        assertEquals(4.9, MortgageMath.DEFAULT_RATE, 0.0)
        assertEquals(30, MortgageMath.DEFAULT_YEARS)
        assertEquals(1000000000L, MortgageMath.P_MAX_FEN)
        assertEquals(100000L, MortgageMath.R4_MAX)
        assertEquals(360, MortgageMath.N_MAX)
        // 换算自洽
        assertEquals(49000L, MortgageMath.roundHalfUpFloat(4.9 * 10000.0))
        assertEquals(100000000L, MortgageMath.roundHalfUpFloat(1000000 * 100.0))
        assertEquals(277778L, MortgageMath.roundHalfUpFrac(100000000L, 360L))
        // 安全界（中间积 < 2^53 与 < 2^63）
        assertTrue(MortgageMath.P_MAX_FEN * MortgageMath.R4_MAX < 9007199254740992L)
        assertTrue(MortgageMath.P_MAX_FEN * MortgageMath.R4_MAX < Long.MAX_VALUE)
        // .5 边界（§6.4：整数口径为唯一正确值，银行家舍入在此分叉）
        assertEquals(408391L, MortgageMath.interestOf(100014000L, 49000L))
        assertEquals(408391L, MortgageMath.roundHalfUpFrac(100014000L * 49000L, 12000000L))
        assertEquals(51L, MortgageMath.roundHalfUpFrac(101L, 2L))
        // D1~D4 生成常量 == 契约 §1.2 冻结字面量（生成通道自身复核）
        assertEquals("24a599d6e677b3640572c56fd47a6d0873315691c9b885e6e12197e2df229cb3", Req015Anchors.TABLE_A_ET_SHA256)
        assertEquals("9a2435d72dbc3913e5d7b0910315d629ec3fc53621e2fd665240f996fb4b506c", Req015Anchors.TABLE_A_EP_SHA256)
        assertEquals("e21a83c02f6b0bde1f092d1e2929d431906fe4db9101dfa7296705737c2bc34f", Req015Anchors.TABLE_B_ET_SHA256)
        assertEquals("fea3c55c4c8fccacfd2a59695c4c21fac7edeecef2e3853f5f9352a6be64725c", Req015Anchors.TABLE_B_EP_SHA256)
    }

    // ===== §6.7-4 结构断言（§6.5 全表校验 ×4 表）=====

    @Test
    fun `结构断言_全表校验`() {
        val tables = listOf(
            Triple(MortgageCore.calc(caseA), Req015Anchors.CA_ET_M, Req015Anchors.CA_ET_M1),
            Triple(MortgageCore.calc(caseA.copy(mode = Mode.EP)), 0L, Req015Anchors.CA_EP_M1),
            Triple(MortgageCore.calc(caseB), Req015Anchors.CB_ET_M, Req015Anchors.CB_ET_M1),
            Triple(MortgageCore.calc(caseB.copy(mode = Mode.EP)), 0L, Req015Anchors.CB_EP_M1),
        )
        for ((result, mFen, firstRow) in tables) {
            val rows = result.rows
            // 行数
            assertEquals(result.n, rows.size)
            // 每行恒等 + 余额链自洽 + 期数连续
            var prevRemaining = result.pFen
            for ((i, row) in rows.withIndex()) {
                assertEquals(i + 1, row.period)
                assertEquals(row.principal + row.interest, row.payment)
                assertEquals(prevRemaining - row.principal, row.remaining)
                prevRemaining = row.remaining
            }
            // 尾差精确归零
            assertEquals(0L, rows.last().remaining)
            if (result.mode == Mode.ET) {
                // 前 n−1 行月供恒等（末月除外）
                for (i in 0 until rows.size - 1) assertEquals(mFen, rows[i].payment)
            } else {
                // EP：前 n−1 行本金恒等 base；月供非增
                for (i in 0 until rows.size - 1) assertEquals(result.baseFen, rows[i].principal)
                for (i in 1 until rows.size) assertFalse(rows[i].payment > rows[i - 1].payment)
            }
            // 序列化首末行（期望串由锚点常量拼接，禁手抄数值）
            val ser = MortgageMath.serializeRows(rows)
            assertEquals(
                "1|${firstRow[0]}|${firstRow[1]}|${firstRow[2]}|${firstRow[3]}",
                ser.substringBefore('\n'),
            )
            val last = rows.last()
            assertEquals(
                "${last.period}|${last.payment}|${last.principal}|${last.interest}|${last.remaining}",
                ser.substringAfterLast('\n'),
            )
        }
    }

    // ===== §6.7-5 输入校验断言（§6.6 非法回退 + 合法边界）=====

    @Test
    fun `非法输入回退_四例`() {
        // 期望 = 回退默认且 mode 保持被测输入的 mode
        fun expectFallback(raw: MortgageInput) = MortgageInput(1000000.0, 4.9, 30, raw.mode)
        // ① P=0 / 负；② R<0；③ Y≤0；④ 越上界（P>10^7 / R>10 / Y>30）
        listOf(
            MortgageInput(0.0, 4.9, 30, Mode.ET),
            MortgageInput(-100.0, 4.9, 30, Mode.ET),
            MortgageInput(1000000.0, -0.1, 30, Mode.ET),
            MortgageInput(1000000.0, 4.9, 0, Mode.EP),
            MortgageInput(10000001.0, 4.9, 30, Mode.EP),
            MortgageInput(1000000.0, 10.1, 30, Mode.ET),
            MortgageInput(1000000.0, 4.9, 31, Mode.ET),
        ).forEach { raw -> assertEquals(expectFallback(raw), MortgageCore.validate(raw)) }
        // 合法域边界不回退：P=0.01 元 / R=0 / Y=1；上界值本身合法
        assertEquals(MortgageInput(0.01, 0.0, 1, Mode.ET), MortgageCore.validate(MortgageInput(0.01, 0.0, 1, Mode.ET)))
        assertEquals(10000000.0, MortgageCore.validate(MortgageInput(10000000.0, 10.0, 30, Mode.EP)).principalYuan, 0.0)
        assertEquals(10.0, MortgageCore.validate(MortgageInput(1000000.0, 10.0, 30, Mode.EP)).ratePercent, 0.0)
    }

    @Test
    fun `零利率退化_无息分期`() {
        // R=0：利息恒 0，M=P/n（half-up 锁整），两种方式全表一致且归零（§6.6）
        val input = MortgageInput(101.0, 0.0, 1, Mode.ET) // P=10100 分, n=12
        val r = MortgageCore.calc(input)
        assertEquals(0L, r.summary.totalInterest)
        assertEquals(10100L, r.summary.totalPayment)
        for (row in r.rows) assertEquals(0L, row.interest)
        val ep = MortgageCore.calc(input.copy(mode = Mode.EP))
        assertEquals(r.rows, ep.rows) // 零息下两方式整表一致
    }

    // ===== 卡片数据（US-7 Should）：首月月供 + 剩余本金 = 第 1 期行 =====

    @Test
    fun `卡片数据_首月月供与剩余本金`() {
        val et = CardDataBuilder.build(caseA)
        assertEquals(Req015Anchors.CA_ET_M1[0], et.monthlyFen)
        assertEquals(Req015Anchors.CA_ET_M1[3], et.remainingFen)
        assertEquals("ET", et.modeLiteral)
        val ep = CardDataBuilder.build(caseA.copy(mode = Mode.EP))
        assertEquals(Req015Anchors.CA_EP_M1[0], ep.monthlyFen)
        assertEquals(Req015Anchors.CA_EP_M1[3], ep.remainingFen)
        assertEquals("EP", ep.modeLiteral)
    }

    // ===== 硬规则 ④：启动参数严格解析（冷/热启动同入口的纯半部）=====

    @Test
    fun `启动参数_严格类型判定`() {
        // 未携带 → null（保持内存态）
        assertNull(OpenInput.parseOpenInput(emptyMap()))
        // 完整合法携带
        assertEquals(
            MortgageInput(100.0, 4.9, 30, Mode.EP),
            OpenInput.parseOpenInput(mapOf("principal" to 100.0, "rate" to 4.9, "years" to 30, "mode" to "EP")),
        )
        // 部分携带：缺省键回填契约默认
        assertEquals(MortgageInput(1000000.0, 4.9, 20, Mode.ET), OpenInput.parseOpenInput(mapOf("years" to 20)))
        // 严格类型：布尔/字符串/浮点漂移/非法字面量一律整体拒绝（防模板串注入）
        assertNull(OpenInput.parseOpenInput(mapOf("mode" to true)))        // Boolean ≠ String 字面量
        assertNull(OpenInput.parseOpenInput(mapOf("principal" to "100")))  // String ≠ 数值
        assertNull(OpenInput.parseOpenInput(mapOf("years" to 30.0)))       // Double ≠ Int
        assertNull(OpenInput.parseOpenInput(mapOf("mode" to "et")))        // 字面量仅 ET/EP
    }
}
