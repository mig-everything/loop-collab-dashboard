package io.eazo.a1d0969a.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.a1d0969a.model.PlanRow
import io.eazo.a1d0969a.platform.MoneyFormat

/**
 * 还款计划表（展示态）：表头 + 逐月行（期数/月供/本金/利息/剩余本金）。
 * 数字列用等宽字体保证纵向对齐；末行（剩余=0）高亮「结清」。
 */
@Composable
fun PlanTable(rows: List<PlanRow>, modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxWidth()) {
        PlanHeaderRow()
        rows.forEach { row -> PlanDataRow(row, isFinal = row.remaining == 0L) }
    }
}

/** LazyColumn 场景：仅渲染表头 + 单行渲染器由调用方 items() 复用。 */
@Composable
fun PlanHeaderRow(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 10.dp, vertical = 8.dp),
    ) {
        HeaderCell("期数", 0.95f)
        HeaderCell("月供(元)", 1.35f)
        HeaderCell("本金(元)", 1.35f)
        HeaderCell("利息(元)", 1.25f)
        HeaderCell("剩余本金(元)", 1.45f)
    }
}

@Composable
fun PlanDataRow(row: PlanRow, isFinal: Boolean = false, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(
                if (isFinal) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                else androidx.compose.ui.graphics.Color.Transparent
            )
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cell("${row.period}", 0.95f, bold = false)
        Cell(MoneyFormat.fenToYuan(row.payment), 1.35f)
        Cell(MoneyFormat.fenToYuan(row.principal), 1.35f)
        Cell(MoneyFormat.fenToYuan(row.interest), 1.25f)
        Box(modifier = Modifier.weight(1.45f)) {
            Text(
                text = if (isFinal) "${MoneyFormat.fenToYuan(row.remaining)} · 结清" else MoneyFormat.fenToYuan(row.remaining),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = if (isFinal) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.align(Alignment.CenterEnd),
            )
        }
    }
}

@Composable
private fun RowScope.HeaderCell(label: String, weight: Float) {
    Text(
        label,
        modifier = Modifier.weight(weight),
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun RowScope.Cell(value: String, weight: Float, bold: Boolean = false) {
    Text(
        value,
        modifier = Modifier.weight(weight),
        fontSize = 12.sp,
        fontFamily = FontFamily.Monospace,
        fontWeight = if (bold) FontWeight.Bold else null,
        color = MaterialTheme.colorScheme.onSurface,
    )
}
