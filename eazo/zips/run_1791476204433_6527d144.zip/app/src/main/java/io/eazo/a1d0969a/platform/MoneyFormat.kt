package io.eazo.a1d0969a.platform

import java.util.Locale

/** 金额展示格式化（分 → 元，千分位，UI/卡片共用；展示态，不进 core）。 */
object MoneyFormat {

    /** 530727 分 → "5,307.27"；0 分 → "0.00"。 */
    fun fenToYuan(fen: Long): String =
        String.format(Locale.US, "%,d.%02d", fen / 100, Math.abs(fen % 100))

    /** 530727 分 → "¥5,307.27"。 */
    fun fenToYuanWithSign(fen: Long): String = "¥" + fenToYuan(fen)

    /** 1000000.0 元 → "1,000,000"；仅用于输入域展示。 */
    fun yuan(value: Double): String =
        String.format(Locale.US, "%,d", Math.round(value))
}
