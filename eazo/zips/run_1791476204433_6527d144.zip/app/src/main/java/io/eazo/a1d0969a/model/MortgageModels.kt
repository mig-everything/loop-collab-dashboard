package io.eazo.a1d0969a.model

/**
 * REQ-015 数据模型（契约 §1.1，与鸿蒙 ArkTS 侧 1:1——字段名/枚举字面量完全一致）。
 *
 * 金额一律「分」的 Long 整数承载（契约 §1.3：中间积 P×R4 ≤ 10^14 > 2^31，
 * Kotlin 全程 Long 禁 Int；ArkTS 侧 Number 安全整数域 < 2^53）。
 */

/** 还款方式：ET = 等额本息（Equal Total）/ EP = 等额本金（Equal Principal）。 */
enum class Mode(val literal: String) {
    ET("ET"),
    EP("EP");

    val label: String get() = if (this == ET) "等额本息" else "等额本金"

    companion object {
        fun fromLiteral(v: String): Mode? = entries.firstOrNull { it.literal == v }
    }
}

/** UI 层输入（元 / % / 年）；core 层先转 (P_分, R4, n) 再计算（契约 §3.0）。 */
data class MortgageInput(
    val principalYuan: Double,
    val ratePercent: Double,
    val years: Int,
    val mode: Mode,
)

/** 计划表行（n × 5）；period 从 1 起；remaining 为本期还款后余额。 */
data class PlanRow(
    val period: Int,
    val payment: Long,
    val principal: Long,
    val interest: Long,
    val remaining: Long,
)

/** 汇总：ET 时 monthly = M_分；EP 时 monthly = 首月月供（展示口径，契约 §3.5）。 */
data class Summary(
    val monthly: Long,
    val totalInterest: Long,
    val totalPayment: Long,
)

/** calc 全量结果：mFen/baseFen 均为输入纯派生（锚点面，契约 §6.1），rows/summary 按当前 mode。 */
data class MortgageResult(
    val mode: Mode,
    val pFen: Long,
    val r4: Long,
    val n: Int,
    val mFen: Long,
    val baseFen: Long,
    val rows: List<PlanRow>,
    val summary: Summary,
)

/** compare：两方式 Summary + 总利息差（ET − EP，契约 §3.5；案例 A 锚点 17357404）。 */
data class MortgageCompare(
    val et: Summary,
    val ep: Summary,
    val totalInterestDiff: Long,
)
