package io.eazo.a1d0969a.platform

import android.content.Context
import io.eazo.a1d0969a.core.MortgageMath
import io.eazo.a1d0969a.model.MortgageInput

/**
 * 骨架模板平台层：AppRepo 进程内单例（生成器硬规则 ①——UI/卡片层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * AppRepo 本身即进程内单例（Kotlin object）；会话按需求把业务仓储/持久化
 * 作为本 object 的成员挂接（参照基线工程 Platform.kt：object AppRepo 持有
 * repo 实例，getRepo() 双检锁构造），保持 getRepo(context) 单例入口不变。
 *
 * REQ-015：契约 §2——「当前输入参数；内存态，无跨日状态」（无持久化、无会话语义，
 * 每次计算整表重算）。UI/卡片读快照、写经 update()，跨层即时可见。
 */
object AppRepo {

    /** 当前输入参数（内存态；初始 = 契约默认 100 万 / 4.9% / 30 年 / ET）。 */
    @Volatile
    private var currentInput: MortgageInput = MortgageInput(
        principalYuan = MortgageMath.DEFAULT_P_YUAN,
        ratePercent = MortgageMath.DEFAULT_RATE,
        years = MortgageMath.DEFAULT_YEARS,
        mode = io.eazo.a1d0969a.model.Mode.ET,
    )

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo = this

    /** 读内存态快照（UI/卡片数据源；validate 兜底在 calc 内统一做）。 */
    fun snapshot(): MortgageInput = currentInput

    /** 写内存态（跨页面/卡片即时可见——无持久化，无竞态面）。 */
    fun update(input: MortgageInput) {
        currentInput = input
    }

    /** 会话按需求扩展：内存态持有 + 持久化读写（读写分离，list() 只读内存态）。 */
    fun refresh() {
        // 硬规则 ②：refresh 只重读内存态，禁止从持久化 load()（本 REQ 无持久化，快照即内存态）
    }
}

