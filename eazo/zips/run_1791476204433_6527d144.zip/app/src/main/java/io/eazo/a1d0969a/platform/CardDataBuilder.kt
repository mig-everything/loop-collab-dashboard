package io.eazo.a1d0969a.platform

import io.eazo.a1d0969a.core.MortgageCore
import io.eazo.a1d0969a.model.MortgageInput

/**
 * 桌面卡片数据（契约 §2：首月月供 + 剩余本金，纯推导，US-7 Should）。
 * 语义：validate → calc → 取第 1 期行（ET 时 rows[0].payment 即 M_分）。
 */
object CardDataBuilder {

    data class CardData(
        val monthlyFen: Long,       // 首月月供（分）
        val remainingFen: Long,     // 第 1 期还款后剩余本金（分）
        val principalYuan: Double,  // 展示：贷款总额（元）
        val ratePercent: Double,    // 展示：年利率（%）
        val years: Int,             // 展示：年限（年）
        val modeLiteral: String,    // 展示：方式字面量 ET/EP（与鸿蒙 1:1）
    )

    fun build(input: MortgageInput): CardData {
        val result = MortgageCore.calc(input)
        val first = result.rows[0]
        return CardData(
            monthlyFen = first.payment,
            remainingFen = first.remaining,
            principalYuan = input.principalYuan,
            ratePercent = input.ratePercent,
            years = input.years,
            modeLiteral = result.mode.literal,
        )
    }
}
