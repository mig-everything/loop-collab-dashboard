package io.eazo.a1d0969a.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import io.eazo.a1d0969a.platform.AppRepo
import io.eazo.a1d0969a.platform.OpenInput

/**
 * 骨架模板主界面：单 Activity + Jetpack Compose（UI 锁死声明式——与鸿蒙 ArkUI
 * 声明式对称，禁止 XML 布局/drawable 扇出；图标用 material-icons，主题用
 * Compose MaterialTheme）。
 *
 * 硬规则 ②：onResume 只 refresh()（重读内存态），禁止从持久化 load()。
 * 硬规则 ④：冷启动 onCreate(intent) 与热启动 onNewIntent(intent) 两路竞态
 * 都覆盖，且走同一 OpenInput.readOpenCreate(intent) 纯函数（严格类型判定），
 * 结果写 AppRepo 内存态并以 nonce 递增桥接 Compose 表单同步。
 */
class MainActivity : ComponentActivity() {

    /** 冷/热启动携带参数写入次数（Compose 侧经 LaunchedEffect 感知同步）。 */
    private var openNonce by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        applyOpen(intent) // 冷启动路：onCreate(want)
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Screen()
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        applyOpen(intent) // 热启动路：onNewIntent(want)——与冷启动同一入口
    }

    /** 两路同一：readOpenCreate(intent) → AppRepo.update → nonce 桥接。 */
    private fun applyOpen(intent: Intent?) {
        val open = OpenInput.readOpenCreate(intent) ?: return
        AppRepo.getRepo(this).update(open)
        openNonce += 1
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(this).refresh() // 本 REQ 无持久化：refresh 仅重读内存态快照
    }

    @Composable
    private fun Screen() {
        MortgageScreen(openNonce = openNonce)
    }
}

/** 骨架默认主题（浅色，会话按需求改配色；不另建 XML 主题）。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) DarkColors else LightColors
    MaterialTheme(colorScheme = scheme, content = content)
}

private val LightColors = lightColorScheme(
    primary = Color(0xFF0E5E4A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB7F0DC),
    onPrimaryContainer = Color(0xFF04261C),
    secondary = Color(0xFFB45309),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFCE8CB),
    tertiary = Color(0xFF475569),
    background = Color(0xFFF5F6F8),
    surface = Color.White,
    surfaceVariant = Color(0xFFEDF0F3),
    onSurfaceVariant = Color(0xFF64748B),
    outlineVariant = Color(0xFFE2E8F0),
)

private val DarkColors = lightColorScheme(
    primary = Color(0xFF6FD9BB),
    onPrimary = Color(0xFF03382B),
    primaryContainer = Color(0xFF0B4A3A),
    onPrimaryContainer = Color(0xFFB7F0DC),
    secondary = Color(0xFFF0B45C),
    tertiary = Color(0xFFB6C2D3),
    background = Color(0xFF10141A),
    surface = Color(0xFF181D24),
    surfaceVariant = Color(0xFF232A33),
    onSurface = Color(0xFFE6EAF0),
    onSurfaceVariant = Color(0xFF9AA7B8),
    outlineVariant = Color(0xFF2C343F),
)
