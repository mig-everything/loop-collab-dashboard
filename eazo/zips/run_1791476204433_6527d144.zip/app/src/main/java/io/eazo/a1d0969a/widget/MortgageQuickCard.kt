package io.eazo.a1d0969a.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import io.eazo.a1d0969a.R
import io.eazo.a1d0969a.platform.AppRepo
import io.eazo.a1d0969a.platform.CardDataBuilder
import io.eazo.a1d0969a.platform.MoneyFormat
import io.eazo.a1d0969a.platform.OpenInput
import io.eazo.a1d0969a.ui.MainActivity

/**
 * 桌面卡片「房贷速算」（契约 §2 widget/ 元服务 Should，§9 AppWidget L1 对等基线）。
 * 数据 = AppRepo.getRepo(context) 内存态 → CardDataBuilder 纯推导（硬规则 ①：不 new 仓储）。
 * 点卡片回 App：携带当前输入 extras —— 冷启动 onCreate / 热启动 onNewIntent
 * 两路同走 OpenInput.readOpenCreate(intent)（硬规则 ④）。
 */
class MortgageQuickCard : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        render(context, appWidgetManager, appWidgetIds)
    }

    companion object {

        /** UI 输入变化后主动刷新全部卡片实例（AppRepo.update 之后调用）。 */
        fun push(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            render(context, manager, manager.getAppWidgetIds(android.content.ComponentName(context, MortgageQuickCard::class.java)))
        }

        private fun render(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
            if (appWidgetIds.isEmpty()) return
            val input = AppRepo.getRepo(context).snapshot()
            val data = CardDataBuilder.build(input)

            val views = RemoteViews(context.packageName, R.layout.mortgage_widget)
            views.setTextViewText(R.id.widget_monthly, "首月月供  " + MoneyFormat.fenToYuanWithSign(data.monthlyFen))
            views.setTextViewText(R.id.widget_remaining, "剩余本金  " + MoneyFormat.fenToYuanWithSign(data.remainingFen))
            views.setTextViewText(
                R.id.widget_sub,
                "${MoneyFormat.yuan(data.principalYuan)}万·${data.ratePercent}%·${data.years}年·" +
                    if (data.modeLiteral == "ET") "等额本息" else "等额本金",
            )

            // 点卡片回 App，携带当前输入（走 readOpenCreate 两路解析）
            val open = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(OpenInput.KEY_PRINCIPAL, data.principalYuan)
                putExtra(OpenInput.KEY_RATE, data.ratePercent)
                putExtra(OpenInput.KEY_YEARS, data.years)
                putExtra(OpenInput.KEY_MODE, data.modeLiteral)
            }
            val pending = PendingIntent.getActivity(
                context, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            views.setOnClickPendingIntent(R.id.widget_root, pending)

            for (id in appWidgetIds) manager.updateAppWidget(id, views)
        }
    }
}
