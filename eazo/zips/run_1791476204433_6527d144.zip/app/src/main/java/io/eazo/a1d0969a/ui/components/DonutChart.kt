package io.eazo.a1d0969a.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.a1d0969a.platform.MoneyFormat
import io.eazo.a1d0969a.ui.theme.DonutInterest
import io.eazo.a1d0969a.ui.theme.DonutPrincipal
import java.util.Locale

/**
 * 本息构成环形图（展示态）：本金环 + 利息环 + 中心总还款与利息占比。
 */
@Composable
fun DonutChart(
    principalFen: Long,
    interestFen: Long,
    modifier: Modifier = Modifier,
    diameter: Dp = 170.dp,
) {
    val total = principalFen + interestFen
    val principalRatio = if (total > 0) principalFen.toDouble() / total else 0.0

    Box(modifier = modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 24.dp.toPx()
            val inset = stroke / 2
            val arcSize = Size(size.width - stroke, size.height - stroke)
            val topLeft = Offset(inset, inset)
            if (total > 0) {
                val principalSweep = 360.0 * principalRatio
                drawArc(
                    color = DonutPrincipal,
                    startAngle = -90f,
                    sweepAngle = principalSweep.toFloat(),
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Butt),
                )
                drawArc(
                    color = DonutInterest,
                    startAngle = (-90.0 + principalSweep).toFloat(),
                    sweepAngle = (360.0 - principalSweep).toFloat(),
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke, cap = StrokeCap.Butt),
                )
            } else {
                drawArc(
                    color = DonutPrincipal,
                    startAngle = -90f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = stroke),
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("总还款", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                MoneyFormat.fenToYuanWithSign(total),
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
                "利息占比 ${"%.1f".format(Locale.US, (1.0 - principalRatio) * 100)}%",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** 环形图图例（本金/利息 双色点 + 金额与占比）。 */
@Composable
fun DonutLegend(principalFen: Long, interestFen: Long, modifier: Modifier = Modifier) {
    val total = (principalFen + interestFen).coerceAtLeast(1)
    Column(modifier = modifier) {
        LegendLine(DonutPrincipal, "贷款本金", principalFen, total)
        LegendLine(DonutInterest, "利息总额", interestFen, total)
    }
}

@Composable
private fun LegendLine(color: Color, label: String, fen: Long, totalFen: Long) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            "  $label  ${MoneyFormat.fenToYuan(fen)}（${"%.1f".format(Locale.US, 100.0 * fen / totalFen)}%）",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
