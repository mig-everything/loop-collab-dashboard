package io.eazo.a1d0969a.core

import io.eazo.a1d0969a.model.Mode
import io.eazo.a1d0969a.model.PlanRow
import io.eazo.a1d0969a.model.Summary

/**
 * REQ-015 计算原语（契约 §3，双端等价伪代码的 Kotlin 落点）。
 * 纯函数、无 IO/网络/随机/系统时钟（契约 §2 禁 core 反向依赖）。
 * 唯一浮点运算 = ET 月供 M 的一次 double pow 后立即锁整数（契约 §1.4）。
 */
object MortgageMath {

    // ---- 常量（契约 §1.2，双端单测直断言）----
    const val RATE_DENOM: Long = 12000000L       // 月利率分母：R4/12000000 = 月利率
    const val HALF_RATE_DENOM: Long = 6000000L   // = RATE_DENOM/2，精确（分母偶数）
    const val DEFAULT_P_YUAN: Double = 1000000.0 // 非法输入回退默认（AC-S1.2）
    const val DEFAULT_RATE: Double = 4.9         // %
    const val DEFAULT_YEARS: Int = 30
    const val P_MAX_FEN: Long = 1000000000L      // 输入域上界（1000 万元）
    const val R4_MAX: Long = 100000L             // 利率域上界（10%）
    const val N_MAX: Int = 360                   // 年限域上界（30 年）

    // ---- 定点转换（UI 输入 → 整数域，契约 §3.0）----

    /** 元 → 分。 */
    fun toPFen(principalYuan: Double): Long = roundHalfUpFloat(principalYuan * 100.0)

    /** % → 万分之一。 */
    fun toR4(ratePercent: Double): Long = roundHalfUpFloat(ratePercent * 10000.0)

    /** 年 → 月数 n（恒为偶数无需断言：Y 整年 → n = Y×12）。 */
    fun toMonths(years: Int): Int = years * 12

    // ---- 舍入原语（★ 锁死语义，仅正数域；禁银行家舍入）----

    /** 整数分数四舍五入：b 恒为偶数（b/2 精确），实现必须用整数式（契约 §3.0）。 */
    fun roundHalfUpFrac(a: Long, b: Long): Long = (a + b / 2) / b

    /** 浮点四舍五入：仅两处用——元→分、%→万分之一、M 锁整数。 */
    fun roundHalfUpFloat(x: Double): Long = Math.floor(x + 0.5).toLong()

    // ---- 逐月利息（★ 全整数，无浮点；契约 §3.1）----

    /** 计息基 = 本期期初剩余本金；中间积 remaining×R4 ≤ 10^14（§1.3 安全界）。 */
    fun interestOf(remaining: Long, r4: Long): Long =
        (remaining * r4 + HALF_RATE_DENOM) / RATE_DENOM

    // ---- 等额本息月供 M（★ 唯一浮点量；写法锁定，禁拆项重排，契约 §3.2/§9）----

    fun equalPayment(pFen: Long, r4: Long, n: Int): Long {
        if (r4 == 0L) return roundHalfUpFrac(pFen, n.toLong()) // R=0 退化：M = P/n（§6.6 无息分期）
        val r = r4 / RATE_DENOM.toDouble()            // 月利率（十进制 double；仅此处用）
        val q = Math.pow(1.0 + r, n.toDouble())       // IEEE-754 double pow（C2 锁定写法）
        return Math.floor(pFen * r * q / (q - 1.0) + 0.5).toLong()
    }

    // ---- 等额本金每月本金 base（契约 §3.4）----

    fun equalPrincipal(pFen: Long, n: Int): Long = roundHalfUpFrac(pFen, n.toLong())

    // ---- 逐月递推（整数 + 尾差归零，契约 §3.3/§3.4）----

    fun amortize(pFen: Long, r4: Long, n: Int, mode: Mode): List<PlanRow> {
        val mFen = equalPayment(pFen, r4, n)
        val base = equalPrincipal(pFen, n)
        val rows = ArrayList<PlanRow>(n)
        var remaining = pFen
        for (i in 1..n) {
            val interest = interestOf(remaining, r4)
            val principal = if (i == n) remaining else if (mode == Mode.ET) mFen - interest else base
            val payment = principal + interest
            remaining -= principal
            rows.add(PlanRow(period = i, payment = payment, principal = principal, interest = interest, remaining = remaining))
        }
        return rows
    }

    // ---- 汇总（契约 §3.5：整数累加，★ 禁 M×n−P 浮点捷径）----

    fun summarize(rows: List<PlanRow>, pFen: Long, mode: Mode, mFen: Long): Summary {
        var totalPayment = 0L
        for (row in rows) totalPayment += row.payment
        val totalInterest = totalPayment - pFen
        val monthly = if (mode == Mode.ET) mFen else rows[0].payment
        return Summary(monthly = monthly, totalInterest = totalInterest, totalPayment = totalPayment)
    }

    // ---- 规范序列化（契约 §4：`期数|月供|本金|利息|剩余本金` LF 连接，行尾无换行）----

    fun serializeRows(rows: List<PlanRow>): String =
        rows.joinToString("\n") { "${it.period}|${it.payment}|${it.principal}|${it.interest}|${it.remaining}" }
}
