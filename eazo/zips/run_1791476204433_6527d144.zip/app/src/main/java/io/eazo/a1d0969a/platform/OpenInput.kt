package io.eazo.a1d0969a.platform

import android.content.Intent
import android.os.Bundle
import io.eazo.a1d0969a.core.MortgageCore
import io.eazo.a1d0969a.core.MortgageMath
import io.eazo.a1d0969a.model.Mode
import io.eazo.a1d0969a.model.MortgageInput

/**
 * 启动参数解析（生成器硬规则 ④）：冷启动 onCreate(intent) 与热启动
 * onNewIntent(intent) 两路竞态都覆盖，且走同一 readOpenCreate(intent) 纯函数；
 * 布尔/类型参数严格判定（等价 ArkTS `typeof v === 'boolean' && v === true`）。
 *
 * 携带键（与桌面卡片 PendingIntent 对齐）：principal(元)/rate(%)/years(年)/mode(ET|EP)。
 */
object OpenInput {

    const val KEY_PRINCIPAL = "principal"
    const val KEY_RATE = "rate"
    const val KEY_YEARS = "years"
    const val KEY_MODE = "mode"

    /**
     * 纯函数半部（JVM 可单测）：extras 键值对 → 输入参数。
     * 任一键存在但类型不符即整体视为无携带（严格判定，防模板串/类型漂移）；
     * 未携带任何键 → null（保持当前内存态）。解析结果仍经 validate 兜底。
     */
    fun parseOpenInput(raw: Map<String, Any?>): MortgageInput? {
        val keys = listOf(KEY_PRINCIPAL, KEY_RATE, KEY_YEARS, KEY_MODE)
        val hasAny = keys.any { raw.containsKey(it) }
        if (!hasAny) return null

        val principal = when (val v = raw[KEY_PRINCIPAL]) {
            null -> MortgageMath.DEFAULT_P_YUAN
            is Double -> v                        // 严格类型：仅接受数值（拒绝字符串模板串）
            is Int -> v.toDouble()
            else -> return null
        }
        val rate = when (val v = raw[KEY_RATE]) {
            null -> MortgageMath.DEFAULT_RATE
            is Double -> v
            is Int -> v.toDouble()
            else -> return null
        }
        val years = when (val v = raw[KEY_YEARS]) {
            null -> MortgageMath.DEFAULT_YEARS
            is Int -> v                            // 严格类型：年限仅接受 Int（拒绝 30.0 浮点串）
            else -> return null
        }
        val mode = when (val v = raw[KEY_MODE]) {
            null -> Mode.ET
            is String -> Mode.fromLiteral(v) ?: return null   // 严格字面量：仅 ET/EP
            else -> return null
        }
        return MortgageInput(principal, rate, years, mode)
    }

    /** 两路同一入口：Intent extras → Map → parseOpenInput（纯半部）→ validate 兜底。 */
    fun readOpenCreate(intent: Intent?): MortgageInput? {
        val extras: Bundle? = intent?.extras
        if (extras == null || extras.isEmpty) return null
        val raw = HashMap<String, Any?>()
        for (key in extras.keySet()) raw[key] = extras.get(key)
        return parseOpenInput(raw)?.let { MortgageCore.validate(it) }
    }
}
