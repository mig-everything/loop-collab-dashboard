package io.eazo.a1d0969a.ui.theme

import androidx.compose.ui.graphics.Color

/** 展示态调色（与 AppTheme 主题色一致的扩展色板；环形图/对比条共用）。 */
val DonutPrincipal = Color(0xFF0E5E4A)   // 本金 · 深松绿（=主题 primary）
val DonutInterest = Color(0xFFE8A33D)    // 利息 · 琥珀
val CompareBarEt = Color(0xFF2563EB)     // 对比条 · 等额本息蓝
val CompareBarEp = Color(0xFF0E9F6E)     // 对比条 · 等额本金绿
