package io.eazo.a1d0969a.core

import io.eazo.a1d0969a.model.Mode
import io.eazo.a1d0969a.model.MortgageCompare
import io.eazo.a1d0969a.model.MortgageInput
import io.eazo.a1d0969a.model.MortgageResult

/**
 * REQ-015 业务入口（契约 §2：MortgageCore = validate/calc/compare）。
 * 无会话语义：每次计算从初始值整表递推，输入变化即全量重算（n≤360，~1ms 级）。
 */
object MortgageCore {

    /** 输入校验与回退（AC-S1.2，契约 §3.6）：任一非法 → 回退默认，mode 不变，双端行为一致。 */
    fun validate(input: MortgageInput): MortgageInput {
        val pOk = input.principalYuan > 0.0 && input.principalYuan <= 1.0e7            // 0 < P ≤ 10^7 元
        val rOk = input.ratePercent >= 0.0 && input.ratePercent <= 10.0                // 0 ≤ R ≤ 10 %
        val yOk = input.years > 0 && input.years <= 30                                 // 0 < Y ≤ 30 且整数
        val mOk = input.mode == Mode.ET || input.mode == Mode.EP
        return if (pOk && rOk && yOk && mOk) input
        else MortgageInput(
            principalYuan = MortgageMath.DEFAULT_P_YUAN,
            ratePercent = MortgageMath.DEFAULT_RATE,
            years = MortgageMath.DEFAULT_YEARS,
            mode = input.mode,
        )
    }

    /** 全量计算：转整数域 → 递推 → 汇总（rows/summary 按当前 mode）。 */
    fun calc(input: MortgageInput): MortgageResult {
        val v = validate(input)
        val pFen = MortgageMath.toPFen(v.principalYuan)
        val r4 = MortgageMath.toR4(v.ratePercent)
        val n = MortgageMath.toMonths(v.years)
        val mFen = MortgageMath.equalPayment(pFen, r4, n)
        val baseFen = MortgageMath.equalPrincipal(pFen, n)
        val rows = MortgageMath.amortize(pFen, r4, n, v.mode)
        val summary = MortgageMath.summarize(rows, pFen, v.mode, mFen)
        return MortgageResult(
            mode = v.mode,
            pFen = pFen,
            r4 = r4,
            n = n,
            mFen = mFen,
            baseFen = baseFen,
            rows = rows,
            summary = summary,
        )
    }

    /** 双方式对比（AC-S6.1）：totalInterestDiff = 总息_ET − 总息_EP（案例 A 锚点 17357404）。 */
    fun compare(input: MortgageInput): MortgageCompare {
        val et = calc(input.copy(mode = Mode.ET)).summary
        val ep = calc(input.copy(mode = Mode.EP)).summary
        return MortgageCompare(et = et, ep = ep, totalInterestDiff = et.totalInterest - ep.totalInterest)
    }
}
