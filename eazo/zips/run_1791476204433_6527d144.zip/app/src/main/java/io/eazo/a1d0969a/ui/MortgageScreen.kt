package io.eazo.a1d0969a.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.a1d0969a.core.MortgageCore
import io.eazo.a1d0969a.model.Mode
import io.eazo.a1d0969a.model.MortgageInput
import io.eazo.a1d0969a.platform.AppRepo
import io.eazo.a1d0969a.platform.MoneyFormat
import io.eazo.a1d0969a.ui.components.DonutChart
import io.eazo.a1d0969a.ui.components.DonutLegend
import io.eazo.a1d0969a.ui.components.PlanDataRow
import io.eazo.a1d0969a.ui.components.PlanHeaderRow
import io.eazo.a1d0969a.ui.theme.CompareBarEp
import io.eazo.a1d0969a.ui.theme.CompareBarEt
import io.eazo.a1d0969a.widget.MortgageQuickCard
import kotlin.math.roundToInt

/**
 * 房贷计算器首屏（展示态，契约 §2 pages/）。
 *
 * 数据流：表单文本态 → MortgageInput → validate（非法回退默认，AC-S1.2）→
 * calc/compare 全量重算（无会话语义）→ AppRepo 内存态 + 桌面卡片推送。
 * 利率/年限滑杆实时联动；方式切换即对比；≥600dp 宽屏双栏自适应（AC-S8.1）。
 */
@Composable
fun MortgageScreen(openNonce: Int = 0) {
    val context = LocalContext.current
    val initial = remember { AppRepo.getRepo(context).snapshot() }
    var principalWan by remember { mutableStateOf(numText(initial.principalYuan / 10000.0)) }
    var rateText by remember { mutableStateOf(numText(initial.ratePercent)) }
    var yearsText by remember { mutableStateOf(initial.years.toString()) }
    var mode by remember { mutableStateOf(initial.mode) }

    // 冷/热启动携带参数（readOpenCreate 两路写入 AppRepo 后 nonce 递增）→ 同步表单
    LaunchedEffect(openNonce) {
        val s = AppRepo.getRepo(context).snapshot()
        principalWan = numText(s.principalYuan / 10000.0)
        rateText = numText(s.ratePercent)
        yearsText = s.years.toString()
        mode = s.mode
    }

    val pWan = principalWan.toDoubleOrNull()
    val r = rateText.toDoubleOrNull()
    val y = yearsText.toIntOrNull()
    val raw = MortgageInput(
        principalYuan = pWan?.times(10000.0) ?: 0.0,
        ratePercent = r ?: -1.0,
        years = y ?: 0,
        mode = mode,
    )
    val effective = remember(raw) { MortgageCore.validate(raw) }
    val result = remember(effective) { MortgageCore.calc(effective) }
    val cmp = remember(effective) { MortgageCore.compare(effective) }
    LaunchedEffect(effective) {
        AppRepo.getRepo(context).update(effective)
        runCatching { MortgageQuickCard.push(context) } // 无卡片宿主环境（本地测试）静默
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        val wide = maxWidth >= 600.dp
        if (wide) {
            Row(modifier = Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
                Column(
                    modifier = Modifier
                        .weight(0.46f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState())
                        .padding(vertical = 16.dp),
                ) {
                    Header()
                    InputCard(principalWan, rateText, yearsText, mode,
                        onPrincipal = { principalWan = it }, onRate = { rateText = it },
                        onYears = { yearsText = it }, onMode = { mode = it })
                    Spacer(Modifier.height(14.dp))
                    SummaryCard(result.mode.literal, result.summary.monthly,
                        result.summary.totalPayment, result.summary.totalInterest, result.pFen)
                    Spacer(Modifier.height(14.dp))
                    CompareCard(cmp.et.totalInterest, cmp.ep.totalInterest, cmp.totalInterestDiff)
                    Spacer(Modifier.height(14.dp))
                }
                Column(modifier = Modifier.weight(0.54f).fillMaxHeight().padding(vertical = 16.dp)) {
                    TableTitle()
                    PlanHeaderRow()
                    LazyColumn(modifier = Modifier.fillMaxHeight()) {
                        items(result.rows) { row -> PlanDataRow(row, isFinal = row.remaining == 0L) }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp),
            ) {
                item { Header() }
                item {
                    InputCard(principalWan, rateText, yearsText, mode,
                        onPrincipal = { principalWan = it }, onRate = { rateText = it },
                        onYears = { yearsText = it }, onMode = { mode = it })
                }
                item {
                    Spacer(Modifier.height(14.dp))
                    SummaryCard(result.mode.literal, result.summary.monthly,
                        result.summary.totalPayment, result.summary.totalInterest, result.pFen)
                }
                item {
                    Spacer(Modifier.height(14.dp))
                    CompareCard(cmp.et.totalInterest, cmp.ep.totalInterest, cmp.totalInterestDiff)
                }
                item {
                    Spacer(Modifier.height(16.dp))
                    TableTitle()
                    PlanHeaderRow()
                }
                items(result.rows) { row -> PlanDataRow(row, isFinal = row.remaining == 0L) }
                item { Spacer(Modifier.height(28.dp)) }
            }
        }
    }
}

// ---- 区块 ----

@Composable
private fun Header() {
    Column(modifier = Modifier.padding(top = 14.dp, bottom = 12.dp)) {
        Text("房贷计算器", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(
            "等额本息 / 等额本金 · 逐月还款计划",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun CardBox(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
    ) { content() }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun InputCard(
    principalWan: String, rateText: String, yearsText: String, mode: Mode,
    onPrincipal: (String) -> Unit, onRate: (String) -> Unit,
    onYears: (String) -> Unit, onMode: (Mode) -> Unit,
) {
    CardBox {
        SectionLabel("贷款参数")
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = principalWan,
            onValueChange = onPrincipal,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("贷款总额（万元）") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = rateText,
            onValueChange = onRate,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("年利率（%）") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        )
        RateSlider(rateText, onRate)
        OutlinedTextField(
            value = yearsText,
            onValueChange = onYears,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("贷款年限（年）") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        )
        YearsSlider(yearsText, onYears)
        Spacer(Modifier.height(6.dp))
        SectionLabel("还款方式")
        Spacer(Modifier.height(8.dp))
        ModeToggle(mode, onMode)
    }
}

@Composable
private fun RateSlider(rateText: String, onRate: (String) -> Unit) {
    val current = (rateText.toFloatOrNull() ?: 4.9f).coerceIn(0f, 10f)
    Column {
        Slider(
            value = current,
            onValueChange = { raw ->
                val snapped = (raw / 0.05f).roundToInt() * 0.05f
                onRate(String.format(java.util.Locale.US, "%.2f", snapped))
            },
            valueRange = 0f..10f,
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("0%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("拖动实时调息 · 上限 10%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("10%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun YearsSlider(yearsText: String, onYears: (String) -> Unit) {
    val current = (yearsText.toIntOrNull() ?: 30).coerceIn(1, 30).toFloat()
    Column {
        Slider(
            value = current,
            onValueChange = { raw -> onYears(raw.roundToInt().toString()) },
            valueRange = 1f..30f,
            steps = 28,
        )
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("1 年", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            val months = (yearsText.toIntOrNull() ?: 30) * 12
            Text("$months 期", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("30 年", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ModeToggle(mode: Mode, onChange: (Mode) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(4.dp),
    ) {
        Mode.entries.forEach { m ->
            val selected = mode == m
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(9.dp))
                    .background(if (selected) MaterialTheme.colorScheme.primary else Color.Transparent)
                    .clickable { onChange(m) }
                    .padding(vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    m.label,
                    color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 14.sp,
                )
            }
        }
    }
}

@Composable
private fun SummaryCard(
    modeLiteral: String, monthlyFen: Long, totalPaymentFen: Long, totalInterestFen: Long, principalFen: Long,
) {
    CardBox {
        SectionLabel("还款概览 · ${if (modeLiteral == "ET") "等额本息" else "等额本金"}")
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            DonutChart(principalFen = principalFen, interestFen = totalInterestFen)
            Spacer(Modifier.width(18.dp))
            Column {
                DonutLegend(principalFen = principalFen, interestFen = totalInterestFen)
                Spacer(Modifier.height(10.dp))
                Text(
                    MoneyFormat.fenToYuanWithSign(monthlyFen),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    if (modeLiteral == "ET") "每月月供（固定）" else "首月月供 · 逐月递减",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                SummaryLine("总还款", MoneyFormat.fenToYuanWithSign(totalPaymentFen))
                SummaryLine("总利息", MoneyFormat.fenToYuanWithSign(totalInterestFen))
            }
        }
    }
}

@Composable
private fun SummaryLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun CompareCard(etInterestFen: Long, epInterestFen: Long, diffFen: Long) {
    CardBox {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            SectionLabel("两种方式对比 · 总利息")
            Text(
                if (diffFen > 0) "等额本金省 ${MoneyFormat.fenToYuan(diffFen)}" else "两种方式利息相同",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        Spacer(Modifier.height(12.dp))
        val maxFen = maxOf(etInterestFen, epInterestFen).coerceAtLeast(1)
        CompareBar("等额本息", etInterestFen, maxFen, CompareBarEt)
        Spacer(Modifier.height(10.dp))
        CompareBar("等额本金", epInterestFen, maxFen, CompareBarEp)
    }
}

@Composable
private fun CompareBar(label: String, valueFen: Long, maxFen: Long, color: Color) {
    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(MoneyFormat.fenToYuan(valueFen), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(color.copy(alpha = 0.15f)),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth((valueFen.toDouble() / maxFen).toFloat().coerceIn(0f, 1f))
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(color),
            )
        }
    }
}

@Composable
private fun TableTitle() {
    Text(
        "还款计划表",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 8.dp),
    )
}

/** 数值文本化：100.0 → "100"，4.9 → "4.9"（滑杆/输入框双向同步用）。 */
private fun numText(v: Double): String =
    if (v == Math.floor(v) && !v.isInfinite()) Math.round(v).toString() else v.toString()
