package io.eazo.a038a10a.core

import io.eazo.a038a10a.data.TimeSignatures

/**
 * REQ-022 节拍器确定性核心（契约 §2.1~§2.3 逐行落码）。
 *
 * D7 禁用清单：本文件禁 IO/网络/随机/时钟/UI API——elapsed 一律显式传参，
 * 全函数可脱离 UI 单测。
 */
object MetronomeCore {

    const val BPM_MIN = 40
    const val BPM_MAX = 240

    /** §2.1 intervalMs：round_half_up(60000/bpm)，免浮点整数式（Int 域除法天然 half-up）。 */
    fun intervalMs(bpm: Int): Int = (60000 + bpm / 2) / bpm

    /** §2.2 isAccent：0-based，beat 0 = 首小节第 1 拍恒重音。 */
    fun isAccent(beatIndex: Int, beatsPerBar: Int): Boolean = beatIndex % beatsPerBar == 0

    /** §2.3 beatCountAt：floor(elapsed / interval)，已完成完整节拍间隔数（Int 整除天然 floor，正值）。 */
    fun beatCountAt(elapsedMs: Int, bpm: Int): Int = elapsedMs / intervalMs(bpm)

    /** §2.3 currentBeatIndex：beat_count % bpb（展示层辅助值；推导值数据态可测）。 */
    fun currentBeatIndex(elapsedMs: Int, bpm: Int, bpb: Int): Int = beatCountAt(elapsedMs, bpm) % bpb

    /** §2.5 clampBpm：越界收敛到域边界 [40, 240]，域内原样返回。 */
    fun clampBpm(v: Int): Int = if (v < BPM_MIN) BPM_MIN else if (v > BPM_MAX) BPM_MAX else v

    // ===== §2.5 运行状态机（纯转移，数据态可测）=====

    /** 运行层状态（契约 §1.1 RunState；elapsed 由运行层持有，不入纯转移）。 */
    data class RunState(
        val state: String,      // "idle" | "running"
        val bpm: Int,
        val tsId: String,
        val beatIndex: Int,     // 0-based；stop 归零
    )

    /**
     * §2.5 next：2 态 × 4 事件全集（6 有效 + 2 忽略）。
     * running 中 setBpm/setTimeSignature = 原子 stop+start 重基准（beatIndex 归零，
     * 下一拍恒为新小节第 1 拍重音）；idle 中持久化由运行层壳执行。
     * 未列出组合原样返回（禁崩溃、禁隐式跳转）。
     */
    fun next(
        rs: RunState,
        event: String,
        payloadBpm: Int = 0,
        payloadTsId: String = "",
    ): RunState = when {
        rs.state == "idle" && event == "start" ->
            RunState("running", rs.bpm, rs.tsId, 0)
        rs.state == "running" && event == "stop" ->
            RunState("idle", rs.bpm, rs.tsId, 0)
        rs.state == "running" && event == "setBpm" ->
            RunState("running", clampBpm(payloadBpm), rs.tsId, 0)
        rs.state == "idle" && event == "setBpm" ->
            RunState("idle", clampBpm(payloadBpm), rs.tsId, rs.beatIndex)
        rs.state == "running" && event == "setTimeSignature" ->
            RunState("running", rs.bpm, payloadTsId, 0)
        rs.state == "idle" && event == "setTimeSignature" ->
            RunState("idle", rs.bpm, payloadTsId, rs.beatIndex)
        else -> rs.copy()
    }

    /** 冷启动拍号恢复：无效/缺失 tsId 回退字典序首个（§2.5 初始 idle 载入持久化）。 */
    fun restoreTsId(saved: String?): String =
        saved?.takeIf { s -> TimeSignatures.ALL.any { it.id == s } }
            ?: TimeSignatures.ALL.first().id
}
