package io.eazo.a038a10a.platform

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File

/**
 * REQ-022 音频触发层（契约 §2.4）：只触发、不承载确定性。
 *
 * 强拍 1000Hz 方波短音（~30ms）/ 弱拍 800Hz（~30ms），运行时预生成 PCM WAV
 * 临时文件交 SoundPool 低延迟回放（§9 选型锁定 SoundPool，禁流媒体路径）。
 * 初始化失败/无声卡：降级 no-op——可视化-only 继续，禁崩溃禁阻塞节拍循环。
 */
object AudioTick {

    private const val SAMPLE_RATE = 44100
    private const val DURATION_MS = 30
    private const val ACCENT_HZ = 1000
    private const val WEAK_HZ = 800

    @Volatile
    private var pool: SoundPool? = null
    private var accentId = 0
    private var weakId = 0

    /** 幂等初始化；任何异常吞掉降级 no-op。 */
    fun ensure(context: Context) {
        if (pool != null) return
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val p = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(attrs).build()
            val dir = context.cacheDir
            accentId = p.load(writeWav(File(dir, "metronome_accent.wav"), ACCENT_HZ), 1)
            weakId = p.load(writeWav(File(dir, "metronome_weak.wav"), WEAK_HZ), 1)
            pool = p
        } catch (_: Throwable) {
            pool = null
        }
    }

    /** 触发一次节拍短音；未就绪/失败静默。 */
    fun play(accent: Boolean) {
        val p = pool ?: return
        val id = if (accent) accentId else weakId
        if (id <= 0) return
        try {
            p.play(id, 1f, 1f, 1, 0, 1f)
        } catch (_: Throwable) {
            // no-op 降级
        }
    }

    /** 生成 16bit mono PCM 方波 WAV，返回路径。 */
    private fun writeWav(out: File, hz: Int): String {
        val n = SAMPLE_RATE * DURATION_MS / 1000
        val pcm = ByteArray(n * 2)
        for (i in 0 until n) {
            // 方波 + 首 2ms 线性衰减包络，避免爆音
            val s = if (Math.sin(2.0 * Math.PI * hz * i / SAMPLE_RATE) >= 0) 1.0 else -1.0
            val env = if (i < SAMPLE_RATE / 500) i.toDouble() / (SAMPLE_RATE / 500) else 1.0
            val v = (s * env * Short.MAX_VALUE).toInt()
            pcm[i * 2] = (v and 0xFF).toByte()
            pcm[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
        }
        val header = ByteArray(44)
        header[0] = 'R'.code.toByte(); header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte(); header[3] = 'F'.code.toByte()
        writeInt(header, 4, 36 + pcm.size)
        header[8] = 'W'.code.toByte(); header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte(); header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte(); header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte(); header[15] = ' '.code.toByte()
        writeInt(header, 16, 16)
        writeShort(header, 20, 1)
        writeShort(header, 22, 1)
        writeInt(header, 24, SAMPLE_RATE)
        writeInt(header, 28, SAMPLE_RATE * 2)
        writeShort(header, 32, 2)
        writeShort(header, 34, 16)
        header[36] = 'd'.code.toByte(); header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte(); header[39] = 'a'.code.toByte()
        writeInt(header, 40, pcm.size)
        out.writeBytes(header + pcm)
        return out.absolutePath
    }

    private fun writeInt(b: ByteArray, at: Int, v: Int) {
        b[at] = (v and 0xFF).toByte()
        b[at + 1] = ((v shr 8) and 0xFF).toByte()
        b[at + 2] = ((v shr 16) and 0xFF).toByte()
        b[at + 3] = ((v shr 24) and 0xFF).toByte()
    }

    private fun writeShort(b: ByteArray, at: Int, v: Int) {
        b[at] = (v and 0xFF).toByte()
        b[at + 1] = ((v shr 8) and 0xFF).toByte()
    }
}
