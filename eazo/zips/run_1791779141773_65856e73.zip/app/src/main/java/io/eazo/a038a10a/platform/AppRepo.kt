package io.eazo.a038a10a.platform

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import io.eazo.a038a10a.core.MetronomeCore
import io.eazo.a038a10a.data.TimeSignatures

/**
 * REQ-022 运行层（契约 §2.5/§3）：进程内单例仓储（硬规则 ①——UI 层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * 职责：节拍器状态机（start/stop/setBpm/setTimeSignature + 重基准重启）、
 * 会话定时调度（Handler 按 intervalMs 逐拍推进）、BPM/拍号持久化
 * （SharedPreferences last_bpm/last_ts）。系统时钟仅用于节拍定时抖动容差
 * 内的调度节拍（对账锚点全在纯函数层，§3 调度容差注记）。
 */
object AppRepo {

    private const val PREFS = "metronome"
    const val KEY_LAST_BPM = "last_bpm"
    const val KEY_LAST_TS = "last_ts"

    /** UI 快照（数据态）：state/bpm/tsId/beatCount（0-based 总拍计数）。 */
    data class Snapshot(
        val state: String,
        val bpm: Int,
        val tsId: String,
        val beatCount: Int,
    )

    private var prefs: SharedPreferences? = null
    private val handler = Handler(Looper.getMainLooper())

    private var state = "idle"
    private var bpm = 120
    private var tsId = "TS3"
    private var beatCount = 0

    /** UI 注册的快照回调（主线程）。 */
    var onSnapshot: ((Snapshot) -> Unit)? = null

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。冷启动恢复一次持久化。 */
    fun getRepo(context: Context): AppRepo {
        synchronized(this) {
            if (prefs == null) {
                prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                bpm = MetronomeCore.clampBpm(prefs?.getInt(KEY_LAST_BPM, 120) ?: 120)
                tsId = MetronomeCore.restoreTsId(prefs?.getString(KEY_LAST_TS, null))
                state = "idle"
                beatCount = 0
                AudioTick.ensure(context.applicationContext)
            }
        }
        return this
    }

    /** 硬规则 ②：refresh 只重读内存态，禁止从持久化 load()。 */
    fun refresh() {
        notifySnapshot()
    }

    fun snapshot(): Snapshot = Snapshot(state, bpm, tsId, beatCount)

    fun beatsPerBar(): Int =
        (TimeSignatures.ALL.firstOrNull { it.id == tsId } ?: TimeSignatures.ALL.first()).beatsPerBar

    fun isRunning(): Boolean = state == "running"

    // ===== 状态机（契约 §2.5：转移语义全部经 MetronomeCore.next 纯函数）=====

    /** (idle, start) -> running；t0 起拍（beat 0 恒重音）立即触发。 */
    fun start() {
        applyNext(MetronomeCore.next(mkRunState(), "start"), restartBeat = true)
    }

    /** (running, stop) -> idle；beatIndex 归零、elapsed 冻结清零。 */
    fun stop() {
        if (state != "running") return
        handler.removeCallbacks(tick)
        state = "idle"
        beatCount = 0
        notifySnapshot()
    }

    /** setBpm：idle 持久化；running 重基准（原子 stop+start，beat 归零、下一拍恒重音）。 */
    fun setBpm(v: Int) {
        val before = mkRunState()
        val after = MetronomeCore.next(before, "setBpm", payloadBpm = v)
        applyNext(after, restartBeat = before.state == "running")
    }

    /** setTimeSignature：idle 持久化；running 重基准重启。 */
    fun setTimeSignature(newTsId: String) {
        val valid = TimeSignatures.ALL.any { it.id == newTsId }
        if (!valid) return
        val before = mkRunState()
        val after = MetronomeCore.next(before, "setTimeSignature", payloadTsId = newTsId)
        applyNext(after, restartBeat = before.state == "running")
    }

    private fun mkRunState() = MetronomeCore.RunState(state, bpm, tsId, beatCount)

    /** 应用纯转移结果；restartBeat=真时按重基准语义重启拍循环。 */
    private fun applyNext(after: MetronomeCore.RunState, restartBeat: Boolean) {
        if (restartBeat) handler.removeCallbacks(tick)
        state = after.state
        bpm = after.bpm
        tsId = after.tsId
        beatCount = after.beatIndex
        if (state == "running") {
            if (restartBeat) {
                fireBeat()
                scheduleNext()
            }
        } else {
            // idle 落点（§2.5：idle 改 BPM/拍号 → 持久化）
            persist()
        }
        notifySnapshot()
    }

    /** 逐拍调度：按 intervalMs 推进计数 + 触发短音（运行层定时，±数 ms 属调度噪声）。 */
    private val tick = object : Runnable {
        override fun run() {
            if (state != "running") return
            fireBeat()
            notifySnapshot()
            scheduleNext()
        }
    }

    /** 排下一次拍（间隔 = 纯函数 intervalMs）。 */
    private fun scheduleNext() {
        handler.postDelayed(tick, MetronomeCore.intervalMs(bpm).toLong())
    }

    /** 单拍触发：计数 +1 推进，发声按 0-based 重音模式（beat 0 恒重音）。 */
    private fun fireBeat() {
        AudioTick.play(MetronomeCore.isAccent(beatCount, beatsPerBar()))
        beatCount += 1
    }

    private fun persist() {
        prefs?.edit()
            ?.putInt(KEY_LAST_BPM, bpm)
            ?.putString(KEY_LAST_TS, tsId)
            ?.apply()
    }

    private fun notifySnapshot() {
        onSnapshot?.invoke(snapshot())
    }
}
