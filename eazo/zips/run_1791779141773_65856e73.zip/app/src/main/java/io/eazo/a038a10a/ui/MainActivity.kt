package io.eazo.a038a10a.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import io.eazo.a038a10a.platform.AppRepo

/**
 * REQ-022 主界面：单 Activity + Jetpack Compose（UI 锁死声明式——与鸿蒙 ArkUI
 * 声明式对称）。Screen 已替换为 MetronomeScreen（保留 AppTheme 包裹）。
 * 硬规则 ②：onResume 只 refresh()（重读内存态），禁止从持久化 load()。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = AppRepo.getRepo(this)
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MetronomeScreen(repo)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        AppRepo.getRepo(this).refresh()
    }
}

/** 骨架默认主题（浅色）。会话按需求在此改配色，不另建 XML 主题。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(content = content)
}
