package io.eazo.a038a10a.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.a038a10a.data.TimeSignatures
import io.eazo.a038a10a.platform.AppRepo

/** 主题色（展示态，§1.4 排除项）。 */
private val Bg = Color(0xFF0E1420)
private val Card = Color(0xFF161F31)
private val Accent = Color(0xFF4F8CFF)
private val AccentSoft = Color(0x334F8CFF)
private val BeatOn = Color(0xFF4F8CFF)
private val BeatOff = Color(0xFF2A3650)
private val TextDim = Color(0xFF8A97B0)

/**
 * REQ-022 节拍器单页（§3 三区：BPM 控件 + 拍号选择 + 节拍圆点可视化 + 信息仪表）。
 * 600dp 断点多端自适应：窄屏单列 / 宽屏双列（AC-S9.1，可降级）。
 */
@Composable
fun MetronomeScreen(repo: AppRepo) {
    var snap by remember { mutableStateOf(repo.snapshot()) }
    DisposableEffect(repo) {
        repo.onSnapshot = { snap = it }
        onDispose { repo.onSnapshot = null }
    }

    val ts = TimeSignatures.ALL.first { it.id == snap.tsId }
    val bpb = ts.beatsPerBar
    val currentBeat = if (snap.beatCount > 0) (snap.beatCount - 1) % bpb else 0

    Surface(color = Bg, modifier = Modifier.fillMaxSize()) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize().padding(20.dp)) {
            if (maxWidth >= 600.dp) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    Column(
                        modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) { BpmCard(snap.bpm, repo); TsCard(snap.tsId, repo) }
                    Column(
                        modifier = Modifier.weight(1f).fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) { BeatCard(bpb, currentBeat); InfoCard(snap, ts.name); StartButton(snap.state, repo) }
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    BeatCard(bpb, currentBeat)
                    BpmCard(snap.bpm, repo)
                    TsCard(snap.tsId, repo)
                    InfoCard(snap, ts.name)
                    StartButton(snap.state, repo)
                }
            }
        }
    }
}

/** BPM 调节卡：大数字 + ±按钮 + 滑杆（40~240）。 */
@Composable
private fun BpmCard(bpm: Int, repo: AppRepo) {
    Column(
        modifier = cardModifier().padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("BPM", color = TextDim, fontSize = 13.sp, letterSpacing = 3.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton("−") { repo.setBpm(bpm - 1) }
            Text(
                "$bpm",
                color = Color.White,
                fontSize = 56.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 22.dp),
            )
            RoundIconButton("＋") { repo.setBpm(bpm + 1) }
        }
        Slider(
            value = bpm.toFloat(),
            onValueChange = { repo.setBpm(it.toInt()) },
            valueRange = 40f..240f,
            steps = 199,
            colors = SliderDefaults.colors(
                thumbColor = Accent,
                activeTrackColor = Accent,
                inactiveTrackColor = BeatOff,
            ),
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("40", color = TextDim, fontSize = 12.sp)
            Text("240", color = TextDim, fontSize = 12.sp)
        }
    }
}

/** 拍号三选一卡：2/4 · 3/4 · 4/4 chips。 */
@Composable
private fun TsCard(tsId: String, repo: AppRepo) {
    Column(
        modifier = cardModifier().padding(vertical = 18.dp, horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("拍号", color = TextDim, fontSize = 13.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TimeSignatures.ALL.forEach { item ->
                FilterChip(
                    selected = item.id == tsId,
                    onClick = { repo.setTimeSignature(item.id) },
                    label = { Text(item.name, fontSize = 16.sp, fontWeight = FontWeight.Medium) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = BeatOff,
                        labelColor = TextDim,
                        selectedContainerColor = AccentSoft,
                        selectedLabelColor = Accent,
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = BeatOff,
                        selectedBorderColor = Accent,
                        enabled = true,
                        selected = item.id == tsId,
                    ),
                )
            }
        }
    }
}

/** 节拍圆点可视化：当前拍高亮放大，重音拍描边强调。 */
@Composable
private fun BeatCard(bpb: Int, currentBeat: Int) {
    Column(
        modifier = cardModifier().padding(26.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("节拍", color = TextDim, fontSize = 13.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            repeat(bpb) { i ->
                val on = i == currentBeat
                val scale by animateFloatAsState(
                    targetValue = if (on) 1.25f else 1f,
                    animationSpec = tween(90),
                    label = "beat$i",
                )
                val accentBeat = i == 0
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .scale(scale)
                        .background(if (on) BeatOn else BeatOff, CircleShape)
                        .border(
                            width = if (accentBeat) 2.dp else 0.dp,
                            color = if (accentBeat) TextDim else Color.Transparent,
                            shape = CircleShape,
                        ),
                )
            }
        }
    }
}

/** 信息仪表：当前 BPM / 拍号 / 节拍计数（AC-S7.1）。 */
@Composable
private fun InfoCard(snap: AppRepo.Snapshot, tsName: String) {
    Row(
        modifier = cardModifier().padding(horizontal = 28.dp, vertical = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(30.dp),
    ) {
        Metric("BPM", "${snap.bpm}")
        Metric("拍号", tsName)
        Metric("计数", "${snap.beatCount}")
    }
}

@Composable
private fun Metric(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextDim, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** 开始/停止主按钮。 */
@Composable
private fun StartButton(state: String, repo: AppRepo) {
    val running = state == "running"
    Button(
        onClick = { if (running) repo.stop() else repo.start() },
        colors = ButtonDefaults.buttonColors(
            containerColor = if (running) Color(0xFFE2574C) else Accent,
        ),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().height(58.dp),
    ) {
        Text(if (running) "■ 停止" else "▶ 开始", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun RoundIconButton(label: String, onClick: () -> Unit) {
    androidx.compose.material3.IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(44.dp)
            .background(BeatOff, CircleShape)
            .border(1.dp, Color(0xFF3A4A6A), CircleShape),
    ) {
        Text(label, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

private fun cardModifier(): Modifier = Modifier
    .fillMaxWidth()
    .background(Card, RoundedCornerShape(24.dp))
    .border(1.dp, Color(0xFF232F48), RoundedCornerShape(24.dp))
