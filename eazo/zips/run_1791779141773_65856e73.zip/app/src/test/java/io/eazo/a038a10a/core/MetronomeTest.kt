package io.eazo.a038a10a.core

import io.eazo.a038a10a.platform.AppRepo
import io.eazo.a038a10a.data.TimeSignature
import io.eazo.a038a10a.data.TimeSignatures
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.security.MessageDigest

/** REQ-022 契约用例（version eazo-cases-1.0.0，slug 逐字等于冻结清单 14 条；锚点=契约 §6 全集）。 */
class MetronomeTest {

    // ===== C01 bpm_adjust_range：BPM 调节 40~240 整数，越界收敛 =====
    @Test
    fun `bpm_adjust_range`() {
        // §6.5 域收敛 4 锚点
        assertEquals(40, MetronomeCore.clampBpm(39))
        assertEquals(40, MetronomeCore.clampBpm(40))
        assertEquals(240, MetronomeCore.clampBpm(240))
        assertEquals(240, MetronomeCore.clampBpm(241))
        // 域内原样返回 + 全域整数
        for (b in 40..240) {
            assertEquals(b, MetronomeCore.clampBpm(b))
        }
    }

    // ===== C02 time_signature_select：拍号三选一 =====
    @Test
    fun `time_signature_select`() {
        assertEquals(3, TimeSignatures.ALL.size)
        assertEquals(listOf("TS1", "TS2", "TS3"), TimeSignatures.IDS)
        val expected = listOf(
            TimeSignature("TS1", "2/4", 2),
            TimeSignature("TS2", "3/4", 3),
            TimeSignature("TS3", "4/4", 4),
        )
        assertEquals(expected, TimeSignatures.ALL)
        // name ↔ beats_per_bar 自洽（V5 抓获面）
        TimeSignatures.ALL.forEach {
            assertEquals(it.name, "${it.beatsPerBar}/4")
        }
    }

    // ===== C03 start_stop_toggle：开始/停止，停止后计数归零 =====
    @Test
    fun `start_stop_toggle`() {
        var rs = MetronomeCore.RunState("idle", 120, "TS3", 0)
        // start -> running，beat 0
        rs = MetronomeCore.next(rs, "start")
        assertEquals("running", rs.state)
        assertEquals(0, rs.beatIndex)
        // stop -> idle，计数归零
        rs = MetronomeCore.next(rs, "stop")
        assertEquals("idle", rs.state)
        assertEquals(0, rs.beatIndex)
        // 再次 start 从 0 重开
        rs = MetronomeCore.next(rs, "start")
        assertEquals("running", rs.state)
        assertEquals(0, rs.beatIndex)
    }

    // ===== C04 interval_ms_deterministic：10 条锚点 =====
    @Test
    fun `interval_ms_deterministic`() {
        val anchors = mapOf(
            40 to 1500, 60 to 1000, 90 to 667, 100 to 600, 120 to 500,
            133 to 451, 160 to 375, 192 to 313, 200 to 300, 240 to 250,
        )
        anchors.forEach { (bpm, expected) ->
            assertEquals("intervalMs($bpm)", expected, MetronomeCore.intervalMs(bpm))
        }
        // 同输入多次重算全等（确定性）
        assertEquals(MetronomeCore.intervalMs(120), MetronomeCore.intervalMs(120))
        assertEquals(MetronomeCore.intervalMs(192), MetronomeCore.intervalMs(192))
    }

    // ===== C05 interval_ms_round_half_up：三判别点 =====
    @Test
    fun `interval_ms_round_half_up`() {
        assertEquals(313, MetronomeCore.intervalMs(192)) // half-even 312 分叉点
        assertEquals(667, MetronomeCore.intervalMs(90))  // 浮点 floor 666 分叉点
        assertEquals(451, MetronomeCore.intervalMs(133)) // 451.127… 非整除
    }

    // ===== C06 accent_first_beat：每小节第 1 拍重音（0-based，3 模式）=====
    @Test
    fun `accent_first_beat`() {
        val patterns = mapOf(2 to "1010", 3 to "100100", 4 to "10001000")
        patterns.forEach { (bpb, pattern) ->
            val actual = (0 until pattern.length).joinToString("") {
                if (MetronomeCore.isAccent(it, bpb)) "1" else "0"
            }
            assertEquals("bpb=$bpb", pattern, actual)
        }
        // beat 0 恒重音（V3 判别）
        assertTrue(MetronomeCore.isAccent(0, 4))
        assertFalse(MetronomeCore.isAccent(1, 4))
    }

    // ===== C07 beat_count_progression：9 条锚点（floor）=====
    @Test
    fun `beat_count_progression`() {
        assertEquals(0, MetronomeCore.beatCountAt(0, 120))
        assertEquals(0, MetronomeCore.beatCountAt(499, 120))
        assertEquals(1, MetronomeCore.beatCountAt(500, 120))
        assertEquals(2, MetronomeCore.beatCountAt(1000, 120))
        assertEquals(120, MetronomeCore.beatCountAt(60000, 120))
        assertEquals(60, MetronomeCore.beatCountAt(60000, 60))
        assertEquals(240, MetronomeCore.beatCountAt(60000, 240))
        assertEquals(1, MetronomeCore.beatCountAt(999, 100))
        assertEquals(50, MetronomeCore.beatCountAt(30000, 100))
        // 区间性质 c·iv ≤ el < (c+1)·iv（§2.3 注 2）
        listOf(120, 90, 133).forEach { bpm ->
            val iv = MetronomeCore.intervalMs(bpm)
            for (c in 0 until 50) {
                val el = c * iv + iv / 2
                assertEquals(c, MetronomeCore.beatCountAt(el, bpm))
            }
        }
    }

    // ===== C08 current_beat_highlight：当前拍推导（周期）=====
    @Test
    fun `current_beat_highlight`() {
        // §6.4 周期锚点：bpm=120、bpb=4、前 16 拍 0123×4
        val iv = MetronomeCore.intervalMs(120)
        val seq = (0 until 16).map { MetronomeCore.currentBeatIndex(it * iv, 120, 4) }
        assertEquals(listOf(0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3), seq)
        // §8 直断言：3 拍后当前拍 = 3
        assertEquals(3, MetronomeCore.currentBeatIndex(1500, 120, 4))
        // 与重音对齐（D5）：currentBeatIndex==0 ⇔ isAccent
        (0 until 24).forEach { n ->
            val cb = MetronomeCore.currentBeatIndex(n * iv, 120, 4)
            assertEquals(MetronomeCore.isAccent(n, 4), cb == 0)
        }
    }

    // ===== C09 display_bpm_signature_count：信息区数据态（bpm/拍号/计数）=====
    @Test
    fun `display_bpm_signature_count`() {
        val rs = MetronomeCore.RunState("running", 120, "TS3", 7)
        // 信息区三元组数据态：BPM / 拍号 name / 计数
        assertEquals(120, rs.bpm)
        assertEquals("4/4", TimeSignatures.ALL.first { it.id == rs.tsId }.name)
        assertEquals(7, rs.beatIndex)
        // 当前拍展示值 = beatIndex % bpb
        assertEquals(3, rs.beatIndex % 4)
        // 展示数据源字段完备（反射）
        val fields = MetronomeCore.RunState::class.java.declaredFields.map { it.name }
        assertTrue(fields.containsAll(listOf("state", "bpm", "tsId", "beatIndex")))
    }

    // ===== C10 time_signature_serialization_hash：SHA-256 29B =====
    @Test
    fun `time_signature_serialization_hash`() {
        val lines = TimeSignatures.ALL
            .sortedBy { it.id }
            .joinToString("\n") { "${it.id}|${it.name}|${it.beatsPerBar}" }
        val bytes = lines.toByteArray(Charsets.UTF_8)
        assertEquals(29, bytes.size)
        assertEquals(TimeSignatures.TS_BYTES, bytes.size)
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        val hex = digest.joinToString("") { "%02x".format(it) }
        assertEquals(TimeSignatures.TS_SHA256, hex)
        assertEquals("4575625db61285cdb81183eeaaf395c7089014d23a52a56fecea98556a4f064c", hex)
    }

    // ===== C11 beat_loop_continuous：循环推进（单调 + 重音周期 + stop 归零）=====
    @Test
    fun `beat_loop_continuous`() {
        val bpm = 120
        val iv = MetronomeCore.intervalMs(bpm)
        // 计数按 interval 单调推进
        var prev = -1
        for (n in 0 until 12) {
            val c = MetronomeCore.beatCountAt(n * iv, bpm)
            assertTrue(c > prev)
            prev = c
        }
        // 重音周期正确：每 bpb 拍一次
        for (n in 0 until 12) {
            assertEquals(n % 4 == 0, MetronomeCore.isAccent(n, 4))
        }
        // stop 归零（状态机）
        var rs = MetronomeCore.next(MetronomeCore.RunState("running", bpm, "TS3", 11), "stop")
        assertEquals("idle", rs.state)
        assertEquals(0, rs.beatIndex)
        // 重基准：running 中 setBpm → 仍 running、beat 0、下一拍重音（§6.6）
        rs = MetronomeCore.next(rs, "start")
        rs = MetronomeCore.next(rs, "setBpm", payloadBpm = 180)
        assertEquals("running", rs.state)
        assertEquals(180, rs.bpm)
        assertEquals(0, rs.beatIndex)
        assertTrue(MetronomeCore.isAccent(0, 4))
    }

    // ===== C12 no_random_source：core 无随机/时间源（D7 静态检查）=====
    @Test
    fun `no_random_source`() {
        val banned = listOf(
            "Math.random", "kotlin.random", "Random(", "Date(",
            "System.currentTimeMillis", "SystemClock", "System.nanoTime",
        )
        listOf(
            "src/main/java/io/eazo/a038a10a/core/MetronomeCore.kt",
            "src/main/java/io/eazo/a038a10a/data/TimeSignatures.kt",
        ).forEach { path ->
            val src = File(path).readText(Charsets.UTF_8)
            banned.forEach { tok ->
                assertFalse("$path 含禁用 token: $tok", src.contains(tok))
            }
        }
        // core 无 android 框架依赖（纯函数可脱离 UI 单测）
        val coreSrc = File("src/main/java/io/eazo/a038a10a/core/MetronomeCore.kt").readText(Charsets.UTF_8)
        assertFalse(coreSrc.contains("import android."))
    }

    // ===== C13 local_state_persist：本地状态持久化语义 =====
    @Test
    fun `local_state_persist`() {
        // 持久化键字面量（last_bpm / last_ts，§6.6）
        assertEquals("last_bpm", AppRepo.KEY_LAST_BPM)
        assertEquals("last_ts", AppRepo.KEY_LAST_TS)
        // 冷启动恢复：BPM clamp 收敛
        assertEquals(40, MetronomeCore.clampBpm(37))
        assertEquals(240, MetronomeCore.clampBpm(300))
        assertEquals(176, MetronomeCore.clampBpm(176))
        // tsId 恢复：有效值原样、无效/缺失回退字典序首个
        assertEquals("TS2", MetronomeCore.restoreTsId("TS2"))
        assertEquals("TS1", MetronomeCore.restoreTsId(null))
        assertEquals("TS1", MetronomeCore.restoreTsId("TS9"))
    }

    // ===== C14 multiscreen_adaptive：多端自适应（600dp 断点，Should 可降级）=====
    @Test
    fun `multiscreen_adaptive`() {
        val src = File("src/main/java/io/eazo/a038a10a/ui/MetronomeScreen.kt").readText(Charsets.UTF_8)
        // 断点 600dp + 单列/双列分支结构存在性（渲染产物展示态，截图评审归 uijudge）
        assertTrue(src.contains("600.dp"))
        assertTrue(src.contains("BoxWithConstraints"))
        assertTrue(src.contains("maxWidth >= 600.dp"))
    }
}
