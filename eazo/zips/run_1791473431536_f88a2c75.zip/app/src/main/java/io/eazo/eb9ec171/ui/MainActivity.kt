package io.eazo.eb9ec171.ui

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.eb9ec171.core.Phase
import io.eazo.eb9ec171.core.PomodoroCore
import io.eazo.eb9ec171.core.PomodoroSpec
import io.eazo.eb9ec171.core.TimerState
import io.eazo.eb9ec171.platform.AppRepo
import kotlinx.coroutines.delay

/**
 * 番茄钟主界面：单 Activity + Jetpack Compose（UI 锁死声明式——与鸿蒙 ArkUI
 * 声明式对称，禁止 XML 布局/drawable 扇出；图标用 material-icons，主题用
 * Compose MaterialTheme）。
 *
 * 硬规则 ①：仓储经 AppRepo.getRepo(this).focus() 单例获取；
 * 硬规则 ②：onResume 只 refresh()（重读内存态），禁止从持久化 load()。
 */
class MainActivity : ComponentActivity() {

    private lateinit var holder: PomodoroHolder

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        holder = PomodoroHolder(AppRepo.getRepo(this).focus())
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Screen(holder)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(this).refresh()
        if (::holder.isInitialized) holder.refreshFromMemory()
    }
}

/** 深色主题（需求：深色 + 柔和渐变环）；会话按需求在此改配色，不另建 XML 主题。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = FocusAccent,
            onPrimary = Color(0xFF2B1210),
            secondary = BreakAccent,
            onSecondary = Color(0xFF0D2620),
            background = Color(0xFF101116),
            onBackground = Color(0xFFF2F1F6),
            surface = Color(0xFF171921),
            onSurface = Color(0xFFF2F1F6),
            surfaceVariant = Color(0xFF1F222C),
            onSurfaceVariant = Color(0xFFB9BCC9),
            outline = Color(0xFF3A3E4C),
        ),
        content = content,
    )
}

// —— 配色口径（专注暖珊瑚 / 休息薄荷青，sweep 首尾同色保证环无缝） ——

private val FocusAccent = Color(0xFFFF7E6E)
private val BreakAccent = Color(0xFF5ECFA8)
private val FocusRingColors = listOf(Color(0xFFFFB199), Color(0xFFFF6B7E), Color(0xFFFFC46B), Color(0xFFFFB199))
private val BreakRingColors = listOf(Color(0xFF7CE8C9), Color(0xFF54A8FF), Color(0xFF8FF0C9), Color(0xFF7CE8C9))
private val RingTrack = Color(0xFF262A36)
private val ClockColor = Color(0xFFF4F3F8)

/** 首屏：多端自适应（≥600dp 宽双栏：左计时右面板；窄屏单栏纵向滚动）。 */
@Composable
private fun Screen(holder: PomodoroHolder) {
    val model = holder.model

    // 每拍对拍：250ms（deadline 换算，无累积漂移）
    LaunchedEffect(Unit) {
        while (true) {
            holder.sync()
            delay(250)
        }
    }

    // 完成一轮触觉反馈（仅增量触发，避免启动即震）
    val haptic = LocalHapticFeedback.current
    var lastRounds by remember { mutableStateOf(holder.todayStats.rounds) }
    LaunchedEffect(holder.todayStats.rounds) {
        if (holder.todayStats.rounds > lastRounds) {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
        lastRounds = holder.todayStats.rounds
    }

    // 运行中保持屏幕常亮（窗口 flag，免权限）
    val window = (LocalContext.current as? Activity)?.window
    LaunchedEffect(model.state) {
        if (model.state == TimerState.RUNNING) {
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding(),
    ) {
        val availWidth = maxWidth
        val availHeight = maxHeight
        if (availWidth >= 600.dp) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 40.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(48.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(24.dp),
                ) {
                    TopBar(holder)
                    TimerSection(holder, ringSize = maxOf(minOf(availHeight - 240.dp, 330.dp), 220.dp))
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    StatsCard(holder)
                    SettingsCard(holder)
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Spacer(Modifier.height(4.dp))
                TopBar(holder)
                Spacer(Modifier.height(2.dp))
                TimerSection(holder, ringSize = maxOf(minOf(availWidth - 64.dp, 320.dp), 220.dp))
                StatsCard(holder)
                SettingsCard(holder)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun TopBar(holder: PomodoroHolder) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = "🍅 番茄钟",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.weight(1f),
        )
        Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceVariant) {
            Text(
                text = "今日 ${holder.todayStats.rounds} 轮 · ${PomodoroCore.formatDurationCn(holder.todayStats.focusSec)}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
    }
}

@Composable
private fun TimerSection(holder: PomodoroHolder, ringSize: Dp) {
    val model = holder.model
    val focusMode = model.phase == Phase.FOCUS
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        PhaseChip(model.phase)
        ProgressRing(
            progress = holder.progress(),
            focusMode = focusMode,
            sizeDp = ringSize,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = PomodoroCore.formatClock(holder.remainingSec),
                    style = TextStyle(
                        fontSize = (ringSize.value * 0.215f).sp,
                        fontWeight = FontWeight.Medium,
                        fontFeatureSettings = "tnum",
                        color = ClockColor,
                    ),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = statusText(model),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Controls(holder)
    }
}

private fun statusText(model: io.eazo.eb9ec171.core.TimerModel): String = when {
    model.state == TimerState.RUNNING && model.phase == Phase.FOCUS -> "专注中"
    model.state == TimerState.RUNNING -> "休息中"
    model.state == TimerState.PAUSED -> "已暂停"
    model.phase == Phase.FOCUS -> "准备专注"
    else -> "准备休息"
}

@Composable
private fun PhaseChip(phase: Phase) {
    val focus = phase == Phase.FOCUS
    val color = if (focus) FocusAccent else BreakAccent
    Surface(
        shape = RoundedCornerShape(50),
        color = Color.Transparent,
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(8.dp).background(color, CircleShape))
            Spacer(Modifier.width(8.dp))
            Text(
                text = if (focus) "专注时间" else "休息时间",
                style = MaterialTheme.typography.labelLarge,
                color = color,
            )
        }
    }
}

/** 圆形进度环：柔和 sweep 渐变、12 点方向起、随时间耗尽；内嵌倒计时大字。 */
@Composable
private fun ProgressRing(
    progress: Float,
    focusMode: Boolean,
    sizeDp: Dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val colors = if (focusMode) FocusRingColors else BreakRingColors
    val glow = colors[1].copy(alpha = 0.16f)
    val track = RingTrack
    val animated by animateFloatAsState(progress, tween(280, easing = LinearEasing), label = "ringProgress")
    Box(modifier = Modifier.size(sizeDp)) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeW = this.size.minDimension * 0.052f
            val stroke = Stroke(width = strokeW, cap = StrokeCap.Round)
            val inset = strokeW / 2f + 4.dp.toPx()
            val arcSize = Size(this.size.width - inset * 2f, this.size.height - inset * 2f)
            val topLeft = Offset(inset, inset)
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val radius = this.size.minDimension / 2f
            // 柔和径向底光
            drawCircle(
                brush = Brush.radialGradient(listOf(glow, Color.Transparent), center = center, radius = radius),
                radius = radius,
                center = center,
            )
            // 轨道
            drawArc(color = track, startAngle = 0f, sweepAngle = 360f, useCenter = false, topLeft = topLeft, size = arcSize, style = stroke)
            // 渐变进度环（旋转 -90° 使渐变起点与弧线起点同在 12 点方向）
            val sweep = 360f * animated.coerceIn(0f, 1f)
            if (sweep > 0.5f) {
                rotate(degrees = -90f, pivot = center) {
                    drawArc(
                        brush = Brush.sweepGradient(colors, center),
                        startAngle = 0f,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = stroke,
                    )
                }
            }
        }
        content()
    }
}

/** 三个主按钮：开始/继续（主）、暂停、重置。 */
@Composable
private fun Controls(holder: PomodoroHolder) {
    val model = holder.model
    val running = model.state == TimerState.RUNNING
    val accent = if (model.phase == Phase.FOCUS) FocusAccent else BreakAccent
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Button(
            onClick = holder::start,
            enabled = !running,
            modifier = Modifier
                .weight(1.25f)
                .height(56.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color(0xFF20100F)),
        ) {
            Text(
                text = if (model.state == TimerState.PAUSED) "继续" else "开始",
                style = MaterialTheme.typography.titleMedium,
            )
        }
        OutlinedButton(
            onClick = holder::pause,
            enabled = running,
            modifier = Modifier
                .weight(1f)
                .height(56.dp),
            shape = RoundedCornerShape(18.dp),
        ) {
            Text(text = "暂停", style = MaterialTheme.typography.titleMedium)
        }
        OutlinedButton(
            onClick = holder::reset,
            modifier = Modifier
                .weight(1f)
                .height(56.dp),
            shape = RoundedCornerShape(18.dp),
        ) {
            Text(text = "重置", style = MaterialTheme.typography.titleMedium)
        }
    }
}

/** 今日统计：完成轮数 + 累计专注时长。 */
@Composable
private fun StatsCard(holder: PomodoroHolder) {
    val stats = holder.todayStats
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                text = "今日专注",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                StatItem(
                    value = "${stats.rounds}",
                    unit = "轮",
                    label = "已完成专注轮数",
                    modifier = Modifier.weight(1f),
                )
                Box(
                    Modifier
                        .width(1.dp)
                        .height(44.dp)
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                )
                StatItem(
                    value = PomodoroCore.formatDurationCn(stats.focusSec),
                    unit = "",
                    label = "累计专注时长",
                    modifier = Modifier.weight(1.4f),
                    center = true,
                )
            }
        }
    }
}

@Composable
private fun StatItem(value: String, unit: String, label: String, modifier: Modifier = Modifier, center: Boolean = false) {
    Column(
        modifier = modifier,
        horizontalAlignment = if (center) Alignment.CenterHorizontally else Alignment.Start,
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onBackground,
            )
            if (unit.isNotEmpty()) {
                Spacer(Modifier.width(4.dp))
                Text(
                    text = unit,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 4.dp),
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/** 自定义时长：专注 1..180 分钟、休息 1..60 分钟，步进 1 分钟；未开跑整轮即时生效。 */
@Composable
private fun SettingsCard(holder: PomodoroHolder) {
    val model = holder.model
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
    ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "自定义时长",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                if (model.state == TimerState.RUNNING) {
                    Text(
                        text = "下一轮生效",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            StepperRow(
                label = "专注时长",
                sec = model.focusSec,
                rangeSec = PomodoroSpec.MIN_FOCUS_SEC..PomodoroSpec.MAX_FOCUS_SEC,
                onChange = holder::changeFocusSec,
            )
            StepperRow(
                label = "休息时长",
                sec = model.breakSec,
                rangeSec = PomodoroSpec.MIN_BREAK_SEC..PomodoroSpec.MAX_BREAK_SEC,
                onChange = holder::changeBreakSec,
            )
        }
    }
}

@Composable
private fun StepperRow(label: String, sec: Int, rangeSec: IntRange, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
        )
        StepButton(symbol = "−", enabled = sec > rangeSec.first) { onChange(sec - 60) }
        Text(
            text = "${sec / 60} 分钟",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier
                .padding(horizontal = 12.dp)
                .width(84.dp),
        )
        StepButton(symbol = "+", enabled = sec < rangeSec.last) { onChange(sec + 60) }
    }
}

@Composable
private fun StepButton(symbol: String, enabled: Boolean, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.size(44.dp),
        shape = CircleShape,
        contentPadding = PaddingValues(0.dp),
    ) {
        Text(text = symbol, style = MaterialTheme.typography.titleLarge)
    }
}
