package io.eazo.eb9ec171.platform

import android.content.Context
import io.eazo.eb9ec171.core.FocusRepository
import io.eazo.eb9ec171.core.KeyValueStore

/**
 * 骨架模板平台层：AppRepo 进程内单例（生成器硬规则 ①——UI/卡片层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * 本需求挂接：番茄钟仓储 FocusRepository（内存态即真相 + SharedPreferences
 * 持久化），getRepo(context) 双检锁构造一次，进程内复用。
 */
object AppRepo {

    @Volatile
    private var focusRepo: FocusRepository? = null

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo {
        if (focusRepo == null) {
            synchronized(this) {
                if (focusRepo == null) {
                    focusRepo = FocusRepository(PrefsKeyValueStore(context.applicationContext))
                }
            }
        }
        return this
    }

    /** 番茄钟业务仓储（须先经 getRepo(context) 初始化）。 */
    fun focus(): FocusRepository = checkNotNull(focusRepo) { "AppRepo.getRepo(context) 尚未初始化" }

    /** 会话按需求扩展：内存态持有 + 持久化读写（读写分离，list() 只读内存态）。 */
    fun refresh() {
        // 硬规则 ②：refresh 只重读内存态，禁止从持久化 load()——
        // FocusRepository 内存即真相，UI 层经 list()/todayStats() 重读即可
    }
}

/** SharedPreferences 键值持久化（core.KeyValueStore 的平台实现）。 */
private class PrefsKeyValueStore(context: Context) : KeyValueStore {
    private val prefs = context.getSharedPreferences("pomodoro_store", Context.MODE_PRIVATE)

    override fun read(key: String): String? = prefs.getString(key, null)

    override fun write(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }
}
