package io.eazo.eb9ec171.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import io.eazo.eb9ec171.core.DayStats
import io.eazo.eb9ec171.core.FocusRepository
import io.eazo.eb9ec171.core.Phase
import io.eazo.eb9ec171.core.PomodoroCore
import io.eazo.eb9ec171.core.TimerModel

/**
 * 计时有状态壳：Compose 可观察（mutableStateOf），纯逻辑全部下沉 PomodoroCore，
 * 持久化全部经 FocusRepository（构造方经 AppRepo.getRepo(context).focus() 获取——
 * 硬规则 ①：UI 层禁止 new Repository）。
 *
 * tick 只对拍不清零：UI 每 250ms 调 sync()，剩余秒由 deadline 换算（无累积漂移，
 * 进程重建/后台返回后依旧正确）。
 */
class PomodoroHolder(private val repo: FocusRepository) {

    /** 恢复上次快照；过期 RUNNING 的完成在下一拍 sync 结算。 */
    var model: TimerModel by mutableStateOf(repo.restoreModel())
        private set

    var todayStats: DayStats by mutableStateOf(repo.todayStats())
        private set

    /** 显示用剩余秒（每拍刷新，驱动倒计时/进度环重组）。 */
    var remainingSec: Int by mutableStateOf(PomodoroCore.remainingAt(model, now()))
        private set

    fun start() {
        model = PomodoroCore.start(model, now())
        afterChange()
    }

    fun pause() {
        model = PomodoroCore.pause(model, now())
        afterChange()
    }

    fun reset() {
        model = PomodoroCore.reset(model)
        afterChange()
    }

    fun changeFocusSec(sec: Int) = changeSettings(sec, model.breakSec)

    fun changeBreakSec(sec: Int) = changeSettings(model.focusSec, sec)

    private fun changeSettings(focusSec: Int, breakSec: Int) {
        repo.updateSettings(focusSec, breakSec)
        model = PomodoroCore.applySettings(model, focusSec, breakSec)
        afterChange()
    }

    /**
     * 每拍对拍（UI 250ms 一拍）：唯一完成结算入口。
     * 完成专注轮 → 仓储记录一条（completedAtMs=结算时刻，durationSec=本轮 roundSec）。
     */
    fun sync() {
        val nowMs = now()
        val r = PomodoroCore.sync(model, nowMs)
        if (r.completedPhase != null) {
            if (r.completedPhase == Phase.FOCUS) {
                repo.addFocusRecord(r.completedRoundSec, nowMs)
            }
            model = r.model
            todayStats = repo.todayStats()
            repo.saveSnapshot(model)
        }
        remainingSec = PomodoroCore.remainingAt(model, nowMs)
    }

    /** 硬规则 ②：只重读内存态（记录/统计），不从持久化 load()。onResume 调此入口。 */
    fun refreshFromMemory() {
        todayStats = repo.todayStats()
    }

    /** 环形进度 0..1（随时间耗尽）。 */
    fun progress(): Float =
        if (model.roundSec <= 0) 0f else remainingSec.toFloat() / model.roundSec.toFloat()

    private fun afterChange() {
        repo.saveSnapshot(model)
        todayStats = repo.todayStats()
        remainingSec = PomodoroCore.remainingAt(model, now())
    }

    private fun now(): Long = System.currentTimeMillis()
}
