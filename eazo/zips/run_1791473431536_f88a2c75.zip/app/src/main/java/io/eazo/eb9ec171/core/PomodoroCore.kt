package io.eazo.eb9ec171.core

import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * 番茄钟纯核（契约层）：全部整数域运算，无 Android/Compose 依赖，JUnit 可测。
 *
 * 双端 1:1 契约（生成器硬规则 ③——字段名/枚举字面量/排序口径与鸿蒙端完全一致）：
 * - 枚举 Phase { FOCUS, BREAK } / TimerState { IDLE, RUNNING, PAUSED }
 * - 时长一律整秒存储；毫秒仅作运行期 deadline 换算（endAtMs），不落浮点
 * - 剩余秒口径 = ceil(剩余毫秒 / 1000)（满秒起显：25:00 保持 1 秒后跳 24:59）
 * - 进度 = 剩余秒 / 本轮秒（环形进度随时间耗尽）
 * - 完成一轮结算一次；completedAtMs = 结算时刻，durationSec = 本轮实际配置时长 roundSec
 */

/** 计时阶段（双端枚举字面量 1:1）。 */
enum class Phase { FOCUS, BREAK }

/** 计时状态（双端枚举字面量 1:1）。 */
enum class TimerState { IDLE, RUNNING, PAUSED }

/** 数值口径与边界（整数域，双端锁死）。 */
object PomodoroSpec {
    const val DEFAULT_FOCUS_SEC: Int = 25 * 60   // 1500：默认 25 分钟专注
    const val DEFAULT_BREAK_SEC: Int = 5 * 60    // 300：默认 5 分钟短休息
    const val MIN_FOCUS_SEC: Int = 1 * 60        // 自定义下限 1 分钟
    const val MAX_FOCUS_SEC: Int = 180 * 60      // 自定义上限 180 分钟
    const val MIN_BREAK_SEC: Int = 1 * 60
    const val MAX_BREAK_SEC: Int = 60 * 60

    fun clampFocus(sec: Int): Int = sec.coerceIn(MIN_FOCUS_SEC, MAX_FOCUS_SEC)

    fun clampBreak(sec: Int): Int = sec.coerceIn(MIN_BREAK_SEC, MAX_BREAK_SEC)
}

/** 计时态（快照持久化的唯一真身）。roundSec=本轮配置时长（入库口径）；remainingSec=IDLE/PAUSED 时的剩余秒。 */
data class TimerModel(
    val phase: Phase = Phase.FOCUS,
    val state: TimerState = TimerState.IDLE,
    val roundSec: Int = PomodoroSpec.DEFAULT_FOCUS_SEC,
    val remainingSec: Int = PomodoroSpec.DEFAULT_FOCUS_SEC,
    val focusSec: Int = PomodoroSpec.DEFAULT_FOCUS_SEC,
    val breakSec: Int = PomodoroSpec.DEFAULT_BREAK_SEC,
    val endAtMs: Long = 0L,
)

/** sync 对拍结果：completedPhase 非空表示该轮恰在本拍结算完成。 */
data class SyncResult(
    val model: TimerModel,
    val completedPhase: Phase?,
    val completedRoundSec: Int,
)

object PomodoroCore {

    fun initial(focusSec: Int, breakSec: Int): TimerModel {
        val f = PomodoroSpec.clampFocus(focusSec)
        val b = PomodoroSpec.clampBreak(breakSec)
        return TimerModel(
            phase = Phase.FOCUS,
            state = TimerState.IDLE,
            roundSec = f,
            remainingSec = f,
            focusSec = f,
            breakSec = b,
        )
    }

    fun phaseDuration(model: TimerModel, phase: Phase): Int =
        if (phase == Phase.FOCUS) model.focusSec else model.breakSec

    /** 开始/继续：IDLE|PAUSED → RUNNING，deadline = now + 剩余秒 * 1000。 */
    fun start(model: TimerModel, nowMs: Long): TimerModel {
        if (model.state == TimerState.RUNNING) return model
        val rem = if (model.remainingSec > 0) model.remainingSec else phaseDuration(model, model.phase)
        return model.copy(state = TimerState.RUNNING, remainingSec = rem, endAtMs = nowMs + rem * 1000L)
    }

    /** 暂停：RUNNING → PAUSED，按当前时刻冻结剩余秒（毫秒换算、整数域 ceil）。 */
    fun pause(model: TimerModel, nowMs: Long): TimerModel {
        if (model.state != TimerState.RUNNING) return model
        return model.copy(state = TimerState.PAUSED, remainingSec = remainingAt(model, nowMs), endAtMs = 0L)
    }

    /** 重置：当前阶段回到整轮 IDLE（不切阶段）。 */
    fun reset(model: TimerModel): TimerModel {
        val full = phaseDuration(model, model.phase)
        return model.copy(state = TimerState.IDLE, roundSec = full, remainingSec = full, endAtMs = 0L)
    }

    /** 剩余秒：RUNNING 按 deadline 换算（无累积漂移；进程被杀后重建仍正确）。 */
    fun remainingAt(model: TimerModel, nowMs: Long): Int {
        if (model.state != TimerState.RUNNING) return model.remainingSec
        val remMs = (model.endAtMs - nowMs).coerceAtLeast(0L)
        return ((remMs + 999L) / 1000L).toInt()
    }

    /** 环形进度 0..1 = 剩余秒 / 本轮秒（随时间耗尽；本轮耗尽即环空）。 */
    fun progress(model: TimerModel, nowMs: Long): Float {
        if (model.roundSec <= 0) return 0f
        return remainingAt(model, nowMs).toFloat() / model.roundSec.toFloat()
    }

    /**
     * 每拍对拍：RUNNING 且剩余归零 → 结算完成一轮，自动切到对侧阶段整轮 IDLE
     * （不自动开跑，休息由用户手动开始）。后台期间跨过的完成最多结算一次（本拍结算口径）。
     */
    fun sync(model: TimerModel, nowMs: Long): SyncResult {
        if (model.state == TimerState.RUNNING && remainingAt(model, nowMs) == 0) {
            val nextPhase = if (model.phase == Phase.FOCUS) Phase.BREAK else Phase.FOCUS
            val nextDur = phaseDuration(model, nextPhase)
            return SyncResult(
                model = model.copy(
                    phase = nextPhase,
                    state = TimerState.IDLE,
                    roundSec = nextDur,
                    remainingSec = nextDur,
                    endAtMs = 0L,
                ),
                completedPhase = model.phase,
                completedRoundSec = model.roundSec,
            )
        }
        return SyncResult(model, null, 0)
    }

    /**
     * 自定义时长：未开跑的整轮（非 RUNNING 且 remaining == round）整轮替换为新时长；
     * 已开跑/部分消耗的轮保持原剩余不动，新时长只作用于下一轮（入库按 roundSec 口径）。
     */
    fun applySettings(model: TimerModel, focusSec: Int, breakSec: Int): TimerModel {
        val f = PomodoroSpec.clampFocus(focusSec)
        val b = PomodoroSpec.clampBreak(breakSec)
        var out = model.copy(focusSec = f, breakSec = b)
        if (model.state != TimerState.RUNNING && model.remainingSec == model.roundSec) {
            val dur = if (model.phase == Phase.FOCUS) f else b
            out = out.copy(roundSec = dur, remainingSec = dur)
        }
        return out
    }

    /** 倒计时文本 MM:SS（分钟可超 99；Locale.US 锁数字形态，双端字面量一致）。 */
    fun formatClock(totalSec: Int): String {
        val s = totalSec.coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    /** 累计专注中文时长：N 分钟 / H 小时 M 分（整分钟向下取整）。 */
    fun formatDurationCn(totalSec: Int): String {
        val min = totalSec.coerceAtLeast(0) / 60
        return if (min < 60) "$min 分钟" else "${min / 60} 小时 ${min % 60} 分"
    }
}

/** 本地日期键 yyyy-MM-dd（「今日」口径；Calendar 整数域手工格式化，minSdk24 免 desugar、Locale 无关）。 */
object DayKey {
    fun of(epochMs: Long, zone: TimeZone): String {
        val c = Calendar.getInstance(zone)
        c.timeInMillis = epochMs
        return String.format(
            Locale.US, "%04d-%02d-%02d",
            c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH),
        )
    }
}
