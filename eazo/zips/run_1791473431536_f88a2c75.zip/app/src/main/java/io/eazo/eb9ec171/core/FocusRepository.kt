package io.eazo.eb9ec171.core

import java.util.Locale
import java.util.TimeZone

/**
 * 番茄钟仓储（进程内单例，经 AppRepo.getRepo(context) 获取——生成器硬规则 ①）。
 *
 * 内存态即真相：构造时唯一一次持久化 load；此后一切读走内存（list()/todayStats()），
 * 写（addFocusRecord/updateSettings/saveSnapshot）同步落盘——硬规则 ②：onResume
 * 只 refresh 重读内存态，禁止从持久化 load()。
 *
 * 持久化格式（v1，竖线分隔，无 JSON 依赖、JVM 纯逻辑可测）：
 * - settings: "v1|focusSec|breakSec"
 * - records:  每行 "id|dateKey|completedAtMs|durationSec"，换行拼接
 * - snapshot: "v1|phase|state|roundSec|remainingSec|focusSec|breakSec|endAtMs"
 */

/** 键值持久化抽象（平台层用 SharedPreferences 实现；测试用内存实现）。 */
interface KeyValueStore {
    fun read(key: String): String?
    fun write(key: String, value: String)
}

/** 完成专注轮记录（双端字段 1:1：id/dateKey/completedAtMs/durationSec）。 */
data class FocusRecord(
    val id: String,
    val dateKey: String,
    val completedAtMs: Long,
    val durationSec: Int,
)

/** 日统计：rounds=当日完成专注轮数；focusSec=当日累计专注秒数。 */
data class DayStats(
    val dateKey: String,
    val rounds: Int,
    val focusSec: Int,
)

class FocusRepository(
    private val store: KeyValueStore,
    private val zone: TimeZone = TimeZone.getDefault(),
    private val clock: () -> Long = System::currentTimeMillis,
) {
    companion object {
        const val KEY_SETTINGS = "pomodoro.settings"
        const val KEY_RECORDS = "pomodoro.records"
        const val KEY_SNAPSHOT = "pomodoro.snapshot"
        private const val SCHEMA = "v1"
    }

    private val records = mutableListOf<FocusRecord>()
    private var focusSecConf = PomodoroSpec.DEFAULT_FOCUS_SEC
    private var breakSecConf = PomodoroSpec.DEFAULT_BREAK_SEC
    private var nextSeq = 1

    init {
        loadFromStore()
    }

    /** 已完成专注轮列表（双端排序 1:1：completedAtMs 升序为主键，id 字典序兜底）。 */
    fun list(): List<FocusRecord> = records.toList()

    fun configuredFocusSec(): Int = focusSecConf

    fun configuredBreakSec(): Int = breakSecConf

    fun updateSettings(newFocusSec: Int, newBreakSec: Int) {
        focusSecConf = PomodoroSpec.clampFocus(newFocusSec)
        breakSecConf = PomodoroSpec.clampBreak(newBreakSec)
        persistSettings()
    }

    /** 记一轮完成专注。id = "f"+13 位零垫 completedAtMs+"-"+6 位零垫自增序号（确定性、免撞）。 */
    fun addFocusRecord(durationSec: Int, completedAtMs: Long): FocusRecord {
        val id = String.format(Locale.US, "f%013d-%06d", completedAtMs, nextSeq)
        nextSeq += 1
        val rec = FocusRecord(id, DayKey.of(completedAtMs, zone), completedAtMs, durationSec)
        records.add(rec)
        records.sortWith(compareBy({ it.completedAtMs }, { it.id }))
        persistRecords()
        return rec
    }

    /** 按日期键统计（dateKey = 完成时刻的本地日期）。 */
    fun stats(dateKey: String): DayStats {
        val rs = records.filter { it.dateKey == dateKey }
        return DayStats(dateKey, rs.size, rs.sumOf { it.durationSec })
    }

    /** 今日统计（clock 注入可测）。 */
    fun todayStats(): DayStats = stats(DayKey.of(clock(), zone))

    fun saveSnapshot(model: TimerModel) {
        store.write(KEY_SNAPSHOT, encodeSnapshot(model))
    }

    /** 进程重建恢复计时态；无快照/坏快照回退到配置时长初始态（过期 RUNNING 由下拍 sync 结算）。 */
    fun restoreModel(): TimerModel =
        decodeSnapshot(store.read(KEY_SNAPSHOT)) ?: PomodoroCore.initial(focusSecConf, breakSecConf)

    /** 硬规则 ②：refresh 只重读内存态（本仓储内存即真相），禁止从持久化 load()。 */
    fun refresh() = Unit

    private fun persistSettings() {
        store.write(KEY_SETTINGS, "$SCHEMA|$focusSecConf|$breakSecConf")
    }

    private fun persistRecords() {
        store.write(KEY_RECORDS, records.joinToString("\n") { encodeRecord(it) })
    }

    private fun encodeRecord(r: FocusRecord) = "${r.id}|${r.dateKey}|${r.completedAtMs}|${r.durationSec}"

    private fun loadFromStore() {
        store.read(KEY_SETTINGS)?.let { s ->
            val p = s.split("|")
            if (p.size == 3 && p[0] == SCHEMA) {
                p[1].toIntOrNull()?.let { focusSecConf = PomodoroSpec.clampFocus(it) }
                p[2].toIntOrNull()?.let { breakSecConf = PomodoroSpec.clampBreak(it) }
            }
        }
        store.read(KEY_RECORDS)?.takeIf { it.isNotEmpty() }?.let { blob ->
            blob.split("\n").forEach { line -> decodeRecord(line)?.let { records.add(it) } }
            records.sortWith(compareBy({ it.completedAtMs }, { it.id }))
            nextSeq = (records.maxOf { it.id.substringAfterLast('-').toIntOrNull() ?: 0 }) + 1
        }
    }

    private fun decodeRecord(line: String): FocusRecord? {
        val p = line.split("|")
        if (p.size != 4) return null
        val id = p[0]
        val completedAtMs = p[2].toLongOrNull() ?: return null
        val durationSec = p[3].toIntOrNull() ?: return null
        if (id.isEmpty() || p[1].isEmpty() || durationSec <= 0) return null
        return FocusRecord(id, p[1], completedAtMs, durationSec)
    }

    private fun encodeSnapshot(m: TimerModel) =
        "$SCHEMA|${m.phase.name}|${m.state.name}|${m.roundSec}|${m.remainingSec}|${m.focusSec}|${m.breakSec}|${m.endAtMs}"

    private fun decodeSnapshot(s: String?): TimerModel? {
        if (s == null) return null
        val p = s.split("|")
        if (p.size != 8 || p[0] != SCHEMA) return null
        val phase = runCatching { Phase.valueOf(p[1]) }.getOrNull() ?: return null
        val state = runCatching { TimerState.valueOf(p[2]) }.getOrNull() ?: return null
        return TimerModel(
            phase = phase,
            state = state,
            roundSec = p[3].toIntOrNull() ?: return null,
            remainingSec = p[4].toIntOrNull() ?: return null,
            focusSec = p[5].toIntOrNull() ?: return null,
            breakSec = p[6].toIntOrNull() ?: return null,
            endAtMs = p[7].toLongOrNull() ?: return null,
        )
    }
}
