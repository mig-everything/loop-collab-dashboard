package io.eazo.eb9ec171.contract

import io.eazo.eb9ec171.core.DayKey
import io.eazo.eb9ec171.core.FocusRecord
import io.eazo.eb9ec171.core.FocusRepository
import io.eazo.eb9ec171.core.KeyValueStore
import io.eazo.eb9ec171.core.Phase
import io.eazo.eb9ec171.core.PomodoroCore
import io.eazo.eb9ec171.core.PomodoroSpec
import io.eazo.eb9ec171.core.TimerModel
import io.eazo.eb9ec171.core.TimerState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.TimeZone

/**
 * 番茄钟契约用例（每需求一个 ContractTest）：全部 JVM 纯逻辑——不依赖 Android
 * 框架、不用 Robolectric。覆盖：默认口径/状态机/完成结算/自定义时长/展示口径/
 * 日期键/仓储持久化/端到端轮循环。
 */
class PomodoroContractTest {

    private val utc = TimeZone.getTimeZone("UTC")
    private val shanghai = TimeZone.getTimeZone("Asia/Shanghai")

    // 已核验锚点：1791417600000 = 2026-10-08T00:00:00Z（上海 +8 → 08:00 同日）
    private val day0 = 1791417600000L
    private val day0Plus16h = 1791475200000L   // 2026-10-08T16:00:00Z（上海 → 10-09 00:00）
    private val day0Minus8h = 1791388800000L   // 2026-10-07T16:00:00Z（上海 → 10-08 00:00）

    private class MemStore : KeyValueStore {
        val map = mutableMapOf<String, String>()
        override fun read(key: String): String? = map[key]
        override fun write(key: String, value: String) {
            map[key] = value
        }
    }

    // ===== P-A 默认口径 =====

    @Test
    fun `P-A1 默认 25 分钟专注 5 分钟短休息 FOCUS IDLE 整轮`() {
        val m = PomodoroCore.initial(PomodoroSpec.DEFAULT_FOCUS_SEC, PomodoroSpec.DEFAULT_BREAK_SEC)
        assertEquals(Phase.FOCUS, m.phase)
        assertEquals(TimerState.IDLE, m.state)
        assertEquals(1500, m.roundSec)
        assertEquals(1500, m.remainingSec)
        assertEquals(1500, m.focusSec)
        assertEquals(300, m.breakSec)
    }

    @Test
    fun `P-A2 initial 对越界时长做 clamp`() {
        val m = PomodoroCore.initial(9999 * 60, 10)
        assertEquals(PomodoroSpec.MAX_FOCUS_SEC, m.focusSec)
        assertEquals(PomodoroSpec.MAX_FOCUS_SEC, m.roundSec)
        assertEquals(PomodoroSpec.MIN_BREAK_SEC, m.breakSec)
    }

    // ===== P-B 开始/暂停/重置 =====

    @Test
    fun `P-B1 start 置 RUNNING 且 deadline 等于 now 加剩余秒乘 1000`() {
        val m0 = PomodoroCore.initial(1500, 300)
        val m1 = PomodoroCore.start(m0, day0)
        assertEquals(TimerState.RUNNING, m1.state)
        assertEquals(1500, m1.remainingSec)
        assertEquals(day0 + 1500_000L, m1.endAtMs)
    }

    @Test
    fun `P-B2 剩余秒满秒起显 ceil 口径`() {
        val m = PomodoroCore.start(PomodoroCore.initial(1500, 300), day0)
        assertEquals(1500, PomodoroCore.remainingAt(m, day0))
        assertEquals(1500, PomodoroCore.remainingAt(m, day0 + 999L))
        assertEquals(1499, PomodoroCore.remainingAt(m, day0 + 1000L))
        assertEquals(0, PomodoroCore.remainingAt(m, day0 + 1500_000L))
        assertEquals(0, PomodoroCore.remainingAt(m, day0 + 999_999_999L)) // 逾期钳 0
    }

    @Test
    fun `P-B3 pause 按当前时刻冻结剩余秒并清 deadline`() {
        val m = PomodoroCore.start(PomodoroCore.initial(1500, 300), day0)
        val p = PomodoroCore.pause(m, day0 + 30_000L)
        assertEquals(TimerState.PAUSED, p.state)
        assertEquals(1470, p.remainingSec)
        assertEquals(0L, p.endAtMs)
        assertEquals(1470, PomodoroCore.remainingAt(p, day0 + 999_999L)) // 暂停后不再随时间走
    }

    @Test
    fun `P-B4 暂停后继续按冻结剩余秒重设 deadline`() {
        val m = PomodoroCore.pause(PomodoroCore.start(PomodoroCore.initial(1500, 300), day0), day0 + 30_000L)
        val r = PomodoroCore.start(m, day0 + 120_000L)
        assertEquals(TimerState.RUNNING, r.state)
        assertEquals(1470, r.remainingSec)
        assertEquals(day0 + 120_000L + 1470_000L, r.endAtMs)
    }

    @Test
    fun `P-B5 reset 回当前阶段整轮 IDLE 不切阶段`() {
        val m = PomodoroCore.pause(PomodoroCore.start(PomodoroCore.initial(1500, 300), day0), day0 + 30_000L)
        val r = PomodoroCore.reset(m)
        assertEquals(TimerState.IDLE, r.state)
        assertEquals(Phase.FOCUS, r.phase)
        assertEquals(1500, r.roundSec)
        assertEquals(1500, r.remainingSec)
    }

    @Test
    fun `P-B6 非法态操作为无操作幂等`() {
        val idle = PomodoroCore.initial(1500, 300)
        assertEquals(idle, PomodoroCore.pause(idle, day0))            // IDLE 暂停无效
        val running = PomodoroCore.start(idle, day0)
        assertEquals(running, PomodoroCore.start(running, day0 + 1000L)) // RUNNING 再开始无效
        assertEquals(idle, PomodoroCore.reset(idle))                  // IDLE 重置幂等
    }

    // ===== P-C 完成结算 =====

    @Test
    fun `P-C1 专注轮到点结算 切 BREAK 整轮 IDLE 回传完成信息`() {
        val m = PomodoroCore.start(PomodoroCore.initial(1500, 300), day0)
        val r = PomodoroCore.sync(m, day0 + 1500_000L)
        assertEquals(Phase.FOCUS, r.completedPhase)
        assertEquals(1500, r.completedRoundSec)
        assertEquals(Phase.BREAK, r.model.phase)
        assertEquals(TimerState.IDLE, r.model.state)
        assertEquals(300, r.model.roundSec)
        assertEquals(300, r.model.remainingSec)
    }

    @Test
    fun `P-C2 休息轮到点结算 切回 FOCUS 不产生专注记录语义`() {
        val focusDone = PomodoroCore.sync(PomodoroCore.start(PomodoroCore.initial(1500, 300), day0), day0 + 1500_000L)
        val brk = PomodoroCore.start(focusDone.model, day0 + 2000_000L)
        val r = PomodoroCore.sync(brk, day0 + 2300_000L)
        assertEquals(Phase.BREAK, r.completedPhase)
        assertEquals(300, r.completedRoundSec)
        assertEquals(Phase.FOCUS, r.model.phase)
        assertEquals(1500, r.model.roundSec)
    }

    @Test
    fun `P-C3 未到点与未运行 sync 均不结算`() {
        val m = PomodoroCore.start(PomodoroCore.initial(1500, 300), day0)
        assertNull(PomodoroCore.sync(m, day0 + 1499_999L).completedPhase)
        assertNull(PomodoroCore.sync(PomodoroCore.initial(1500, 300), day0).completedPhase)
        val paused = PomodoroCore.pause(m, day0 + 1000L)
        assertNull(PomodoroCore.sync(paused, day0 + 999_999_999L).completedPhase)
    }

    @Test
    fun `P-C4 运行中改设置 入库口径按本轮 roundSec 不按新 focusSec`() {
        var m = PomodoroCore.start(PomodoroCore.initial(1500, 300), day0)
        m = PomodoroCore.applySettings(m, 3600, 600) // 运行中改专注 60 分钟
        assertEquals(1500, m.roundSec)               // 本轮不变
        assertEquals(day0 + 1500_000L, m.endAtMs)
        val r = PomodoroCore.sync(m, day0 + 1500_000L)
        assertEquals(1500, r.completedRoundSec)      // 完成仍按本轮 25 分钟入库
        assertEquals(600, r.model.roundSec)          // 休息轮已用新 breakSec
        val nextFocus = PomodoroCore.sync(PomodoroCore.start(r.model, day0 + 3_000_000L), day0 + 3_600_000L)
        assertEquals(3600, nextFocus.model.roundSec) // 下一专注轮用新 focusSec
    }

    // ===== P-D 自定义时长 =====

    @Test
    fun `P-D1 clamp 边界 专注 60 到 10800 秒 休息 60 到 3600 秒`() {
        assertEquals(60, PomodoroSpec.clampFocus(1))
        assertEquals(10800, PomodoroSpec.clampFocus(99999 * 60))
        assertEquals(1500, PomodoroSpec.clampFocus(1500))
        assertEquals(60, PomodoroSpec.clampBreak(59))
        assertEquals(3600, PomodoroSpec.clampBreak(9999 * 60))
    }

    @Test
    fun `P-D2 未开跑整轮改设置 即时替换整轮时长`() {
        val m0 = PomodoroCore.initial(1500, 300)
        val m1 = PomodoroCore.applySettings(m0, 1800, 600)
        assertEquals(1800, m1.focusSec)
        assertEquals(1800, m1.roundSec)
        assertEquals(1800, m1.remainingSec)
        // BREAK 阶段整轮同理用新 breakSec
        val b0 = PomodoroCore.sync(PomodoroCore.start(PomodoroCore.initial(1800, 600), day0), day0 + 1800_000L).model
        val b1 = PomodoroCore.applySettings(b0, 1800, 900)
        assertEquals(900, b1.roundSec)
        assertEquals(900, b1.remainingSec)
    }

    @Test
    fun `P-D3 部分消耗的暂停轮改设置 只影响下一轮`() {
        val paused = PomodoroCore.pause(PomodoroCore.start(PomodoroCore.initial(1500, 300), day0), day0 + 30_000L)
        val m1 = PomodoroCore.applySettings(paused, 1800, 600)
        assertEquals(1470, m1.remainingSec)  // 剩余不动
        assertEquals(1500, m1.roundSec)      // 本轮口径不动
        val r = PomodoroCore.reset(m1)       // 重置则吃新配置
        assertEquals(1800, r.roundSec)
        assertEquals(1800, r.remainingSec)
    }

    // ===== P-E 展示口径 =====

    @Test
    fun `P-E1 倒计时文本 MM-SS`() {
        assertEquals("25:00", PomodoroCore.formatClock(1500))
        assertEquals("00:59", PomodoroCore.formatClock(59))
        assertEquals("00:00", PomodoroCore.formatClock(0))
        assertEquals("00:00", PomodoroCore.formatClock(-5))
        assertEquals("61:01", PomodoroCore.formatClock(3661))
        assertEquals("180:00", PomodoroCore.formatClock(10800))
    }

    @Test
    fun `P-E2 累计专注中文时长整分钟向下取整`() {
        assertEquals("0 分钟", PomodoroCore.formatDurationCn(0))
        assertEquals("25 分钟", PomodoroCore.formatDurationCn(1500))
        assertEquals("25 分钟", PomodoroCore.formatDurationCn(1559))
        assertEquals("1 小时 0 分", PomodoroCore.formatDurationCn(3600))
        assertEquals("2 小时 15 分", PomodoroCore.formatDurationCn(8100))
    }

    @Test
    fun `P-E3 环形进度等于剩余秒除以本轮秒 随时间耗尽`() {
        val m = PomodoroCore.start(PomodoroCore.initial(1500, 300), day0)
        assertEquals(1.0f, PomodoroCore.progress(m, day0), 0.0001f)
        assertEquals(0.5f, PomodoroCore.progress(m, day0 + 750_000L), 0.001f)
        assertEquals(0.0f, PomodoroCore.progress(m, day0 + 1500_000L), 0.0001f)
    }

    // ===== P-F 日期键（今日口径） =====

    @Test
    fun `P-F1 UTC 日期键手工格式化`() {
        assertEquals("2026-10-08", DayKey.of(day0, utc))
        assertEquals("2026-10-07", DayKey.of(day0Minus8h, utc))
        assertEquals("2026-10-08", DayKey.of(day0Plus16h, utc))
    }

    @Test
    fun `P-F2 上海时区跨日边界`() {
        assertEquals("2026-10-08", DayKey.of(day0, shanghai))       // 08:00 本地
        assertEquals("2026-10-08", DayKey.of(day0Minus8h, shanghai)) // 00:00 本地
        assertEquals("2026-10-09", DayKey.of(day0Plus16h, shanghai)) // 次日 00:00
    }

    // ===== P-G 仓储 =====

    @Test
    fun `P-G1 记录 id 确定性生成且列表按 completedAtMs 主键 id 字典序兜底排序`() {
        val repo = FocusRepository(MemStore(), utc) { day0 }
        val r1 = repo.addFocusRecord(1500, day0 + 1000L)
        assertEquals("f1791417601000-000001", r1.id)
        val r2 = repo.addFocusRecord(1500, day0 + 1000L) // 同刻并列 → id 兜底
        val r3 = repo.addFocusRecord(1800, day0)
        val list = repo.list()
        assertEquals(listOf(r3, r1, r2), list) // 1791417600000 < ...001 两次并列
        assertTrue(list[1].id < list[2].id)
    }

    @Test
    fun `P-G2 stats 按 dateKey 过滤求轮数与秒数`() {
        val repo = FocusRepository(MemStore(), utc) { day0 }
        repo.addFocusRecord(1500, day0)
        repo.addFocusRecord(1500, day0 + 1000L)
        repo.addFocusRecord(1800, day0Plus16h) // UTC 仍 10-08；上海口径次日
        val s = repo.stats("2026-10-08")
        assertEquals(3, s.rounds)
        assertEquals(4800, s.focusSec)
        assertEquals(0, repo.stats("2026-10-07").rounds)
    }

    @Test
    fun `P-G3 todayStats 走注入时钟与时区`() {
        val repoUtc = FocusRepository(MemStore(), utc) { day0Plus16h }
        repoUtc.addFocusRecord(1500, day0)
        assertEquals("2026-10-08", repoUtc.todayStats().dateKey)
        assertEquals(1, repoUtc.todayStats().rounds)

        val repoSh = FocusRepository(MemStore(), shanghai) { day0Plus16h } // 上海已是 10-09
        assertEquals("2026-10-09", repoSh.todayStats().dateKey)
        assertEquals(0, repoSh.todayStats().rounds)
    }

    @Test
    fun `P-G4 持久化 roundtrip 设置 记录 快照经同一 store 重建`() {
        val store = MemStore()
        val repo = FocusRepository(store, utc) { day0 }
        repo.updateSettings(2700, 900)
        repo.addFocusRecord(2700, day0)
        repo.addFocusRecord(2700, day0 + 60000L)
        val running = TimerModel(
            phase = Phase.BREAK, state = TimerState.RUNNING,
            roundSec = 900, remainingSec = 900, focusSec = 2700, breakSec = 900,
            endAtMs = day0 + 3_000_000L,
        )
        repo.saveSnapshot(running)

        val reborn = FocusRepository(store, utc) { day0 }
        assertEquals(2700, reborn.configuredFocusSec())
        assertEquals(900, reborn.configuredBreakSec())
        assertEquals(2, reborn.list().size)
        assertEquals(2, reborn.todayStats().rounds)
        assertEquals(5400, reborn.todayStats().focusSec)
        assertEquals(running, reborn.restoreModel())
    }

    @Test
    fun `P-G5 坏行跳过 空存储回默认 且重建后序号续号不撞 id`() {
        val store = MemStore()
        store.write(FocusRepository.KEY_RECORDS, "f1791417600000-000001|2026-10-08|1791417600000|1500\n坏行|x|y|z\n\nf1791417600000-000002|2026-10-08|1791417600000|-1")
        val repo = FocusRepository(store, utc) { day0 }
        assertEquals(1, repo.list().size) // 仅首行合法
        val next = repo.addFocusRecord(1500, day0)
        assertEquals("f1791417600000-000002", next.id) // 序号从 max=1 续到 2，不撞

        val empty = FocusRepository(MemStore(), utc) { day0 }
        assertEquals(1500, empty.configuredFocusSec())
        assertEquals(300, empty.configuredBreakSec())
        assertEquals(0, empty.list().size)
        assertEquals(
            PomodoroCore.initial(1500, 300),
            empty.restoreModel(),
        )
    }

    @Test
    fun `P-G6 updateSettings 落盘即 clamp 后值`() {
        val store = MemStore()
        val repo = FocusRepository(store, utc) { day0 }
        repo.updateSettings(5, 9999 * 60) // 专注 5 秒级越界(视作秒 clamp 到 60)、休息越界
        assertEquals(60, repo.configuredFocusSec())
        assertEquals(3600, repo.configuredBreakSec())
        assertEquals(60, FocusRepository(store, utc) { day0 }.configuredFocusSec()) // 落盘可见
    }

    // ===== P-H 端到端轮循环模拟 =====

    @Test
    fun `P-H1 一整轮 专注完成入库 休息完成不入库 统计只计专注`() {
        val store = MemStore()
        val repo = FocusRepository(store, utc) { day0 }
        var m = PomodoroCore.initial(repo.configuredFocusSec(), repo.configuredBreakSec())

        m = PomodoroCore.start(m, day0)
        var r = PomodoroCore.sync(m, day0 + 1500_000L) // 专注到点
        if (r.completedPhase == Phase.FOCUS) repo.addFocusRecord(r.completedRoundSec, day0 + 1500_000L)
        m = r.model

        m = PomodoroCore.start(m, day0 + 1600_000L)
        r = PomodoroCore.sync(m, day0 + 1900_000L)     // 休息到点
        if (r.completedPhase == Phase.FOCUS) repo.addFocusRecord(r.completedRoundSec, day0 + 1900_000L)
        m = r.model

        assertEquals(Phase.FOCUS, m.phase)
        assertEquals(TimerState.IDLE, m.state)
        assertEquals(1, repo.list().size)
        val record: FocusRecord = repo.list().first()
        assertEquals(1500, record.durationSec)
        assertEquals("2026-10-08", record.dateKey)
        assertEquals(1, repo.todayStats().rounds)
        assertEquals(1500, repo.todayStats().focusSec)
    }

    @Test
    fun `P-H2 后台跨完成的重建恢复 RUNNING 过期由下拍结算一次`() {
        val store = MemStore()
        val repo = FocusRepository(store, utc) { day0 }
        repo.saveSnapshot(PomodoroCore.start(PomodoroCore.initial(1500, 300), day0))
        // 进程"死"了 3 小时后重建
        val reborn = FocusRepository(store, utc) { day0 + 3 * 3600_000L }
        val m0 = reborn.restoreModel()
        assertEquals(TimerState.RUNNING, m0.state)
        val r = PomodoroCore.sync(m0, day0 + 3 * 3600_000L)
        assertEquals(Phase.FOCUS, r.completedPhase) // 只结算一次，不追多轮
        assertEquals(Phase.BREAK, r.model.phase)
        assertEquals(TimerState.IDLE, r.model.state)
    }
}
