package io.eazo.dailyquote.core

/** JVM 单测用的内存 KeyValueStore。 */
class MemStore : KeyValueStore {
    val strings = mutableMapOf<String, String>()
    val sets = mutableMapOf<String, Set<String>>()
    val ints = mutableMapOf<String, Int>()

    override fun getString(key: String): String? = strings[key]

    override fun getStringSet(key: String): Set<String>? = sets[key]

    override fun getInt(key: String, def: Int): Int = ints[key] ?: def

    override fun putString(key: String, value: String) {
        strings[key] = value
    }

    override fun putStringSet(key: String, values: Set<String>) {
        sets[key] = values.toSet()
    }

    override fun putInt(key: String, value: Int) {
        ints[key] = value
    }
}
