package io.eazo.dailyquote.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 生成器硬规则④：冷/热启动同走 readOpenCreate；布尔参数严格判定
 * （对位鸿蒙 typeof v === 'boolean' && v === true）。
 */
class OpenContractTest {

    @Test
    fun `empty want opens home`() {
        val spec = OpenContract.readOpenCreate(null, null)
        assertNull(spec.quoteId)
        assertFalse(spec.openFavorites)
    }

    @Test
    fun `valid quote id and strict true route to detail`() {
        val spec = OpenContract.readOpenCreate("q005", true)
        assertEquals("q005", spec.quoteId)
        assertTrue(spec.openFavorites)
    }

    @Test
    fun `open favorites wins over quote id`() {
        // 与 Android 侧 MainActivity 路由优先级一致：openFavorites > quoteId > home
        val spec = OpenContract.readOpenCreate("q005", true)
        assertTrue(spec.openFavorites)
    }

    @Test
    fun `string true is rejected by strict boolean check`() {
        assertFalse(OpenContract.readOpenCreate("q001", "true").openFavorites)
        assertFalse(OpenContract.readOpenCreate("q001", 1).openFavorites)
        assertFalse(OpenContract.readOpenCreate("q001", "TRUE").openFavorites)
    }

    @Test
    fun `strictTrue table`() {
        assertTrue(OpenContract.strictTrue(true))
        assertFalse(OpenContract.strictTrue(false))
        assertFalse(OpenContract.strictTrue(null))
        assertFalse(OpenContract.strictTrue("true"))
        assertFalse(OpenContract.strictTrue(1))
    }

    @Test
    fun `blank or non string quote id becomes null`() {
        assertNull(OpenContract.readOpenCreate("   ", null).quoteId)
        assertNull(OpenContract.readOpenCreate("", null).quoteId)
        assertNull(OpenContract.readOpenCreate(42, null).quoteId)
    }

    @Test
    fun `readOpenCreate is a pure function - same input same output`() {
        assertEquals(
            OpenContract.readOpenCreate("q007", true),
            OpenContract.readOpenCreate("q007", true),
        )
    }
}
