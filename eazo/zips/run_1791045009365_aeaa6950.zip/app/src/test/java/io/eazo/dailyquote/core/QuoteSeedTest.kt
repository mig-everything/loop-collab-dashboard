package io.eazo.dailyquote.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class QuoteSeedTest {

    @Test
    fun `seed has 24 quotes with unique well formed ids`() {
        assertEquals(24, QuoteSeed.ALL.size)
        val ids = QuoteSeed.ALL.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        ids.forEach { assertTrue("bad id: $it", Regex("q\\d{3}").matches(it)) }
    }

    @Test
    fun `all fields non blank`() {
        QuoteSeed.ALL.forEach { q ->
            assertTrue(q.id.isNotBlank())
            assertTrue("text blank for ${q.id}", q.text.isNotBlank())
            assertTrue("author blank for ${q.id}", q.author.isNotBlank())
            assertTrue("source blank for ${q.id}", q.source.isNotBlank())
        }
    }

    @Test
    fun `all three types present`() {
        val types = QuoteSeed.ALL.map { it.type }.toSet()
        assertEquals(setOf(QuoteType.BOOK, QuoteType.CLASSIC, QuoteType.MOVIE), types)
        // 每类 8 条
        assertEquals(8, QuoteSeed.ALL.count { it.type == QuoteType.BOOK })
        assertEquals(8, QuoteSeed.ALL.count { it.type == QuoteType.CLASSIC })
        assertEquals(8, QuoteSeed.ALL.count { it.type == QuoteType.MOVIE })
    }

    @Test
    fun `ALL is sorted by QuoteOrder deterministically`() {
        // 相邻两两满足排序关系 => 全序确定
        QuoteSeed.ALL.zipWithNext().forEach { (a, b) ->
            assertTrue(
                "order broken between ${a.id} and ${b.id}",
                QuoteOrder.compare(a, b) < 0,
            )
        }
        // 稳定性：重复构建顺序一致
        val again = QuoteSeed.ALL.sortedWith(QuoteOrder)
        assertEquals(QuoteSeed.ALL.map { it.id }, again.map { it.id })
    }

    @Test
    fun `type labels are stable chinese mapping`() {
        assertEquals("名言", QuoteType.CLASSIC.label)
        assertEquals("电影", QuoteType.MOVIE.label)
        assertEquals("书摘", QuoteType.BOOK.label)
    }
}
