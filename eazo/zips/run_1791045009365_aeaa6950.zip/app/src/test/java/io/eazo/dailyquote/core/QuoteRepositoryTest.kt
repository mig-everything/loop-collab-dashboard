package io.eazo.dailyquote.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

/**
 * 生成器硬规则①②的行为级验证：
 * 内存态 list() 即时可见、构造时唯一一次持久化 load、写操作回写存储。
 */
class QuoteRepositoryTest {

    private val day1 = LocalDate.of(2026, 10, 4)
    private val day2 = LocalDate.of(2026, 10, 5)
    private var now: LocalDate = day1

    private fun repo(store: MemStore = MemStore()): QuoteRepository =
        QuoteRepository(store) { now }

    @Test
    fun `list matches seed size and deterministic order`() {
        val r = repo()
        assertEquals(QuoteSeed.ALL.size, r.size)
        assertEquals(QuoteSeed.ALL.map { it.id }, r.list().map { it.quote.id })
        assertTrue(r.list().none { it.favorite })
    }

    @Test
    fun `toggle favorite is immediately visible in list without reload`() {
        val r = repo()
        val target = r.list().first()
        assertFalse(target.favorite)

        assertTrue(r.toggleFavorite(target.quote.id)) // 收藏 -> true
        assertTrue(r.list().first().favorite)        // 硬规则②：内存态即时可见
        assertEquals(listOf(target.quote.id), r.favorites().map { it.quote.id })

        assertFalse(r.toggleFavorite(target.quote.id)) // 取消 -> false
        assertFalse(r.list().first().favorite)
        assertTrue(r.favorites().isEmpty())
    }

    @Test
    fun `favorites persist across repository rebuild`() {
        val store = MemStore()
        repo(store).toggleFavorite("q001")
        repo(store).toggleFavorite("q024")
        // 持久化确已回写
        assertTrue(store.sets[QuoteRepository.KEY_FAVORITES]?.containsAll(setOf("q001", "q024")) == true)
        // 新实例构造时一次性 load 回来
        val reborn = QuoteRepository(store) { now }
        assertEquals(setOf("q001", "q024"), reborn.favorites().map { it.quote.id }.toSet())
    }

    @Test
    fun `today is stable within one day`() {
        val r = repo()
        val expected = QuoteSeed.ALL[DailyEngine.baseIndex("2026-10-04", QuoteSeed.ALL.size)]
        assertEquals(expected.id, r.today().quote.id)
        assertEquals(expected.id, r.today().quote.id)
        assertEquals("2026-10-04", r.todayDayKey())
    }

    @Test
    fun `refresh advances deterministically and wraps around`() {
        val r = repo()
        val n = QuoteSeed.ALL.size
        val base = DailyEngine.baseIndex("2026-10-04", n)
        assertEquals(QuoteSeed.ALL[(base + 1) % n].id, r.refresh().quote.id)
        assertEquals(QuoteSeed.ALL[(base + 2) % n].id, r.refresh().quote.id)
        // 刷新 n 次后绕回基准位
        repeat(n - 2) { r.refresh() }
        assertEquals(QuoteSeed.ALL[base].id, r.today().quote.id)
    }

    @Test
    fun `day rollover resets refresh offset`() {
        val store = MemStore()
        val r = repo(store)
        r.refresh()
        r.refresh()
        now = day2
        val base2 = DailyEngine.baseIndex("2026-10-05", QuoteSeed.ALL.size)
        assertEquals(QuoteSeed.ALL[base2].id, r.today().quote.id)
        assertEquals("2026-10-05", r.todayDayKey())
    }

    @Test
    fun `refresh offset persists across instances same day`() {
        val store = MemStore()
        repo(store).refresh()
        val reborn = QuoteRepository(store) { now }
        val n = QuoteSeed.ALL.size
        val base = DailyEngine.baseIndex("2026-10-04", n)
        assertEquals(QuoteSeed.ALL[(base + 1) % n].id, reborn.today().quote.id)
    }

    @Test
    fun `byId finds quote and returns null for unknown`() {
        val r = repo()
        assertNotNull(r.byId("q001"))
        assertEquals("小王子", r.byId("q001")?.source)
        assertNull(r.byId("nope"))
    }

    @Test
    fun `today display uses injected clock`() {
        assertEquals("10月4日", repo().todayDisplay())
        now = day2
        assertEquals("10月5日", repo().todayDisplay())
    }
}
