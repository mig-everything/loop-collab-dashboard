package io.eazo.dailyquote.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class DailyEngineTest {

    @Test
    fun `dayKey formats with zero padding`() {
        assertEquals("2026-10-04", DailyEngine.dayKey(LocalDate.of(2026, 10, 4)))
        assertEquals("2026-01-01", DailyEngine.dayKey(LocalDate.of(2026, 1, 1)))
        assertEquals("1999-12-31", DailyEngine.dayKey(LocalDate.of(1999, 12, 31)))
    }

    @Test
    fun `displayDay renders chinese label`() {
        assertEquals("10月4日", DailyEngine.displayDay(LocalDate.of(2026, 10, 4)))
        assertEquals("1月1日", DailyEngine.displayDay(LocalDate.of(2026, 1, 1)))
    }

    @Test
    fun `fnv1a matches standard vectors`() {
        // FNV-1a 32 标准向量："" -> 0x811C9DC5, "a" -> 0xE40C292C
        assertEquals(0x811C9DC5.toInt(), DailyEngine.fnv1a(""))
        assertEquals(0xE40C292C.toInt(), DailyEngine.fnv1a("a"))
    }

    @Test
    fun `baseIndex is deterministic and in range`() {
        val size = 24
        val first = DailyEngine.baseIndex("2026-10-04", size)
        assertEquals(first, DailyEngine.baseIndex("2026-10-04", size))
        assertTrue(first in 0 until size)
        assertTrue(DailyEngine.baseIndex("1970-01-01", size) in 0 until size)
    }

    @Test
    fun `baseIndex spreads across days`() {
        val size = 24
        val distinct = (0..399)
            .map { DailyEngine.baseIndex(LocalDate.ofEpochDay(20000L + it).toString(), size) }
            .toSet()
        // 模 24 的上限即 24：400 天应铺满全部桶位
        assertTrue("expected spread over 400 days, got ${distinct.size}", distinct.size == size)
    }

    @Test
    fun `slotIndex advances by one per refresh and wraps`() {
        val size = 24
        val key = "2026-10-04"
        val base = DailyEngine.baseIndex(key, size)
        assertEquals((base + 1) % size, DailyEngine.slotIndex(key, 1, size))
        assertEquals((base + 2) % size, DailyEngine.slotIndex(key, 2, size))
        assertEquals(base, DailyEngine.slotIndex(key, size, size)) // 绕回
        assertEquals(base, DailyEngine.slotIndex(key, 0, size))
    }

    @Test
    fun `slotIndex normalizes negative offsets`() {
        val size = 24
        val key = "2026-10-04"
        val base = DailyEngine.baseIndex(key, size)
        assertEquals((base + size - 1) % size, DailyEngine.slotIndex(key, -1, size))
    }

    @Test
    fun `slotIndex works for single item library`() {
        assertEquals(0, DailyEngine.slotIndex("2026-10-04", 0, 1))
        assertEquals(0, DailyEngine.slotIndex("2026-10-04", 7, 1))
        assertEquals(0, DailyEngine.slotIndex("2026-10-04", -3, 1))
    }
}
