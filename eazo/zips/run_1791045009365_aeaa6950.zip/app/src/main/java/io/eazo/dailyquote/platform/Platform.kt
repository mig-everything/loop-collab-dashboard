package io.eazo.dailyquote.platform

import android.content.Context
import io.eazo.dailyquote.core.KeyValueStore
import io.eazo.dailyquote.core.QuoteRepository

/**
 * 进程内单例仓储入口（生成器硬规则①）：
 * UI / 桌面卡片层禁止 new QuoteRepository(...)，一律 AppRepo.getRepo(context)。
 */
object AppRepo {
    @Volatile
    private var repo: QuoteRepository? = null

    fun getRepo(context: Context): QuoteRepository =
        repo ?: synchronized(this) {
            repo ?: QuoteRepository(PrefsStore(context.applicationContext)).also { repo = it }
        }
}

/** SharedPreferences 实现的 KeyValueStore。 */
class PrefsStore(context: Context) : KeyValueStore {
    private val prefs = context.getSharedPreferences("daily_quote", Context.MODE_PRIVATE)

    override fun getString(key: String): String? = prefs.getString(key, null)

    override fun getStringSet(key: String): Set<String>? = prefs.getStringSet(key, null)

    override fun getInt(key: String, def: Int): Int = prefs.getInt(key, def)

    override fun putString(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    override fun putStringSet(key: String, values: Set<String>) {
        prefs.edit().putStringSet(key, values).apply()
    }

    override fun putInt(key: String, value: Int) {
        prefs.edit().putInt(key, value).apply()
    }
}
