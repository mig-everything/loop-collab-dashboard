package io.eazo.dailyquote.core

/**
 * 本地种子库（书摘 / 名言 / 电影台词 各 8 条，共 24 条）。
 * id 为 q001..q024；加载即按 [QuoteOrder] 排序，保证双端遍历顺序一致。
 */
object QuoteSeed {

    private val raw = listOf(
        // BOOK 书摘
        Quote("q001", "所有的大人都曾经是小孩，虽然只有少数人记得。", "圣埃克苏佩里", "小王子", QuoteType.BOOK),
        Quote("q002", "满地都是六便士，他却抬头看见了月亮。", "毛姆", "月亮与六便士", QuoteType.BOOK),
        Quote("q003", "一个人可以被毁灭，但不能被打败。", "海明威", "老人与海", QuoteType.BOOK),
        Quote("q004", "且视他人之疑目如盏盏鬼火，大胆地去走你的夜路。", "史铁生", "病隙碎笔", QuoteType.BOOK),
        Quote("q005", "人生如梦，我投入的却是真情。世界先爱了我，我不能不爱它。", "汪曾祺", "人间草木", QuoteType.BOOK),
        Quote("q006", "生如夏花之绚烂，死如秋叶之静美。", "泰戈尔", "飞鸟集", QuoteType.BOOK),
        Quote("q007", "从前的日色变得慢，车、马、邮件都慢，一生只够爱一个人。", "木心", "云雀叫了一整天", QuoteType.BOOK),
        Quote("q008", "当你穿过了暴风雨，你早已不再是原来那个人。", "村上春树", "海边的卡夫卡", QuoteType.BOOK),
        // CLASSIC 名言
        Quote("q009", "知之者不如好之者，好之者不如乐之者。", "孔子", "论语", QuoteType.CLASSIC),
        Quote("q010", "千里之行，始于足下。", "老子", "道德经", QuoteType.CLASSIC),
        Quote("q011", "腹有诗书气自华。", "苏轼", "和董传留别", QuoteType.CLASSIC),
        Quote("q012", "志不立，天下无可成之事。", "王阳明", "传习录", QuoteType.CLASSIC),
        Quote("q013", "每一个不曾起舞的日子，都是对生命的辜负。", "尼采", "查拉图斯特拉如是说", QuoteType.CLASSIC),
        Quote("q014", "在隆冬，我终于知道，我身上有一个不可战胜的夏天。", "加缪", "夏天集", QuoteType.CLASSIC),
        Quote("q015", "世界上只有一种真正的英雄主义，那就是认清生活的真相之后依然热爱生活。", "罗曼·罗兰", "米开朗琪罗传", QuoteType.CLASSIC),
        Quote("q016", "未经审视的人生，不值得度过。", "苏格拉底", "申辩篇", QuoteType.CLASSIC),
        // MOVIE 电影台词
        Quote("q017", "生活就像一盒巧克力，你永远不知道下一颗是什么滋味。", "阿甘", "阿甘正传", QuoteType.MOVIE),
        Quote("q018", "希望是美好的，也许是人间至善，而美好的事物永不消逝。", "安迪", "肖申克的救赎", QuoteType.MOVIE),
        Quote("q019", "生活是否永远艰辛？还是仅仅童年如此？——总是如此。", "玛蒂尔达", "这个杀手不太冷", QuoteType.MOVIE),
        Quote("q020", "假如再也见不到你，祝你早安、午安、晚安。", "楚门", "楚门的世界", QuoteType.MOVIE),
        Quote("q021", "陆地对我来说是一艘太大的船，一个太美的女人，一段太长的旅程。", "1900", "海上钢琴师", QuoteType.MOVIE),
        Quote("q022", "Carpe diem。及时采撷你的花蕾，让此生不同凡响。", "基廷", "死亡诗社", QuoteType.MOVIE),
        Quote("q023", "不管前方的路有多苦，只要走的方向正确，都比站在原地更接近幸福。", "宫崎骏", "千与千寻", QuoteType.MOVIE),
        Quote("q024", "即使是最微小的人，也能改变世界的进程。", "甘道夫", "指环王", QuoteType.MOVIE),
    )

    /** 排序后的全量种子（确定性，双端一致）。 */
    val ALL: List<Quote> = raw.sortedWith(QuoteOrder)
}
