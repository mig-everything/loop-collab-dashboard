package io.eazo.dailyquote.core

/**
 * 语录类型。字段字面量与鸿蒙端 1:1（生成器硬规则③：字段名、枚举字面量、排序键完全一致）。
 */
enum class QuoteType { CLASSIC, MOVIE, BOOK }

/** UI 展示标签，双端映射一致。 */
val QuoteType.label: String
    get() = when (this) {
        QuoteType.CLASSIC -> "名言"
        QuoteType.MOVIE -> "电影"
        QuoteType.BOOK -> "书摘"
    }

/**
 * 语录实体。字段名与鸿蒙端 1:1：id / text / author / source / type。
 */
data class Quote(
    val id: String,
    val text: String,
    val author: String,
    val source: String,
    val type: QuoteType,
)

/** 仓储内存态视图：语录 + 是否已收藏。 */
data class QuoteView(
    val quote: Quote,
    val favorite: Boolean,
)

/**
 * 确定性排序（生成器硬规则③）：
 * 主键 = type.name 字典序；次键 = author 字典序；兜底 = id 字典序。
 * 字典序均为 UTF-16 码元比较，与鸿蒙端字符串比较语义一致。
 */
object QuoteOrder : Comparator<Quote> {
    override fun compare(a: Quote, b: Quote): Int {
        var c = a.type.name.compareTo(b.type.name)
        if (c != 0) return c
        c = a.author.compareTo(b.author)
        if (c != 0) return c
        return a.id.compareTo(b.id)
    }
}
