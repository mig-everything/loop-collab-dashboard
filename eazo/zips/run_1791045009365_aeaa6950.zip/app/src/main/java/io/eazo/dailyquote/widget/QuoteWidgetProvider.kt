package io.eazo.dailyquote.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import io.eazo.dailyquote.R
import io.eazo.dailyquote.platform.AppRepo
import io.eazo.dailyquote.ui.MainActivity

/**
 * 桌面「今日一句」卡片（元服务卡片对位实现）。
 *
 * 生成器硬规则落点：
 * - ① 卡片层不 new 仓储，一律 AppRepo.getRepo(context) 与应用同进程单例；
 * - ② 卡片上的「换一句」写偏移后，应用侧 onResume 重读 list() 即时可见。
 */
class QuoteWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        push(context, appWidgetManager, appWidgetIds)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val repo = AppRepo.getRepo(context)
            repo.refresh()
            val manager = AppWidgetManager.getInstance(context)
            push(context, manager, manager.getAppWidgetIds(ComponentName(context, QuoteWidgetProvider::class.java)))
        }
    }

    companion object {
        private const val ACTION_REFRESH = "io.eazo.dailyquote.action.WIDGET_REFRESH"

        /** 应用内数据变动后主动同步所有桌面卡片。 */
        fun push(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            push(context, manager, manager.getAppWidgetIds(ComponentName(context, QuoteWidgetProvider::class.java)))
        }

        private fun push(context: Context, manager: AppWidgetManager, ids: IntArray) {
            if (ids.isEmpty()) return
            val repo = AppRepo.getRepo(context)
            val view = repo.today()
            val remote = RemoteViews(context.packageName, R.layout.widget_quote).apply {
                setTextViewText(R.id.widget_label, "今日一句 · ${repo.todayDisplay()}")
                setTextViewText(R.id.widget_quote_text, "「${view.quote.text}」")
                setTextViewText(R.id.widget_author, "—— ${view.quote.author}《${view.quote.source}》")
                setOnClickPendingIntent(
                    R.id.widget_root,
                    PendingIntent.getActivity(
                        context,
                        0,
                        Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                    ),
                )
                setOnClickPendingIntent(
                    R.id.widget_refresh,
                    PendingIntent.getBroadcast(
                        context,
                        1,
                        Intent(context, QuoteWidgetProvider::class.java).setAction(ACTION_REFRESH),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                    ),
                )
            }
            ids.forEach { manager.updateAppWidget(it, remote) }
        }
    }
}
