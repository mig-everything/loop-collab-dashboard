package io.eazo.dailyquote.core

import java.time.LocalDate

/**
 * 极简键值持久化抽象：core 层只依赖此接口，JVM 单测注入内存实现。
 */
interface KeyValueStore {
    fun getString(key: String): String?
    fun getStringSet(key: String): Set<String>?
    fun getInt(key: String, def: Int): Int

    fun putString(key: String, value: String)
    fun putStringSet(key: String, values: Set<String>)
    fun putInt(key: String, value: Int)
}

/**
 * 进程内唯一语录仓储（生成器硬规则①②的落点）。
 *
 * - 构造时一次性 load 持久化（收藏集合 / 当日 dayKey / 刷新偏移）；
 * - 之后一切读（list/today/favorites）只读内存态，绝不触发持久化 load；
 * - 一切写（toggleFavorite/refresh）先改内存再回写存储，跨页面即时可见。
 *
 * UI / 桌面卡片层一律经 platform.AppRepo.getRepo(context) 取单例，禁止直接构造。
 */
class QuoteRepository(
    private val store: KeyValueStore,
    private val clock: () -> LocalDate = { LocalDate.now() },
) {
    private val ordered: List<Quote> = QuoteSeed.ALL
    private val byIdMap: Map<String, Quote> = ordered.associateBy { it.id }
    private val favorites = mutableSetOf<String>()
    private var dayKey: String = ""
    private var refreshOffset: Int = 0

    init {
        favorites.addAll(store.getStringSet(KEY_FAVORITES).orEmpty())
        dayKey = store.getString(KEY_DAY) ?: ""
        refreshOffset = store.getInt(KEY_OFFSET, 0).coerceAtLeast(0)
    }

    val size: Int get() = ordered.size

    /** 全量内存态（确定性排序）。onResume 的 refresh 只走这里。 */
    fun list(): List<QuoteView> = ordered.map { QuoteView(it, it.id in favorites) }

    fun favorites(): List<QuoteView> = list().filter { it.favorite }

    fun byId(id: String): Quote? = byIdMap[id]

    fun isFavorite(id: String): Boolean = id in favorites

    /** 返回收藏后的新状态（true=已收藏）。写内存即时生效，并回写存储。 */
    fun toggleFavorite(id: String): Boolean {
        if (!favorites.add(id)) favorites.remove(id)
        store.putStringSet(KEY_FAVORITES, favorites)
        return id in favorites
    }

    /** 今日一句（当天多次调用结果稳定）。 */
    fun today(): QuoteView {
        ensureDay()
        return list()[slot()]
    }

    /** 刷新换一句：偏移 +1 并回写，同日跨页面/跨卡片一致。 */
    fun refresh(): QuoteView {
        ensureDay()
        refreshOffset += 1
        persistProgress()
        return list()[slot()]
    }

    /** 今日 dayKey（先 ensureDay，跨零点后自动翻转）。 */
    fun todayDayKey(): String {
        ensureDay()
        return dayKey
    }

    /** 今日展示文案（如「10月4日」）。 */
    fun todayDisplay(): String = DailyEngine.displayDay(clock())

    private fun ensureDay() {
        val nowKey = DailyEngine.dayKey(clock())
        if (dayKey != nowKey) {
            dayKey = nowKey
            refreshOffset = 0
            persistProgress()
        }
    }

    private fun slot(): Int = DailyEngine.slotIndex(dayKey, refreshOffset, ordered.size)

    private fun persistProgress() {
        store.putString(KEY_DAY, dayKey)
        store.putInt(KEY_OFFSET, refreshOffset)
    }

    companion object {
        const val KEY_FAVORITES = "favorites"
        const val KEY_DAY = "day"
        const val KEY_OFFSET = "refresh_offset"
    }
}
