package io.eazo.dailyquote.core

/**
 * 启动路由契约（生成器硬规则④）。
 *
 * 冷启动 onCreate(want) 与热启动 onNewIntent(want)（鸿蒙侧对位 onNewWant）两路
 * 必须走同一个 readOpenCreate 纯函数；布尔参数严格判定（对位鸿蒙
 * `typeof v === 'boolean' && v === true`）：仅接受真正的 Boolean true，
 * 字符串 "true" / 1 / null 一律为 false。
 */
object OpenContract {

    const val EXTRA_QUOTE_ID = "io.eazo.dailyquote.extra.QUOTE_ID"
    const val EXTRA_OPEN_FAVORITES = "io.eazo.dailyquote.extra.OPEN_FAVORITES"

    data class OpenSpec(
        val quoteId: String?,
        val openFavorites: Boolean,
    )

    fun strictTrue(value: Any?): Boolean = value is Boolean && value == true

    /**
     * 入参为 want/Intent extras 里读出的原始值（Any?），保持纯函数可 JVM 单测。
     * quoteId 仅接受非空白 String；openFavorites 仅接受严格 Boolean true。
     */
    fun readOpenCreate(quoteIdValue: Any?, openFavoritesValue: Any?): OpenSpec = OpenSpec(
        quoteId = (quoteIdValue as? String)?.takeIf { it.isNotBlank() },
        openFavorites = strictTrue(openFavoritesValue),
    )
}
