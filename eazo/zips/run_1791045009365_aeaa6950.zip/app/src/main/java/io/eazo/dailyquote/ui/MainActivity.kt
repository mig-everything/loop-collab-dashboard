package io.eazo.dailyquote.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.dailyquote.R
import io.eazo.dailyquote.core.OpenContract
import io.eazo.dailyquote.core.Quote
import io.eazo.dailyquote.core.QuoteView
import io.eazo.dailyquote.core.label
import io.eazo.dailyquote.platform.AppRepo
import io.eazo.dailyquote.widget.QuoteWidgetProvider

/**
 * 主界面：今日一句卡片 + 刷新/收藏/分享 + 收藏列表 + 详情。
 *
 * 生成器硬规则落点：
 * - ① 仓储一律 AppRepo.getRepo(context) 单例获取；
 * - ② onResume 只 refresh()（重读内存态 list()），绝无持久化 load；
 * - ④ 冷启动 onCreate(want) 与热启动 onNewIntent(want) 同走 readOpenCreate 纯函数。
 */
class MainActivity : ComponentActivity() {

    private val repo by lazy { AppRepo.getRepo(this) }

    private val snapshot = mutableStateOf<List<QuoteView>>(emptyList())
    private val page = mutableStateOf(Page.Home)
    private val detailId = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        applyWant(intent) // 冷启动路
        setContent { Root() }
        QuoteWidgetProvider.push(this) // 每次冷启动顺带刷新桌面卡片
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        applyWant(intent) // 热启动路（对位鸿蒙 onNewWant），同一 readOpenCreate
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    /** 硬规则②：只重读内存态 list()。 */
    private fun refresh() {
        snapshot.value = repo.list()
    }

    private fun applyWant(want: Intent?) {
        val extras = want?.extras
        val spec = OpenContract.readOpenCreate(
            extras?.get(OpenContract.EXTRA_QUOTE_ID),
            extras?.get(OpenContract.EXTRA_OPEN_FAVORITES),
        )
        detailId.value = spec.quoteId
        page.value = when {
            spec.openFavorites -> Page.Favorites
            spec.quoteId != null -> Page.Detail
            else -> Page.Home
        }
        refresh()
    }

    private fun doRefresh() {
        repo.refresh()
        refresh()
        QuoteWidgetProvider.push(this)
    }

    private fun doToggle(id: String) {
        repo.toggleFavorite(id)
        refresh()
    }

    private fun shareQuote(quote: Quote) {
        val text = "「${quote.text}」\n—— ${quote.author}《${quote.source}》\n来自「每日一句」"
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            putExtra(Intent.EXTRA_TITLE, quote.author)
        }
        startActivity(Intent.createChooser(send, getString(R.string.share_via)))
    }

    private enum class Page { Home, Favorites, Detail }

    // ---------- UI ----------

    @Composable
    private fun Root() {
        AppTheme {
            when (page.value) {
                Page.Home -> HomeScreen(
                    dateText = repo.todayDisplay(),
                    today = repo.today(),
                    favoriteCount = snapshot.value.count { it.favorite },
                    onFavorites = { page.value = Page.Favorites },
                    onRefresh = ::doRefresh,
                    onToggleFavorite = ::doToggle,
                    onShare = ::shareQuote,
                )
                Page.Favorites -> FavoritesScreen(
                    items = snapshot.value.filter { it.favorite },
                    onBack = { page.value = Page.Home },
                    onOpen = { id ->
                        detailId.value = id
                        page.value = Page.Detail
                    },
                    onToggle = ::doToggle,
                )
                Page.Detail -> {
                    val quote = detailId.value?.let { repo.byId(it) }
                    if (quote == null) {
                        HomeScreen(
                            dateText = repo.todayDisplay(),
                            today = repo.today(),
                            favoriteCount = snapshot.value.count { it.favorite },
                            onFavorites = { page.value = Page.Favorites },
                            onRefresh = ::doRefresh,
                            onToggleFavorite = ::doToggle,
                            onShare = ::shareQuote,
                        )
                    } else {
                        DetailScreen(
                            view = snapshot.value.firstOrNull { it.quote.id == quote.id }
                                ?: QuoteView(quote, repo.isFavorite(quote.id)),
                            onBack = { page.value = Page.Home },
                            onToggleFavorite = ::doToggle,
                            onShare = ::shareQuote,
                        )
                    }
                }
            }
        }
    }
}

// ---------- 主题 ----------

private val PaperTop = Color(0xFFF8F4EA)
private val PaperBottom = Color(0xFFEFE5D3)
private val CardSurface = Color(0xFFFFFDF8)
private val Ink = Color(0xFF2A2520)
private val InkSoft = Color(0xFF8A7F70)
private val Accent = Color(0xFFC4553F)
private val AccentSoft = Color(0xFFF4E3DB)
private val Hairline = Color(0xFFE8DECB)

@Composable
private fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Accent,
            background = PaperTop,
            surface = CardSurface,
            onBackground = Ink,
            onSurface = Ink,
            secondary = InkSoft,
            onSecondary = InkSoft,
        ),
    ) { content() }
}

private fun Modifier.paperBackground(): Modifier = background(
    Brush.verticalGradient(listOf(PaperTop, PaperBottom))
)

// ---------- 首页 ----------

@Composable
private fun HomeScreen(
    dateText: String,
    today: QuoteView?,
    favoriteCount: Int,
    onFavorites: () -> Unit,
    onRefresh: () -> Unit,
    onToggleFavorite: (String) -> Unit,
    onShare: (Quote) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .paperBackground()
            .systemBarsPadding()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "每日一句",
                    color = Accent,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp,
                )
                Spacer(Modifier.height(2.dp))
                Text(dateText, color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            BadgedBox(
                badge = {
                    if (favoriteCount > 0) Badge { Text("$favoriteCount") }
                },
            ) {
                Surface(
                    shape = CircleShape,
                    color = AccentSoft,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .clickable(onClick = onFavorites),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Filled.FavoriteBorder,
                            contentDescription = "我的收藏",
                            tint = Accent,
                            modifier = Modifier.size(20.dp),
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        today?.let { QuoteCard(it) }
        Spacer(Modifier.height(32.dp))
        ActionRow(
            view = today,
            onRefresh = onRefresh,
            onToggleFavorite = onToggleFavorite,
            onShare = onShare,
        )
        Spacer(Modifier.height(24.dp))
    }
}

/** 精排卡片：大引号 + 衬线正文 + 细分隔线 + 作者/出处/类型章。 */
@Composable
private fun QuoteCard(view: QuoteView, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(26.dp),
        color = CardSurface,
        shadowElevation = 8.dp,
        border = BorderStroke(1.dp, Hairline),
        modifier = modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(horizontal = 24.dp, vertical = 26.dp)) {
            Text(
                "“",
                color = Accent.copy(alpha = 0.85f),
                fontSize = 54.sp,
                fontFamily = FontFamily.Serif,
                lineHeight = 54.sp,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                view.quote.text,
                color = Ink,
                fontSize = 23.sp,
                lineHeight = 38.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(20.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Hairline),
            )
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(50), color = AccentSoft) {
                    Text(
                        "  ${view.quote.type.label}  ",
                        color = Accent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
                Spacer(Modifier.size(10.dp))
                Text(
                    "${view.quote.author} · 《${view.quote.source}》",
                    color = InkSoft,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun ActionRow(
    view: QuoteView?,
    onRefresh: () -> Unit,
    onToggleFavorite: (String) -> Unit,
    onShare: (Quote) -> Unit,
) {
    val active = view?.favorite == true
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        ActionButton(Icons.Filled.Refresh, "刷新") { onRefresh() }
        ActionButton(
            icon = if (active) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            label = if (active) "已收藏" else "收藏",
            active = active,
            enabled = view != null,
        ) { view?.let { onToggleFavorite(it.quote.id) } }
        ActionButton(Icons.Filled.Share, "分享", enabled = view != null) {
            view?.let { onShare(it.quote) }
        }
    }
}

@Composable
private fun ActionButton(
    icon: ImageVector,
    label: String,
    active: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(10.dp),
    ) {
        Surface(shape = CircleShape, color = if (active) Accent else AccentSoft) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(54.dp)) {
                Icon(
                    icon,
                    contentDescription = label,
                    tint = if (active) Color.White else Accent,
                    modifier = Modifier.size(22.dp),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = if (active) Accent else InkSoft, fontSize = 12.sp)
    }
}

// ---------- 收藏列表 ----------

@Composable
private fun FavoritesScreen(
    items: List<QuoteView>,
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    onToggle: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .paperBackground()
            .systemBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(Icons.AutoMirrored.Filled.ArrowBack, "返回", onBack)
            Spacer(Modifier.size(8.dp))
            Text("我的收藏", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        if (items.isEmpty()) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
            ) {
                Text("“", color = Hairline, fontSize = 64.sp, fontFamily = FontFamily.Serif)
                Spacer(Modifier.height(8.dp))
                Text("还没有收藏", color = InkSoft, fontSize = 15.sp)
                Spacer(Modifier.height(6.dp))
                Text("点亮卡片下方的爱心，把心动留下来", color = InkSoft, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f),
            ) {
                items(items, key = { it.quote.id }) { view ->
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = CardSurface,
                        border = BorderStroke(1.dp, Hairline),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpen(view.quote.id) },
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    view.quote.text,
                                    color = Ink,
                                    fontSize = 15.sp,
                                    fontFamily = FontFamily.Serif,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    lineHeight = 23.sp,
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "${view.quote.author} · 《${view.quote.source}》",
                                    color = InkSoft,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            Spacer(Modifier.size(8.dp))
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .clickable { onToggle(view.quote.id) },
                            ) {
                                Icon(
                                    Icons.Filled.Favorite,
                                    contentDescription = "取消收藏",
                                    tint = Accent,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ---------- 详情 ----------

@Composable
private fun DetailScreen(
    view: QuoteView,
    onBack: () -> Unit,
    onToggleFavorite: (String) -> Unit,
    onShare: (Quote) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .paperBackground()
            .systemBarsPadding()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(Icons.AutoMirrored.Filled.ArrowBack, "返回", onBack)
            Spacer(Modifier.size(8.dp))
            Text("语录详情", color = Ink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(28.dp))
        QuoteCard(view)
        Spacer(Modifier.height(32.dp))
        ActionRow(
            view = view,
            onRefresh = {},
            onToggleFavorite = onToggleFavorite,
            onShare = onShare,
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun IconButton(icon: ImageVector, contentDescription: String, onClick: () -> Unit) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
    ) {
        Icon(
            icon,
            contentDescription = contentDescription,
            tint = Ink,
            modifier = Modifier.size(22.dp),
        )
    }
}
