package io.eazo.dailyquote.core

import java.time.LocalDate
import java.util.Locale

/**
 * 按日期索引的确定性调度引擎（纯函数，无状态）。
 *
 * 算法口径双端 1:1：
 * - dayKey = "yyyy-MM-dd"（Locale.ROOT 四位年两位月日）；
 * - baseIndex = FNV-1a 32（offset basis 0x811C9DC5，prime 0x01000193，按 UTF-16 码元迭代）
 *   的无符号值 % size；
 * - slotIndex = (baseIndex + 规范化后的 refreshOffset) % size，offset 先折到 [0, size)。
 */
object DailyEngine {

    fun dayKey(date: LocalDate): String =
        String.format(Locale.ROOT, "%04d-%02d-%02d", date.year, date.monthValue, date.dayOfMonth)

    fun displayDay(date: LocalDate): String = "${date.monthValue}月${date.dayOfMonth}日"

    fun fnv1a(value: String): Int {
        var hash = 0x811C9DC5.toInt() // FNV-1a 32 offset basis（字面量超 Int 范围，截位取低 32 位）
        for (c in value) {
            hash = hash xor c.code
            hash *= 0x01000193
        }
        return hash
    }

    fun baseIndex(dayKey: String, size: Int): Int {
        require(size > 0) { "size must be positive" }
        return ((fnv1a(dayKey).toLong() and 0xFFFFFFFFL) % size).toInt()
    }

    fun slotIndex(dayKey: String, refreshOffset: Int, size: Int): Int {
        require(size > 0) { "size must be positive" }
        val base = baseIndex(dayKey, size)
        val offset = ((refreshOffset % size) + size) % size
        return (base + offset) % size
    }
}
