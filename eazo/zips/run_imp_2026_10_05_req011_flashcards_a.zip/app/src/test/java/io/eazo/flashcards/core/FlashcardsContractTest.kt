package io.eazo.flashcards.core

import io.eazo.flashcards.model.CardState
import io.eazo.flashcards.model.Quality
import io.eazo.flashcards.model.StudyStats
import io.eazo.flashcards.platform.StudySession
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

/**
 * REQ-011 契约双端单测(Android 基线侧)。
 * 期望值全部取 scripts/gen_vocab_constants.py 本机重算锚点(seed/sm2-anchors.json,经验 8,禁手抄):
 *   词库哈希 15a89fb260e0d594eac28629a6ad738e0a2b5a097ff5a9e283877247d8d46b74 / 2619 bytes
 * SM-2 口径:EF2=EF×100(默认 250/下限 130),I(2)=6,半进位整数除法,q<3 重置。
 * 鸿蒙 Hypium 侧将按同一锚点集 1:1 对齐(同集同期望)。
 */
class FlashcardsContractTest {

    // ---------- §1 词库数据面哈希锁(AC-S3) ----------

    /** 用例 1:规范序列化 SHA-256 全量锁(30 条,2619 bytes)。 */
    @Test fun `case1_vocab_canonical_sha256_lock`() {
        val canonical = VocabConstants.WORDS.joinToString("\n") {
            "${it.id}|${it.word}|${it.phonetic}|${it.definition}|${it.example}"
        }
        assertEquals(VocabConstants.CANONICAL_BYTES, canonical.toByteArray(Charsets.UTF_8).size)
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { b -> "%02x".format(b) }
        assertEquals("15a89fb260e0d594eac28629a6ad738e0a2b5a097ff5a9e283877247d8d46b74", digest)
        assertEquals(VocabConstants.CANONICAL_SHA256, digest)
    }

    /** 用例 2:词库条数与 id 序(1..30 连续升序,防漏条/乱序)。 */
    @Test fun `case2_vocab_count_and_id_order`() {
        assertEquals(30, VocabConstants.COUNT)
        assertEquals(30, VocabConstants.WORDS.size)
        assertEquals((1..30).toList(), VocabConstants.WORDS.map { it.id })
        // 首末条内容锚点(错 1 字即 FAIL)
        assertEquals("abandon", VocabConstants.WORDS.first().word)
        assertEquals("/əˈbændən/", VocabConstants.WORDS.first().phonetic)
        assertEquals("curious", VocabConstants.WORDS.last().word)
        assertEquals("The curious child asked many questions.", VocabConstants.WORDS.last().example)
    }

    /** 用例 3:关键字段抽查(中间条 15 budget / 18 challenge,双端逐字符对账)。 */
    @Test fun `case3_vocab_spot_fields`() {
        val b = VocabConstants.WORDS[14]
        assertEquals(15, b.id); assertEquals("budget", b.word)
        assertEquals("/ˈbʌdʒɪt/", b.phonetic); assertEquals("n. 预算 v. 编预算", b.definition)
        assertEquals("We finished the project under budget.", b.example)
        val c = VocabConstants.WORDS[17]
        assertEquals(18, c.id); assertEquals("challenge", c.word)
        assertEquals("/ˈtʃælɪndʒ/", c.phonetic)
    }

    // ---------- §2 SM-2 调度锚点(AC-S2,数值全部取 sm2-anchors.json) ----------

    private fun st(rep: Int, ef2: Int, iv: Int, due: Int) = CardState(rep, ef2, iv, due)
    private fun assertState(exp: List<Int>, actual: CardState) {
        assertEquals(exp[0], actual.repetitions)
        assertEquals(exp[1], actual.ef2)
        assertEquals(exp[2], actual.interval)
        assertEquals(exp[3], actual.dueDay)
    }

    /** 用例 4:A1 新卡 q3 → [1, 236, 1, 101]。 */
    @Test fun `case4_sm2_newcard_good`() {
        assertState(listOf(1, 236, 1, 101), Sm2.next(st(0, 250, 0, 0), Quality.GOOD, 100))
    }

    /** 用例 5:A1 新卡 q2(困难,q<3 不计连击)→ [0, 218, 1, 101]。 */
    @Test fun `case5_sm2_newcard_hard_resets`() {
        assertState(listOf(0, 218, 1, 101), Sm2.next(st(0, 250, 0, 0), Quality.HARD, 100))
    }

    /** 用例 6:A1 新卡 q5 → [1, 260, 1, 101]。 */
    @Test fun `case6_sm2_newcard_easy`() {
        assertState(listOf(1, 260, 1, 101), Sm2.next(st(0, 250, 0, 0), Quality.EASY, 100))
    }

    /** 用例 7:A2 连续良好 q3×3 → [1,236,1,101]→[2,222,6,107]→[3,208,13,120](I(2)=6 锚点)。 */
    @Test fun `case7_sm2_chain_good_x3`() {
        var s = st(0, 250, 0, 0)
        var t = 100
        val expected = listOf(
            listOf(1, 236, 1, 101),
            listOf(2, 222, 6, 107),
            listOf(3, 208, 13, 120),
        )
        for (e in expected) {
            s = Sm2.next(s, Quality.GOOD, t)
            assertState(e, s)
            t = s.dueDay
        }
    }

    /** 用例 8:A3 简单链 q5×3(EF 每步 +10)→ [1,260,1,101]→[2,270,6,107]→[3,280,16,123]。 */
    @Test fun `case8_sm2_chain_easy_x3`() {
        var s = st(0, 250, 0, 0)
        var t = 100
        val expected = listOf(
            listOf(1, 260, 1, 101),
            listOf(2, 270, 6, 107),
            listOf(3, 280, 16, 123),
        )
        for (e in expected) {
            s = Sm2.next(s, Quality.EASY, t)
            assertState(e, s)
            t = s.dueDay
        }
    }

    /** 用例 9:A4 忘记重置链 q3,q3,q0,q3 → 重置 rep=0/interval=1,EF 继续演化。 */
    @Test fun `case9_sm2_forget_resets_then_restart`() {
        var s = st(0, 250, 0, 0)
        var t = 100
        val expected = listOf(
            listOf(1, 236, 1, 101),
            listOf(2, 222, 6, 107),
            listOf(0, 142, 1, 108),
            listOf(1, 130, 1, 109),
        )
        for ((i, e) in expected.withIndex()) {
            val q = listOf(Quality.GOOD, Quality.GOOD, Quality.FORGET, Quality.GOOD)[i]
            s = Sm2.next(s, q, t)
            assertState(e, s)
            t = s.dueDay
        }
    }

    /** 用例 10:A5 EF 下限 130 粘住(200 起两次 q0:200-80→130 钳;130-80→130 粘住)。 */
    @Test fun `case10_sm2_ef_floor_130_sticky`() {
        var s = st(3, 200, 10, 50)
        s = Sm2.next(s, Quality.FORGET, 100)
        assertState(listOf(0, 130, 1, 101), s)
        s = Sm2.next(s, Quality.FORGET, s.dueDay)
        assertState(listOf(0, 130, 1, 102), s)
    }

    /** 用例 11:A6 老卡增长 rep=3,ef2=250,interval=7 → q3 → [4, 236, 18, 118](半进位 (7*250+50)/100=18)。 */
    @Test fun `case11_sm2_mature_growth_halfup`() {
        assertState(listOf(4, 236, 18, 118), Sm2.next(st(3, 250, 7, 50), Quality.GOOD, 100))
    }

    /** 用例 12:同输入同输出(确定性,3 次调用逐字段一致,AC-S2 无随机)。 */
    @Test fun `case12_sm2_deterministic_repeat`() {
        val s0 = st(2, 244, 6, 90)
        val a = Sm2.next(s0, Quality.GOOD, 100)
        val b = Sm2.next(s0, Quality.GOOD, 100)
        val c = Sm2.next(s0, Quality.GOOD, 100)
        assertEquals(a, b); assertEquals(b, c)
    }

    // ---------- §3 翻转/收藏/统计/队列(AC-S1/S4/S5) ----------

    /** 用例 13:flip 纯函数 front↔back 往返。 */
    @Test fun `case13_flip_roundtrip`() {
        assertEquals("back", FlashcardLogic.flip("front"))
        assertEquals("front", FlashcardLogic.flip("back"))
        assertEquals("front", FlashcardLogic.flip(FlashcardLogic.flip("front")))
    }

    /** 用例 14:toggleFavorite 布尔翻转。 */
    @Test fun `case14_toggle_favorite`() {
        assertFalse(FlashcardLogic.toggleFavorite(true))
        assertTrue(FlashcardLogic.toggleFavorite(false))
    }

    /** 用例 15:stats 纯函数逐字段(learned=rep>0 / dueToday=dueDay<=today / mastered=interval>=21 / favorite)。 */
    @Test fun `case15_stats_fields`() {
        val states = mapOf(
            1 to st(0, 250, 0, 0),    // 新卡:due 0<=100 计 dueToday,不计 learned
            2 to st(1, 236, 1, 101),  // 学过:learned;due 101>100 不计 dueToday
            3 to st(3, 208, 13, 120), // 学过:learned
            4 to st(4, 236, 18, 118), // 学过
            5 to st(5, 280, 21, 140), // 学过 + mastered(21>=21)
            6 to st(2, 250, 6, 50),   // 学过 + dueToday(50<=100)
        )
        val favs = setOf(3, 6)
        val s = FlashcardLogic.stats(states, favs, today = 100)
        assertEquals(6, s.total)
        assertEquals(5, s.learned)
        assertEquals(2, s.dueToday)
        assertEquals(1, s.mastered)
        assertEquals(2, s.favorite)
    }

    /** 用例 16:sessionQueue 确定性(到期按 (dueDay,id) 升序;无到期取新卡 id 升序)。 */
    @Test fun `case16_session_queue_deterministic`() {
        // 全部 dueDay=0(新卡):按 (dueDay=0, id) 升序取前 10
        val fresh = (1..30).associateWith { st(0, 250, 0, 0) }
        assertEquals((1..10).toList(), FlashcardLogic.sessionQueue(fresh, today = 100))
        // 混合:27 张已学未到期(due 200),2/5/9 到期(due 100/50/80)→ 仅到期卡按 dueDay 升序 [5,9,2]
        val mixed = (1..30).associateWith { st(3, 250, 13, 200) }.toMutableMap()
        mixed[2] = st(1, 250, 1, 100)
        mixed[5] = st(1, 250, 1, 50)
        mixed[9] = st(1, 250, 1, 80)
        assertEquals(listOf(5, 9, 2), FlashcardLogic.sessionQueue(mixed, today = 100))
        // 全部未到期且无新卡(都学过)→ 按 id 升序兜底
        val allLearned = (1..5).associateWith { st(3, 250, 13, 200) }
        assertEquals(listOf(1, 2, 3, 4, 5), FlashcardLogic.sessionQueue(allLearned, today = 100))
    }

    /** 用例 17:全链路——同词库同评分序列 → 同调度状态序列(30 卡 q3 全评一轮后的统计)。 */
    @Test fun `case17_full_session_30_cards_all_good`() {
        var states = (1..30).associateWith { CardState() }
        val t = 100
        for (id in 1..30) {
            states = states.toMutableMap().apply {
                put(id, Sm2.next(getValue(id), Quality.GOOD, t))
            } as Map<Int, CardState>
        }
        val s = FlashcardLogic.stats(states, emptySet(), today = 100)
        assertEquals(30, s.total)
        assertEquals(30, s.learned)   // 全部 rep=1
        assertEquals(0, s.dueToday)   // 全部 due=101 > 100
        assertEquals(0, s.mastered)   // interval=1 < 21
        assertEquals(0, s.favorite)
        // 全部调度状态逐字段一致(锚点:每张卡都应为 [1,236,1,101])
        states.values.forEach { assertState(listOf(1, 236, 1, 101), it) }
    }

    /** 用例 18:StudySession 集成——startSession 后 gradeCurrent 推进,收藏序稳定。 */
    @Test fun `case18_study_session_integration`() {
        StudySession.startSession(100, 10)
        assertEquals(1, StudySession.currentCardId)
        assertEquals(30, StudySession.allCards.size)
        StudySession.gradeCurrent(Quality.EASY, 100)
        assertEquals(2, StudySession.currentCardId)
        StudySession.toggleFavoriteCurrent()
        assertTrue(StudySession.isFavorite(2))
        StudySession.toggleFavoriteCurrent()
        assertFalse(StudySession.isFavorite(2))
        val stats = StudySession.stats(100)
        assertEquals(1, stats.learned)
        assertEquals(30, stats.total)
    }

    // ====================================================================
    // IPD-281 TR-Accept 差分回补(IPD-275 断言集缺口 4 处,DoD-1):
    //   ①A09/A11  ②S01~S07(契约 §6.2 十卡构造集)  ③J01~J12(五日旅程)
    //   ④F03(收藏列表 id 升序显式断言)
    // 期望值全部经 Tester 第三实现复算机程序化复算(docs/test/req011/
    // machine_recheck.json 54/54 PASS,探针 /tmp/req011_gap_probe.py 同步复算),
    // 与契约 1e38154 冻结值逐条一致,禁手抄(经验 8)。
    // ====================================================================

    /** 用例 19(F03):favoriteList 按 id 升序稳定输出,与收藏时间无关。 */
    @Test fun `case19_f03_favorite_list_sorted_by_id`() {
        // F3 锚点:favoriteList({5,3,9,1}) == [1,3,5,9](插入序无关)
        val favs = linkedSetOf(5, 3, 9, 1)
        assertEquals(listOf(1, 3, 5, 9), FlashcardLogic.favoriteList(favs))
        // StudySession.favoriteCards 同口径(收藏列表页数据源)
        StudySession.favorites.clear()
        StudySession.favorites.addAll(listOf(5, 3, 9, 1))
        assertEquals(listOf(1, 3, 5, 9), StudySession.favoriteCards().map { it.id })
    }

    /** 用例 20(A09 / A7):rep>=3 且 q5——(3,270,6,107)@107 q5 → (4,280,16,123)。 */
    @Test fun `case20_a09_mature_q5_growth`() {
        assertState(
            listOf(4, 280, 16, 123),
            Sm2.next(st(3, 270, 6, 107), Quality.EASY, 107),
        )
    }

    /** 用例 21(A11):today 平移不变——前 3 字段不变,dueDay 随 today 平移(注入语义)。 */
    @Test fun `case21_a11_today_shift_invariant`() {
        val a = Sm2.next(st(1, 236, 1, 101), Quality.GOOD, 100)
        val b = Sm2.next(st(1, 236, 1, 101), Quality.GOOD, 200)
        assertEquals(a.repetitions, b.repetitions)
        assertEquals(a.ef2, b.ef2)
        assertEquals(a.interval, b.interval)
        assertEquals(106, a.dueDay)
        assertEquals(206, b.dueDay)
        assertEquals(100, b.dueDay - a.dueDay) // 平移量 == today 差
    }

    /** 契约 §6.2 十卡构造集(S01~S07 共用)。 */
    private fun contractTenCards(): Map<Int, CardState> = mapOf(
        1 to st(1, 260, 1, 100),
        2 to st(2, 246, 6, 94),
        3 to st(3, 246, 14, 100),
        4 to st(0, 250, 0, 0),
        5 to st(0, 250, 0, 0),
        6 to st(5, 260, 30, 200),
        14 to st(5, 260, 30, 200),
        7 to st(4, 246, 21, 60),
        8 to st(3, 260, 25, 50),
        9 to st(3, 260, 25, 70),
    )

    /** 用例 22(S01):十卡构造集 stats 五字段全口径(99 不在 states 仍计 favorite)。 */
    @Test fun `case22_s01_stats_ten_card_set`() {
        val s = FlashcardLogic.stats(contractTenCards(), setOf(3, 6, 99), today = 100)
        assertEquals(10, s.total)
        assertEquals(8, s.learned)
        assertEquals(8, s.dueToday)
        assertEquals(5, s.mastered)
        assertEquals(3, s.favorite)
    }

    /** 用例 23(S02/S03):(dueDay,id) 升序队列 + limit 截取不改排序。 */
    @Test fun `case23_s02_s03_queue_due_then_id_order`() {
        assertEquals(
            listOf(4, 5, 8, 7, 9, 2, 1, 3),
            FlashcardLogic.sessionQueue(contractTenCards(), today = 100),
        )
        assertEquals(
            listOf(4, 5, 8),
            FlashcardLogic.sessionQueue(contractTenCards(), today = 100, limit = 3),
        )
    }

    /** 用例 24(S04/S05/S06):无 due 全 id 兜底 / dueDay 主键优先 / fresh 防御路径。 */
    @Test fun `case24_s04_s05_s06_queue_fallback_paths`() {
        // S04:无 due 无 fresh → 全 id 升序兜底
        val noDue = mapOf(2 to st(1, 260, 1, 999), 1 to st(1, 260, 1, 999), 3 to st(1, 260, 1, 999))
        assertEquals(listOf(1, 2, 3), FlashcardLogic.sessionQueue(noDue, today = 100))
        // S05:dueDay 主键优先于 id(新卡 0,0 恒最前)
        val mixed = mapOf(
            1 to st(1, 260, 1, 100), 3 to st(1, 260, 1, 100),
            4 to st(0, 250, 0, 0), 5 to st(0, 250, 0, 0),
        )
        assertEquals(listOf(4, 5, 1, 3), FlashcardLogic.sessionQueue(mixed, today = 100))
        // S06:fresh 防御路径(理论不可达:dueDay=0<=today 必入 due;此处构造 dueDay=200 的新卡验证)
        val freshDef = mapOf(
            3 to st(1, 260, 1, 200), 1 to st(0, 250, 0, 200), 2 to st(0, 250, 0, 200),
        )
        assertEquals(listOf(1, 2), FlashcardLogic.sessionQueue(freshDef, today = 100))
    }

    /** 用例 25(S07):mastered 边界——I=20 否 / I=21 是(>=21,变异 >21 被 CAUGHT)。 */
    @Test fun `case25_s07_mastered_boundary_21`() {
        val s20 = FlashcardLogic.stats(mapOf(1 to st(1, 250, 20, 100)), emptySet(), today = 100)
        val s21 = FlashcardLogic.stats(mapOf(1 to st(1, 250, 21, 100)), emptySet(), today = 100)
        assertEquals(0, s20.mastered)
        assertEquals(1, s21.mastered)
    }

    /**
     * 用例 26~29(J01~J12):五日旅程主锚(契约 §6.3,AC-S8 机器判定主锚)。
     * 30 卡全初始,day100~104 每日 sessionQueue(limit=10) → 奇 id=GOOD/偶 id=EASY → sm2;
     * day101 收藏 {1,2}。单测内模拟循环,禁真系统时钟(today 注入)。
     */
    private fun runJourney(): Triple<Map<Int, List<Int>>, Map<Int, StudyStats>, Map<Int, CardState>> {
        var states = (1..30).associateWith { CardState() }
        val favorites = LinkedHashSet<Int>()
        val queues = mutableMapOf<Int, List<Int>>()
        val statsMap = mutableMapOf<Int, StudyStats>()
        for (day in 100..104) {
            val q = FlashcardLogic.sessionQueue(states, day, 10)
            queues[day] = q
            for (cid in q) {
                val cur = states.getValue(cid)
                states = states.toMutableMap().apply {
                    put(cid, Sm2.next(cur, if (cid % 2 == 1) Quality.GOOD else Quality.EASY, day))
                }
            }
            if (day == 101) { favorites.add(1); favorites.add(2) }
            statsMap[day] = FlashcardLogic.stats(states, favorites, day)
        }
        return Triple(queues, statsMap, states)
    }

    /** 用例 26(J01~J05):逐日队列——新卡优先引入(day101 取 11..20 而非到期卡 1..10)。 */
    @Test fun `case26_j01_j05_journey_daily_queues`() {
        val (queues, _, _) = runJourney()
        assertEquals((1..10).toList(), queues[100])   // J01
        assertEquals((11..20).toList(), queues[101])  // J02 ★新卡优先引入
        assertEquals((21..30).toList(), queues[102])  // J03
        assertEquals((1..10).toList(), queues[103])   // J04 最旧到期批先复习
        assertEquals((11..20).toList(), queues[104])  // J05
    }

    /** 用例 27(J06~J10):逐日 stats 五字段。 */
    @Test fun `case27_j06_j10_journey_daily_stats`() {
        val (_, statsMap, _) = runJourney()
        fun assertStats(day: Int, total: Int, learned: Int, due: Int, mastered: Int, fav: Int) {
            val s = statsMap.getValue(day)
            assertEquals("total@$day", total, s.total)
            assertEquals("learned@$day", learned, s.learned)
            assertEquals("dueToday@$day", due, s.dueToday)
            assertEquals("mastered@$day", mastered, s.mastered)
            assertEquals("favorite@$day", fav, s.favorite)
        }
        assertStats(100, 30, 10, 20, 0, 0)  // J06
        assertStats(101, 30, 20, 20, 0, 2)  // J07
        assertStats(102, 30, 30, 20, 0, 2)  // J08
        assertStats(103, 30, 30, 20, 0, 2)  // J09
        assertStats(104, 30, 30, 10, 0, 2)  // J10
    }

    /** 用例 28(J11):终态 30 行规范序列化 SHA-256 主锚(任何调度分叉必炸)。 */
    @Test fun `case28_j11_journey_final_state_sha256_lock`() {
        val (_, _, states) = runJourney()
        val canonical = states.keys.sorted().joinToString("\n") { id ->
            val s = states.getValue(id)
            "$id:${s.repetitions},${s.ef2},${s.interval},${s.dueDay}"
        }
        val bytes = canonical.toByteArray(Charsets.UTF_8)
        assertEquals(440, bytes.size)
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(bytes).joinToString("") { b -> "%02x".format(b) }
        assertEquals("e999bc73d56c51f8409707ac16436dd3b092acff72ac1314e3877d24511922fb", digest)
    }

    /** 用例 29(J12):幂等重放一致——同一 journey 连跑 2 次终态哈希与字节数一致。 */
    @Test fun `case29_j12_journey_idempotent_replay`() {
        fun finalCanonical(): Pair<String, Int> {
            val (_, _, states) = runJourney()
            val canonical = states.keys.sorted().joinToString("\n") { id ->
                val s = states.getValue(id)
                "$id:${s.repetitions},${s.ef2},${s.interval},${s.dueDay}"
            }
            val bytes = canonical.toByteArray(Charsets.UTF_8)
            val digest = MessageDigest.getInstance("SHA-256")
                .digest(bytes).joinToString("") { b -> "%02x".format(b) }
            return Pair(digest, bytes.size)
        }
        val first = finalCanonical()
        val second = finalCanonical()
        assertEquals(first, second)
        assertEquals(440, first.second)
    }
}
