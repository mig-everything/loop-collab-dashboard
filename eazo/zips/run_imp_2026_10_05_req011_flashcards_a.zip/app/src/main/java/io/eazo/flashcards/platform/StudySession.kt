package io.eazo.flashcards.platform

import io.eazo.flashcards.core.FlashcardLogic
import io.eazo.flashcards.core.Sm2
import io.eazo.flashcards.core.VocabConstants
import io.eazo.flashcards.model.CardState
import io.eazo.flashcards.model.StudyStats

/**
 * REQ-011 单例学习会话(页面唯一数据源,承 REQ-010 GameSession 范式)。
 * 「今天」由外部注入(dayIndex),核心调度不读系统时钟——确定性可注入、可回放。
 */
object StudySession {

    val allCards = VocabConstants.WORDS

    /** 卡片调度状态(id → state),初始:全部 CardState()。 */
    val states: MutableMap<Int, CardState> =
        VocabConstants.WORDS.associate { it.id to CardState() }.toMutableMap()

    /** 收藏集合(收藏序稳定:LinkedHashSet 保持插入序)。 */
    val favorites: LinkedHashSet<Int> = LinkedHashSet()

    /** 当前 session 队列与游标。 */
    private var queue: List<Int> = emptyList()
    private var cursor: Int = 0

    val currentCardId: Int get() = queue.getOrElse(cursor) { -1 }
    val currentCard: VocabConstants.WordCard?
        get() = allCards.firstOrNull { it.id == currentCardId }

    val remaining: Int get() = (queue.size - cursor).coerceAtLeast(0)

    /** 词库哈希锁暴露(供 UI「数据完整性」角标与单测断言)。 */
    fun vocabSha256(): String = VocabConstants.CANONICAL_SHA256

    /** 开启一轮学习:queue = sessionQueue(states, today, 10)。 */
    fun startSession(today: Int, limit: Int = 10) {
        queue = FlashcardLogic.sessionQueue(states, today, limit)
        cursor = 0
    }

    /** 对当前卡评分(忘记/困难/良好/简单),推进游标。 */
    fun gradeCurrent(quality: Int, today: Int) {
        val id = currentCardId
        if (id < 0) return
        val cur = states[id] ?: CardState()
        states[id] = Sm2.next(cur, quality, today)
        cursor++
    }

    /** 收藏/取消收藏当前卡。 */
    fun toggleFavoriteCurrent(): Boolean {
        val id = currentCardId
        if (id < 0) return false
        return if (favorites.contains(id)) {
            favorites.remove(id)
            false
        } else {
            favorites.add(id)
            true
        }
    }

    fun isFavorite(id: Int): Boolean = favorites.contains(id)

    /** 统计(纯函数透传)。 */
    fun stats(today: Int): StudyStats = FlashcardLogic.stats(states, favorites, today)

    /** 收藏列表(按 id 升序稳定输出,契约 §4 favoriteList;与收藏时间无关,F03 锚点)。 */
    fun favoriteCards(): List<VocabConstants.WordCard> =
        FlashcardLogic.favoriteList(favorites)
            .mapNotNull { fid -> allCards.firstOrNull { it.id == fid } }
}
