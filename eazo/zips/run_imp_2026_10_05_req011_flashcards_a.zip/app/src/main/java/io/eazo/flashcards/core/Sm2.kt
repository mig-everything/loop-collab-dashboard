package io.eazo.flashcards.core

import io.eazo.flashcards.model.CardState

/**
 * REQ-011 SM-2 间隔重复调度(纯函数,零随机/零系统时钟——today 由调用方注入)。
 * 口径与 scripts/gen_vocab_constants.py sm2_prev 100% 一致(锚点见 seed/sm2-anchors.json):
 *   q<3: rep=0, interval=1
 *   else: rep+1; rep==1→1; rep==2→6; rep>=3→max(1,(interval*ef2+50)/100)
 *   EF2' = max(130, EF2 + (10 - (5-q)*(8 + (5-q)*2)))
 *   dueDay = today + interval
 */
object Sm2 {

    fun next(state: CardState, quality: Int, today: Int): CardState {
        val rep = state.repetitions
        val ef2 = state.ef2
        val interval = state.interval
        val newRep: Int
        val newInterval: Int
        if (quality < 3) {
            newRep = 0
            newInterval = 1
        } else {
            newRep = rep + 1
            newInterval = when (newRep) {
                1 -> 1
                2 -> 6
                else -> maxOf(1, (interval * ef2 + 50) / 100)
            }
        }
        val delta = 10 - (5 - quality) * (8 + (5 - quality) * 2)
        val newEf2 = maxOf(130, ef2 + delta)
        return CardState(newRep, newEf2, newInterval, today + newInterval)
    }
}
