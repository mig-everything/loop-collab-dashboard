package io.eazo.flashcards.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.flashcards.model.Quality
import io.eazo.flashcards.model.StudyStats
import io.eazo.flashcards.platform.StudySession

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF6F4EF)) {
                    FlashcardsApp()
                }
            }
        }
    }
}

private enum class Screen { Home, Study, Favorites }

@Composable
fun FlashcardsApp() {
    // 确定性「今天」:dayIndex = 自 2026-01-01 起的天数,纯整数注入核心调度(UI 层才触系统时钟)。
    val today = remember {
        val now = java.time.LocalDate.now().toEpochDay()
        val epoch2026 = java.time.LocalDate.of(2026, 1, 1).toEpochDay()
        (now - epoch2026).toInt()
    }
    var screen by rememberSaveable { mutableStateOf(Screen.Home) }
    var version by remember { mutableIntStateOf(0) }
    val stats = StudySession.stats(today) // 读 session 真值,version 变化触发本作用域重建,stats 随之刷新

    Column(modifier = Modifier.fillMaxSize()) {
        Header(stats) {
            screen = when (screen) {
                Screen.Home -> Screen.Favorites
                else -> Screen.Home
            }
        }
        when (val s = screen) {
            Screen.Home -> HomeScreen(today, onStart = { screen = Screen.Study })
            Screen.Study -> StudyScreen(today, version, onExit = { screen = Screen.Home }, onTick = { version++ })
            Screen.Favorites -> FavoritesScreen()
        }
    }
}

@Composable
fun Header(stats: StudyStats, onToggleFav: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF1F6F5C))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text("背单词闪卡", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                "已学 ${stats.learned}/${stats.total} · 待复习 ${stats.dueToday} · 已掌握 ${stats.mastered} · 收藏 ${stats.favorite}",
                color = Color(0xFFD3E8DF), fontSize = 12.sp,
            )
        }
        Text(
            "收藏",
            color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier
                .clickable { onToggleFav() }
                .padding(horizontal = 8.dp, vertical = 4.dp),
        )
    }
}

@Composable
fun HomeScreen(today: Int, onStart: () -> Unit) {
    val stats = StudySession.stats(today)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("今日学习", fontSize = 16.sp, color = Color(0xFF5A6B66))
        Text(
            "${stats.dueToday}",
            fontSize = 64.sp, fontWeight = FontWeight.Black, color = Color(0xFF1F6F5C),
        )
        Text("张卡片等待复习", fontSize = 14.sp, color = Color(0xFF5A6B66))
        Spacer(Modifier.height(28.dp))
        ProgressRing(stats, modifier = Modifier.fillMaxWidth(0.55f))
        Spacer(Modifier.height(28.dp))
        Text(
            "开始学习",
            color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .background(Color(0xFF1F6F5C), RoundedCornerShape(24.dp))
                .clickable { onStart() }
                .padding(horizontal = 44.dp, vertical = 14.dp),
        )
        Spacer(Modifier.height(16.dp))
        Text(
            "词库 ${StudySession.allCards.size} 词 · 数据校验 ${StudySession.vocabSha256().take(8)}",
            fontSize = 11.sp, color = Color(0xFF9AA8A2),
        )
    }
}

@Composable
fun ProgressRing(stats: StudyStats, modifier: Modifier = Modifier) {
    val progress = if (stats.total == 0) 0f else stats.learned.toFloat() / stats.total
    Box(modifier = modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 20.dp.toPx()
            val inset = stroke / 2 + 4.dp.toPx()
            val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
            drawArc(
                color = Color(0xFFE3EAE6),
                startAngle = -90f, sweepAngle = 360f, useCenter = false,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
                topLeft = Offset(inset, inset), size = arcSize,
            )
            drawArc(
                color = Color(0xFF1F6F5C),
                startAngle = -90f, sweepAngle = 360f * progress, useCenter = false,
                style = Stroke(width = stroke, cap = StrokeCap.Round),
                topLeft = Offset(inset, inset), size = arcSize,
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${(progress * 100).toInt()}%", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F6F5C))
            Text("已学进度", fontSize = 12.sp, color = Color(0xFF5A6B66))
            Text("已掌握 ${stats.mastered} 词", fontSize = 11.sp, color = Color(0xFF9AA8A2))
        }
    }
}

@Composable
fun StudyScreen(today: Int, version: Int, onExit: () -> Unit, onTick: () -> Unit) {
    var started by rememberSaveable { mutableStateOf(false) }
    var flipped by rememberSaveable { mutableStateOf(false) }
    var idx by rememberSaveable { mutableIntStateOf(0) }
    var favState by rememberSaveable { mutableStateOf(false) }
    var done by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        if (!started) {
            StudySession.startSession(today, 10)
            started = true
            flipped = false
            idx = 0
            favState = StudySession.isFavorite(StudySession.currentCardId)
        }
    }

    fun advance(quality: Int) {
        StudySession.gradeCurrent(quality, today)
        idx++
        flipped = false
        if (StudySession.remaining <= 0) {
            done = true
        } else {
            favState = StudySession.isFavorite(StudySession.currentCardId)
        }
        onTick()
    }

    if (!started) {
        // 首帧占位,LaunchedEffect 完成初始化后再渲染学习界面
        Box(Modifier.fillMaxSize())
        return
    }

    if (done) {
        val stats = StudySession.stats(today)
        Column(
            modifier = Modifier.fillMaxSize().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("本轮完成 🎉", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F6F5C))
            Spacer(Modifier.height(10.dp))
            Text(
                "已学 ${stats.learned}/${stats.total} · 待复习 ${stats.dueToday} · 已掌握 ${stats.mastered} · 收藏 ${stats.favorite}",
                fontSize = 13.sp, color = Color(0xFF5A6B66), textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(20.dp))
            Text(
                "返回首页",
                color = Color.White, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .background(Color(0xFF1F6F5C), RoundedCornerShape(20.dp))
                    .clickable { onExit() }
                    .padding(horizontal = 32.dp, vertical = 12.dp),
            )
        }
        return
    }

    val card = StudySession.currentCard ?: return
    val rotation by animateFloatAsState(
        targetValue = if (flipped) 180f else 0f,
        animationSpec = tween(400),
        label = "flip",
    )

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("剩余 ${StudySession.remaining} 张 · 第 ${idx + 1} 张", fontSize = 12.sp, color = Color(0xFF5A6B66))
        Spacer(Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.85f)
                .graphicsLayer { rotationY = rotation }
                .background(Color.White, RoundedCornerShape(20.dp))
                .clickable { flipped = !flipped },
            contentAlignment = Alignment.Center,
        ) {
            if (flipped) {
                Column(
                    modifier = Modifier
                        .graphicsLayer { rotationY = 180f }
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(card.word, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1F6F5C))
                    Text(card.phonetic, fontSize = 14.sp, color = Color(0xFF8AA398))
                    Spacer(Modifier.height(14.dp))
                    Text(card.definition, fontSize = 18.sp, textAlign = TextAlign.Center, color = Color(0xFF333D3A))
                    Spacer(Modifier.height(10.dp))
                    Text("“${card.example}”", fontSize = 13.sp, textAlign = TextAlign.Center, color = Color(0xFF7C8A85), lineHeight = 19.sp)
                }
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(card.word, fontSize = 40.sp, fontWeight = FontWeight.Black, color = Color(0xFF233932))
                    Spacer(Modifier.height(8.dp))
                    Text(card.phonetic, fontSize = 16.sp, color = Color(0xFF8AA398))
                    Spacer(Modifier.height(18.dp))
                    Text("点击卡片查看释义", fontSize = 12.sp, color = Color(0xFFB4BEB9))
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            if (favState) "★ 已收藏" else "☆ 收藏",
            fontSize = 13.sp, color = if (favState) Color(0xFFD99A2B) else Color(0xFF9AA8A2),
            modifier = Modifier.clickable {
                favState = StudySession.toggleFavoriteCurrent()
                onTick()
            },
        )
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GradeButton("忘记", Color(0xFFC0554A)) { advance(Quality.FORGET) }
            GradeButton("困难", Color(0xFFD99A2B)) { advance(Quality.HARD) }
            GradeButton("良好", Color(0xFF3E7D6B)) { advance(Quality.GOOD) }
            GradeButton("简单", Color(0xFF3B6EA5)) { advance(Quality.EASY) }
        }
        Spacer(Modifier.height(8.dp))
        Text("忘记=0 · 困难=2 · 良好=3 · 简单=5(SM-2 档位)", fontSize = 10.sp, color = Color(0xFFB4BEB9))
    }
}

@Composable
fun GradeButton(label: String, color: Color, onClick: () -> Unit) {
    Text(
        label,
        color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
        modifier = Modifier
            .background(color, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 12.dp),
    )
}

@Composable
fun FavoritesScreen() {
    val cards = StudySession.favoriteCards()
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
    ) {
        if (cards.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(top = 120.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("暂无收藏", fontSize = 16.sp, color = Color(0xFF9AA8A2))
                Spacer(Modifier.height(8.dp))
                Text("在学习页点击 ☆ 收藏生词", fontSize = 12.sp, color = Color(0xFFB4BEB9))
            }
        } else {
            cards.forEach { c ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(modifier = Modifier.weight(0.4f)) {
                        Text(c.word, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF233932))
                        Text(c.phonetic, fontSize = 11.sp, color = Color(0xFF8AA398))
                    }
                    Text(c.definition, fontSize = 12.sp, color = Color(0xFF5A6B66), modifier = Modifier.weight(0.6f))
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
