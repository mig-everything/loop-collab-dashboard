package io.eazo.flashcards.core

import io.eazo.flashcards.model.CardState
import io.eazo.flashcards.model.StudyStats

/**
 * REQ-011 闪卡核心逻辑(纯函数,均不含随机/时钟)。
 * 双端对账口径:同词库 + 同评分序列 → 同调度状态 → 同统计。
 */
object FlashcardLogic {

    /** 卡片翻转:front↔back。 */
    fun flip(side: String): String = if (side == "front") "back" else "front"

    /** 收藏布尔翻转。 */
    fun toggleFavorite(fav: Boolean): Boolean = !fav

    /**
     * 收藏列表(契约 §4 纯函数):按 id 升序稳定输出,与收藏时间无关。
     * 双端对账锚点 F3:favoriteList({5,3,9,1}) == [1,3,5,9]。
     */
    fun favoriteList(favorites: Set<Int>): List<Int> = favorites.sorted()

    /**
     * 学习进度统计(纯函数)。
     * - learned: reps>0 的卡(学过至少一次)
     * - dueToday: dueDay <= today 的卡(含未学新卡)
     * - mastered: interval >= 21 天的卡(间隔三周以上视为已掌握)
     * - favorite: 收藏中的卡
     */
    fun stats(
        states: Map<Int, CardState>,
        favorites: Set<Int>,
        today: Int,
    ): StudyStats {
        var learned = 0
        var dueToday = 0
        var mastered = 0
        for (s in states.values) {
            if (s.repetitions > 0) learned++
            if (s.dueDay <= today) dueToday++
            if (s.interval >= 21) mastered++
        }
        return StudyStats(
            total = states.size,
            learned = learned,
            dueToday = dueToday,
            mastered = mastered,
            favorite = favorites.size,
        )
    }

    /**
     * 队列选取(确定性):到期卡按 (dueDay, id) 升序;全不失约时(队列空)按 id 升序补新卡。
     * 返回本 session 要学的卡片 id 序列。
     */
    fun sessionQueue(
        states: Map<Int, CardState>,
        today: Int,
        limit: Int = 10,
    ): List<Int> {
        val due = states.entries
            .filter { it.value.dueDay <= today }
            .sortedWith(compareBy({ it.value.dueDay }, { it.key }))
            .map { it.key }
        if (due.isNotEmpty()) return due.take(limit)
        // 无到期卡:按 id 升序取未学卡(rep==0);仍无则取全部 id 最小者兜底
        val fresh = states.entries.filter { it.value.repetitions == 0 }
            .sortedBy { it.key }.map { it.key }
        if (fresh.isNotEmpty()) return fresh.take(limit)
        return states.keys.sorted().take(limit)
    }
}
