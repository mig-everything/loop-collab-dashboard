package io.eazo.flashcards.core

/**
 * REQ-011 背单词闪卡 · 本地种子词库(Android 基线侧)。
 * ⚠️ 本文件由 scripts/gen_vocab_constants.py 从 seed/vocab.json 生成,禁手改。
 * 数据面哈希锁:SHA-256 = 15a89fb260e0d594eac28629a6ad738e0a2b5a097ff5a9e283877247d8d46b74(2619 bytes,规范序列化见脚本 docstring)。
 */
object VocabConstants {
    const val COUNT: Int = 30
    const val CANONICAL_SHA256: String = "15a89fb260e0d594eac28629a6ad738e0a2b5a097ff5a9e283877247d8d46b74"
    const val CANONICAL_BYTES: Int = 2619

    data class WordCard(
        val id: Int,
        val word: String,
        val phonetic: String,
        val definition: String,
        val example: String,
    )

    val WORDS: List<WordCard> = listOf(
        WordCard(1, "abandon", "/əˈbændən/", "v. 放弃；抛弃", "He abandoned the plan at the last minute."),
        WordCard(2, "ability", "/əˈbɪləti/", "n. 能力；才能", "She has the ability to solve hard problems."),
        WordCard(3, "absorb", "/əbˈzɔːrb/", "v. 吸收；理解（知识）", "Plants absorb water through their roots."),
        WordCard(4, "abstract", "/ˈæbstrækt/", "adj. 抽象的 n. 摘要", "The idea is too abstract for young children."),
        WordCard(5, "academy", "/əˈkædəmi/", "n. 学院；研究院", "He studies at a military academy."),
        WordCard(6, "account", "/əˈkaʊnt/", "n. 账户；描述 v. 解释", "She opened a bank account last week."),
        WordCard(7, "achieve", "/əˈtʃiːv/", "v. 实现；达到", "You can achieve your goals with hard work."),
        WordCard(8, "adapt", "/əˈdæpt/", "v. 适应；改编", "Animals adapt to their environment."),
        WordCard(9, "balance", "/ˈbæləns/", "n. 平衡 v. 使平衡", "Try to keep a balance between work and rest."),
        WordCard(10, "ban", "/bæn/", "v. 禁止 n. 禁令", "The city banned smoking in public parks."),
        WordCard(11, "barrier", "/ˈbæriər/", "n. 障碍；屏障", "Language is no barrier for good friends."),
        WordCard(12, "benefit", "/ˈbenɪfɪt/", "n. 好处 v. 有益于", "Daily exercise benefits your health."),
        WordCard(13, "beyond", "/bɪˈjɑːnd/", "prep. 超出；越出", "The result went beyond our expectations."),
        WordCard(14, "brilliant", "/ˈbrɪliənt/", "adj. 杰出的；明亮的", "That is a brilliant idea for the project."),
        WordCard(15, "budget", "/ˈbʌdʒɪt/", "n. 预算 v. 编预算", "We finished the project under budget."),
        WordCard(16, "capable", "/ˈkeɪpəbl/", "adj. 有能力的", "She is capable of running ten kilometers."),
        WordCard(17, "capture", "/ˈkæptʃər/", "v. 捕获；捕捉（画面）", "The camera captured the sunset perfectly."),
        WordCard(18, "challenge", "/ˈtʃælɪndʒ/", "n. 挑战 v. 向…挑战", "Learning new words is a fun challenge."),
        WordCard(19, "character", "/ˈkærəktər/", "n. 性格；角色；字符", "The main character wins in the end."),
        WordCard(20, "commit", "/kəˈmɪt/", "v. 承诺；提交", "He committed to finishing the report today."),
        WordCard(21, "community", "/kəˈmjuːnəti/", "n. 社区；群体", "Our community built a small library."),
        WordCard(22, "compare", "/kəmˈper/", "v. 比较", "Compare the two pictures and find differences."),
        WordCard(23, "conduct", "/kənˈdʌkt/", "v. 进行；指挥 n. 行为", "They conducted an experiment in class."),
        WordCard(24, "confident", "/ˈkɑːnfɪdənt/", "n. 自信的；确信的", "Be confident when you speak English."),
        WordCard(25, "consider", "/kənˈsɪdər/", "v. 考虑；认为", "Please consider my suggestion carefully."),
        WordCard(26, "create", "/kriˈeɪt/", "v. 创造；创建", "Artists create beautiful things every day."),
        WordCard(27, "culture", "/ˈkʌltʃər/", "n. 文化；修养", "Tea is an important part of Chinese culture."),
        WordCard(28, "daily", "/ˈdeɪli/", "adj. 每日的 n. 日报", "Reading daily improves your vocabulary."),
        WordCard(29, "decide", "/dɪˈsaɪd/", "v. 决定；决心", "We decided to start a new study plan."),
        WordCard(30, "curious", "/ˈkjʊriəs/", "adj. 好奇的", "The curious child asked many questions."),
    )
}
