package io.eazo.flashcards.model

/**
 * REQ-011 模型层。SM-2 调度状态四元组(repetitions, ef2, interval, dueDay)——
 * ef2 = EF×100 定点整数(默认 250,下限 130),全程整数运算,无双端浮点分叉。
 */
data class CardState(
    val repetitions: Int = 0,
    val ef2: Int = 250,
    val interval: Int = 0,
    val dueDay: Int = 0,
)

/** quality 评分档位(按钮映射:忘记=0 / 困难=2 / 良好=3 / 简单=5)。 */
object Quality {
    const val FORGET: Int = 0
    const val HARD: Int = 2
    const val GOOD: Int = 3
    const val EASY: Int = 5
}

/** 学习进度统计(纯函数 stats 输出,双端逐字段对账)。 */
data class StudyStats(
    val total: Int,
    val learned: Int,
    val dueToday: Int,
    val mastered: Int,
    val favorite: Int,
)
