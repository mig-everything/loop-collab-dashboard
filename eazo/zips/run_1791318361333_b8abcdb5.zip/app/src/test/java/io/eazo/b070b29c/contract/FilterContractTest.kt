package io.eazo.b070b29c.contract

import io.eazo.b070b29c.core.filter.FilterEngine
import io.eazo.b070b29c.core.filter.SampleImage
import io.eazo.b070b29c.core.model.FilterParams
import io.eazo.b070b29c.core.model.FilterType
import io.eazo.b070b29c.core.model.SavedPhoto
import io.eazo.b070b29c.core.persist.PhotoStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotSame
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 图片滤镜契约用例（纯 JVM）：锚定七款滤镜的确定性像素算法已知值、
 * 混合舍入口径、示例图关键像素锚点、保存记录往返与确定性排序。
 */
class FilterContractTest {

    private fun apply(type: FilterType, argb: Long, strength: Int): Int =
        FilterEngine.apply(type, intArrayOf(argb.toInt()), strength)[0]

    @Test
    fun `七款滤镜枚举契约——id与中文标签与顺序跨端口径`() {
        assertEquals(
            listOf("grayscale", "invert", "sepia", "brightness", "contrast", "warm", "cool"),
            FilterType.values().map { it.id },
        )
        assertEquals(
            listOf("灰度", "反色", "怀旧", "亮度", "对比度", "暖色", "冷色"),
            FilterType.values().map { it.label },
        )
        assertEquals(FilterType.GRAYSCALE, FilterType.DEFAULT)
    }

    @Test
    fun `id反查全量命中且未知id兜底DEFAULT`() {
        for (t in FilterType.values()) assertEquals(t, FilterType.byId(t.id))
        assertEquals(FilterType.DEFAULT, FilterType.byId("nope"))
    }

    @Test
    fun `强度归一化与默认参数`() {
        assertEquals(100, FilterParams(FilterType.GRAYSCALE, 120).normalized.strength)
        assertEquals(0, FilterParams(FilterType.GRAYSCALE, -5).normalized.strength)
        assertEquals(60, FilterParams().strength)
        assertEquals(FilterType.GRAYSCALE, FilterParams().filter)
        assertEquals(FilterParams(FilterType.WARM, 40), FilterParams(FilterType.WARM, 40))
    }

    @Test
    fun `强度0为恒等且不共享底层数组`() {
        val src = intArrayOf(0xFF123456L.toInt(), 0x80AABBDDL.toInt(), 0)
        val out = FilterEngine.apply(FilterType.SEPIA, src, 0)
        assertTrue(src.contentEquals(out))
        assertNotSame(src, out)
    }

    @Test
    fun `灰度BT601整型加权与混合舍入`() {
        // (100*299 + 120*587 + 144*114)/1000 = 116 = 0x74
        assertEquals(0xFF747474L, apply(FilterType.GRAYSCALE, 0xFF647890L, 100).toLong() and 0xFFFFFFFFL)
        // s=50 纯红逐通道混合：r=(255*50+76*50+50)/100=166=0xA6；g/b=(0+76*50+50)/100=38=0x26
        assertEquals(0xFFA62626L, apply(FilterType.GRAYSCALE, 0xFFFF0000L, 50).toLong() and 0xFFFFFFFFL)
    }

    @Test
    fun `反色s100逐通道取反`() {
        assertEquals(0xFFEDCBA9L, apply(FilterType.INVERT, 0xFF123456L, 100).toLong() and 0xFFFFFFFFL)
    }

    @Test
    fun `怀旧sepia经典矩阵`() {
        // 纯红：(393*255)/1000=100 (349*255)/1000=88 (272*255)/1000=69 → 0x64/0x58/0x45
        assertEquals(0xFF645845L, apply(FilterType.SEPIA, 0xFFFF0000L, 100).toLong() and 0xFFFFFFFFL)
    }

    @Test
    fun `亮度s100目标偏移加76`() {
        // 100+76=176=0xB0, 120+76=196=0xC4, 144+76=220=0xDC
        assertEquals(0xFFB0C4DCL, apply(FilterType.BRIGHTNESS, 0xFF647890L, 100).toLong() and 0xFFFFFFFFL)
    }

    @Test
    fun `对比度中灰不动且已知值`() {
        // (128-128)*1.6+128 = 128（中灰锚点）
        assertEquals(0xFF808080L, apply(FilterType.CONTRAST, 0xFF808080L, 100).toLong() and 0xFFFFFFFFL)
        // (160c-7630)/100：100→83, 120→115, 144→154
        assertEquals(0xFF53739AL, apply(FilterType.CONTRAST, 0xFF647890L, 100).toLong() and 0xFFFFFFFFL)
    }

    @Test
    fun `暖色冷色方向相反且饱和端钳制`() {
        // 0xFF647890：暖 (100+30,120+10,144-30)=0xFF828272；冷 (70,110,174)=0xFF466EAE
        assertEquals(0xFF828272L, apply(FilterType.WARM, 0xFF647890L, 100).toLong() and 0xFFFFFFFFL)
        assertEquals(0xFF466EAEL, apply(FilterType.COOL, 0xFF647890L, 100).toLong() and 0xFFFFFFFFL)
        // 纯红暖色不越界：255 钳制、b 钳 0 → 0xFFFF0A00；纯蓝冷色 → 0xFF0000FF
        assertEquals(0xFFFF0A00L, apply(FilterType.WARM, 0xFFFF0000L, 100).toLong() and 0xFFFFFFFFL)
        assertEquals(0xFF0000FFL, apply(FilterType.COOL, 0xFF0000FFL, 100).toLong() and 0xFFFFFFFFL)
    }

    @Test
    fun `alpha保留与全透明像素跳过`() {
        assertEquals(0x80, apply(FilterType.GRAYSCALE, 0x80FF0000L, 100) ushr 24 and 0xFF)
        assertEquals(0, apply(FilterType.GRAYSCALE, 0x00000000L, 100))
    }

    @Test
    fun `越界强度收敛到边界`() {
        val src = intArrayOf(0xFF647890L.toInt())
        assertTrue(
            FilterEngine.apply(FilterType.GRAYSCALE, src, 150)
                .contentEquals(FilterEngine.apply(FilterType.GRAYSCALE, src, 100)),
        )
        assertTrue(
            FilterEngine.apply(FilterType.GRAYSCALE, src, -3)
                .contentEquals(FilterEngine.apply(FilterType.GRAYSCALE, src, 0)),
        )
    }

    @Test
    fun `引擎同输入必同输出`() {
        val src = intArrayOf(0xFF647890L.toInt(), 0xFFABCDEFL.toInt(), 0x4000FF00L.toInt())
        val a = FilterEngine.apply(FilterType.SEPIA, src, 73)
        val b = FilterEngine.apply(FilterType.SEPIA, src, 73)
        assertTrue(a.contentEquals(b))
    }

    @Test
    fun `示例图确定性生成与关键像素锚点`() {
        val a = SampleImage.generate()
        val b = SampleImage.generate()
        assertTrue(a.contentEquals(b))
        assertEquals(SampleImage.WIDTH * SampleImage.HEIGHT, a.size)
        assertEquals(0xFF253060L, a[0].toLong() and 0xFFFFFFFFL) // 左上 = 天顶色
        // 太阳中心（240, 202）= 太阳色；左下角 = 最远山脊色
        assertEquals(0xFFFFE9B0L, a[202 * SampleImage.WIDTH + 240].toLong() and 0xFFFFFFFFL)
        val h = SampleImage.HEIGHT
        val w = SampleImage.WIDTH
        assertEquals(0xFF31244AL, a[(h - 1) * w].toLong() and 0xFFFFFFFFL)
    }

    @Test
    fun `滤镜确实改变示例图`() {
        val src = SampleImage.generate()
        assertFalse(
            src.contentEquals(FilterEngine.apply(FilterType.GRAYSCALE, src, 100)),
        )
    }

    @Test
    fun `保存记录往返与确定性排序`() {
        val recs = listOf(
            SavedPhoto("b", "/p/b.png", "warm", 40, 100L),
            SavedPhoto("a", "/p/a.png", "cool", 20, 200L),
            SavedPhoto("c", "/p/c.png", "sepia", 60, 100L),
        )
        val text = PhotoStore.encode(recs)
        val decoded = PhotoStore.decode(text)
        // 主键 savedAt 倒序，次键 id 字典序兜底：a(200) → b(100) → c(100)
        assertEquals(listOf("a", "b", "c"), decoded.map { it.id })
        assertEquals(recs.sortedWith(SavedPhoto.ORDER), decoded)
        assertEquals(decoded, PhotoStore.decode(PhotoStore.encode(decoded)))
        // 脏行静默跳过
        assertEquals(3, PhotoStore.decode("$text\ngarbage\nxx|1\n").size)
        assertEquals(0, PhotoStore.decode("").size)
    }
}
