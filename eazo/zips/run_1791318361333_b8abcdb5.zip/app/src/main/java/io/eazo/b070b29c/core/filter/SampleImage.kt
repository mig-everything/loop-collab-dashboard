package io.eazo.b070b29c.core.filter

/**
 * 内置示例图：程序化确定性生成的「暮色山峦」图案。
 *
 * 纯整型/确定性运算（三角函数仅逐列一次），无二进制资源依赖，
 * JVM 单测可直接断言关键像素锚点。
 */
object SampleImage {
    const val WIDTH = 480
    const val HEIGHT = 480

    // 暮色配色（ARGB）：天顶深蓝 → 地平线琥珀，三层山脊渐暗
    private val SKY_TOP = 0xFF253060.toInt()
    private val SKY_BOTTOM = 0xFFF2A65A.toInt()
    private val SUN = 0xFFFFE9B0.toInt()
    private val HILL_1 = 0xFF8A5A72.toInt()
    private val HILL_2 = 0xFF5C3D63.toInt()
    private val HILL_3 = 0xFF31244A.toInt()

    fun generate(): IntArray {
        val w = WIDTH
        val h = HEIGHT
        val out = IntArray(w * h)

        // 三层山脊线：每列一次三角函数预算，逐像素整型套用
        val ridge = IntArray(w * 3)
        val base = doubleArrayOf(0.66, 0.74, 0.84)
        val amp = doubleArrayOf(0.035, 0.05, 0.06)
        val freq = doubleArrayOf(3.0, 2.0, 1.5)
        val phase = doubleArrayOf(0.0, 1.3, 2.7)
        for (l in 0..2) {
            for (x in 0 until w) {
                val t = base[l] + amp[l] * Math.sin(2.0 * Math.PI * (freq[l] * x / w + phase[l]))
                ridge[l * w + x] = (t * h).toInt()
            }
        }

        // 太阳（含 4px 软边缘）
        val sunCx = w / 2.0
        val sunCy = h * 0.42
        val sunR = h * 0.13
        val soft = sunR - 4.0

        for (y in 0 until h) {
            val t = y * 1000 / (h - 1)
            val sr = ch(SKY_TOP, 16) + (ch(SKY_BOTTOM, 16) - ch(SKY_TOP, 16)) * t / 1000
            val sg = ch(SKY_TOP, 8) + (ch(SKY_BOTTOM, 8) - ch(SKY_TOP, 8)) * t / 1000
            val sb = ch(SKY_TOP, 0) + (ch(SKY_BOTTOM, 0) - ch(SKY_TOP, 0)) * t / 1000
            val sky = (0xFF shl 24) or (sr shl 16) or (sg shl 8) or sb
            for (x in 0 until w) {
                out[y * w + x] = when {
                    y >= ridge[2 * w + x] -> HILL_3
                    y >= ridge[w + x] -> HILL_2
                    y >= ridge[x] -> HILL_1
                    else -> {
                        val dx = x - sunCx
                        val dy = y - sunCy
                        val d2 = dx * dx + dy * dy
                        if (d2 >= sunR * sunR) sky
                        else blend(sky, SUN, sunAlpha(d2, sunR, soft))
                    }
                }
            }
        }
        return out
    }

    private fun sunAlpha(d2: Double, r: Double, soft: Double): Int =
        if (d2 <= soft * soft) 255
        else (((r * r - d2) * 255) / (r * r - soft * soft)).toInt().coerceIn(0, 255)

    private fun ch(c: Int, shift: Int): Int = c ushr shift and 0xFF

    /** over 以 a255 覆盖 base（整型四舍五入；a255=255 直接取 over）。 */
    private fun blend(base: Int, over: Int, a255: Int): Int {
        if (a255 >= 255) return over
        if (a255 <= 0) return base
        val ia = 255 - a255
        fun mix(shift: Int): Int = (ch(over, shift) * a255 + ch(base, shift) * ia + 127) / 255
        return (0xFF shl 24) or (mix(16) shl 16) or (mix(8) shl 8) or mix(0)
    }
}
