package io.eazo.b070b29c.platform

import android.content.Context
import android.graphics.Bitmap
import android.os.Environment
import android.os.Handler
import android.os.Looper
import io.eazo.b070b29c.core.filter.FilterEngine
import io.eazo.b070b29c.core.model.FilteredImage
import io.eazo.b070b29c.core.model.FilterParams
import io.eazo.b070b29c.core.model.SavedPhoto
import io.eazo.b070b29c.core.persist.PhotoStore
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * 平台层：AppRepo 进程内单例（生成器硬规则 ①——UI/卡片层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * 内存态 = 已保存记录列表（list() 只读内存态）；仅首次 getRepo 时从持久化
 * 装载一次，此后 refresh() 只重读内存态（硬规则 ②）。
 */
object AppRepo {

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val savedPhotos = mutableListOf<SavedPhoto>()
    private var loaded = false

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo {
        synchronized(this) {
            if (!loaded) {
                loaded = true
                savedPhotos.addAll(PhotoStore.decode(readStoreFile(context.applicationContext)))
            }
        }
        return this
    }

    /** 只读内存态（已按 SavedPhoto.ORDER 确定性排序）。 */
    fun list(): List<SavedPhoto> = synchronized(this) { savedPhotos.toList() }

    /** 硬规则 ②：onResume 只重读内存态，禁止从持久化 load()。 */
    fun refresh() {
        // 内存列表即真源（写入即时可见），无额外动作
    }

    /**
     * 后台执行滤镜计算并保存 PNG 到应用专属图片目录（无需存储权限），
     * 完成后主线程回调记录（失败回调 null）。
     */
    fun save(
        context: Context,
        source: FilteredImage,
        params: FilterParams,
        callback: (SavedPhoto?) -> Unit,
    ) {
        val app = context.applicationContext
        val p = params.normalized
        io.execute {
            val record: SavedPhoto? = try {
                val px = FilterEngine.apply(p.filter, source.pixels, p.strength)
                val bitmap = Bitmap.createBitmap(px, source.width, source.height, Bitmap.Config.ARGB_8888)
                val dir = app.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: app.filesDir
                val name = "filter_${p.filter.id}_${p.strength}_${System.currentTimeMillis()}"
                val file = File(dir, "$name.png")
                FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bitmap.recycle()
                val r = SavedPhoto(name, file.absolutePath, p.filter.id, p.strength, System.currentTimeMillis())
                synchronized(this) {
                    savedPhotos.add(r)
                    File(app.filesDir, STORE_FILE).writeText(PhotoStore.encode(savedPhotos))
                }
                r
            } catch (t: Throwable) {
                null
            }
            main.post { callback(record) }
        }
    }

    private fun readStoreFile(app: Context): String {
        val f = File(app.filesDir, STORE_FILE)
        return if (f.exists()) f.readText() else ""
    }

    private const val STORE_FILE = "saved_photos.txt"
}
