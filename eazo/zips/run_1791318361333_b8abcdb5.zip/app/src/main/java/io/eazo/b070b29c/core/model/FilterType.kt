package io.eazo.b070b29c.core.model

/**
 * 七款内置滤镜（确定性像素算法）。
 *
 * 枚举字面量 / id / 顺序为跨端契约口径：双端必须 1:1 一致（硬规则 ③），
 * 排序即声明顺序，未知 id 一律兜底 DEFAULT 保证确定性。
 */
enum class FilterType(val id: String, val label: String) {
    GRAYSCALE("grayscale", "灰度"),
    INVERT("invert", "反色"),
    SEPIA("sepia", "怀旧"),
    BRIGHTNESS("brightness", "亮度"),
    CONTRAST("contrast", "对比度"),
    WARM("warm", "暖色"),
    COOL("cool", "冷色");

    companion object {
        val DEFAULT: FilterType = GRAYSCALE

        /** id 反查：未知 id 兜底 DEFAULT（字典序/未知输入确定性）。 */
        fun byId(id: String): FilterType = values().firstOrNull { it.id == id } ?: DEFAULT
    }
}
