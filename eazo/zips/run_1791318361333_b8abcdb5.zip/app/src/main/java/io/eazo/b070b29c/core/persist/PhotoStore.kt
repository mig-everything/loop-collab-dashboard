package io.eazo.b070b29c.core.persist

import io.eazo.b070b29c.core.model.SavedPhoto

/**
 * 保存记录的文本序列化（行格式：id|path|filterId|strength|savedAt）。
 * 纯 JVM 逻辑可单测；编解码均输出 [SavedPhoto.ORDER] 确定性排序，脏行静默跳过。
 */
object PhotoStore {

    fun encode(records: List<SavedPhoto>): String =
        records.sortedWith(SavedPhoto.ORDER).joinToString("\n") {
            "${it.id}|${it.path}|${it.filterId}|${it.strength}|${it.savedAt}"
        }

    fun decode(text: String): List<SavedPhoto> =
        text.lineSequence()
            .filter { it.isNotBlank() }
            .mapNotNull { line ->
                val p = line.split("|")
                if (p.size != 5) return@mapNotNull null
                val strength = p[3].toIntOrNull() ?: return@mapNotNull null
                val savedAt = p[4].toLongOrNull() ?: return@mapNotNull null
                SavedPhoto(p[0], p[1], p[2], strength, savedAt)
            }
            .sortedWith(SavedPhoto.ORDER)
            .toList()
}
