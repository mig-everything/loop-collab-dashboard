package io.eazo.b070b29c.core.filter

import io.eazo.b070b29c.core.model.FilterParams
import io.eazo.b070b29c.core.model.FilterType

/**
 * 确定性像素滤镜引擎（纯 JVM 逻辑，零 Android 依赖，可单测复现）。
 *
 * 统一模型：每款滤镜 = 一个逐像素目标变换 T；输出 = 原值与目标值按强度
 * s∈[0,100] 线性混合，全部整型运算 + 四舍五入，同输入必同输出：
 *   out = (orig * (100 - s) + T(orig) * s + 50) / 100
 * 强度 0 即恒等（返回原像素拷贝），100 即纯目标变换。
 */
object FilterEngine {

    fun apply(type: FilterType, pixels: IntArray, strength: Int): IntArray {
        val s = strength.coerceIn(FilterParams.MIN_STRENGTH, FilterParams.MAX_STRENGTH)
        val out = IntArray(pixels.size)
        if (s == FilterParams.MIN_STRENGTH) {
            System.arraycopy(pixels, 0, out, 0, pixels.size)
            return out
        }
        for (i in pixels.indices) {
            val p = pixels[i]
            val a = p ushr 24 and 0xFF
            if (a == 0) continue // 全透明像素保持不动（out 默认 0）
            val r = p ushr 16 and 0xFF
            val g = p ushr 8 and 0xFF
            val b = p and 0xFF
            var tr = r
            var tg = g
            var tb = b
            when (type) {
                FilterType.GRAYSCALE -> {
                    // ITU-R BT.601 整型加权：(299R + 587G + 114B) / 1000
                    val y = (r * 299 + g * 587 + b * 114) / 1000
                    tr = y; tg = y; tb = y
                }
                FilterType.INVERT -> { tr = 255 - r; tg = 255 - g; tb = 255 - b }
                FilterType.SEPIA -> {
                    // 经典怀旧矩阵（×1000 整型化）
                    tr = clamp((r * 393 + g * 769 + b * 189) / 1000)
                    tg = clamp((r * 349 + g * 686 + b * 168) / 1000)
                    tb = clamp((r * 272 + g * 534 + b * 131) / 1000)
                }
                FilterType.BRIGHTNESS -> {
                    // 目标 = 原值 + 76（0.3 × 255 整型化），强度控制混合比例
                    tr = clamp(r + 76); tg = clamp(g + 76); tb = clamp(b + 76)
                }
                FilterType.CONTRAST -> {
                    // 目标 = (c - 128) × 1.6 + 128，整型化即 (160c - 7630) / 100
                    tr = clamp((r * 160 - 7630) / 100)
                    tg = clamp((g * 160 - 7630) / 100)
                    tb = clamp((b * 160 - 7630) / 100)
                }
                FilterType.WARM -> { tr = clamp(r + 30); tg = clamp(g + 10); tb = clamp(b - 30) }
                FilterType.COOL -> { tr = clamp(r - 30); tg = clamp(g - 10); tb = clamp(b + 30) }
            }
            val nr = (r * (100 - s) + tr * s + 50) / 100
            val ng = (g * (100 - s) + tg * s + 50) / 100
            val nb = (b * (100 - s) + tb * s + 50) / 100
            out[i] = (a shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
        return out
    }

    private fun clamp(v: Int): Int = if (v < 0) 0 else if (v > 255) 255 else v
}
