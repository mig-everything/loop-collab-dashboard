package io.eazo.b070b29c.core.model

/**
 * 滤镜参数（滤镜 + 强度）。强度口径统一归一化到 [MIN_STRENGTH, MAX_STRENGTH]，
 * 越界值经 [normalized] 收敛，保证引擎输入确定。
 */
data class FilterParams(
    val filter: FilterType = FilterType.DEFAULT,
    val strength: Int = DEFAULT_STRENGTH,
) {
    /** 收敛越界强度后的等价参数。 */
    val normalized: FilterParams
        get() = copy(strength = strength.coerceIn(MIN_STRENGTH, MAX_STRENGTH))

    companion object {
        const val MIN_STRENGTH = 0
        const val MAX_STRENGTH = 100
        const val DEFAULT_STRENGTH = 60
    }
}

/** 内存中的源图（ARGB 像素 + 尺寸）——AppRepo 持有的内存态，不落持久化。 */
class FilteredImage(val pixels: IntArray, val width: Int, val height: Int) {
    val pixelCount: Int get() = width * height
}

/** 一次保存效果的记录（文件名去扩展名即 id，id 字典序为排序兜底键）。 */
data class SavedPhoto(
    val id: String,
    val path: String,
    val filterId: String,
    val strength: Int,
    val savedAt: Long,
) {
    companion object {
        /** 确定性排序：保存时间倒序为主键，id 字典序为次键兜底（跨端口径）。 */
        val ORDER: Comparator<SavedPhoto> =
            compareByDescending<SavedPhoto> { it.savedAt }.thenBy { it.id }
    }
}
