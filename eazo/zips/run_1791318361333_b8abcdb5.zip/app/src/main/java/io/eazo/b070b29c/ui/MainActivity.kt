package io.eazo.b070b29c.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import io.eazo.b070b29c.platform.AppRepo

/**
 * 主界面：单 Activity + Jetpack Compose（UI 锁死声明式——与鸿蒙 ArkUI
 * 声明式对称，禁止 XML 布局/drawable 扇出；图标用 material-icons，主题用
 * Compose MaterialTheme）。
 *
 * 硬规则 ②：onResume 只 refresh()（重读内存态），禁止从持久化 load()。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    FilterScreen(repo = AppRepo.getRepo(applicationContext))
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(applicationContext).refresh()
    }
}

/** 深色画廊风主题：暮色琥珀主色（与内置示例图同源配色），保持单主题入口。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFF2A65A),
            onPrimary = Color(0xFF2E1A06),
            secondary = Color(0xFF9AC4D8),
            onSecondary = Color(0xFF0E2733),
            background = Color(0xFF0F1319),
            onBackground = Color(0xFFE4E2DE),
            surface = Color(0xFF1A212C),
            onSurface = Color(0xFFE4E2DE),
            surfaceVariant = Color(0xFF39434F),
            onSurfaceVariant = Color(0xFFB9C2CE),
            outline = Color(0xFF57616F),
        ),
        content = content,
    )
}
