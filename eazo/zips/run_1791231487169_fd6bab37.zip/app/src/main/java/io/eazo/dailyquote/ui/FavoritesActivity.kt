package io.eazo.dailyquote.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import io.eazo.dailyquote.R
import io.eazo.dailyquote.core.QuoteLogic
import io.eazo.dailyquote.model.Quote
import io.eazo.dailyquote.platform.AppRepo

/** 收藏列表:取消收藏 / 分享。硬规则 2:onResume 只重读内存态 */
class FavoritesActivity : AppCompatActivity() {

    private lateinit var repo: AppRepo
    private lateinit var adapter: FavoritesAdapter
    private lateinit var emptyView: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorites)
        repo = AppRepo.getRepo(this)
        findViewById<ImageButton>(R.id.btn_back).setOnClickListener { finish() }
        val recycler = findViewById<RecyclerView>(R.id.recycler_favorites)
        emptyView = findViewById(R.id.empty_favorites)
        adapter = FavoritesAdapter(
            onToggle = { id -> repo.toggleFavorite(id); render() },
            onShare = { share(it) },
        )
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val favorites = repo.favoriteQuotes()
        adapter.submit(favorites)
        emptyView.visibility = if (favorites.isEmpty()) View.VISIBLE else View.GONE
        findViewById<TextView>(R.id.tv_favorites_count).text =
            getString(R.string.favorites_count, repo.stats().favoriteCount)
    }

    private fun share(quote: Quote) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, QuoteLogic.shareText(quote))
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share_chooser)))
    }
}

private class FavoritesAdapter(
    val onToggle: (Int) -> Unit,
    val onShare: (Quote) -> Unit,
) : RecyclerView.Adapter<FavoritesAdapter.Holder>() {

    private val items = ArrayList<Quote>()

    fun submit(next: List<Quote>) {
        items.clear()
        items.addAll(next)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_favorite, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val quote = items[position]
        holder.tvText.text = quote.text
        holder.tvAuthor.text =
            holder.itemView.context.getString(R.string.author_line, quote.author, quote.source)
        holder.btnStar.setColorFilter(
            ContextCompat.getColor(holder.itemView.context, R.color.star_gold),
        )
        holder.btnStar.setOnClickListener { onToggle(quote.id) }
        holder.btnShare.setOnClickListener { onShare(quote) }
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val tvText: TextView = view.findViewById(R.id.tv_item_text)
        val tvAuthor: TextView = view.findViewById(R.id.tv_item_author)
        val btnStar: ImageButton = view.findViewById(R.id.btn_item_star)
        val btnShare: ImageButton = view.findViewById(R.id.btn_item_share)
    }
}
