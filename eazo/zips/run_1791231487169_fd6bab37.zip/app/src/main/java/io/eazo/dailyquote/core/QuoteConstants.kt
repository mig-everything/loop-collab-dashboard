package io.eazo.dailyquote.core

import io.eazo.dailyquote.model.Quote
import io.eazo.dailyquote.model.QuoteKind

/**
 * 本地种子语录库:id 从 1 连续编号(确定性主键 + 排序主键),条目顺序即 id 顺序。
 * kind=MOVIE 电影台词 / kind=QUOTE 名人语录;author=说话人或原作者,source=电影或著作。
 */
object QuoteConstants {

    val QUOTES: List<Quote> = listOf(
        q(1, "希望是个好东西,也许是最好的东西,好东西是不会消逝的。", "安迪", "肖申克的救赎", QuoteKind.MOVIE),
        q(2, "生活就像一盒巧克力,你永远不知道下一颗是什么味道。", "阿甘", "阿甘正传", QuoteKind.MOVIE),
        q(3, "不要让别人告诉你,你成不了才,即使是我也不行。", "克里斯·加德纳", "当幸福来敲门", QuoteKind.MOVIE),
        q(4, "我们的生命被琐碎消耗殆尽……简单些,再简单些。", "梭罗", "瓦尔登湖", QuoteKind.QUOTE),
        q(5, "世界上只有一种真正的英雄主义,就是认清生活的真相后依然热爱生活。", "罗曼·罗兰", "米开朗琪罗传", QuoteKind.QUOTE),
        q(6, "路漫漫其修远兮,吾将上下而求索。", "屈原", "离骚", QuoteKind.QUOTE),
        q(7, "你所站立的地方,正是你的中国;你怎么样,中国便怎么样。", "崔卫平", "演讲与随笔", QuoteKind.QUOTE),
        q(8, "星星发亮,是为了让每一个人有一天都能找到属于自己的星星。", "小王子", "小王子", QuoteKind.MOVIE),
        q(9, "如果你有梦想,就要守护它。", "克里斯·加德纳", "当幸福来敲门", QuoteKind.MOVIE),
        q(10, "人生如逆旅,我亦是行人。", "苏轼", "临江仙·送钱穆父", QuoteKind.QUOTE),
        q(11, "不管前方的路有多苦,只要走的方向正确,不管多么崎岖不平,都比站在原地更接近幸福。", "千寻", "千与千寻", QuoteKind.MOVIE),
        q(12, "生命中真正重要的不是你遭遇了什么,而是你记住了哪些事,又是如何铭记的。", "马尔克斯", "百年孤独", QuoteKind.QUOTE),
        q(13, "把每一天当成人生最后一天来过,你会豁然开朗。", "乔布斯", "斯坦福演讲", QuoteKind.QUOTE),
        q(14, "现在不了,也许将来……你知道,将来是很重要的。", "瑞德", "肖申克的救赎", QuoteKind.MOVIE),
        q(15, "种一棵树最好的时间是十年前,其次是现在。", "谚语", "非洲谚语", QuoteKind.QUOTE),
        q(16, "有些鸟儿是关不住的,因为它们的每一片羽毛都闪耀着自由的光辉。", "瑞德", "肖申克的救赎", QuoteKind.MOVIE),
        q(17, "山不过来,我就过去。", "谚语", "阿拉伯谚语", QuoteKind.QUOTE),
        q(18, "人最宝贵的是生命,生命每个人只有一次。", "奥斯特洛夫斯基", "钢铁是怎样炼成的", QuoteKind.QUOTE),
        q(19, "当你凝视深渊时,深渊也在凝视你。", "尼采", "善恶的彼岸", QuoteKind.QUOTE),
        q(20, "死亡不是生命的终点,遗忘才是。", "埃克托", "寻梦环游记", QuoteKind.MOVIE),
        q(21, "少即是多。", "密斯·凡德罗", "建筑十书讲稿", QuoteKind.QUOTE),
        q(22, "天才也免不了犯错,所以才有人发明了橡皮擦。", "纳什", "美丽心灵", QuoteKind.MOVIE),
        q(23, "知之者不如好之者,好之者不如乐之者。", "孔子", "论语", QuoteKind.QUOTE),
        q(24, "重要的不是治愈,而是带着病痛活下去。", "加缪", "西西弗神话", QuoteKind.QUOTE),
        q(25, "奇迹不是等来的,是每天为之奋斗争取来的。", "尚恩", "心灵捕手", QuoteKind.MOVIE),
        q(26, "合抱之木,生于毫末;九层之台,起于累土。", "老子", "道德经", QuoteKind.QUOTE),
        q(27, "凡是过往,皆为序章。", "莎士比亚", "暴风雨", QuoteKind.QUOTE),
        q(28, "记住,希望不是凭空而来的,是靠自己一步一步走出来的。", "阿米尔", "追风筝的人", QuoteKind.MOVIE),
    )

    val COUNT: Int = QUOTES.size

    private fun q(id: Int, text: String, author: String, source: String, kind: QuoteKind) =
        Quote(id = id, text = text, author = author, source = source, kind = kind)
}
