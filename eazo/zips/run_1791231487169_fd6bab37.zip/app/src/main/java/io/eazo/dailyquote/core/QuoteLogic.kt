package io.eazo.dailyquote.core

import io.eazo.dailyquote.model.Quote
import io.eazo.dailyquote.model.QuoteStats
import io.eazo.dailyquote.model.TodayState

/**
 * 纯函数域:每日选句 / 收藏排序 / 分享文案 / 今日状态序列化。
 * 不落盘、不取钟、不碰 Android 类型 —— JVM 单测直接覆盖(契约:core 纯函数,持久化收 platform 层)。
 */
object QuoteLogic {

    /**
     * 按日期选句:base = floorMod(epochDay, count) 保证逐日轮换;
     * 刷新在当日基数上叠加 refreshCount 并对 count 取模回绕(确定性,双端一致)。
     */
    fun pickOfDay(count: Int, epochDay: Long, refreshCount: Int): Int {
        require(count > 0) { "count must be positive" }
        return Math.floorMod(Math.floorMod(epochDay, count.toLong()).toInt() + refreshCount, count)
    }

    /** 收藏列表:按 id 升序(确定性排序,id 字典序兜底语义的数值等价) */
    fun favoriteIds(favorites: Set<Int>): List<Int> = favorites.sorted()

    /** 分享文案(格式双端一致,单测锁定) */
    fun shareText(quote: Quote): String =
        "「${quote.text}」\n—— ${quote.author}《${quote.source}》\n\n来自「每日一句」"

    /** 桌面卡片单行文案(text 过长截断,省略号收尾) */
    fun widgetLine(quote: Quote, maxChars: Int = 42): String {
        val head = quote.text
        return if (head.length <= maxChars) head else head.take(maxChars) + "…"
    }

    /** 统计快照 */
    fun stats(total: Int, favoriteCount: Int, refreshCount: Int): QuoteStats =
        QuoteStats(total = total, favoriteCount = favoriteCount, refreshCount = refreshCount)

    // ---- 今日状态序列化:"epochDay|index|refreshCount" 单行 ----

    fun serializeToday(state: TodayState): String =
        "${state.epochDay}|${state.index}|${state.refreshCount}"

    fun parseToday(blob: String?): TodayState? {
        if (blob.isNullOrBlank()) return null
        val parts = blob.trim().split("|")
        if (parts.size != 3) return null
        val day = parts[0].trim().toLongOrNull() ?: return null
        val index = parts[1].trim().toIntOrNull() ?: return null
        val refresh = parts[2].trim().toIntOrNull() ?: return null
        if (index < 0 || refresh < 0) return null
        return TodayState(epochDay = day, index = index, refreshCount = refresh)
    }

    /** 跨日失效:持久化态不是今天 → 回退到当日基础选句(refreshCount 归零) */
    fun resolveToday(saved: TodayState?, epochDay: Long, count: Int): TodayState {
        if (saved != null && saved.epochDay == epochDay &&
            saved.index in 0 until count
        ) {
            return saved
        }
        return TodayState(
            epochDay = epochDay,
            index = pickOfDay(count, epochDay, 0),
            refreshCount = 0,
        )
    }
}
