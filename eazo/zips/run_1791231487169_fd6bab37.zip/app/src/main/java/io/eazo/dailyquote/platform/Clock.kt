package io.eazo.dailyquote.platform

/** 时钟端口:core/platform 纯逻辑不直接取系统时间,便于 JVM 单测注入 */
interface ClockPort {
    /** 当前 epoch 天数(UTC 日界,与 Date.now()/86400000 同口径) */
    fun today(): Long
}

class SystemClockPort : ClockPort {
    override fun today(): Long = System.currentTimeMillis() / MILLIS_PER_DAY
    companion object {
        const val MILLIS_PER_DAY: Long = 86_400_000L
    }
}
