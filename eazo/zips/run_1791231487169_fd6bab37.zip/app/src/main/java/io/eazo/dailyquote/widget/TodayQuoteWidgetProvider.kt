package io.eazo.dailyquote.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import io.eazo.dailyquote.R
import io.eazo.dailyquote.core.QuoteLogic
import io.eazo.dailyquote.platform.AppRepo
import io.eazo.dailyquote.ui.MainActivity

/**
 * 桌面「今日一句」卡片:展示 + 刷新 + 点入主页面。
 * 硬规则 1:一律 AppRepo.getRepo(context),禁止 new 仓储;
 * 硬规则 2:每次渲染重读内存态,不单独 load()。
 */
class TodayQuoteWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
    ) {
        val views = render(context)
        appWidgetIds.forEach { appWidgetManager.updateAppWidget(it, views) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_REFRESH -> {
                AppRepo.getRepo(context).refresh()
                pushAll(context)
            }
        }
    }

    private fun pushAll(context: Context) {
        pushUpdate(context)
    }

    companion object {
        const val ACTION_REFRESH = "io.eazo.dailyquote.widget.ACTION_REFRESH"

        /** 供 UI 层在写操作后同步桌面卡片(重读内存态,不 load) */
        fun pushUpdate(context: Context, views: RemoteViews? = null) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(
                ComponentName(context, TodayQuoteWidgetProvider::class.java),
            )
            if (ids.isEmpty()) return
            manager.updateAppWidget(ids, views ?: render(context))
        }

        private fun render(context: Context): RemoteViews {
            val repo = AppRepo.getRepo(context)
            val quote = repo.todayQuote()
            return RemoteViews(context.packageName, R.layout.widget_today_quote).apply {
                setTextViewText(R.id.widget_quote, QuoteLogic.widgetLine(quote))
                setTextViewText(
                    R.id.widget_author,
                    context.getString(R.string.widget_author_line, quote.author),
                )
                setOnClickPendingIntent(R.id.widget_root, mainActivityPendingIntent(context))
                setOnClickPendingIntent(
                    R.id.widget_refresh,
                    PendingIntent.getBroadcast(
                        context,
                        0,
                        Intent(context, TodayQuoteWidgetProvider::class.java)
                            .setAction(ACTION_REFRESH),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                    ),
                )
            }
        }

        private fun mainActivityPendingIntent(context: Context): PendingIntent =
            PendingIntent.getActivity(
                context,
                0,
                Intent(context, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
    }
}
