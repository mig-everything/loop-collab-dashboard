package io.eazo.dailyquote.platform

import android.content.Context
import android.content.SharedPreferences
import io.eazo.dailyquote.core.QuoteConstants
import io.eazo.dailyquote.core.QuoteLogic
import io.eazo.dailyquote.model.Quote
import io.eazo.dailyquote.model.QuoteStats
import io.eazo.dailyquote.model.TodayState

/** 持久化键值端口(契约:持久化收 platform 层,core 纯函数不落盘) */
interface Store {
    fun getString(key: String, def: String?): String?
    fun putString(key: String, value: String?)
}

class PrefsStore(context: Context) : Store {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("dailyquote_repo", Context.MODE_PRIVATE)

    override fun getString(key: String, def: String?): String? = prefs.getString(key, def)
    override fun putString(key: String, value: String?) {
        prefs.edit().putString(key, value).apply()
    }
}

/**
 * 进程内单例仓储 —— 生成器硬规则 1:UI/卡片层一律 AppRepo.getRepo(context),
 * 禁止 new XxxRepository(...)。
 * 硬规则 2:load() 仅冷启动构造时执行一次;页面 onResume 只 refresh()(重读内存态),
 * 跨页面写操作即时可见,禁止从持久化 reload。
 */
class AppRepo private constructor(
    private val store: Store,
    private val clock: ClockPort,
    private val quotes: List<Quote>,
) {
    private val quotesById: Map<Int, Quote> = quotes.associateBy { it.id }
    private val favorites = HashSet<Int>()
    private var todayState: TodayState

    init {
        // load() 仅冷启动一次(硬规则 2)
        favorites.clear()
        store.getString(KEY_FAVORITES, null)?.let { blob ->
            blob.split(",").filter { it.isNotBlank() }.forEach {
                it.trim().toIntOrNull()?.let { id -> favorites.add(id) }
            }
        }
        todayState = QuoteLogic.resolveToday(
            saved = QuoteLogic.parseToday(store.getString(KEY_TODAY, null)),
            epochDay = clock.today(),
            count = quotes.size,
        )
    }

    // ---- 读:全部重读内存态 ----

    fun today(): Long = todayState.epochDay

    fun quotesList(): List<Quote> = quotesById.values.sortedBy { it.id }

    fun quoteOf(id: Int): Quote? = quotesById[id]

    fun todayQuote(): Quote = quotes[todayState.index]

    fun todayState(): TodayState = todayState

    fun isFavorite(id: Int): Boolean = favorites.contains(id)

    fun favoriteIds(): List<Int> = QuoteLogic.favoriteIds(favorites)

    fun favoriteQuotes(): List<Quote> = favoriteIds().mapNotNull { quotesById[it] }

    fun stats(): QuoteStats = QuoteLogic.stats(
        total = quotes.size,
        favoriteCount = favorites.size,
        refreshCount = todayState.refreshCount,
    )

    // ---- 写:内存即时更新 + 持久化(经 Store 端口) ----

    /** 刷新换一句:当日基数上 +1 回绕,即时生效并落盘 */
    fun refresh(): Quote {
        val next = (todayState.index + 1) % quotes.size
        todayState = todayState.copy(index = next, refreshCount = todayState.refreshCount + 1)
        persistToday()
        return todayQuote()
    }

    fun toggleFavorite(id: Int): Boolean {
        val now = !favorites.contains(id)
        if (now) favorites.add(id) else favorites.remove(id)
        persistFavorites()
        return now
    }

    // ---- 持久化 ----

    private fun persistToday() {
        store.putString(KEY_TODAY, QuoteLogic.serializeToday(todayState))
    }

    private fun persistFavorites() {
        store.putString(KEY_FAVORITES, favorites.sorted().joinToString(","))
    }

    companion object {
        private const val KEY_TODAY = "today.v1"
        private const val KEY_FAVORITES = "favorites.v1"

        @Volatile
        private var instance: AppRepo? = null

        fun getRepo(context: Context): AppRepo =
            instance ?: synchronized(this) {
                instance ?: AppRepo(
                    PrefsStore(context.applicationContext),
                    SystemClockPort(),
                    QuoteConstants.QUOTES,
                ).also { instance = it }
            }

        /** 仅供 JVM 单测注入(测试侧非 UI/卡片层,不受硬规则 1 约束) */
        fun createForTest(
            store: Store,
            clock: ClockPort,
            quotes: List<Quote> = QuoteConstants.QUOTES,
        ): AppRepo = AppRepo(store, clock, quotes)
    }
}
