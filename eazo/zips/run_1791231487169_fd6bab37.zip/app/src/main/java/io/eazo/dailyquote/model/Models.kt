package io.eazo.dailyquote.model

/** 语录种类:QUOTE=名人语录 / MOVIE=电影台词(枚举字面量双端 1:1) */
enum class QuoteKind { QUOTE, MOVIE }

/** 一句语录(id 确定性主键,排序主键) */
data class Quote(
    val id: Int,
    val text: String,
    val author: String,
    val source: String,
    val kind: QuoteKind,
)

/** 今日状态:epochDay 定位日期,index 当前句下标,refreshCount 当日已刷新次数 */
data class TodayState(
    val epochDay: Long,
    val index: Int,
    val refreshCount: Int,
)

/** 汇总统计 */
data class QuoteStats(
    val total: Int,
    val favoriteCount: Int,
    val refreshCount: Int,
)
