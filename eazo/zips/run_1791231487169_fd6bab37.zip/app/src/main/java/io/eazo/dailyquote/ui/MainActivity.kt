package io.eazo.dailyquote.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import io.eazo.dailyquote.R
import io.eazo.dailyquote.core.QuoteLogic
import io.eazo.dailyquote.model.Quote
import io.eazo.dailyquote.model.QuoteKind
import io.eazo.dailyquote.platform.AppRepo
import io.eazo.dailyquote.platform.SystemClockPort
import io.eazo.dailyquote.widget.TodayQuoteWidgetProvider
import java.util.Calendar
import java.util.TimeZone

/**
 * 首页:今日一句卡片 + 刷新换一句 / 收藏 / 分享 + 收藏入口。
 * 硬规则 2:onResume 只 render()(重读 AppRepo 内存态),禁止从持久化 reload。
 */
class MainActivity : AppCompatActivity() {

    private lateinit var repo: AppRepo

    private lateinit var tvDate: TextView
    private lateinit var tvKind: TextView
    private lateinit var tvText: TextView
    private lateinit var tvAuthor: TextView
    private lateinit var btnFavorite: ImageButton
    private lateinit var btnRefresh: View
    private lateinit var btnShare: View
    private lateinit var tvFavoritesEntry: TextView
    private lateinit var tvStats: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        repo = AppRepo.getRepo(this)
        bindViews()
        btnFavorite.setOnClickListener {
            val quote = repo.todayQuote()
            val nowFav = repo.toggleFavorite(quote.id)
            renderFavorite(quote, nowFav)
            renderStats()
        }
        btnRefresh.setOnClickListener {
            renderQuote(repo.refresh())
            renderStats()
            // 桌面卡片同步今日新句(重读内存态)
            TodayQuoteWidgetProvider.pushUpdate(this)
        }
        btnShare.setOnClickListener { share(repo.todayQuote()) }
        tvFavoritesEntry.setOnClickListener {
            startActivity(Intent(this, FavoritesActivity::class.java))
        }
    }

    /** 硬规则 2:跨页面写操作(收藏页取消收藏等)返回时即时可见 */
    override fun onResume() {
        super.onResume()
        render()
    }

    /** 热启动(桌面卡片点入,launchMode=singleTop):只重读内存态,同 onCreate 一路 */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        render()
    }

    private fun bindViews() {
        tvDate = findViewById(R.id.tv_date)
        tvKind = findViewById(R.id.tv_kind)
        tvText = findViewById(R.id.tv_quote_text)
        tvAuthor = findViewById(R.id.tv_quote_author)
        btnFavorite = findViewById(R.id.btn_favorite)
        btnRefresh = findViewById(R.id.btn_refresh)
        btnShare = findViewById(R.id.btn_share)
        tvFavoritesEntry = findViewById(R.id.tv_favorites_entry)
        tvStats = findViewById(R.id.tv_stats)
    }

    private fun render() {
        renderQuote(repo.todayQuote())
        renderDate()
        renderStats()
    }

    private fun renderQuote(quote: Quote) {
        tvKind.setText(
            if (quote.kind == QuoteKind.MOVIE) R.string.kind_movie else R.string.kind_quote,
        )
        tvText.text = quote.text
        tvAuthor.text = getString(R.string.author_line, quote.author, quote.source)
        renderFavorite(quote, repo.isFavorite(quote.id))
    }

    private fun renderFavorite(quote: Quote, isFav: Boolean) {
        btnFavorite.setImageResource(
            if (isFav) R.drawable.ic_star_filled else R.drawable.ic_star_outline,
        )
        btnFavorite.contentDescription =
            getString(if (isFav) R.string.cd_unfavorite else R.string.cd_favorite)
        val tint =
            ContextCompat.getColor(
                this,
                if (isFav) R.color.star_gold else R.color.icon_muted,
            )
        btnFavorite.setColorFilter(tint)
    }

    private fun renderDate() {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            timeInMillis = repo.today() * SystemClockPort.MILLIS_PER_DAY
        }
        val week = resources.getStringArray(R.array.weekdays)[cal.get(Calendar.DAY_OF_WEEK) - 1]
        tvDate.text = getString(
            R.string.date_line,
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH),
            week,
        )
    }

    private fun renderStats() {
        val stats = repo.stats()
        tvStats.text = getString(R.string.stats_line, stats.total, stats.refreshCount)
        tvFavoritesEntry.text = getString(R.string.favorites_entry, stats.favoriteCount)
    }

    private fun share(quote: Quote) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, QuoteLogic.shareText(quote))
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share_chooser)))
    }
}
