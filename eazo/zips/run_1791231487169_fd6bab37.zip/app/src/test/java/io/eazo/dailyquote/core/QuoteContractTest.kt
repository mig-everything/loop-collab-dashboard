package io.eazo.dailyquote.core

import io.eazo.dailyquote.model.Quote
import io.eazo.dailyquote.model.QuoteKind
import io.eazo.dailyquote.model.TodayState
import io.eazo.dailyquote.platform.AppRepo
import io.eazo.dailyquote.platform.ClockPort
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 契约测试:每日选句确定性 / 收藏排序 / 序列化往返 / 仓储单例语义。
 * 全部 JVM 纯逻辑,不依赖 Android 框架。
 */
class QuoteContractTest {

    // ---- 种子库卫生 ----

    @Test
    fun `种子库 id 唯一且从 1 连续递增`() {
        val ids = QuoteConstants.QUOTES.map { it.id }
        assertEquals(ids.distinct().size, ids.size)
        assertEquals((1..QuoteConstants.QUOTES.size).toList(), ids)
    }

    @Test
    fun `种子库字段非空且枚举字面量稳定`() {
        QuoteConstants.QUOTES.forEach { q ->
            assertTrue(q.text.isNotBlank())
            assertTrue(q.author.isNotBlank())
            assertTrue(q.source.isNotBlank())
            assertTrue(
                "kind 必须是 QUOTE 或 MOVIE(双端字面量 1:1)",
                q.kind == QuoteKind.QUOTE || q.kind == QuoteKind.MOVIE,
            )
        }
        assertEquals("QUOTE", QuoteKind.QUOTE.name)
        assertEquals("MOVIE", QuoteKind.MOVIE.name)
    }

    // ---- 每日选句确定性 ----

    @Test
    fun `同日期同刷新次数选句确定`() {
        val a = QuoteLogic.pickOfDay(QuoteConstants.COUNT, 20000L, 0)
        val b = QuoteLogic.pickOfDay(QuoteConstants.COUNT, 20000L, 0)
        assertEquals(a, b)
    }

    @Test
    fun `逐日轮换不越界且回绕`() {
        val count = QuoteConstants.COUNT
        for (day in 0L until 400L) {
            val idx = QuoteLogic.pickOfDay(count, day, 0)
            assertTrue(idx in 0 until count)
        }
    }

    @Test
    fun `刷新次数按 count 回绕`() {
        val count = QuoteConstants.COUNT
        val day = 12345L
        assertEquals(
            QuoteLogic.pickOfDay(count, day, 0),
            QuoteLogic.pickOfDay(count, day, count),
        )
        assertEquals(
            QuoteLogic.pickOfDay(count, day, 1),
            QuoteLogic.pickOfDay(count, day, count + 1),
        )
    }

    @Test
    fun `刷新逐步推进且覆盖全库`() {
        val count = QuoteConstants.COUNT
        val day = 7L
        val visited = (0 until count).map { QuoteLogic.pickOfDay(count, day, it) }.toSet()
        assertEquals(count, visited.size)
    }

    // ---- 跨日失效 ----

    @Test
    fun `保存态是今天则保留刷新进度`() {
        val saved = TodayState(epochDay = 100L, index = 3, refreshCount = 2)
        val resolved = QuoteLogic.resolveToday(saved, 100L, QuoteConstants.COUNT)
        assertEquals(saved, resolved)
    }

    @Test
    fun `跨日重置为当日基础句且刷新归零`() {
        val saved = TodayState(epochDay = 100L, index = 3, refreshCount = 2)
        val resolved = QuoteLogic.resolveToday(saved, 101L, QuoteConstants.COUNT)
        assertEquals(101L, resolved.epochDay)
        assertEquals(0, resolved.refreshCount)
        assertEquals(QuoteLogic.pickOfDay(QuoteConstants.COUNT, 101L, 0), resolved.index)
    }

    @Test
    fun `越界下标视为损坏数据并重置`() {
        val saved = TodayState(epochDay = 100L, index = 999, refreshCount = 2)
        val resolved = QuoteLogic.resolveToday(saved, 100L, QuoteConstants.COUNT)
        assertEquals(0, resolved.refreshCount)
    }

    // ---- 序列化往返 ----

    @Test
    fun `今日状态序列化往返一致`() {
        val state = TodayState(epochDay = 20701L, index = 5, refreshCount = 12)
        assertEquals(state, QuoteLogic.parseToday(QuoteLogic.serializeToday(state)))
    }

    @Test
    fun `损坏序列化输入返回 null`() {
        assertNull(QuoteLogic.parseToday(null))
        assertNull(QuoteLogic.parseToday(""))
        assertNull(QuoteLogic.parseToday("not-a-blob"))
        assertNull(QuoteLogic.parseToday("1|2"))
        assertNull(QuoteLogic.parseToday("abc|0|0"))
        assertNull(QuoteLogic.parseToday("100|-1|0"))
    }

    // ---- 收藏排序(确定性:id 升序,去重) ----

    @Test
    fun `收藏列表按 id 升序去重`() {
        val sorted = QuoteLogic.favoriteIds(setOf(9, 1, 5, 1, 28))
        assertEquals(listOf(1, 5, 9, 28), sorted)
    }

    @Test
    fun `空收藏返回空列表`() {
        assertTrue(QuoteLogic.favoriteIds(emptySet()).isEmpty())
    }

    // ---- 分享与卡片文案 ----

    @Test
    fun `分享文案包含原文作者出处与签名`() {
        val quote = QuoteConstants.QUOTES.first()
        val text = QuoteLogic.shareText(quote)
        assertTrue(text.contains(quote.text))
        assertTrue(text.contains(quote.author))
        assertTrue(text.contains(quote.source))
        assertTrue(text.contains("每日一句"))
        assertTrue(text.startsWith("「"))
    }

    @Test
    fun `卡片单行文案超长截断加省略号`() {
        val short = Quote(1, "短句", "作者", "出处", QuoteKind.QUOTE)
        assertEquals("短句", QuoteLogic.widgetLine(short, maxChars = 10))
        val long = Quote(2, "一".repeat(50), "作者", "出处", QuoteKind.MOVIE)
        val line = QuoteLogic.widgetLine(long, maxChars = 42)
        assertEquals(43, line.length)
        assertTrue(line.endsWith("…"))
    }

    // ---- 仓储语义(JVM 注入,单测侧允许 createForTest) ----

    private class FakeStore : io.eazo.dailyquote.platform.Store {
        val map = HashMap<String, String?>()
        override fun getString(key: String, def: String?): String? = map[key] ?: def
        override fun putString(key: String, value: String?) {
            map[key] = value
        }
    }

    private class FixedClock(private var day: Long) : ClockPort {
        override fun today(): Long = day
        fun advance() = day++
    }

    @Test
    fun `刷新即时可见且写穿持久化`() {
        val store = FakeStore()
        val clock = FixedClock(30000L)
        val repo = AppRepo.createForTest(store, clock)
        val before = repo.todayQuote()
        val after = repo.refresh()
        // 内存即时可见
        assertTrue(after.id != before.id)
        assertEquals(after.id, repo.todayQuote().id)
        assertEquals(1, repo.stats().refreshCount)
        // 写穿持久化:新实例同 store 读回同状态
        val reborn = AppRepo.createForTest(store, clock)
        assertEquals(after.id, reborn.todayQuote().id)
        assertEquals(1, reborn.stats().refreshCount)
    }

    @Test
    fun `收藏切换即时可见且写穿持久化`() {
        val store = FakeStore()
        val repo = AppRepo.createForTest(store, FixedClock(1L))
        val quote = repo.todayQuote()
        assertTrue(repo.toggleFavorite(quote.id))
        assertTrue(repo.isFavorite(quote.id))
        assertFalse(repo.toggleFavorite(quote.id))
        assertFalse(repo.isFavorite(quote.id))
        // 写穿持久化
        repo.toggleFavorite(quote.id)
        val reborn = AppRepo.createForTest(store, FixedClock(1L))
        assertTrue(reborn.isFavorite(quote.id))
        assertEquals(listOf(quote.id), reborn.favoriteIds())
    }

    @Test
    fun `冷启动跨日重置刷新进度`() {
        val store = FakeStore()
        val repo = AppRepo.createForTest(store, FixedClock(500L))
        repo.refresh()
        repo.refresh()
        assertEquals(2, repo.stats().refreshCount)
        val reborn = AppRepo.createForTest(store, FixedClock(501L))
        assertEquals(0, reborn.stats().refreshCount)
        assertEquals(QuoteLogic.pickOfDay(QuoteConstants.COUNT, 501L, 0), reborn.todayState().index)
    }

    @Test
    fun `统计与收藏快照一致`() {
        val store = FakeStore()
        val repo = AppRepo.createForTest(store, FixedClock(9L))
        val q1 = repo.todayQuote()
        val other = QuoteConstants.QUOTES.last()
        repo.toggleFavorite(q1.id)
        repo.toggleFavorite(other.id)
        repo.toggleFavorite(other.id) // 再切一次 = 取消
        val stats = repo.stats()
        assertEquals(QuoteConstants.COUNT, stats.total)
        assertEquals(1, stats.favoriteCount)
        assertEquals(listOf(q1.id), repo.favoriteQuotes().map { it.id })
    }

    @Test
    fun `quoteOf 覆盖全部种子 id`() {
        val repo = AppRepo.createForTest(FakeStore(), FixedClock(0L))
        QuoteConstants.QUOTES.forEach { assertEquals(it, repo.quoteOf(it.id)) }
        assertNull(repo.quoteOf(-1))
        assertNull(repo.quoteOf(0))
        assertNull(repo.quoteOf(QuoteConstants.COUNT + 1))
    }
}
