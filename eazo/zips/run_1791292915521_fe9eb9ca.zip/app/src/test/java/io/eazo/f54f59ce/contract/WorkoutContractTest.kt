package io.eazo.f54f59ce.contract

import io.eazo.f54f59ce.core.CheckIn
import io.eazo.f54f59ce.core.Codec
import io.eazo.f54f59ce.core.IntervalConfig
import io.eazo.f54f59ce.core.KIND_CUSTOM
import io.eazo.f54f59ce.core.KIND_PRESET
import io.eazo.f54f59ce.core.MILLIS_PER_DAY
import io.eazo.f54f59ce.core.PhaseType
import io.eazo.f54f59ce.core.PRESET_CONFIG
import io.eazo.f54f59ce.core.PARAM_AUTO_START
import io.eazo.f54f59ce.core.PARAM_OPEN_TIMER
import io.eazo.f54f59ce.core.PRESET_EXERCISES
import io.eazo.f54f59ce.core.buildPlan
import io.eazo.f54f59ce.core.checkInId
import io.eazo.f54f59ce.core.currentStreak
import io.eazo.f54f59ce.core.epochDayOf
import io.eazo.f54f59ce.core.exerciseAtRound
import io.eazo.f54f59ce.core.longestStreak
import io.eazo.f54f59ce.core.planTotalSeconds
import io.eazo.f54f59ce.core.readOpenCreate
import io.eazo.f54f59ce.core.sortedCheckIns
import io.eazo.f54f59ce.core.stepAt
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * REQ-012 契约用例（JUnit4 纯 JVM，不依赖 Android 框架）：
 * 计划确定性 / 步骤边界 / 打卡连续天数 / 确定性排序 / 编解码往返 / 严格布尔解析。
 */
class WorkoutContractTest {

    /* ---- 预设计划：12 动作 × 30s 运动 + 10s 休息 ---- */

    @Test
    fun `预设配置为12轮30秒运动10秒休息`() {
        assertEquals(12, PRESET_CONFIG.rounds)
        assertEquals(30, PRESET_CONFIG.workSeconds)
        assertEquals(10, PRESET_CONFIG.restSeconds)
    }

    @Test
    fun `预设动作恰为12个且id定宽字典序等于序列序`() {
        assertEquals(12, PRESET_EXERCISES.size)
        val ids = PRESET_EXERCISES.map { it.id }
        assertEquals(ids.sorted(), ids)
        assertEquals((1..12).map { "ex" + it.toString().padStart(2, '0') }, ids)
    }

    @Test
    fun `预设计划结构为12运动段加11休息段且首尾确定`() {
        val plan = buildPlan(PRESET_CONFIG)
        assertEquals(23, plan.size)
        assertEquals(12, plan.count { it.phaseType == PhaseType.WORK })
        assertEquals(11, plan.count { it.phaseType == PhaseType.REST })
        // 首步：第 1 轮 WORK ex01
        assertEquals(PhaseType.WORK, plan[0].phaseType)
        assertEquals(1, plan[0].round)
        assertEquals("ex01", plan[0].exerciseId)
        assertEquals(30, plan[0].seconds)
        // 第 2 步：第 1 轮 REST
        assertEquals(PhaseType.REST, plan[1].phaseType)
        assertEquals(1, plan[1].round)
        assertEquals(10, plan[1].seconds)
        // 末步：第 12 轮 WORK（末轮无 REST）
        assertEquals(PhaseType.WORK, plan[22].phaseType)
        assertEquals(12, plan[22].round)
        assertEquals("ex12", plan[22].exerciseId)
        // 动作序列与预设序列 1:1
        assertEquals(PRESET_EXERCISES.map { it.id }, plan.filter { it.phaseType == PhaseType.WORK }.map { it.exerciseId })
        // index 全局递增 0..22
        assertEquals((0..22).toList(), plan.map { it.index })
    }

    @Test
    fun `预设计划总时长为470秒`() {
        assertEquals(12 * 30 + 11 * 10, planTotalSeconds(buildPlan(PRESET_CONFIG)))
    }

    @Test
    fun `计划构建确定性_同配置两次构建完全一致`() {
        assertEquals(buildPlan(PRESET_CONFIG), buildPlan(PRESET_CONFIG))
        assertEquals(buildPlan(IntervalConfig(20, 15, 7)), buildPlan(IntervalConfig(20, 15, 7)))
    }

    /* ---- 自定义计划 ---- */

    @Test
    fun `自定义计划_5轮20秒运动10秒休息结构正确`() {
        val plan = buildPlan(IntervalConfig(20, 10, 5))
        assertEquals(9, plan.size)
        assertEquals(5 * 20 + 4 * 10, planTotalSeconds(plan))
        assertTrue(plan.all { it.phaseType == PhaseType.WORK || it.phaseType == PhaseType.REST })
    }

    @Test
    fun `自定义计划_零休息则无休息段`() {
        val plan = buildPlan(IntervalConfig(30, 0, 4))
        assertEquals(4, plan.size)
        assertTrue(plan.all { it.phaseType == PhaseType.WORK })
        assertEquals(120, planTotalSeconds(plan))
    }

    @Test
    fun `自定义轮数超12时动作循环取模`() {
        val plan = buildPlan(IntervalConfig(30, 10, 14))
        assertEquals("ex01", plan.first { it.round == 13 && it.phaseType == PhaseType.WORK }.exerciseId)
        assertEquals("ex02", plan.first { it.round == 14 && it.phaseType == PhaseType.WORK }.exerciseId)
        assertEquals(exerciseAtRound(14).id, "ex02")
    }

    /* ---- stepAt 边界契约 ---- */

    @Test
    fun `步骤定位_区间左闭右开与结束哨兵`() {
        val plan = buildPlan(IntervalConfig(30, 10, 2)) // W30 R10 W30
        assertEquals(0, stepAt(plan, 0))     // 首步起点
        assertEquals(0, stepAt(plan, 29))    // 首步最后 1 秒
        assertEquals(1, stepAt(plan, 30))    // 休息步起点
        assertEquals(1, stepAt(plan, 39))
        assertEquals(2, stepAt(plan, 40))    // 第 2 轮 WORK
        assertEquals(2, stepAt(plan, 69))
        assertEquals(-1, stepAt(plan, 70))   // 越过总时长 → 结束
        assertEquals(-1, stepAt(plan, 9999))
    }

    /* ---- 打卡 id 与确定性排序（硬规则 ③） ---- */

    @Test
    fun `打卡id确定性且同天同kind内字典序等于seq序`() {
        assertEquals("ci_020000_preset_01", checkInId(20000, KIND_PRESET, 1))
        val ids = (1..12).map { checkInId(20000, KIND_CUSTOM, it) }
        assertEquals(ids.sorted(), ids)
    }

    @Test
    fun `打卡排序_主键epochDay降序_id字典序降序兜底`() {
        val list = listOf(
            CheckIn("ci_020001_preset_01", 20001, KIND_PRESET, 470),
            CheckIn("ci_020000_custom_02", 20000, KIND_CUSTOM, 140),
            CheckIn("ci_020000_custom_01", 20000, KIND_CUSTOM, 470),
            CheckIn("ci_019999_preset_01", 19999, KIND_PRESET, 470),
        )
        val sorted = sortedCheckIns(list)
        assertEquals(
            listOf("ci_020001_preset_01", "ci_020000_custom_02", "ci_020000_custom_01", "ci_019999_preset_01"),
            sorted.map { it.id },
        )
    }

    /* ---- 连续天数统计 ---- */

    @Test
    fun `连续天数_空集为0`() {
        assertEquals(0, currentStreak(emptySet(), 20000))
        assertEquals(0, longestStreak(emptySet()))
    }

    @Test
    fun `连续天数_仅今天为1_今天加昨天为2`() {
        assertEquals(1, currentStreak(setOf(20000L), 20000))
        assertEquals(2, currentStreak(setOf(19999L, 20000L), 20000))
    }

    @Test
    fun `连续天数_今天未打则从昨天回数`() {
        assertEquals(1, currentStreak(setOf(19999L), 20000))
        assertEquals(3, currentStreak(setOf(19997L, 19998L, 19999L), 20000))
    }

    @Test
    fun `连续天数_断档清零`() {
        // 今天与 3 天前打过，昨天/前天缺 → 1
        assertEquals(1, currentStreak(setOf(19997L, 20000L), 20000))
        // 全部在过去且昨天起断档 → 0
        assertEquals(0, currentStreak(setOf(19997L, 19998L), 20000))
    }

    @Test
    fun `最长连续_跨断档取最大段`() {
        val days = setOf(1L, 2L, 3L, 5L, 6L, 10L)
        assertEquals(3, longestStreak(days))
        assertEquals(5, longestStreak(setOf(1L, 2L, 3L, 4L, 5L, 8L)))
        assertEquals(1, longestStreak(setOf(7L)))
    }

    /* ---- 编解码往返 ---- */

    @Test
    fun `打卡编解码往返_空_单条_多条`() {
        assertEquals("", Codec.encodeCheckIns(emptyList()))
        assertEquals(0, Codec.decodeCheckIns("").size)
        val one = listOf(CheckIn("ci_020000_preset_01", 20000, KIND_PRESET, 470))
        assertEquals(one, Codec.decodeCheckIns(Codec.encodeCheckIns(one)))
        val many = one + CheckIn("ci_020000_custom_02", 20000, KIND_CUSTOM, 140)
        assertEquals(many, Codec.decodeCheckIns(Codec.encodeCheckIns(many)))
    }

    @Test
    fun `配置编解码往返`() {
        assertEquals("30,10,12", Codec.encodeConfig(PRESET_CONFIG))
        assertEquals(PRESET_CONFIG, Codec.decodeConfig("30,10,12"))
        assertEquals(IntervalConfig(20, 0, 5), Codec.decodeConfig(Codec.encodeConfig(IntervalConfig(20, 0, 5))))
    }

    /* ---- 打开参数严格布尔（硬规则 ④） ---- */

    @Test
    fun `打开参数_缺省全否`() {
        assertEquals(false, readOpenCreate(emptyMap<String, Any?>()).openTimer)
        assertEquals(false, readOpenCreate(emptyMap<String, Any?>()).autoStart)
        assertEquals(false, readOpenCreate(mapOf("other" to 1)).autoStart)
    }

    @Test
    fun `打开参数_仅布尔true命中_字符串true与布尔false不命中`() {
        assertTrue(readOpenCreate(mapOf(PARAM_OPEN_TIMER to true)).openTimer)
        assertTrue(readOpenCreate(mapOf(PARAM_OPEN_TIMER to true, PARAM_AUTO_START to true)).autoStart)
        // 字符串 "true" 不是 Boolean —— 严格判定不命中
        assertFalse(readOpenCreate(mapOf(PARAM_OPEN_TIMER to "true")).openTimer)
        assertFalse(readOpenCreate(mapOf(PARAM_AUTO_START to "true")).autoStart)
        assertFalse(readOpenCreate(mapOf(PARAM_OPEN_TIMER to java.lang.Boolean.FALSE)).openTimer)
        assertFalse(readOpenCreate(mapOf(PARAM_OPEN_TIMER to 1)).openTimer)
    }

    /* ---- 本地纪元天 ---- */

    @Test
    fun `纪元天按毫秒取整_含时区偏移`() {
        assertEquals(0L, epochDayOf(0, 0))
        assertEquals(0L, epochDayOf(MILLIS_PER_DAY - 1, 0))
        assertEquals(1L, epochDayOf(MILLIS_PER_DAY, 0))
        // 正偏移提前进新的一天
        assertEquals(1L, epochDayOf(MILLIS_PER_DAY - 3_600_000, 3_600_000))
        assertEquals(20000L, epochDayOf(20000 * MILLIS_PER_DAY, 0))
    }
}
