package io.eazo.f54f59ce.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.f54f59ce.core.CheckIn
import io.eazo.f54f59ce.core.IntervalConfig
import io.eazo.f54f59ce.core.KIND_CUSTOM
import io.eazo.f54f59ce.core.KIND_PRESET
import io.eazo.f54f59ce.core.MILLIS_PER_DAY
import io.eazo.f54f59ce.core.OpenSpec
import io.eazo.f54f59ce.core.PhaseType
import io.eazo.f54f59ce.core.PRESET_CONFIG
import io.eazo.f54f59ce.core.PRESET_EXERCISES
import io.eazo.f54f59ce.core.buildPlan
import io.eazo.f54f59ce.core.currentStreak
import io.eazo.f54f59ce.core.epochDayOf
import io.eazo.f54f59ce.core.longestStreak
import io.eazo.f54f59ce.core.planTotalSeconds
import io.eazo.f54f59ce.core.readOpenCreate
import io.eazo.f54f59ce.platform.AppRepo
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone

/**
 * 主界面：单 Activity + Jetpack Compose（UI 锁死声明式——与鸿蒙 ArkUI
 * 声明式对称，禁止 XML 布局/drawable 扇出）。
 *
 * 硬规则 ④：冷启动 onCreate(intent) 与热启动 onNewIntent(intent) 两路
 * 都走同一 readOpenCreate 纯函数解析打开参数；硬规则 ②：onResume 只
 * refresh()（重读内存态），禁止从持久化 load()。
 */
class MainActivity : ComponentActivity() {

    /** 打开参数状态——两路（onCreate/onNewIntent）写，组合层读。 */
    private val openSpec = mutableStateOf(OpenSpec(openTimer = false, autoStart = false))

    /** onResume 刷新时钟——驱动组合层重读内存态。 */
    private val refreshTick = mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AppRepo.getRepo(applicationContext) // 同步 init 先于 setContent（REQ-012 判例）
        applyOpenSpec(intent)
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Screen(openSpec.value, refreshTick.value)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        applyOpenSpec(intent)
    }

    /** 两路共用同一纯函数解析（硬规则 ④），不区分冷热启动。 */
    private fun applyOpenSpec(intent: Intent?) {
        val extras = intent?.extras
        val params = HashMap<String, Any?>()
        if (extras != null) {
            for (key in extras.keySet()) {
                params[key] = extras.get(key)
            }
        }
        openSpec.value = readOpenCreate(params)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(applicationContext).refresh()
        refreshTick.value = refreshTick.value + 1
    }
}

/* ---------------- 主题（浅色，运动活力配色） ---------------- */

private val BrandOrange = Color(0xFFE8552F)
private val BrandTeal = Color(0xFF159E8C)
private val BrandBg = Color(0xFFF7F5F2)
private val BrandCard = Color(0xFFFFFFFF)

/** 骨架默认主题：配色在此定制，不另建 XML 主题。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MaterialTheme.colorScheme.copy(
            primary = BrandOrange,
            onPrimary = Color.White,
            secondary = BrandTeal,
            onSecondary = Color.White,
            background = BrandBg,
            surface = BrandCard,
        ),
        content = content,
    )
}

/* ---------------- 路由状态机 ---------------- */

private enum class Route { HOME, RUNNING, DONE }

@Composable
private fun Screen(openSpec: OpenSpec, refreshTick: Int) {
    var route by remember { mutableStateOf(Route.HOME) }
    var autoStart by remember { mutableStateOf(false) }
    var selectedKind by remember { mutableStateOf(KIND_PRESET) }

    // 硬规则 ④ 消费：openTimer 命中即跳计时器（autoStart 决定是否自动开跑）
    LaunchedEffect(openSpec) {
        if (openSpec.openTimer) {
            selectedKind = KIND_PRESET
            autoStart = openSpec.autoStart
            route = Route.RUNNING
        }
    }

    when (route) {
        Route.HOME -> HomeScreen(refreshTick, onStart = { kind ->
            selectedKind = kind
            route = Route.RUNNING
        })
        Route.RUNNING -> RunningScreen(
            kind = selectedKind,
            autoStart = autoStart,
            onFinished = { route = Route.DONE },
            onAborted = { route = Route.HOME },
        )
        Route.DONE -> DoneScreen(onBack = { route = Route.HOME })
    }
    // refreshTick 参与组合（经由子组件入参链重读内存态），仅供 onResume 刷新
    @Suppress("UNUSED_EXPRESSION")
    refreshTick
}

private fun localEpochDay(): Long {
    val now = System.currentTimeMillis()
    return epochDayOf(now, TimeZone.getDefault().getOffset(now).toLong())
}

/* ---------------- 首页 ---------------- */

@Composable
private fun HomeScreen(refreshTick: Int, onStart: (String) -> Unit) {
    val repo = AppRepo.getRepo(LocalContext.current)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Spacer(Modifier.height(12.dp))
        Text("7 分钟健身", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(
            "科学间歇 · 每天一次 · 坚持打卡",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
        )
        StatsCard(repo)
        PresetCard(onStart)
        CustomCard(repo, onStart)
        RecentCard(repo)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun StatsCard(repo: AppRepo) {
    val days = repo.checkInDays()
    val today = localEpochDay()
    val todayCount = repo.listCheckIns().count { it.epochDay == today }
    val streak = currentStreak(days, today)
    val longest = longestStreak(days)

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            StatItem("今日已练", "$todayCount", "次")
            StatItem("连续打卡", "$streak", "天")
            StatItem("最长连续", "$longest", "天")
        }
    }
}

@Composable
private fun StatItem(label: String, value: String, unit: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                value,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
            Text(" $unit", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
        }
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f))
    }
}

@Composable
private fun PresetCard(onStart: (String) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("经典 7 分钟训练", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "${PRESET_CONFIG.rounds} 个固定动作 · ${PRESET_CONFIG.workSeconds}s 运动 + ${PRESET_CONFIG.restSeconds}s 休息 · 共 ${planTotalSeconds(buildPlan(PRESET_CONFIG))} 秒",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
            )
            Text(
                PRESET_EXERCISES.joinToString(" · ") { it.name },
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f),
            )
            Button(
                onClick = { onStart(KIND_PRESET) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(14.dp),
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("开始训练", fontSize = 16.sp)
            }
        }
    }
}

@Composable
private fun CustomCard(repo: AppRepo, onStart: (String) -> Unit) {
    var work by remember { mutableStateOf(repo.getConfig().workSeconds) }
    var rest by remember { mutableStateOf(repo.getConfig().restSeconds) }
    var rounds by remember { mutableStateOf(repo.getConfig().rounds) }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("自定义间歇", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Stepper("运动时长", work, 10, 90, 5, "秒") { work = it }
            Stepper("休息时长", rest, 0, 60, 5, "秒") { rest = it }
            Stepper("训练轮数", rounds, 1, 20, 1, "轮") { rounds = it }
            FilledTonalButton(
                onClick = {
                    val config = IntervalConfig(work, rest, rounds)
                    repo.setConfig(config)
                    onStart(KIND_CUSTOM)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(14.dp),
            ) {
                Text("开始自定义训练", fontSize = 16.sp)
            }
        }
    }
}

@Composable
private fun Stepper(
    label: String,
    value: Int,
    min: Int,
    max: Int,
    step: Int,
    unit: String,
    onChange: (Int) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, fontSize = 15.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilledTonalButton(
                onClick = { if (value - step >= min) onChange(value - step) },
                enabled = value - step >= min,
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(40.dp),
            ) { Text("−", fontSize = 18.sp) }
            Text("  $value $unit  ", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            FilledTonalButton(
                onClick = { if (value + step <= max) onChange(value + step) },
                enabled = value + step <= max,
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(40.dp),
            ) { Text("+", fontSize = 18.sp) }
        }
    }
}

@Composable
private fun RecentCard(repo: AppRepo) {
    val recent = repo.listCheckIns().take(5)
    if (recent.isEmpty()) return
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("最近打卡", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            recent.forEach { CheckInRow(it) }
        }
    }
}

@Composable
private fun CheckInRow(checkIn: CheckIn) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.CheckCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(formatEpochDay(checkIn.epochDay), fontSize = 14.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                if (checkIn.kind == KIND_PRESET) "经典训练" else "自定义",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            )
        }
        Text(
            "${checkIn.totalSeconds / 60} 分 ${checkIn.totalSeconds % 60} 秒",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
        )
    }
}

/** epochDay → MM-dd 展示（epochDay 以 GMT 日界反解，纯展示）。 */
private fun formatEpochDay(epochDay: Long): String {
    val fmt = SimpleDateFormat("MM-dd")
    fmt.timeZone = TimeZone.getTimeZone("GMT")
    return fmt.format(Date(epochDay * MILLIS_PER_DAY))
}

/* ---------------- 训练中 ---------------- */

@Composable
private fun RunningScreen(
    kind: String,
    autoStart: Boolean,
    onFinished: () -> Unit,
    onAborted: () -> Unit,
) {
    val repo = AppRepo.getRepo(LocalContext.current)
    val config = remember { repo.getConfig() }
    val plan = remember(config) { buildPlan(config) }
    val total = remember(config) { planTotalSeconds(plan) }
    var stepIndex by remember(config) { mutableStateOf(0) }
    var remaining by remember(config) { mutableStateOf(plan[0].seconds) }
    var running by remember(config) { mutableStateOf(autoStart) }

    fun finishWithCheckIn() {
        repo.addCheckIn(localEpochDay(), kind, total)
        onFinished()
    }

    // 每秒 tick：优先递减当前步剩余；归零则推进下一步；最后一步结束 → 完成打卡
    LaunchedEffect(running) {
        while (running && isActive) {
            delay(1000)
            if (remaining > 1) {
                remaining--
            } else if (stepIndex < plan.size - 1) {
                stepIndex++
                remaining = plan[stepIndex].seconds
            } else {
                finishWithCheckIn()
                return@LaunchedEffect
            }
        }
    }

    val step = plan[stepIndex]
    val isWork = step.phaseType == PhaseType.WORK
    val phaseColor = if (isWork) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
    val fraction = if (step.seconds <= 0) 0f else remaining.toFloat() / step.seconds.toFloat()
    val nextName = if (stepIndex + 1 < plan.size && plan[stepIndex + 1].phaseType == PhaseType.WORK) {
        plan[stepIndex + 1].exerciseName
    } else {
        null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            "第 ${step.round} / ${config.rounds} 轮",
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
        )
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(280.dp)) {
            Canvas(Modifier.size(280.dp)) {
                val strokeWidth = 20f
                val inset = strokeWidth
                val arcSize = androidx.compose.ui.geometry.Size(
                    size.minDimension - inset * 2,
                    size.minDimension - inset * 2,
                )
                val topLeft = Offset(inset, inset)
                drawCircle(
                    color = Color(0x14000000),
                    radius = arcSize.minDimension / 2,
                    center = Offset(size.width / 2, size.height / 2),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                )
                drawArc(
                    color = phaseColor,
                    startAngle = -90f,
                    sweepAngle = 360f * fraction,
                    useCenter = false,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
                    size = arcSize,
                    topLeft = topLeft,
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (isWork) "运动" else "休息",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = phaseColor,
                )
                Text(
                    "$remaining",
                    fontSize = 76.sp,
                    fontWeight = FontWeight.Bold,
                )
                if (isWork) {
                    Text(step.exerciseName, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                } else if (nextName != null) {
                    Text(
                        "下一个：$nextName",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                    )
                }
            }
        }
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Button(
                onClick = { running = !running },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp),
            ) { Text(if (running) "暂停" else "继续", fontSize = 17.sp) }
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                TextButton(onClick = {
                    if (stepIndex < plan.size - 1) {
                        stepIndex++
                        remaining = plan[stepIndex].seconds
                    } else {
                        finishWithCheckIn()
                    }
                }) { Text("跳过", fontSize = 15.sp) }
                TextButton(onClick = onAborted) { Text("结束训练", fontSize = 15.sp) }
            }
        }
    }
}

/* ---------------- 完成页 ---------------- */

@Composable
private fun DoneScreen(onBack: () -> Unit) {
    val repo = AppRepo.getRepo(LocalContext.current)
    val days = repo.checkInDays()
    val today = localEpochDay()
    val streak = currentStreak(days, today)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            Icons.Filled.CheckCircle,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.size(96.dp),
        )
        Spacer(Modifier.height(20.dp))
        Text("训练完成！", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "打卡成功 · 已连续 $streak 天",
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
        )
        Spacer(Modifier.height(36.dp))
        Button(
            onClick = onBack,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(16.dp),
        ) { Text("回到首页", fontSize = 16.sp) }
    }
}
