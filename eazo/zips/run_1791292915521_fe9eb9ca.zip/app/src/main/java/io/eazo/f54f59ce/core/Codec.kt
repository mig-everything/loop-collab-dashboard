package io.eazo.f54f59ce.core

/**
 * 持久化编解码——行式纯文本格式（字段均无 | 与换行，安全）：
 *   CheckIn: id|epochDay|kind|totalSeconds，一行一条；
 *   Config:  workSeconds,restSeconds,rounds。
 * 纯函数进契约测试；双端序列化口径 1:1。
 */
object Codec {

    fun encodeCheckIns(list: List<CheckIn>): String =
        list.joinToString("\n") { "${it.id}|${it.epochDay}|${it.kind}|${it.totalSeconds}" }

    fun decodeCheckIns(text: String): List<CheckIn> =
        text.split("\n")
            .filter { it.isNotBlank() }
            .map { line ->
                val p = line.split("|")
                CheckIn(id = p[0], epochDay = p[1].toLong(), kind = p[2], totalSeconds = p[3].toInt())
            }

    fun encodeConfig(c: IntervalConfig): String =
        "${c.workSeconds},${c.restSeconds},${c.rounds}"

    fun decodeConfig(text: String): IntervalConfig {
        val p = text.split(",")
        return IntervalConfig(workSeconds = p[0].toInt(), restSeconds = p[1].toInt(), rounds = p[2].toInt())
    }
}
