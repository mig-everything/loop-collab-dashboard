package io.eazo.f54f59ce.core

/**
 * 领域模型——双端字段 1:1（硬规则 ③）：字段名与鸿蒙端 Models 完全一致，
 * 枚举字面量 WORK/REST 一字不差，禁止两端各自漂移。
 */

/** 训练阶段类型（枚举字面量双端锁死）。 */
enum class PhaseType { WORK, REST }

/** 训练动作。 */
data class Exercise(
    val id: String,
    val name: String,
    val desc: String,
)

/** 间歇配置：运动秒数 / 休息秒数 / 轮数。 */
data class IntervalConfig(
    val workSeconds: Int,
    val restSeconds: Int,
    val rounds: Int,
)

/** 计划步骤：第 round 轮的 WORK/REST 段，seconds 为该段时长。 */
data class PlanStep(
    val index: Int,
    val round: Int,
    val phaseType: PhaseType,
    val seconds: Int,
    val exerciseId: String,
    val exerciseName: String,
)

/** 打卡记录：epochDay 为本地纪元天，kind ∈ {preset, custom}。 */
data class CheckIn(
    val id: String,
    val epochDay: Long,
    val kind: String,
    val totalSeconds: Int,
)
