package io.eazo.f54f59ce.core

/**
 * 打开参数解析——硬规则 ④：冷启动 onCreate(intent) 与热启动 onNewIntent
 * (intent) 两路竞态都走同一个 readOpenCreate 纯函数；布尔参数严格判定
 * （等价鸿蒙 typeof v === 'boolean' && v === true，字符串 "true" 不算）。
 */
const val PARAM_OPEN_TIMER = "openTimer"
const val PARAM_AUTO_START = "autoStart"

data class OpenSpec(
    val openTimer: Boolean,
    val autoStart: Boolean,
)

/** 严格布尔判定：仅当参数本身就是 Boolean true 才为真。 */
fun strictBool(v: Any?): Boolean = v is Boolean && v == true

fun readOpenCreate(params: Map<String, Any?>): OpenSpec = OpenSpec(
    openTimer = strictBool(params[PARAM_OPEN_TIMER]),
    autoStart = strictBool(params[PARAM_AUTO_START]),
)
