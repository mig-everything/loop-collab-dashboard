package io.eazo.f54f59ce.core

/**
 * 打卡连续天数统计——纯函数，双端算法 1:1。
 */

/**
 * 当前连续天数：以 today（若今天已打卡）或 yesterday（今天未打时仍延续
 * 到昨天为止）为终点向过去逐天回数。今天未打且昨天也未打 → 0。
 */
fun currentStreak(days: Set<Long>, today: Long): Int {
    var d = if (today in days) today else today - 1
    var streak = 0
    while (d in days) {
        streak++
        d--
    }
    return streak
}

/** 历史最长连续天数。 */
fun longestStreak(days: Set<Long>): Int {
    if (days.isEmpty()) return 0
    val sorted = days.sorted()
    var best = 1
    var cur = 1
    for (i in 1 until sorted.size) {
        cur = if (sorted[i] == sorted[i - 1] + 1) cur + 1 else 1
        if (cur > best) best = cur
    }
    return best
}

/**
 * 确定性排序（硬规则 ③）：主键 epochDay 降序，次键 id 字典序降序兜底。
 */
fun sortedCheckIns(list: List<CheckIn>): List<CheckIn> =
    list.sortedWith(compareByDescending<CheckIn> { it.epochDay }.thenByDescending { it.id })
