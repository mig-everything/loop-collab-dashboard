package io.eazo.f54f59ce.platform

import android.content.Context
import android.content.SharedPreferences
import io.eazo.f54f59ce.core.CheckIn
import io.eazo.f54f59ce.core.Codec
import io.eazo.f54f59ce.core.IntervalConfig
import io.eazo.f54f59ce.core.PRESET_CONFIG
import io.eazo.f54f59ce.core.checkInId
import io.eazo.f54f59ce.core.sortedCheckIns

/**
 * 骨架模板平台层：AppRepo 进程内单例（生成器硬规则 ①——UI/卡片层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * AppRepo 本身即进程内单例（Kotlin object）；业务仓储/持久化作为本 object
 * 的成员挂接：内存态持有打卡 list 与间歇 config，init(context) 同步装载
 * 持久化到内存（对齐 onCreate 先 init 后 setContent 的时序，杜绝 async
 * 竞态——REQ-012 判例），之后 list()/config() 只读内存态。
 */
object AppRepo {

    private const val PREFS_NAME = "workout_prefs"
    private const val KEY_CHECK_INS = "check_ins"
    private const val KEY_CONFIG = "interval_config"

    private var initialized = false
    private var prefs: SharedPreferences? = null

    private val checkIns = mutableListOf<CheckIn>()
    private var intervalConfig: IntervalConfig = PRESET_CONFIG

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo {
        init(context)
        return this
    }

    /** 同步初始化：只执行一次，持久化装载进内存后再返回（先 init 后 UI）。 */
    fun init(context: Context) {
        synchronized(this) {
            if (initialized) return
            prefs = context.applicationContext
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            intervalConfig = Codec.decodeConfig(
                prefs!!.getString(KEY_CONFIG, null) ?: Codec.encodeConfig(PRESET_CONFIG),
            )
            checkIns.clear()
            checkIns.addAll(Codec.decodeCheckIns(prefs!!.getString(KEY_CHECK_INS, "") ?: ""))
            initialized = true
        }
    }

    /** 硬规则 ②：refresh 只重读内存态（内存态写路径即时更新），禁止从持久化 load()。 */
    fun refresh() {
        // 内存态即唯一真源；onResume 走这里触发 UI 重读 list()。
    }

    /** 打卡列表——内存态快照，确定性排序（epochDay 降序 + id 字典序降序兜底）。 */
    fun listCheckIns(): List<CheckIn> = sortedCheckIns(checkIns)

    /** 当前间歇配置（内存态）。 */
    fun getConfig(): IntervalConfig = intervalConfig

    /** 更新间歇配置并持久化。 */
    fun setConfig(config: IntervalConfig) {
        intervalConfig = config
        prefs?.edit()?.putString(KEY_CONFIG, Codec.encodeConfig(config))?.apply()
    }

    /** 新增打卡（seq = 同天同 kind 现有条数 + 1，id 确定性）并持久化。 */
    fun addCheckIn(epochDay: Long, kind: String, totalSeconds: Int): CheckIn {
        val seq = checkIns.count { it.epochDay == epochDay && it.kind == kind } + 1
        val record = CheckIn(checkInId(epochDay, kind, seq), epochDay, kind, totalSeconds)
        checkIns.add(record)
        prefs?.edit()?.putString(KEY_CHECK_INS, Codec.encodeCheckIns(checkIns))?.apply()
        return record
    }

    /** 已打卡的本地纪元天集合（内存态）。 */
    fun checkInDays(): Set<Long> = checkIns.map { it.epochDay }.toSet()
}
