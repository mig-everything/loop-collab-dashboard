package io.eazo.f54f59ce.core

/** 经典 7 分钟训练常量（12 动作 × 30s 运动 + 10s 休息，确定性序列）。 */
const val PRESET_WORK_SECONDS = 30
const val PRESET_REST_SECONDS = 10
const val PRESET_ROUNDS = 12

/** 动作种 kind 字面量（双端 1:1）。 */
const val KIND_PRESET = "preset"
const val KIND_CUSTOM = "custom"

val PRESET_CONFIG = IntervalConfig(PRESET_WORK_SECONDS, PRESET_REST_SECONDS, PRESET_ROUNDS)

/**
 * 12 个固定动作——科学 7 分钟训练经典序列，顺序即训练顺序（确定性，
 * 双端一致，禁止排序漂移）。id 用 0 填充定宽，保证字典序 == 序列序。
 */
val PRESET_EXERCISES: List<Exercise> = listOf(
    Exercise("ex01", "开合跳", "原地跳跃双臂上举，快速激活全身热身"),
    Exercise("ex02", "靠墙静蹲", "背贴墙屈膝九十度，锻炼大腿前侧耐力"),
    Exercise("ex03", "俯卧撑", "身体成直线屈臂下压，强化胸肩与手臂"),
    Exercise("ex04", "卷腹", "下背贴地卷起上身，专注腹部核心发力"),
    Exercise("ex05", "踏凳登阶", "单脚踩凳发力上踏，提升下肢力量与心率"),
    Exercise("ex06", "深蹲", "屈髋后坐下蹲起身，锻炼臀腿全身大肌群"),
    Exercise("ex07", "凳上臂屈伸", "双手撑凳屈伸肘关节，紧致肱三头肌"),
    Exercise("ex08", "平板支撑", "肘撑地身体成直线，全程收紧核心不塌腰"),
    Exercise("ex09", "原地高抬腿", "原地快速交替抬膝，冲刺心率燃脂收尾"),
    Exercise("ex10", "箭步蹲", "前后分腿下蹲起身，塑造腿部线条与平衡"),
    Exercise("ex11", "俯卧撑转体", "俯卧撑起后单侧转体举臂，核心抗旋训练"),
    Exercise("ex12", "侧平板支撑", "侧身肘撑髋部抬起，强化侧腹与腰方肌"),
)

/** 每轮动作 = 预设序列循环取模（自定义轮数 > 12 时复用动作）。 */
fun exerciseAtRound(round: Int): Exercise = PRESET_EXERCISES[(round - 1) % PRESET_EXERCISES.size]

/**
 * 构建训练计划——确定性：轮序 1..rounds，每轮 WORK 在前、REST 在后
 * （末轮无 REST），步骤 index 全局递增。双端同配置产物必须完全一致。
 */
fun buildPlan(config: IntervalConfig): List<PlanStep> {
    val steps = ArrayList<PlanStep>()
    var index = 0
    for (round in 1..config.rounds) {
        val ex = exerciseAtRound(round)
        steps.add(PlanStep(index++, round, PhaseType.WORK, config.workSeconds, ex.id, ex.name))
        if (config.restSeconds > 0 && round < config.rounds) {
            steps.add(PlanStep(index++, round, PhaseType.REST, config.restSeconds, ex.id, "休息"))
        }
    }
    return steps
}

/** 计划总时长（秒）。 */
fun planTotalSeconds(plan: List<PlanStep>): Int = plan.sumOf { it.seconds }

/**
 * 按已流逝秒数定位当前步骤，返回步骤下标；训练结束返回 -1。
 * 边界契约：elapsed 落在步骤累计区间 [start, start+seconds) 内即该步。
 */
fun stepAt(plan: List<PlanStep>, elapsedSeconds: Int): Int {
    var acc = 0
    for (i in plan.indices) {
        acc += plan[i].seconds
        if (elapsedSeconds < acc) return i
    }
    return -1
}

/**
 * 打卡 id 生成——确定性：ci_ + epochDay 定宽 6 位 + kind + 序号定宽 2 位，
 * 字典序与时间序一致（同天同 kind 内 seq 升序即字典序升序），双端一致。
 */
fun checkInId(epochDay: Long, kind: String, seq: Int): String =
    "ci_" + epochDay.toString().padStart(6, '0') + "_" + kind + "_" + seq.toString().padStart(2, '0')

const val MILLIS_PER_DAY = 86_400_000L

/** 本地纪元天——timeMillis 加时区偏移后按天取整（纯函数，双端口径一致）。 */
fun epochDayOf(timeMillis: Long, offsetMillis: Long): Long =
    (timeMillis + offsetMillis) / MILLIS_PER_DAY
