package io.eazo.dailyquote.core

/** 持久化端口（Android=SharedPreferences，测试=内存 Fake；与鸿蒙 PreferencesStore 键 1:1）。 */
interface QuoteStore {
    fun loadRefreshOffset(): Int
    fun saveRefreshOffset(value: Int)
    fun loadFavorites(): String
    fun saveFavorites(value: String)
}

/** 存储键与初始值（双端 1:1：prefs 文件 "dailyquote"，键 refresh_offset / favorites）。 */
object QuoteConstants {
    const val PREFS_FILE = "dailyquote"
    const val KEY_REFRESH_OFFSET = "refresh_offset"
    const val KEY_FAVORITES = "favorites"
    const val INITIAL_REFRESH_OFFSET = 0
}

/**
 * 仓储（进程内唯一实例，由 platform.AppRepo.getRepo(context) 构造——UI/卡片层禁止直构，★规则 ①）。
 *
 * 生命周期口径（★规则 ②）：
 *  - 冷启动构造时**一次性** load 持久化（refresh_offset + favorites）进内存；
 *  - 此后一切读（snapshot/listFavorites/isFavored）都是内存态，onResume 重读零成本；
 *  - 一切写（advance/toggleFavorite）改内存后同步持久化——写后即时可见 + 不怕进程被杀。
 */
class QuoteRepository(
    private val store: QuoteStore,
    private val clock: () -> DateKit.Now = { DateKit.now() },
) {

    private var refreshOffset: Int = loadOffsetGuarded()

    private val favorites = FavoriteStore(StoreCodec.decodeFavorites(store.loadFavorites()))

    private fun loadOffsetGuarded(): Int {
        val v = store.loadRefreshOffset()
        return if (v >= QuoteConstants.INITIAL_REFRESH_OFFSET) v else QuoteConstants.INITIAL_REFRESH_OFFSET
    }

    /** 只读快照：全部从内存态组装（跨页面 onResume 的唯一数据出口）。 */
    fun snapshot(): RepoSnapshot {
        val now = clock()
        val dayBase = QuoteCore.dayBaseIndex(now.epochDay)
        val index = QuoteCore.currentIndex(dayBase, refreshOffset)
        val quote = QuoteSeed.LIST[index]
        return RepoSnapshot(
            dateCn = now.dateCn,
            dateShort = now.dateShort,
            weekdayCn = now.weekdayCn,
            quote = quote,
            displayNo = QuoteCore.displayNo(index),
            total = QuoteSeed.SIZE,
            refreshCount = refreshOffset,
            favorites = favorites.list(),
            favoredNow = favorites.isFavored(quote.id),
            favoredCount = favorites.count(),
        )
    }

    fun listFavorites(): List<FavoriteRecord> = favorites.list()

    fun isFavored(quoteId: String): Boolean = favorites.isFavored(quoteId)

    /** 换一句：offset+1 → 持久化 → 返回新句。 */
    fun advance(): Quote {
        refreshOffset = QuoteCore.advance(refreshOffset)
        store.saveRefreshOffset(refreshOffset)
        return snapshot().quote
    }

    /** 收藏开关：返回 true=已收藏 / false=已取消；改内存 + 同步持久化。 */
    fun toggleFavorite(quoteId: String): Boolean {
        val added = favorites.toggle(quoteId, clock().stamp)
        store.saveFavorites(StoreCodec.encodeFavorites(favorites.list()))
        return added
    }
}
