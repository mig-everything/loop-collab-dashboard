package io.eazo.dailyquote.core

/**
 * ★生成器硬规则 ④（两路路由唯一入口）：
 * 冷启动 onCreate(intent) 与热启动 onNewIntent(intent)（鸿蒙 onCreate(want)/onNewWant(want)）
 * 都只做一件事——把原始参数收进 Map，同走本纯函数 readOpenCreate。
 * 布尔参数严格判定：`raw is Boolean && raw == true`（等价鸿蒙 ArkTS
 * `typeof v === 'boolean' && v === true`）——String "true"、1、1.0 一律判 false。
 * 两路都从「当前 intent」读取，不依赖上一次生命周期残留成员变量（竞态防护）。
 *
 * 参数契约（双端 1:1 键名）：
 *  - "page"：String，"home"（默认/非法回落） | "favorites"。
 *  - "quoteId"：String，必须是种子库存在的 id（q01..q40），否则忽略置 null。
 *  - "focusLatest"：Boolean 严格 true 才生效，收藏页高亮最新一条。
 */
object OpenContract {

    const val PARAM_PAGE = "page"
    const val PARAM_QUOTE_ID = "quoteId"
    const val PARAM_FOCUS_LATEST = "focusLatest"

    const val PAGE_HOME = "home"
    const val PAGE_FAVORITES = "favorites"

    data class OpenRoute(
        val page: String,        // PAGE_HOME | PAGE_FAVORITES
        val quoteId: String?,    // 收藏页高亮目标（null=不高亮）
        val focusLatest: Boolean,
    )

    fun readOpenCreate(params: Map<String, Any?>): OpenRoute {
        val pageRaw = params[PARAM_PAGE]
        val page = if (pageRaw is String && pageRaw == PAGE_FAVORITES) PAGE_FAVORITES else PAGE_HOME

        val quoteRaw = params[PARAM_QUOTE_ID]
        val quoteId = if (quoteRaw is String) QuoteSeed.byId(quoteRaw)?.id else null

        val focusRaw = params[PARAM_FOCUS_LATEST]
        val focusLatest = focusRaw is Boolean && focusRaw == true   // ★严格布尔判定

        return OpenRoute(page, quoteId, focusLatest)
    }
}
