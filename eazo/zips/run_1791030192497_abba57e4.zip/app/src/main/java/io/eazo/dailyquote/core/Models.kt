package io.eazo.dailyquote.core

/**
 * 数据契约（★生成器硬规则 ③：双端字段/枚举/排序 1:1）。
 *
 * 鸿蒙 ArkTS 侧（harmony/）与本文件逐字段对齐：
 *  - Quote 字段名：id / text / author / source / category（同名同义同类型，禁止增删改序）。
 *  - QuoteCategory 枚举字面量："poetry" | "movie" | "book" | "saying"（声明顺序即枚举序，双端一致）。
 *  - FavoriteRecord 字段名：quoteId / favoredAt（favoredAt 为 "yyyy-MM-dd HH:mm:ss"，零填充，
 *    字典序 == 时间序，保证双端字符串比较结果一致）。
 *  - 排序契约：收藏列表主键 favoredAt **倒序**（新收藏在前），次键 quoteId **字典序升序** 兜底；
 *    种子列表按 id 字典序升序（q01..q40 零填充，字典序 == 编号序）。
 *  - 日期→句子索引：dayIndex = epochDay(本地年月日) mod 40，epochDay 为自 1970-01-01 起的
 *    公历天数（[DateKit.civilToEpochDay] 纯函数，双端同算法）。
 *  - 分享文案：`「text」—— author（source）`（与鸿蒙端复制到剪贴板的文案逐字符一致口径）。
 */

/** 分类枚举：literal 为双端 1:1 字面量，display 为双端一致的中文展示名。 */
enum class QuoteCategory(val literal: String, val display: String) {
    POETRY("poetry", "古诗词"),
    MOVIE("movie", "电影"),
    BOOK("book", "名著"),
    SAYING("saying", "名言");

    companion object {
        fun fromLiteral(v: String?): QuoteCategory? = entries.firstOrNull { it.literal == v }
    }
}

/** 种子语录（本地种子库，按日期索引展示）。 */
data class Quote(
    val id: String,             // "q01".."q40"，字典序即种子序
    val text: String,           // 语录正文（含句末标点）
    val author: String,         // 作者 / 角色 / 演员名
    val source: String,         // 出处书名 / 影名 / 篇名（不带书名号）
    val category: QuoteCategory,
)

/** 收藏记录。 */
data class FavoriteRecord(
    val quoteId: String,        // 引用 Quote.id
    val favoredAt: String,      // "yyyy-MM-dd HH:mm:ss"
)

/** 排序契约（确定性排序，双端 1:1）：favoredAt 倒序为主键，quoteId 字典序升序兜底。 */
object SortContract {
    fun compareFavorites(a: FavoriteRecord, b: FavoriteRecord): Int {
        val byTime = b.favoredAt.compareTo(a.favoredAt)                       // 主键：时间倒序
        return if (byTime != 0) byTime else a.quoteId.compareTo(b.quoteId)    // 次键：id 字典序升序
    }
}

/** UI/卡片层只读快照（由 QuoteRepository.snapshot() 从内存态组装）。 */
data class RepoSnapshot(
    val dateCn: String,             // "2026年10月03日"
    val dateShort: String,          // "10月03日"
    val weekdayCn: String,          // "周六"
    val quote: Quote,               // 当前展示句
    val displayNo: Int,             // 第几句（1 起）
    val total: Int,                 // 种子总数 40
    val refreshCount: Int,          // 累计换一句次数（跨会话持久）
    val favorites: List<FavoriteRecord>,
    val favoredNow: Boolean,        // 当前句是否已收藏
    val favoredCount: Int,
) {
    companion object {
        val EMPTY = RepoSnapshot(
            dateCn = "1970年01月01日", dateShort = "01月01日", weekdayCn = "周四",
            quote = Quote("q00", "", "", "", QuoteCategory.POETRY),
            displayNo = 1, total = 1, refreshCount = 0,
            favorites = emptyList(), favoredNow = false, favoredCount = 0,
        )
    }
}
