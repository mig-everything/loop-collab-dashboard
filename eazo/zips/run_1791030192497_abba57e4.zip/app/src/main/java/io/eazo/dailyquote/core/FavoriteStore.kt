package io.eazo.dailyquote.core

/**
 * 收藏内存态（★生成器硬规则 ② 的内存侧根基）：
 *  - 写后即时可见：toggle() 后 list() 立刻反映新状态（同一进程内存，无任何 load）。
 *  - list() 每次按 SortContract 确定性排序返回快照（favoredAt 倒序 + quoteId 字典序升序兜底）。
 */
class FavoriteStore(initial: List<FavoriteRecord> = emptyList()) {

    private val records = initial.toMutableList()

    /** 排序快照（跨页面 onResume 只调本方法重读内存态）。 */
    fun list(): List<FavoriteRecord> = records.sortedWith { a, b -> SortContract.compareFavorites(a, b) }

    fun isFavored(quoteId: String): Boolean = records.any { it.quoteId == quoteId }

    fun count(): Int = records.size

    /**
     * 收藏开关（幂等 toggle）：
     * @return true=已收藏（新增），false=已取消（移除）。
     */
    fun toggle(quoteId: String, now: String): Boolean {
        val existing = records.firstOrNull { it.quoteId == quoteId }
        return if (existing != null) {
            records.remove(existing)
            false
        } else {
            records.add(FavoriteRecord(quoteId, now))
            true
        }
    }
}

/** 持久化编解码（行格式 `quoteId|favoredAt`，损坏行静默跳过不崩溃；与鸿蒙 Preferences 键值 1:1）。 */
object StoreCodec {

    private val STAMP_RE = Regex("""\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}""")

    fun encodeFavorites(records: List<FavoriteRecord>): String =
        records.joinToString("\n") { "${it.quoteId}|${it.favoredAt}" }

    fun decodeFavorites(raw: String?): List<FavoriteRecord> =
        raw.orEmpty().split('\n').mapNotNull { line ->
            val parts = line.split('|')
            if (parts.size == 2 &&
                QuoteSeed.byId(parts[0]) != null &&
                STAMP_RE.matches(parts[1])
            ) FavoriteRecord(parts[0], parts[1]) else null
        }
}
