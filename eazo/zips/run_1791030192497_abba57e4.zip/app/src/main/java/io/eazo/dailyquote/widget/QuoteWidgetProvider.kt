package io.eazo.dailyquote.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import io.eazo.dailyquote.R
import io.eazo.dailyquote.platform.AppRepo

/**
 * 桌面元服务卡片「今日一句」（可选能力）：
 *  - 展示当前句（与 App 首页同一 snapshot，读单例内存态）；
 *  - 点「换一句」走 AppRepo.getRepo(context).advance()（★规则 ①：卡片层禁直构仓储）——
 *    卡片与 App 共享同一 offset，任一侧换句两侧同步；
 *  - App 内换句后调 [pushAll] 主动刷新卡片视图。
 */
class QuoteWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        pushAll(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            AppRepo.getRepo(context).advance()   // ★规则 ①：单例写
            pushAll(context)
        }
    }

    companion object {
        private const val ACTION_REFRESH = "io.eazo.dailyquote.ACTION_REFRESH_QUOTE"

        /** 把单例内存态当前句刷进所有桌面卡片（App 内换句/收藏后也调用）。 */
        fun pushAll(context: Context) {
            val snap = AppRepo.getRepo(context).snapshot()   // ★规则 ①：卡片层只经单例读
            val views = RemoteViews(context.packageName, R.layout.widget_quote).apply {
                setTextViewText(R.id.widget_date, "${snap.dateShort} · 每日一句")
                setTextViewText(R.id.widget_text, snap.quote.text)
                setTextViewText(
                    R.id.widget_meta,
                    "—— ${snap.quote.author}《${snap.quote.source}》",
                )
                setTextViewText(R.id.widget_refresh, "换一句 ↻")
                val refresh = Intent(context, QuoteWidgetProvider::class.java).setAction(ACTION_REFRESH)
                val pi = PendingIntent.getBroadcast(
                    context, 0, refresh,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
                setOnClickPendingIntent(R.id.widget_refresh, pi)
            }
            AppWidgetManager.getInstance(context)
                .updateAppWidget(ComponentName(context, QuoteWidgetProvider::class.java), views)
        }
    }
}
