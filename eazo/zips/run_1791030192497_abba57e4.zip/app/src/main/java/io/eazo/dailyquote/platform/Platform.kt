package io.eazo.dailyquote.platform

import android.content.Context
import android.content.SharedPreferences
import io.eazo.dailyquote.core.QuoteConstants
import io.eazo.dailyquote.core.QuoteRepository
import io.eazo.dailyquote.core.QuoteStore

/**
 * SharedPreferences 持久化（与鸿蒙 PreferencesStore 1:1，存储键双端一致）：
 * prefs 文件 "dailyquote"，键 "refresh_offset"（int）/"favorites"（行文本）。
 * 损坏数据不崩溃（try/catch → 初始值）。
 */
class PreferencesStore(context: Context) : QuoteStore {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(QuoteConstants.PREFS_FILE, Context.MODE_PRIVATE)

    override fun loadRefreshOffset(): Int =
        try {
            prefs.getInt(QuoteConstants.KEY_REFRESH_OFFSET, QuoteConstants.INITIAL_REFRESH_OFFSET)
        } catch (e: Exception) {
            QuoteConstants.INITIAL_REFRESH_OFFSET   // 键被改成非 int 等损坏场景：回落初始值，不崩溃
        }

    override fun saveRefreshOffset(value: Int) {
        prefs.edit().putInt(QuoteConstants.KEY_REFRESH_OFFSET, value).apply()
    }

    override fun loadFavorites(): String =
        try {
            prefs.getString(QuoteConstants.KEY_FAVORITES, "").orEmpty()
        } catch (e: Exception) {
            ""                                     // 损坏场景：视为空收藏，不崩溃
        }

    override fun saveFavorites(value: String) {
        prefs.edit().putString(QuoteConstants.KEY_FAVORITES, value).apply()
    }
}

/**
 * ★进程内单例仓储入口（生成器硬规则 ①）：
 * UI 与卡片层**禁止** `QuoteRepository(...)` 直构，一律 `AppRepo.getRepo(context)`。
 * @Volatile 双检锁——App 页面与桌面卡片共享同一内存态，是「写后即时可见」的前提
 * （卡片上换一句 → 回 App onResume 立即同步；反之亦然）。
 */
object AppRepo {
    @Volatile
    private var repo: QuoteRepository? = null

    fun getRepo(context: Context): QuoteRepository =
        repo ?: synchronized(this) {
            repo ?: QuoteRepository(PreferencesStore(context.applicationContext)).also { repo = it }
        }
}
