package io.eazo.dailyquote.core

/**
 * 每日索引与「换一句」纯逻辑（无状态、无 IO，双端同算法，★规则 ③）：
 *  - 今日基准：dayBaseIndex(epochDay) = epochDay mod 40（同一天设备上恒定，跨端同日同句）。
 *  - 换一句：refreshOffset 每次自增 1，线性推进（q10 → q11 → q12 …），到 40 循环回 q01；
 *    offset 跨会话持久（重开 App 保持进度）。
 */
object QuoteCore {

    fun dayBaseIndex(epochDay: Long): Int = mod(epochDay, QuoteSeed.SIZE).toInt()

    /** 当前句下标（0 起）：(dayBase + refreshOffset) mod 40。 */
    fun currentIndex(dayBase: Int, refreshOffset: Int): Int =
        mod(dayBase.toLong() + refreshOffset.toLong(), QuoteSeed.SIZE).toInt()

    fun currentQuote(dayBase: Int, refreshOffset: Int): Quote =
        QuoteSeed.LIST[currentIndex(dayBase, refreshOffset)]

    /** 换一次：offset + 1（线性推进，不越界——取句时 mod）。 */
    fun advance(refreshOffset: Int): Int = refreshOffset + 1

    /** 展示序号（1 起）：「第 10/40 句」。 */
    fun displayNo(index: Int): Int = index + 1

    /** Long 取非负模（防负 epochDay/负 offset 损坏数据）。 */
    private fun mod(v: Long, m: Int): Long = ((v % m) + m) % m
}
