package io.eazo.dailyquote.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.dailyquote.R
import io.eazo.dailyquote.core.FavoriteRecord
import io.eazo.dailyquote.core.OpenContract
import io.eazo.dailyquote.core.Quote
import io.eazo.dailyquote.core.QuoteSeed
import io.eazo.dailyquote.core.RepoSnapshot
import io.eazo.dailyquote.platform.AppRepo
import io.eazo.dailyquote.widget.QuoteWidgetProvider

/**
 * 「每日一句」主界面（Compose 卡片式排版）：
 *  - 首页：今日一句大卡片（日期头 + 语录 + 出处 + 第 n/40 句）+ 换一句 / 收藏 / 分享；
 *  - 收藏页：确定性排序列表（favoredAt 倒序 + quoteId 字典序兜底），可取消收藏；
 *  - 分享：ACTION_SEND 系统分享面板，文案 `「text」—— author（source）`（双端一致口径）。
 *
 * ★ 生成器硬规则 ④（两路路由）：冷启动 onCreate(intent) 与热启动 onNewIntent(intent)
 *   （鸿蒙 onCreate(want)/onNewWant(want)）都只做一件事——收原始参数进 Map，
 *   同走纯函数 OpenContract.readOpenCreate（严格布尔 `is Boolean && == true`）。
 *   launchMode=singleTask 保证重入拉起走 onNewIntent 热启动路径；
 *   两路都从「当前 intent」读取，不依赖上一次生命周期残留成员变量（竞态防护）。
 * ★ 生成器硬规则 ②：onResume 只 refreshFromRepo()（重读单例内存态 list()），绝不触持久化 load。
 * ★ 生成器硬规则 ①：仓储一律 AppRepo.getRepo(this)，全类 0 处 new QuoteRepository。
 */
class MainActivity : ComponentActivity() {

    private var page by mutableStateOf(OpenContract.PAGE_HOME)
    private var highlightId by mutableStateOf<String?>(null)
    private var snapshot by mutableStateOf(RepoSnapshot.EMPTY)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        routeFromWant(intent)                     // ★ 冷启动路径
        setContent { AppScreen() }
    }

    override fun onNewIntent(intent: Intent) {    // ★ 热启动路径（singleTask 重入）
        super.onNewIntent(intent)
        setIntent(intent)
        routeFromWant(intent)
    }

    /** 冷/热启动共用：原始参数 Map → readOpenCreate 纯函数（规则 ④ 唯一入口，严格 === true 判定）。 */
    private fun routeFromWant(intent: Intent?) {
        val extras = intent?.extras
        val params = HashMap<String, Any?>()
        extras?.keySet()?.forEach { k -> params[k] = extras.get(k) }
        val route = OpenContract.readOpenCreate(params)
        page = route.page
        highlightId = when {
            route.quoteId != null -> route.quoteId
            route.focusLatest -> repo().listFavorites().firstOrNull()?.quoteId
            else -> null
        }
    }

    override fun onResume() {
        super.onResume()
        refreshFromRepo()                         // ★ 规则②：仅重读内存态（卡片上换句也在此同步）
    }

    /** refresh 出口（规则②）：单例内存读，无任何持久化 load。 */
    private fun refreshFromRepo() {
        snapshot = repo().snapshot()
    }

    private fun repo() = AppRepo.getRepo(this)    // ★ 规则①：单例入口

    private fun onRefresh() {
        repo().advance()                          // ★ 规则①：单例写
        refreshFromRepo()
        QuoteWidgetProvider.pushAll(this)         // 桌面卡片同步今日一句
    }

    private fun onToggleFavorite() {
        val added = repo().toggleFavorite(snapshot.quote.id)
        refreshFromRepo()
        val res = if (added) R.string.toast_fav_added else R.string.toast_fav_removed
        Toast.makeText(this, getString(res), Toast.LENGTH_SHORT).show()
    }

    private fun onShare() {
        val q = snapshot.quote
        val text = "「${q.text}」—— ${q.author}（${q.source}）"
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, getString(R.string.button_share)))
    }

    private fun onRemoveFavorite(quoteId: String) {
        repo().toggleFavorite(quoteId)
        refreshFromRepo()
        Toast.makeText(this, getString(R.string.toast_fav_removed), Toast.LENGTH_SHORT).show()
    }

    // ---------- UI ----------

    private val ink = Color(0xFF2B2116)
    private val inkSoft = Color(0xFF6B5D4A)
    private val inkFaint = Color(0xFFA08F76)
    private val accent = Color(0xFFB3432B)
    private val blue = Color(0xFF2F5D8A)
    private val cardBg = Color(0xFFFFFDF8)
    private val cardBorder = Color(0xFFEADCC3)

    @Composable
    fun AppScreen() {
        MaterialTheme {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFFFBF5EA), Color(0xFFF3E9D8)))
                    ),
            ) {
                if (page == OpenContract.PAGE_FAVORITES) FavoritesScreen() else HomeScreen()
            }
        }
    }

    @Composable
    fun HomeScreen() {
        val snap = snapshot
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "每日一句",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = ink,
                )
                Spacer(Modifier.weight(1f))
                Text(
                    "${snap.dateCn} ${snap.weekdayCn}",
                    fontSize = 13.sp,
                    color = inkSoft,
                )
            }
            Spacer(Modifier.height(18.dp))
            QuoteCard(snap)
            Spacer(Modifier.height(22.dp))
            ActionRow(snap)
            Spacer(Modifier.height(14.dp))
            Text(
                getString(R.string.footer_seed),
                fontSize = 12.sp,
                color = inkFaint,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
            )
        }
    }

    @Composable
    fun QuoteCard(snap: RepoSnapshot) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = BorderStroke(1.dp, cardBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(24.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CategoryPill(snap.quote)
                    Spacer(Modifier.weight(1f))
                    Text(snap.dateShort, fontSize = 13.sp, color = inkFaint)
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    "「",
                    fontSize = 34.sp,
                    fontFamily = FontFamily.Serif,
                    color = Color(0xFFD9C9A8),
                )
                Text(
                    snap.quote.text,
                    fontSize = 26.sp,
                    lineHeight = 38.sp,
                    fontFamily = FontFamily.Serif,
                    color = ink,
                )
                Spacer(Modifier.height(16.dp))
                HorizontalDivider(color = Color(0xFFF0E6D2), thickness = 1.dp)
                Spacer(Modifier.height(12.dp))
                Text(
                    "—— ${snap.quote.author}《${snap.quote.source}》",
                    fontSize = 14.sp,
                    color = inkSoft,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.End,
                )
                Spacer(Modifier.height(10.dp))
                Row {
                    Text("第 ${snap.displayNo} / ${snap.total} 句", fontSize = 12.sp, color = inkFaint)
                    Spacer(Modifier.weight(1f))
                    Text("已换 ${snap.refreshCount} 次", fontSize = 12.sp, color = inkFaint)
                }
            }
        }
    }

    @Composable
    fun CategoryPill(q: Quote) {
        val color = when (q.category) {
            io.eazo.dailyquote.core.QuoteCategory.POETRY -> Color(0xFF4A6B4F)
            io.eazo.dailyquote.core.QuoteCategory.MOVIE -> Color(0xFF4A5A8A)
            io.eazo.dailyquote.core.QuoteCategory.BOOK -> Color(0xFF8A6B3D)
            io.eazo.dailyquote.core.QuoteCategory.SAYING -> Color(0xFF6B6B7A)
        }
        Text(
            q.category.display,
            fontSize = 12.sp,
            color = color,
            modifier = Modifier
                .background(Color(0xFFF4EAD5), RoundedCornerShape(999.dp))
                .padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }

    @Composable
    fun ActionRow(snap: RepoSnapshot) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = { onRefresh() },
                colors = ButtonDefaults.buttonColors(containerColor = blue),
                modifier = Modifier.weight(1f),
            ) { Text("换一句 ↻", fontSize = 15.sp, maxLines = 1) }

            if (snap.favoredNow) {
                Button(
                    onClick = { onToggleFavorite() },
                    colors = ButtonDefaults.buttonColors(containerColor = accent),
                    modifier = Modifier.weight(1f),
                ) { Text("♥ ${snap.favoredCount}", fontSize = 15.sp, maxLines = 1) }
            } else {
                OutlinedButton(
                    onClick = { onToggleFavorite() },
                    modifier = Modifier.weight(1f),
                ) { Text("♡ 收藏", fontSize = 15.sp, color = accent, maxLines = 1) }
            }

            OutlinedButton(
                onClick = { onShare() },
                modifier = Modifier.weight(1f),
            ) { Text("分享", fontSize = 15.sp, color = blue, maxLines = 1) }
        }
    }

    @Composable
    fun FavoritesScreen() {
        BackHandler { page = OpenContract.PAGE_HOME }
        val snap = snapshot
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "◂ ${getString(R.string.back)}",
                    fontSize = 16.sp,
                    color = blue,
                    modifier = Modifier.clickable { page = OpenContract.PAGE_HOME },
                )
                Spacer(Modifier.weight(1f))
                Text(
                    "${getString(R.string.title_favorites)} (${snap.favoredCount})",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = ink,
                )
            }
            Spacer(Modifier.height(16.dp))
            if (snap.favorites.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text("♡", fontSize = 52.sp, color = Color(0xFFD9C9A8))
                    Spacer(Modifier.height(12.dp))
                    Text(getString(R.string.empty_favorites_title), fontSize = 17.sp, color = inkSoft)
                    Spacer(Modifier.height(6.dp))
                    Text(getString(R.string.empty_favorites_hint), fontSize = 13.sp, color = inkFaint)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(snap.favorites, key = { it.quoteId }) { record ->
                        FavoriteCard(record, highlighted = record.quoteId == highlightId)
                    }
                }
            }
        }
    }

    @Composable
    fun FavoriteCard(record: FavoriteRecord, highlighted: Boolean) {
        val q = QuoteSeed.byId(record.quoteId)
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = cardBg),
            border = BorderStroke(if (highlighted) 2.dp else 1.dp, if (highlighted) accent else cardBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    q?.text ?: record.quoteId,
                    fontSize = 17.sp,
                    lineHeight = 25.sp,
                    fontFamily = FontFamily.Serif,
                    color = ink,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        q?.let { "—— ${it.author}《${it.source}》" } ?: "",
                        fontSize = 12.sp,
                        color = inkSoft,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Text(listTimeOf(record.favoredAt), fontSize = 12.sp, color = inkFaint)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "♥",
                        fontSize = 18.sp,
                        color = accent,
                        modifier = Modifier.clickable { onRemoveFavorite(record.quoteId) },
                    )
                }
            }
        }
    }

    /** "2026-10-03 20:21:03" → "10-03 20:21"（收藏列表展示，双端一致格式）。 */
    private fun listTimeOf(stamp: String): String =
        if (stamp.length >= 16) stamp.substring(5, 16) else stamp
}
