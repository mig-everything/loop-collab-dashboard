package io.eazo.dailyquote.core

import java.util.Calendar
import java.util.Locale

/**
 * 日期工具（纯函数，双端 1:1 算法，★规则 ③）：
 *  - civilToEpochDay：公历年月日 → 自 1970-01-01 起的天数（Howard Hinnant civil 算法，
 *    鸿蒙端同公式实现），是「本地种子库按日期索引」的确定性根基。
 *  - 不用 java.time（minSdk 24 免脱糖），不用 System.currentTimeMillis()/86400000（免 UTC/本地时区歧义）：
 *    一律取本地时区 Calendar 的年月日字段走纯函数。
 */
object DateKit {

    /** 一次「现在」的纯快照（全部字段预格式化，UI 不再做日期运算）。 */
    data class Now(
        val epochDay: Long,       // 本地年月日 → 公历天数（索引种子用）
        val dateCn: String,       // "2026年10月03日"
        val dateShort: String,    // "10月03日"
        val weekdayCn: String,    // "周六"
        val stamp: String,        // "2026-10-03 20:21:03"（收藏 favoredAt，排序主键载体）
        val listTime: String,     // "10-03 20:21"（收藏列表展示）
    )

    /** 纯函数：公历 → epochDay（输入不校验范围，调用方保证合法日期）。 */
    fun civilToEpochDay(year: Int, month: Int, day: Int): Long {
        val y = if (month <= 2) year - 1 else year
        val era = (if (y >= 0) y else y - 399) / 400
        val yoe = y - era * 400
        val doy = (153 * (if (month > 2) month - 3 else month + 9) + 2) / 5 + day - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        return era * 146097L + doe - 719468L
    }

    /** 纯构造（测试用固定时钟）。 */
    fun of(year: Int, month: Int, day: Int, hour: Int, minute: Int, second: Int): Now {
        val dow = dayOfWeekOf(year, month, day)
        return Now(
            epochDay = civilToEpochDay(year, month, day),
            dateCn = "%d年%02d月%02d日".format(Locale.CHINA, year, month, day),
            dateShort = "%02d月%02d日".format(Locale.CHINA, month, day),
            weekdayCn = WEEKDAYS[dow - 1],
            stamp = "%04d-%02d-%02d %02d:%02d:%02d".format(Locale.CHINA, year, month, day, hour, minute, second),
            listTime = "%02d-%02d %02d:%02d".format(Locale.CHINA, month, day, hour, minute),
        )
    }

    /** 真实时钟（仓储默认注入；测试注入固定值）。 */
    fun now(): Now {
        val c = Calendar.getInstance()
        return of(
            c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH),
            c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), c.get(Calendar.SECOND),
        )
    }

    /** 星期几：1=周日 … 7=周六（与 Calendar.DAY_OF_WEEK 对齐）。 */
    private fun dayOfWeekOf(year: Int, month: Int, day: Int): Int {
        val cal = Calendar.getInstance()
        cal.clear()
        cal.set(year, month - 1, day)
        return cal.get(Calendar.DAY_OF_WEEK)
    }

    private val WEEKDAYS = arrayOf("周日", "周一", "周二", "周三", "周四", "周五", "周六")
}
