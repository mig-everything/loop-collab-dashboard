package io.eazo.dailyquote.core

/**
 * 本地种子库：40 句（q01..q40，id 零填充 → 字典序 == 编号序，★规则 ③ 确定性排序）。
 * 纯常量、无 IO、无随机：同 id 双端内容一致。
 */
object QuoteSeed {

    val LIST: List<Quote> = listOf(
        Quote("q01", "学而时习之，不亦说乎？", "孔子", "论语", QuoteCategory.BOOK),
        Quote("q02", "路漫漫其修远兮，吾将上下而求索。", "屈原", "离骚", QuoteCategory.POETRY),
        Quote("q03", "玉不琢，不成器；人不学，不知道。", "荀子", "劝学", QuoteCategory.BOOK),
        Quote("q04", "非淡泊无以明志，非宁静无以致远。", "诸葛亮", "诫子书", QuoteCategory.BOOK),
        Quote("q05", "纸上得来终觉浅，绝知此事要躬行。", "陆游", "冬夜读书示子聿", QuoteCategory.POETRY),
        Quote("q06", "山重水复疑无路，柳暗花明又一村。", "陆游", "游山西村", QuoteCategory.POETRY),
        Quote("q07", "人生自古谁无死，留取丹心照汗青。", "文天祥", "过零丁洋", QuoteCategory.POETRY),
        Quote("q08", "落红不是无情物，化作春泥更护花。", "龚自珍", "己亥杂诗", QuoteCategory.POETRY),
        Quote("q09", "千磨万击还坚劲，任尔东西南北风。", "郑燮", "竹石", QuoteCategory.POETRY),
        Quote("q10", "会当凌绝顶，一览众山小。", "杜甫", "望岳", QuoteCategory.POETRY),
        Quote("q11", "今天很残酷，明天更残酷，后天很美好。", "马云", "访谈", QuoteCategory.SAYING),
        Quote("q12", "沉舟侧畔千帆过，病树前头万木春。", "刘禹锡", "酬乐天扬州初逢席上见赠", QuoteCategory.POETRY),
        Quote("q13", "生活不止眼前的苟且，还有诗和远方。", "高晓松", "高晓松杂文集", QuoteCategory.SAYING),
        Quote("q14", "世界上只有一种真正的英雄主义，那就是认清生活真相后依然热爱生活。", "罗曼·罗兰", "米开朗琪罗传", QuoteCategory.BOOK),
        Quote("q15", "走你的路吧，让人们去说吧。", "但丁", "神曲", QuoteCategory.BOOK),
        Quote("q16", "幸福的家庭都是相似的，不幸的家庭各有各的不幸。", "列夫·托尔斯泰", "安娜·卡列尼娜", QuoteCategory.BOOK),
        Quote("q17", "人最宝贵的是生命。当他回首往事时，不因虚度年华而悔恨，也不因碌碌无为而羞耻。", "奥斯特洛夫斯基", "钢铁是怎样炼成的", QuoteCategory.BOOK),
        Quote("q18", "生活不能等待别人来安排，要自己去争取和奋斗。", "路遥", "平凡的世界", QuoteCategory.BOOK),
        Quote("q19", "满地都是六便士，他却抬头看见了月亮。", "毛姆", "月亮与六便士", QuoteCategory.BOOK),
        Quote("q20", "我们一路奋战，不是为了改变世界，而是为了不让世界改变我们。", "孔刘", "熔炉", QuoteCategory.MOVIE),
        Quote("q21", "生活就像一盒巧克力，你永远不知道下一颗是什么味道。", "汤姆·汉克斯", "阿甘正传", QuoteCategory.MOVIE),
        Quote("q22", "死亡不是失去了生命，只是走出了时间。", "余华", "在细雨中呼喊", QuoteCategory.BOOK),
        Quote("q23", "如果多一张船票，你会不会跟我走？", "梁朝伟", "花样年华", QuoteCategory.MOVIE),
        Quote("q24", "人生就是不断地放下，然而痛心的是，我还没来得及与你们好好告别。", "李安", "少年派的奇幻漂流", QuoteCategory.MOVIE),
        Quote("q25", "不要让别人告诉你，你成不了才，即使是我也不行。", "威尔·史密斯", "当幸福来敲门", QuoteCategory.MOVIE),
        Quote("q26", "人生是一连串的难题，解决人生问题的首要方案，乃是自律。", "M·斯科特·派克", "少有人走的路", QuoteCategory.BOOK),
        Quote("q27", "不管前方的路有多苦，只要走的方向正确，都比站在原地更接近幸福。", "宫崎骏", "千与千寻", QuoteCategory.MOVIE),
        Quote("q28", "星星发亮，是为了让每一个人有一天都能找到属于自己的星星。", "圣埃克苏佩里", "小王子", QuoteCategory.BOOK),
        Quote("q29", "种一棵树最好的时间是十年前，其次是现在。", "非洲谚语", "谚语集", QuoteCategory.SAYING),
        Quote("q30", "知识就是力量。", "培根", "培根论说文集", QuoteCategory.SAYING),
        Quote("q31", "我思故我在。", "笛卡尔", "第一哲学沉思集", QuoteCategory.SAYING),
        Quote("q32", "简单是终极的复杂。", "达·芬奇", "达·芬奇笔记", QuoteCategory.SAYING),
        Quote("q33", "天才是百分之一的灵感，加百分之九十九的汗水。", "爱迪生", "访谈", QuoteCategory.SAYING),
        Quote("q34", "生活的理想，就是为了理想的生活。", "张闻天", "张闻天文集", QuoteCategory.SAYING),
        Quote("q35", "不积跬步，无以至千里；不积小流，无以成江海。", "荀子", "劝学", QuoteCategory.BOOK),
        Quote("q36", "宝剑锋从磨砺出，梅花香自苦寒来。", "佚名", "警世贤文", QuoteCategory.POETRY),
        Quote("q37", "少年易老学难成，一寸光阴不可轻。", "朱熹", "偶成", QuoteCategory.POETRY),
        Quote("q38", "三军可夺帅也，匹夫不可夺志也。", "孔子", "论语·子罕", QuoteCategory.BOOK),
        Quote("q39", "老骥伏枥，志在千里；烈士暮年，壮心不已。", "曹操", "龟虽寿", QuoteCategory.POETRY),
        Quote("q40", "世上无难事，只要肯登攀。", "毛泽东", "水调歌头·重上井冈山", QuoteCategory.POETRY),
    )

    val SIZE: Int = LIST.size

    private val BY_ID: Map<String, Quote> = LIST.associateBy { it.id }

    fun byId(id: String?): Quote? = BY_ID[id]
}
