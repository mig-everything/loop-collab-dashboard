package io.eazo.dailyquote.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 收藏内存态 + 持久化编解码 + 仓储行为测试（★规则 ② 写后即时可见 / 冷启动唯一 load）。
 */
class FavoriteStoreTest {

    private val clock = { DateKit.of(2026, 10, 3, 20, 21, 3) }

    // ---------- FavoriteStore 内存态 ----------

    @Test fun `toggle 收藏后 list 立即可见（规则② 内存口径）`() {
        val store = FavoriteStore()
        assertTrue(store.toggle("q10", "2026-10-03 20:21:03"))
        assertEquals(1, store.count())
        assertTrue(store.isFavored("q10"))
        assertEquals(listOf("q10"), store.list().map { it.quoteId })   // 无任何 load，内存直读
        assertEquals("2026-10-03 20:21:03", store.list()[0].favoredAt)
    }

    @Test fun `再 toggle 即取消（幂等开关）`() {
        val store = FavoriteStore()
        store.toggle("q10", "2026-10-03 20:21:03")
        assertFalse(store.toggle("q10", "2026-10-03 20:22:00"))
        assertEquals(0, store.count())
        assertFalse(store.isFavored("q10"))
    }

    @Test fun `收藏列表按时间倒序 + 同时刻 id 字典序兜底`() {
        val store = FavoriteStore()
        store.toggle("q01", "2026-10-03 19:00:00")
        store.toggle("q12", "2026-10-03 20:21:03")
        store.toggle("q05", "2026-10-03 20:21:03")
        assertEquals(listOf("q05", "q12", "q01"), store.list().map { it.quoteId })
    }

    // ---------- StoreCodec ----------

    @Test fun `编解码往返一致`() {
        val records = listOf(
            FavoriteRecord("q12", "2026-10-03 20:21:03"),
            FavoriteRecord("q01", "2026-10-01 09:00:00"),
        )
        val decoded = StoreCodec.decodeFavorites(StoreCodec.encodeFavorites(records))
        assertEquals(records.sortedWith { a, b -> SortContract.compareFavorites(a, b) }, decoded)
    }

    @Test fun `损坏行静默跳过不崩溃`() {
        val raw = "q01|2026-10-03 20:00:00\nbadline\nq99|2026-10-03 21:00:00\nq02|wrongtime\n\n"
        val decoded = StoreCodec.decodeFavorites(raw)
        assertEquals(listOf("q01"), decoded.map { it.quoteId })
        assertEquals(emptyList<FavoriteRecord>(), StoreCodec.decodeFavorites(null))
    }

    // ---------- QuoteRepository（内存 Fake 存储） ----------

    private class FakeQuoteStore(
        var offset: Int = QuoteConstants.INITIAL_REFRESH_OFFSET,
        var favs: String = "",
    ) : QuoteStore {
        override fun loadRefreshOffset(): Int = offset
        override fun saveRefreshOffset(value: Int) { offset = value }
        override fun loadFavorites(): String = favs
        override fun saveFavorites(value: String) { favs = value }
    }

    @Test fun `冷启动加载 + 换一句持久化 offset`() {
        val fake = FakeQuoteStore(offset = 2)
        val repo = QuoteRepository(fake, clock)
        assertEquals("q12", repo.snapshot().quote.id)          // offset 2 → (9+2)%40=11 → q12（刘禹锡）
        assertEquals("q13", repo.advance().id)                 // offset 3 → (9+3)%40=12 → q13（高晓松）
        assertEquals(3, fake.offset)
    }

    @Test fun `advance 线性推进并写穿持久化`() {
        val fake = FakeQuoteStore()
        val repo = QuoteRepository(fake, clock)
        assertEquals("q10", repo.snapshot().quote.id)
        assertEquals("q11", repo.advance().id)                 // 马云
        assertEquals("q12", repo.advance().id)                 // 刘禹锡
        assertEquals(2, fake.offset)                           // 持久化已写穿
        assertEquals(2, repo.snapshot().refreshCount)
    }

    @Test fun `收藏写穿持久化 + 新实例冷启动恢复（跨会话不丢）`() {
        val fake = FakeQuoteStore()
        val repo = QuoteRepository(fake, clock)
        assertTrue(repo.toggleFavorite("q10"))
        assertTrue(repo.toggleFavorite("q12"))
        // 同一固定时钟同秒 → 平局走次键 quoteId 字典序：q10 在前
        assertEquals("q10|2026-10-03 20:21:03\nq12|2026-10-03 20:21:03", fake.favs)

        val repo2 = QuoteRepository(fake, clock)               // 模拟重开 App 冷启动
        assertEquals(2, repo2.snapshot().favoredCount)
        assertEquals(listOf("q10", "q12"), repo2.listFavorites().map { it.quoteId })
        assertTrue(repo2.snapshot().favoredNow)                // 当前句 q10 已收藏
    }

    @Test fun `取消收藏后列表即时同步`() {
        val fake = FakeQuoteStore()
        val repo = QuoteRepository(fake, clock)
        repo.toggleFavorite("q10")
        repo.toggleFavorite("q12")
        assertFalse(repo.toggleFavorite("q12"))                // 取消 q12
        assertEquals(listOf("q10"), repo.listFavorites().map { it.quoteId })
        assertEquals(1, repo.snapshot().favoredCount)
        assertTrue(repo.snapshot().favoredNow)                 // 当前句 q10 仍在收藏
    }

    @Test fun `损坏的负 offset 回落 0`() {
        val fake = FakeQuoteStore(offset = -7)
        val repo = QuoteRepository(fake, clock)
        assertEquals("q10", repo.snapshot().quote.id)          // 视同 offset 0
        assertEquals(0, repo.snapshot().refreshCount)
    }

    @Test fun `snapshot 汇总字段一致`() {
        val repo = QuoteRepository(FakeQuoteStore(), clock)
        val snap = repo.snapshot()
        assertEquals("2026年10月03日 周六", "${snap.dateCn} ${snap.weekdayCn}")
        assertEquals(40, snap.total)
        assertEquals(10, snap.displayNo)                       // 第 10/40 句
        assertEquals(false, snap.favoredNow)
        assertTrue(repo.toggleFavorite(snap.quote.id))
        assertTrue(repo.snapshot().favoredNow)
        assertEquals(1, repo.snapshot().favoredCount)
    }
}
