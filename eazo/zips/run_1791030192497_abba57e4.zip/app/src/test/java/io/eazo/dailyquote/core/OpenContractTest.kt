package io.eazo.dailyquote.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * ★规则 ④ 两路路由纯函数测试：冷启动 onCreate(intent) / 热启动 onNewIntent(intent)
 * 共用 readOpenCreate；布尔参数严格 typeof 判定（Boolean true 之外一律 false）。
 */
class OpenContractTest {

    @Test fun `空参数默认首页`() {
        val r = OpenContract.readOpenCreate(emptyMap())
        assertEquals(OpenContract.PAGE_HOME, r.page)
        assertNull(r.quoteId)
        assertFalse(r.focusLatest)
    }

    @Test fun `page 字符串 favorites 才进收藏页`() {
        assertEquals(OpenContract.PAGE_FAVORITES,
            OpenContract.readOpenCreate(mapOf("page" to "favorites")).page)
        assertEquals(OpenContract.PAGE_HOME,
            OpenContract.readOpenCreate(mapOf("page" to "FAVORITES")).page)   // 大小写敏感
        assertEquals(OpenContract.PAGE_HOME,
            OpenContract.readOpenCreate(mapOf("page" to 1)).page)             // 非字符串 → 回落
        assertEquals(OpenContract.PAGE_HOME,
            OpenContract.readOpenCreate(mapOf("page" to null)).page)
    }

    @Test fun `quoteId 必须是种子库存在的 id`() {
        assertEquals("q12", OpenContract.readOpenCreate(mapOf("quoteId" to "q12")).quoteId)
        assertNull(OpenContract.readOpenCreate(mapOf("quoteId" to "q99")).quoteId)
        assertNull(OpenContract.readOpenCreate(mapOf("quoteId" to "q1")).quoteId)
        assertNull(OpenContract.readOpenCreate(mapOf("quoteId" to 12)).quoteId)
        assertNull(OpenContract.readOpenCreate(mapOf("quoteId" to null)).quoteId)
    }

    @Test fun `focusLatest 严格布尔判定 - 仅 Boolean true 生效`() {
        assertTrue(OpenContract.readOpenCreate(mapOf("focusLatest" to true)).focusLatest)
        assertFalse(OpenContract.readOpenCreate(mapOf("focusLatest" to false)).focusLatest)
        assertFalse(OpenContract.readOpenCreate(mapOf("focusLatest" to "true")).focusLatest)  // 字符串拒绝
        assertFalse(OpenContract.readOpenCreate(mapOf("focusLatest" to 1)).focusLatest)       // 数字拒绝
        assertFalse(OpenContract.readOpenCreate(mapOf("focusLatest" to 1.0)).focusLatest)
        assertFalse(OpenContract.readOpenCreate(mapOf("focusLatest" to null)).focusLatest)
    }

    @Test fun `完整收藏页路由 + 未知键忽略`() {
        val params = mapOf<String, Any?>(
            "page" to "favorites",
            "quoteId" to "q12",
            "focusLatest" to true,
            "unknownKey" to "whatever",
        )
        val r = OpenContract.readOpenCreate(params)
        assertEquals(OpenContract.PAGE_FAVORITES, r.page)
        assertEquals("q12", r.quoteId)
        assertTrue(r.focusLatest)
    }
}
