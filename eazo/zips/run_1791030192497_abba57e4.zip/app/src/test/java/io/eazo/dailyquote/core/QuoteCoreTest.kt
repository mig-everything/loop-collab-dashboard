package io.eazo.dailyquote.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 种子库 + 日期索引 + 换一句 契约测试（★规则 ③ 双端 1:1）。
 */
class QuoteCoreTest {

    // ---------- 种子库完整性 ----------

    @Test fun `种子库恰好 40 句`() = assertEquals(40, QuoteSeed.SIZE)

    @Test fun `id 为 q01 到 q40 且字典序严格递增`() {
        val ids = QuoteSeed.LIST.map { it.id }
        assertEquals((1..40).map { "q%02d".format(it) }, ids)
        assertEquals(ids, ids.sorted())                       // 字典序 == 编号序（零填充）
        assertEquals(ids.size, ids.toSet().size)              // 唯一
    }

    @Test fun `所有字段非空且分类合法`() {
        QuoteSeed.LIST.forEach { q ->
            assertTrue("text 非空 ${q.id}", q.text.isNotBlank())
            assertTrue("author 非空 ${q.id}", q.author.isNotBlank())
            assertTrue("source 非空 ${q.id}", q.source.isNotBlank())
        }
    }

    @Test fun `四种枚举字面量全部出现且字面量唯一`() {
        val literals = QuoteCategory.entries.map { it.literal }
        assertEquals(listOf("poetry", "movie", "book", "saying"), literals)
        QuoteCategory.entries.forEach { c ->
            assertTrue("分类 ${c.literal} 至少 1 句", QuoteSeed.LIST.any { it.category == c })
        }
        assertEquals(null, QuoteCategory.fromLiteral("Poetry"))   // 大小写敏感
        assertEquals(QuoteCategory.BOOK, QuoteCategory.fromLiteral("book"))
    }

    @Test fun `byId 查得到与查不到`() {
        assertEquals("会当凌绝顶，一览众山小。", QuoteSeed.byId("q10")?.text)
        assertEquals(null, QuoteSeed.byId("q99"))
        assertEquals(null, QuoteSeed.byId(null))
    }

    // ---------- 日期纯函数 ----------

    @Test fun `civilToEpochDay 基准锚点`() {
        assertEquals(0L, DateKit.civilToEpochDay(1970, 1, 1))
        assertEquals(20729L, DateKit.civilToEpochDay(2026, 10, 3))
        assertEquals(19723L, DateKit.civilToEpochDay(2024, 1, 1))
        assertEquals(19782L, DateKit.civilToEpochDay(2024, 2, 29))   // 闰日
        assertEquals(11017L, DateKit.civilToEpochDay(2000, 3, 1))
    }

    @Test fun `Now 格式化双端口径`() {
        val now = DateKit.of(2026, 10, 3, 20, 21, 3)
        assertEquals(20729L, now.epochDay)
        assertEquals("2026年10月03日", now.dateCn)
        assertEquals("10月03日", now.dateShort)
        assertEquals("周六", now.weekdayCn)
        assertEquals("2026-10-03 20:21:03", now.stamp)
        assertEquals("10-03 20:21", now.listTime)
    }

    // ---------- 每日索引 / 换一句 ----------

    @Test fun `今日基准 = epochDay mod 40`() {
        assertEquals(9, QuoteCore.dayBaseIndex(20729L))       // 2026-10-03
        assertEquals(0, QuoteCore.dayBaseIndex(0L))
        assertEquals(39, QuoteCore.dayBaseIndex(-1L))         // 负值防御
    }

    @Test fun `2026-10-03 首页锚点为 q10 会当凌绝顶`() {
        val dayBase = QuoteCore.dayBaseIndex(20729L)
        assertEquals("q10", QuoteCore.currentQuote(dayBase, 0).id)
        assertEquals("会当凌绝顶，一览众山小。", QuoteCore.currentQuote(dayBase, 0).text)
    }

    @Test fun `换一句线性推进 q10 马云 刘禹锡`() {
        val dayBase = QuoteCore.dayBaseIndex(20729L)
        assertEquals("q11", QuoteCore.currentQuote(dayBase, 1).id)   // 马云
        assertEquals("马云", QuoteCore.currentQuote(dayBase, 1).author)
        assertEquals("q12", QuoteCore.currentQuote(dayBase, 2).id)   // 刘禹锡
        assertEquals("沉舟侧畔千帆过，病树前头万木春。",
            QuoteCore.currentQuote(dayBase, 2).text)
    }

    @Test fun `换 31 次后循环回 q01（mod 40 环回）`() {
        val dayBase = QuoteCore.dayBaseIndex(20729L)          // base 9
        assertEquals("q01", QuoteCore.currentQuote(dayBase, 31).id)  // (9+31)%40=0
        assertEquals("q10", QuoteCore.currentQuote(dayBase, 40).id)  // (9+40)%40=9 → 与 offset 0 同句
    }

    @Test fun `advance 自增与展示序号`() {
        assertEquals(1, QuoteCore.advance(0))
        assertEquals(41, QuoteCore.advance(40))
        assertEquals(10, QuoteCore.displayNo(9))
    }

    @Test fun `排序契约 - favoredAt 倒序主键 + quoteId 字典序次键`() {
        val a = FavoriteRecord("q12", "2026-10-03 20:21:03")
        val b = FavoriteRecord("q05", "2026-10-03 20:21:03")  // 同时刻 → 比字典序
        val c = FavoriteRecord("q01", "2026-10-03 19:00:00")  // 更早 → 排后
        val sorted = listOf(a, b, c).sortedWith { x, y -> SortContract.compareFavorites(x, y) }
        assertEquals(listOf("q05", "q12", "q01"), sorted.map { it.quoteId })
        assertNotEquals(0, SortContract.compareFavorites(a, c).toLong())
    }
}
