// Top-level build file. Plugin versions pinned per docs/arch/req008/03-tech-selection.md §2 (REQ-005/006/007 锁死口径).
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.10" apply false
}
