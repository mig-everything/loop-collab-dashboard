package io.eazo.hydration.core

import io.eazo.hydration.model.HydrationCardData
import io.eazo.hydration.model.HydrationRecord
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * REQ-008 契约双端单测（02-interface-contract.md §4.2 用例 1~9 + 6a/6b，Android 侧）。
 * 与鸿蒙 Hypium（HydrationContract.test.ets）一一同源对齐（Tester 差分执行基准）。
 * ★ 锚点期望按 IPD-184 勘误口径 (4, 3, false)：今日 3 条（cups 1+2+1=4 杯），昨日 1 条不计入。
 */
class HydrationContractTest {

    private val goal = 8
    private val today = "2026-10-02"

    private fun rec(id: String, ts: String, cups: Int) = HydrationRecord(id, ts, cups)

    private fun agg(rs: List<HydrationRecord>?, today: String = this.today, goal: Int = this.goal): String {
        val a = HydrationLogic.aggregate(rs, today, goal)
        return "(${a.todayCups},${a.todayCheckins},${a.goalReached})"
    }

    /** 锚点记录集（契约 §4.1）：今日 3 条（含 cups:2 一条，C1）+ 昨日 1 条。 */
    private fun anchorSet() = listOf(
        rec("a1", "2026-10-02T08:00:00", 1),
        rec("a2", "2026-10-02T10:00:00", 2),     // ★ C1：cups≠1
        rec("a3", "2026-10-02T12:00:00", 1),
        rec("a4", "2026-10-01T23:59:59", 1)      // 昨日，不计入
    )

    private fun nOneCup(n: Int, day: String = today): List<HydrationRecord> =
        (0 until n).map { i ->
            rec("c%03d".format(i), "%sT%02d:%02d:00".format(day, 8 + i / 60, i % 60), 1)
        }

    // ---------- §4.2 回归用例集（10 断言） ----------

    @Test fun `#1_empty`() = assertEquals("(0,0,false)", agg(emptyList()))

    @Test fun `#2_anchor_cups2勘误4_3_false`() {
        // 今日 3 条：1+2+1=4 杯、3 次打卡 → (4, 3, false)（IPD-184 勘误口径）
        assertEquals("(4,3,false)", agg(anchorSet()))
    }

    @Test fun `#3_exact_8x1cup`() = assertEquals("(8,8,true)", agg(nOneCup(8)))   // ≥ 含等于

    @Test fun `#4_overflow_9x1cup`() = assertEquals("(9,9,true)", agg(nOneCup(9)))

    @Test fun `#5_single_3cups`() = assertEquals("(3,1,false)", agg(listOf(rec("s1", "$today T09:00:00".replace(" ", ""), 3))))

    @Test fun `#6a_yesterday_235959`() =
        assertEquals("(0,0,false)", agg(listOf(rec("y1", "2026-10-01T23:59:59", 1))))

    @Test fun `#6b_today_000000`() =
        assertEquals("(1,1,false)", agg(listOf(rec("t1", "${today}T00:00:00", 1))))

    @Test fun `#7_single_8cups_C1_core`() {
        // ★★ C1 判定核心：cups=8 ≠ n=1 且 true——「条数判达成」错误实现在此返回 false
        assertEquals("(8,1,true)", agg(listOf(rec("c8", "${today}T09:00:00", 8))))
    }

    @Test fun `#8_single_7cups`() = assertEquals("(7,1,false)", agg(listOf(rec("c7", "${today}T09:00:00", 7))))

    @Test fun `#9_mixed_2_2_2_3`() {
        val rs = listOf(
            rec("m1", "${today}T08:00:00", 2),
            rec("m2", "${today}T10:00:00", 2),
            rec("m3", "${today}T12:00:00", 2),
            rec("m4", "${today}T14:00:00", 3)
        )
        assertEquals("(9,4,true)", agg(rs))
    }

    // ---------- D2：goalReached 比较数 = todayCups ----------
    @Test fun `d2_goalReached_compares_todayCups`() {
        val a = HydrationLogic.aggregate(listOf(rec("d2", "${today}T09:00:00", 8)), today, goal)
        assert(a.goalReached)
        assertEquals(1, a.todayCheckins)   // 条数与杯数解耦
    }

    // ---------- D3 日期分组 ----------
    @Test fun `d3_localDate_prefix`() {
        assertEquals("2026-10-02", HydrationLogic.localDate("2026-10-02T08:00:00"))
        assertEquals("2026-10-01", HydrationLogic.localDate("2026-10-01T23:59:59"))
        assertEquals("", HydrationLogic.localDate(""))
    }

    // ---------- D4 排序确定性 ----------
    @Test fun `d4_sortDesc_stable`() {
        val rs = listOf(
            rec("id001", "${today}T08:00:00", 1),
            rec("id002", "${today}T09:00:00", 1),
            rec("id003", "${today}T09:00:00", 2),   // 同 timestamp
            rec("id004", "2026-10-01T23:59:59", 1)
        )
        val sorted = HydrationLogic.sortDesc(rs)
        assertEquals(listOf("id002", "id003", "id001", "id004"), sorted.map { it.id })
    }

    // ---------- O2/AD-4：id 派生 ----------
    @Test fun `o2_nextId_pure`() {
        val ts = "${today}T09:00:00"
        assertEquals("$ts-001", HydrationLogic.nextId(emptyList(), ts))
        assertEquals("$ts-002", HydrationLogic.nextId(listOf(rec("x1", ts, 1)), ts))
        assertEquals("$ts-003", HydrationLogic.nextId(listOf(rec("x1", ts, 1), rec("x2", ts, 2)), ts))
        assertEquals("$ts-001", HydrationLogic.nextId(listOf(rec("y", "${today}T09:00:01", 1)), ts))
    }

    // ---------- §4.3 幂等与输入边界（D6/U3） ----------

    private class MemStore : HydrationStore {
        var saved: List<HydrationRecord> = emptyList()
        override fun load(): List<HydrationRecord> = saved.toList()
        override fun save(records: List<HydrationRecord>) { saved = records.toList() }
    }

    private class FixedTime(var iso: String) : TimeSource {
        override fun nowLocalIso(): String = iso
    }

    @Test fun `boundary_invalid_cups_ignored`() {
        val repo = HydrationRepository(MemStore(), FixedTime("${today}T09:00:00"))
        assertNull(repo.create(0))
        assertNull(repo.create(-1))
        assertEquals(0, repo.list().size)
    }

    @Test fun `boundary_invalid_records_skipped_on_load`() {
        val mem = MemStore()
        mem.saved = listOf(
            rec("ok1", "${today}T08:00:00", 1),
            rec("bad1", "", 1),
            rec("bad2", "${today}T09:00:00", 0),
            rec("ok2", "${today}T12:00:00", 2)
        )
        val repo = HydrationRepository(mem, FixedTime("${today}T13:00:00"))
        assertEquals(2, repo.list().size)
        assertEquals("(3,2,false)", agg(repo.list()))
    }

    @Test fun `d6_idempotent_rapid_taps`() {
        val time = FixedTime("${today}T09:00:00")
        val repo = HydrationRepository(MemStore(), time)
        repo.create(1); repo.create(1); repo.create(1)   // 同秒同杯数 → 去重
        val a = repo.aggregateToday(today)
        assertEquals(1, a.todayCheckins)
        assertEquals(1, a.todayCups)
        time.iso = "${today}T09:00:01"                    // 下一秒新记录
        repo.create(1)
        val b = repo.aggregateToday(today)
        assertEquals(2, b.todayCheckins)
        assertEquals(2, b.todayCups)
    }

    @Test fun `s2_record_limit_trims_oldest`() {
        class SteppingTime(startIso: String) : TimeSource {
            private var t = java.time.LocalDateTime.parse(startIso)
            override fun nowLocalIso(): String = t.toString().let { s ->
                "%04d-%02d-%02dT%02d:%02d:%02d".format(
                    java.time.LocalDateTime.parse(s).year,
                    java.time.LocalDateTime.parse(s).monthValue,
                    java.time.LocalDateTime.parse(s).dayOfMonth,
                    java.time.LocalDateTime.parse(s).hour,
                    java.time.LocalDateTime.parse(s).minute,
                    java.time.LocalDateTime.parse(s).second
                )
            }

            fun step() { t = t.plusSeconds(1) }
        }
        val time = SteppingTime("${today}T08:00:00")
        val repo = HydrationRepository(MemStore(), time)
        repeat(HydrationConstants.RECORD_LIMIT + 5) {
            repo.create(1)
            time.step()
        }
        assertEquals(HydrationConstants.RECORD_LIMIT, repo.list().size)
    }

    // ---------- progressPercent 展示态 ----------
    @Test fun `display_progressPercent_bounds`() {
        assertEquals(0, HydrationLogic.progressPercent(0, 8))
        assertEquals(50, HydrationLogic.progressPercent(4, 8))
        assertEquals(75, HydrationLogic.progressPercent(6, 8))
        assertEquals(87, HydrationLogic.progressPercent(7, 8))   // 向下取整
        assertEquals(100, HydrationLogic.progressPercent(8, 8))
        assertEquals(100, HydrationLogic.progressPercent(12, 8))
    }

    // ---------- US-4 卡片快照 ----------
    @Test fun `us4_cardData_snapshot`() {
        val a = HydrationLogic.aggregate(anchorSet(), today, goal)
        val card = HydrationCardData(a.todayCups, HydrationConstants.DAILY_GOAL)
        assertEquals(4, card.todayCups)
        assertEquals(8, card.dailyGoal)
    }

    // ---------- 常量口径 ----------
    @Test fun `constants_locked`() {
        assertEquals(8, HydrationConstants.DAILY_GOAL)
        assertEquals(120, HydrationConstants.REMIND_INTERVAL_MIN)
        assertEquals(2, HydrationConstants.REMIND_INTERVAL_MIN_FOR_TEST)
        assertEquals(500, HydrationConstants.RECORD_LIMIT)
        assertEquals(3, HydrationConstants.CARD_RECENT_LIMIT)
    }

    // ---------- null 入参不抛异常 ----------
    @Test fun `fuzzy_aggregate_never_throws`() {
        var threw = false
        try {
            HydrationLogic.aggregate(null, today, goal)
            HydrationLogic.aggregate(emptyList(), "", goal)
            HydrationLogic.aggregate(emptyList(), today, 0)
        } catch (e: Exception) {
            threw = true
        }
        assertFalse(threw)
    }
}
