package io.eazo.hydration.core

/**
 * REQ-008 常量集中（契约 §1 + NFR S2/M1；与鸿蒙 HydrationConstants.ets 同值 1:1）。
 * C3 落点：取证常量与生产常量同置；改值仅改常量不改逻辑（M2/T4）。
 */
object HydrationConstants {
    /** 目标杯数（PRD §5 全局常量，双端一致，首版锁定）。 */
    const val DAILY_GOAL: Int = 8
    /** 提醒间隔分钟（生产常量）。 */
    const val REMIND_INTERVAL_MIN: Int = 120
    /** ★ C3：取证版常量（仅验证构建用，生产禁改 120）。 */
    const val REMIND_INTERVAL_MIN_FOR_TEST: Int = 2
    /** 记录上限（NFR S2）。 */
    const val RECORD_LIMIT: Int = 500
    /** 卡片近记录条数（展示态）。 */
    const val CARD_RECENT_LIMIT: Int = 3
    /** 提醒通知文案（PRD SC2，双端一致）。 */
    const val REMIND_TEXT: String = "该喝水了"
}
