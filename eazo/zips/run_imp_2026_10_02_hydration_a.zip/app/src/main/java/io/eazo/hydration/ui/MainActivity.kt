package io.eazo.hydration.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.booleanResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.hydration.R
import io.eazo.hydration.core.HydrationConstants
import io.eazo.hydration.core.HydrationLogic
import io.eazo.hydration.model.AggregationResult
import io.eazo.hydration.model.HydrationRecord
import io.eazo.hydration.platform.AppRepo
import io.eazo.hydration.platform.Clock
import io.eazo.hydration.platform.ReminderScheduler
import io.eazo.hydration.platform.WidgetBridge

/**
 * 主界面（US-1/2/3/5）：进度 + 「+1 杯」/补记 + 提醒开关 + 记录列表。
 * 多端自适应（AC-HY5.1，O4）：res/values-sw600dp + BoxWithConstraints 双列（600dp ≈ 600vp 语义对齐）。
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HydrationApp() }
    }
}

@Composable
fun HydrationApp() {
    val context = LocalContext.current
    var result by mutableStateOf(AppRepo.get(context).aggregateToday(Clock().todayLocal()))
    var records by mutableStateOf(AppRepo.get(context).list())
    var reminderOn by mutableStateOf(false)

    fun refresh() {
        result = AppRepo.get(context).aggregateToday(Clock().todayLocal())
        records = AppRepo.get(context).list()
    }

    fun checkin(cups: Int) {
        AppRepo.get(context).create(cups)          // 单例写（R4 对等）
        WidgetBridge.notifyChanged(context)        // 写后主动推送 AppWidget（P3）
        refresh()
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF0F7FF)) {
        // sw600dp 资源限定符 + BoxWithConstraints 双保险（O4 口径）
        val wideByRes = booleanResource(R.bool.two_pane)
        BoxWithConstraints {
            val wide = wideByRes || maxWidth >= 600.dp
            if (wide) {
                Row(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                    Column(
                        modifier = Modifier.weight(1f).fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) { ProgressPanel(result, reminderOn, ::checkin) { on ->
                        reminderOn = on
                        ReminderScheduler.setReminderEnabled(context, on)
                    } }
                    Spacer(Modifier.width(24.dp))
                    Column(modifier = Modifier.weight(1f).fillMaxSize()) { RecordList(records) }
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    ProgressPanel(result, reminderOn, ::checkin) { on ->
                        reminderOn = on
                        ReminderScheduler.setReminderEnabled(context, on)
                    }
                    RecordList(records)
                }
            }
        }
    }
}

@Composable
fun ProgressPanel(
    result: AggregationResult,
    reminderOn: Boolean,
    onCheckin: (Int) -> Unit,
    onReminder: (Boolean) -> Unit
) {
    val goal = HydrationConstants.DAILY_GOAL
    Text("今日喝水", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0D47A1))
    Spacer(Modifier.height(12.dp))
    Text(
        "${result.todayCups}/$goal",
        fontSize = 44.sp, fontWeight = FontWeight.Bold,
        color = if (result.goalReached) Color(0xFF2E7D32) else Color(0xFF1565C0)
    )
    Text("杯 · 已打卡 ${result.todayCheckins} 次", fontSize = 13.sp, color = Color(0xFF78909C))
    if (result.goalReached) {
        Spacer(Modifier.height(4.dp))
        Text("🎉 今日目标达成", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF2E7D32))
    }
    Spacer(Modifier.height(12.dp))
    LinearProgressIndicator(
        progress = { HydrationLogic.progressPercent(result.todayCups, goal) / 100f },
        modifier = Modifier.fillMaxWidth().height(10.dp),
        color = Color(0xFF42A5F5),
        trackColor = Color(0xFFE3F2FD)
    )
    Spacer(Modifier.height(16.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
            onClick = { onCheckin(1) },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E88E5))
        ) { Text("＋1 杯", fontSize = 17.sp) }
        Button(
            onClick = { onCheckin(2) },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF64B5F6))
        ) { Text("+2 杯") }
        Button(
            onClick = { onCheckin(3) },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF90CAF9))
        ) { Text("+3 杯", color = Color(0xFF0D47A1)) }
    }
    Spacer(Modifier.height(16.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("⏰ 定时提醒（每 2 小时）", fontSize = 14.sp, color = Color(0xFF37474F))
        Spacer(Modifier.width(8.dp))
        Switch(checked = reminderOn, onCheckedChange = onReminder)
    }
}

@Composable
fun RecordList(records: List<HydrationRecord>) {
    val today = Clock().todayLocal()
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("打卡记录", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF37474F))
        Spacer(Modifier.height(8.dp))
        if (records.isEmpty()) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("💧", fontSize = 40.sp)
                Text("还没有记录，点「＋1 杯」开始打卡吧", fontSize = 13.sp, color = Color(0xFF90A4AE))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(records, key = { it.id }) { r ->
                    Row(
                        modifier = Modifier.fillMaxWidth()
                            .background(Color(0xFFF5FBFF), RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            if (HydrationLogic.localDate(r.timestamp) == today) "今天 " else "",
                            fontSize = 12.sp, color = Color(0xFF1E88E5)
                        )
                        Text(r.timestamp.substring(11), fontSize = 13.sp, color = Color(0xFF455A64))
                        Spacer(Modifier.weight(1f))
                        Text("+${r.cups} 杯", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color(0xFF1565C0))
                    }
                }
            }
        }
    }
}
