package io.eazo.hydration.core

import io.eazo.hydration.model.AggregationResult
import io.eazo.hydration.model.HydrationRecord

/**
 * REQ-008 聚合纯函数（契约 §2 逐行等价实现；与鸿蒙 HydrationLogic.ets 1:1）。
 * today 一律入参注入（AD-6）；core 无 Date/时区/random/网络依赖（D3/D5）。
 */
object HydrationLogic {

    /**
     * ★ 聚合纯函数（C1 落点）：goalReached = (todayCups >= goal)——杯数判达成，
     * 禁用 todayCheckins >= goal（D2；用例 7 判定核心）。对任意输入不抛异常。
     */
    fun aggregate(records: List<HydrationRecord>?, today: String, goal: Int): AggregationResult {
        val safe = records ?: emptyList()
        val todayRecords = safe.filter { localDate(it.timestamp) == today && HydrationRecord.isValid(it) }
        val todayCups = todayRecords.sumOf { it.cups }      // 整数求和，无浮点
        val todayCheckins = todayRecords.size
        val goalReached = todayCups >= goal                  // ★ 杯数判达成（>= 含等于）
        return AggregationResult(todayCups, todayCheckins, goalReached)
    }

    /** 日期分组（D3）：字符串前缀截取，禁 Date/时区 API。 */
    fun localDate(timestamp: String): String =
        if (timestamp.length < 10) "" else timestamp.substring(0, 10)

    /** 进度百分比（★ 展示态，排除对账）：min(100, floor(cups/goal*100))，整数路径 floorDiv。 */
    fun progressPercent(todayCups: Int, goal: Int): Int {
        if (goal <= 0) return 0
        return minOf(100, (todayCups * 100).floorDiv(goal))   // 整数路径，无浮点
    }

    /** 记录排序（D4，US-6）：timestamp 字典序倒序；同 timestamp 用 id 升序兜底（稳定排序）。 */
    fun sortDesc(records: List<HydrationRecord>?): List<HydrationRecord> {
        val safe = records ?: emptyList()
        return safe.sortedWith(
            compareByDescending<HydrationRecord> { it.timestamp }.thenBy { it.id }
        )
    }

    /** 升序排序（S2 裁最旧用）。 */
    fun sortAsc(records: List<HydrationRecord>?): List<HydrationRecord> {
        val safe = records ?: emptyList()
        return safe.sortedWith(
            compareBy<HydrationRecord> { it.timestamp }.thenBy { it.id }
        )
    }

    /** id 派生（AD-4/O2，纯函数）：timestamp + '-' + 三位零填充（同秒已有条数 + 1）。 */
    fun nextId(existing: List<HydrationRecord>?, timestamp: String): String {
        val safe = existing ?: emptyList()
        val sameSecondCount = safe.count { it.timestamp == timestamp }
        return "%s-%03d".format(timestamp, sameSecondCount + 1)
    }
}
