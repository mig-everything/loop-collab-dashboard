package io.eazo.hydration.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import io.eazo.hydration.R
import io.eazo.hydration.core.HydrationConstants
import io.eazo.hydration.core.HydrationLogic
import io.eazo.hydration.platform.AppRepo
import io.eazo.hydration.platform.Clock

/**
 * US-4 AppWidget 对等基线（C2 L1 落点，AD-5）：AppWidgetProvider + RemoteViews。
 * 「+1」PendingIntent.getBroadcast → onReceive 卡内直写（不拉起 Activity，对齐鸿蒙 onFormEvent 方案 B）。
 * 写后主动推送 AppWidgetManager.updateAppWidget（AD-2 对等）+ onUpdate 周期兜底（30 分钟）。
 * ★ R4 对等自检：一律经 AppRepo.get() 单例，禁止 new HydrationRepository。
 */
class HydrationWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        // 周期兜底（updatePeriodMillis 30 分钟）：快照与同源数据一致
        pushUpdate(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_CHECKIN) {
            val repo = AppRepo.get(context)   // ★ R4：单例
            repo.create(1)                    // 卡内直写一杯（US-1）
            pushUpdate(context)               // 写后主动推送
        }
    }

    companion object {
        const val ACTION_CHECKIN = "io.eazo.hydration.ACTION_CHECKIN"

        /** 同源读取（SharedPreferences）→ 快照 → updateAppWidget（AC-HY4.1 逐字段口径）。 */
        fun pushUpdate(context: Context) {
            val repo = AppRepo.get(context)   // ★ R4：单例
            val result = repo.aggregateToday(Clock().todayLocal())
            val views = RemoteViews(context.packageName, R.layout.hydration_widget).apply {
                setTextViewText(
                    R.id.widget_goal_text,
                    "${result.todayCups}/${HydrationConstants.DAILY_GOAL} 杯"
                )
                val percent = HydrationLogic.progressPercent(result.todayCups, HydrationConstants.DAILY_GOAL)
                setProgressBar(R.id.widget_progress, 100, percent, false)
                if (result.goalReached) {
                    setViewVisibility(R.id.widget_reached, android.view.View.VISIBLE)
                    setTextViewText(R.id.widget_reached, "🎉 今日目标达成")
                } else {
                    setViewVisibility(R.id.widget_reached, android.view.View.GONE)
                }
                setOnClickPendingIntent(R.id.widget_checkin, checkinPendingIntent(context))
            }
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, HydrationWidgetProvider::class.java))
            ids.forEach { manager.updateAppWidget(it, views) }
        }

        private fun checkinPendingIntent(context: Context): PendingIntent =
            PendingIntent.getBroadcast(
                context, 1,
                Intent(context, HydrationWidgetProvider::class.java).setAction(ACTION_CHECKIN),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
    }
}
