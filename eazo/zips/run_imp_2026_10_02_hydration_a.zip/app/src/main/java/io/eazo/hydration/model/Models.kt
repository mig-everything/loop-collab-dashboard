package io.eazo.hydration.model

/**
 * REQ-008 数据模型（契约 02 §1，与鸿蒙 model/Models.ets 1:1）。
 */
data class HydrationRecord(
    val id: String,        // id = timestamp + '-' + 同秒内序号（三位零填充，AD-4/O2）
    val timestamp: String, // 本地 ISO-8601 无时区 "YYYY-MM-DDTHH:mm:ss"
    val cups: Int          // 正整数（≥1），默认 1，补记可 >1
) {
    companion object {
        /** 契约 §4.3：非法记录判定（cups≤0/非整数、空/格式非法 timestamp）——命中即忽略。 */
        fun isValid(rec: HydrationRecord?): Boolean {
            if (rec == null) return false
            if (rec.cups < 1) return false
            if (rec.timestamp.length != 19) return false
            return true
        }
    }
}

/** 聚合结果（AC-HY2.2/8.2 断言载体）。 */
data class AggregationResult(
    val todayCups: Int = 0,
    val todayCheckins: Int = 0,
    val goalReached: Boolean = false
)

/** 卡片快照 DTO（US-4，双端 1:1；入对账）。 */
data class HydrationCardData(
    val todayCups: Int,
    val dailyGoal: Int
)
