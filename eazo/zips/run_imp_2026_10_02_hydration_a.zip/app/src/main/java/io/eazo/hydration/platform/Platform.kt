package io.eazo.hydration.platform

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.core.app.NotificationCompat
import io.eazo.hydration.R
import io.eazo.hydration.core.HydrationConstants
import io.eazo.hydration.core.HydrationRepository
import io.eazo.hydration.core.HydrationStore
import io.eazo.hydration.core.TimeSource
import io.eazo.hydration.model.HydrationRecord
import io.eazo.hydration.widget.HydrationWidgetProvider
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/** SharedPreferences 持久化（契约 §10：JSON 数组，键 "hydration_records"；与鸿蒙 PreferencesStore 1:1）。 */
class PreferencesStore(context: Context) : HydrationStore {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("hydration", Context.MODE_PRIVATE)

    override fun load(): List<HydrationRecord> {
        val json = prefs.getString(KEY, "[]") ?: "[]"
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                HydrationRecord(o.getString("id"), o.getString("timestamp"), o.getInt("cups"))
            }
        } catch (e: Exception) {
            emptyList()   // 损坏数据不崩溃
        }
    }

    override fun save(records: List<HydrationRecord>) {
        val arr = JSONArray()
        records.forEach { r ->
            arr.put(JSONObject().put("id", r.id).put("timestamp", r.timestamp).put("cups", r.cups))
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    companion object {
        private const val KEY = "hydration_records"
        const val FORM_IDS_KEY = "hydration_form_ids"
    }
}

/** 唯一时间端口（契约 §10：LocalDateTime + DateTimeFormatter，无时区换算）。 */
class Clock : TimeSource {
    override fun nowLocalIso(): String =
        LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"))

    fun todayLocal(): String = nowLocalIso().substring(0, 10)
}

/** 进程内单例仓储入口（生成器规则 1 / R4：页面与 AppWidget 一律经此获取，禁止各自 new）。 */
object AppRepo {
    @Volatile
    private var repo: HydrationRepository? = null

    fun get(context: Context): HydrationRepository =
        repo ?: synchronized(this) {
            repo ?: HydrationRepository(PreferencesStore(context.applicationContext), Clock()).also { repo = it }
        }
}

/** 卡片快照构建纯函数（契约 §2 buildCardData；与鸿蒙 FormDataBuilder 1:1）。 */
object FormDataBuilder {
    fun build(todayCups: Int, todayCheckins: Int, goalReached: Boolean, goal: Int) =
        io.eazo.hydration.model.HydrationCardData(todayCups, goal)

    fun goalText(card: io.eazo.hydration.model.HydrationCardData): String =
        "${card.todayCups}/${card.dailyGoal} 杯"
}

/**
 * 提醒调度（US-3 / 契约 §8 / C3 落点，AD-3 OS 级预排）：AlarmManager setRepeating / cancel。
 * ★ C3 取证路径：effectiveIntervalMin() 单点——取证版改指向 REMIND_INTERVAL_MIN_FOR_TEST（改常量不改逻辑）。
 * nextRemind 重开语义：每次开启以「当前时刻」为起点 setRepeating——「关→再开」天然以再开时刻重算。
 */
object ReminderScheduler {
    private const val CHANNEL_ID = "hydration_remind"
    private const val NOTIFY_ID = 1008

    /** ★ 取证版构建：临时改为 return HydrationConstants.REMIND_INTERVAL_MIN_FOR_TEST */
    fun effectiveIntervalMin(): Int = HydrationConstants.REMIND_INTERVAL_MIN

    fun setReminderEnabled(context: Context, enabled: Boolean) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = remindPendingIntent(context)
        if (!enabled) {
            alarm.cancel(pi)
            return
        }
        alarm.cancel(pi)
        val intervalMillis = effectiveIntervalMin() * 60_000L
        val firstTrigger = System.currentTimeMillis() + intervalMillis
        try {
            alarm.setRepeating(AlarmManager.RTC_WAKEUP, firstTrigger, intervalMillis, pi)
        } catch (e: SecurityException) {
            // 无精确闹钟权限时降级 inexact（行为态，取证截图会体现）
            alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, firstTrigger, intervalMillis, pi)
        }
    }

    /** 触发时发系统通知「该喝水了」（PRD SC2；点击进入 App 打卡）。 */
    fun onRemindFired(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, context.getString(R.string.remind_channel_name),
                    NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val open = PendingIntent.getActivity(
            context, 0,
            Intent(context, io.eazo.hydration.ui.MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notify = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(context.getString(R.string.remind_text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            nm.notify(NOTIFY_ID, notify)
        } catch (e: SecurityException) {
            // 通知权限未授予（API 33+ 运行时权限）：行为态取证时授予后重试
        }
    }

    private fun remindPendingIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context, 0,
            Intent(context, RemindReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
}

/** 提醒触发接收器：发通知。 */
class RemindReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.onRemindFired(context)
    }
}

/** 写后推送出口：打卡落盘后主动刷新 AppWidget（P3：仅事件时一次）。 */
object WidgetBridge {
    fun notifyChanged(context: Context) {
        HydrationWidgetProvider.pushUpdate(context)
    }
}
