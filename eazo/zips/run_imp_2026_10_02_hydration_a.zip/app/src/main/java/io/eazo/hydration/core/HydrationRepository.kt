package io.eazo.hydration.core

import io.eazo.hydration.model.AggregationResult
import io.eazo.hydration.model.HydrationRecord

/** 持久化端口（测试可注入内存实现）。 */
interface HydrationStore {
    fun load(): List<HydrationRecord>
    fun save(records: List<HydrationRecord>)
}

/** 时间端口（core 不读系统时间）。 */
interface TimeSource {
    fun nowLocalIso(): String
}

/**
 * REQ-008 状态管理（与鸿蒙 HydrationRepository.ets 1:1）。
 * create 幂等（同秒同杯数去重）、非法 cups 静默忽略、RECORD_LIMIT 裁最旧、写后回调推送卡片。
 */
class HydrationRepository(
    private val store: HydrationStore,
    private val time: TimeSource
) {
    private var records: MutableList<HydrationRecord> = mutableListOf()

    init {
        reload()
    }

    /** 读档：非法记录跳过不崩溃（契约 §4.3）。 */
    fun reload() {
        records = store.load().filter { HydrationRecord.isValid(it) }.toMutableList()
    }

    /**
     * 打卡写入口（US-1）：cups 非法 → 返回 null（静默忽略）。
     * 幂等（D6）：同 timestamp+cups 去重键（锁效果不锁机制）。
     */
    fun create(cups: Int, onWritten: (() -> Unit)? = null): HydrationRecord? {
        if (cups < 1) return null
        val timestamp = time.nowLocalIso()
        if (isDuplicate(timestamp, cups)) return null
        val id = HydrationLogic.nextId(records, timestamp)
        val rec = HydrationRecord(id, timestamp, cups)
        records.add(rec)
        if (records.size > HydrationConstants.RECORD_LIMIT) {
            // 裁最旧（timestamp+id 字典序最小）
            val sorted = HydrationLogic.sortAsc(records)
            records = sorted.takeLast(HydrationConstants.RECORD_LIMIT).toMutableList()
        }
        store.save(records)
        onWritten?.invoke()
        return rec
    }

    /** 全量读取（US-6）：timestamp 倒序 + 同 timestamp id 升序兜底（D4）。 */
    fun list(): List<HydrationRecord> = HydrationLogic.sortDesc(records)

    /** 今日聚合（today 入参可测）。 */
    fun aggregateToday(today: String): AggregationResult =
        HydrationLogic.aggregate(records, today, HydrationConstants.DAILY_GOAL)

    private fun isDuplicate(timestamp: String, cups: Int): Boolean =
        records.any { it.timestamp == timestamp && it.cups == cups }
}
