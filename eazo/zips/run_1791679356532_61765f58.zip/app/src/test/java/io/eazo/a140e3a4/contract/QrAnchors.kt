package io.eazo.a140e3a4.contract

import io.eazo.a140e3a4.model.ECLevel

/**
 * 冻结锚点全集(18 条 encodeMatrix 锚点:version/modules/SHA-256)。
 *
 * 由 scripts/gen_qr_contract_artifacts.py 机械解析 PRD §5② 锚点表(契约 §4
 * 钦定期望值单一数据源)生成,逐条经 segno 1.6.6 复算门禁全等放行;锚点输入与
 * sa_req019_design_verify.py ANCHOR_* 常量交叉核对——禁手改,重跑零 diff。
 * 注:契约 02-interface-contract.md §6.1 表 HELLO@H 行为 62 位 hex 截断转录,
 * 期望值以 PRD 表 + segno 复算为准(契约 §4 自述「期望值以本机复算为准」)。
 */
object QrAnchors {

    data class Anchor(
        val key: String,
        val content: String,
        val ec: ECLevel,
        val version: Int,
        val modules: Int,
        val sha256: String,
    )

    const val HELLO = "HELLO"
    const val URL = "https://example.com"
    const val CN = "Eazo二维码生成器"
    const val DIGITS = "1234567890"
    val LONG = "Eazo".repeat(40) // 160 字符(repeat 非编译期常量)
    const val SPECIAL = "https://a.b/?q=你好&x=123&emoji=😀"


    val all: List<Anchor> = listOf(
        Anchor("ascii_text", HELLO, ECLevel.L, 1, 21, "a748449400bb5bc0f19504218e3379c2f8c109e76429ad424158a98386a25a41"),
        Anchor("ascii_text", HELLO, ECLevel.M, 1, 21, "de338c834a3ba693572ddf28577dfe1de8b694eac321dec7d559cfdb6a60cd70"),
        Anchor("ascii_text", HELLO, ECLevel.Q, 1, 21, "664f624c017daa67b697fcb455f3ef7921e27c97ecfdfbb1cc75a239e88dc77e"),
        Anchor("ascii_text", HELLO, ECLevel.H, 1, 21, "19c50848b4e4af1a28a2f50ed5f9fec1c6c9a72d73596f6e4ff7b4d496934a75"),
        Anchor("url", URL, ECLevel.L, 2, 25, "1d423dc12343eadfbe06a80cb7a946901a9165e0eca9b0e8b033d7da4c6f5b16"),
        Anchor("url", URL, ECLevel.M, 2, 25, "1ffc4a8e6a08202bc7418473f21d50b0ce7dcbc5f08884c6468a5007ee1d6049"),
        Anchor("url", URL, ECLevel.Q, 2, 25, "3ea52e8dc363b274525872a97df3862b111649ed2fb04f5610436294230db2ee"),
        Anchor("url", URL, ECLevel.H, 3, 29, "8f0a44c7bc24d9509eaa7d20177c1def965c6f1b561e28cf875aae46b27a1e16"),
        Anchor("cn_text", CN, ECLevel.L, 2, 25, "7d0427161f4072d565b3a45d742b17fe233b9921e2a60b352cc20dcbdd535c80"),
        Anchor("cn_text", CN, ECLevel.M, 2, 25, "7b52e0f163fcd5d91f8b89cfc964fee26f08a9a29c580e6301a1ea4fde0522db"),
        Anchor("cn_text", CN, ECLevel.Q, 3, 29, "b24b485ead676d0b718017ed17490e127c5b8e3818681582419d66fb729c239e"),
        Anchor("cn_text", CN, ECLevel.H, 3, 29, "407356dfb70adafebaba317e3ee499826eada0378ceeaf7d93faf84f2cec3682"),
        Anchor("digits", DIGITS, ECLevel.L, 1, 21, "8790a5b52db455e8586502cc10fadca13d4430e9b0596512996acdd45b3ae3bb"),
        Anchor("digits", DIGITS, ECLevel.M, 1, 21, "251d16ae42c09241fd53a5e5d28cd11ad461a3b63b70dc043a73f3ef10ab9be2"),
        Anchor("digits", DIGITS, ECLevel.Q, 1, 21, "8dcf54310fbcc38939f3f387b2d3926b570f7ad5e0e5ecbe0c01091ceb6c89e0"),
        Anchor("digits", DIGITS, ECLevel.H, 1, 21, "1cfd396db76a13b912ef18e15cbbc8c9ae957d8a026c381a03cc6339e3f3817d"),
        Anchor("long_text", LONG, ECLevel.M, 9, 53, "0590ebe9297c6231c2dddc606893bc03802ff19104cb0364b71df9d4f7d5ec54"),
        Anchor("special", SPECIAL, ECLevel.M, 3, 29, "2646be7acccc7af8f4f3fe1277f65c39bf26705abb76d12efde1d21d3769c1fe"),
    )
}
