package io.eazo.a140e3a4.contract

import io.eazo.a140e3a4.core.QrEncoder
import io.eazo.a140e3a4.core.QrRules
import io.eazo.a140e3a4.model.ECLevel
import io.eazo.a140e3a4.model.EC_TO_BITS
import io.eazo.a140e3a4.model.MAX_INPUT_LENGTH
import io.eazo.a140e3a4.model.SIZE_TO_EDGE
import io.eazo.a140e3a4.model.Size
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

/**
 * 契约断言集(02-interface-contract.md §6.5 建议 ~35 条/端,JVM 纯逻辑):
 * encodeMatrix 18 锚点 + normalizeInput 7 + 映射函数 7 + 确定性 2 + 空拒绝 1。
 * 锚点期望值由生成器从 PRD §5② 机械提取并经 segno 1.6.6 复算门禁(QrAnchors.kt)。
 */
class QrContractTest {

    private fun sha256(matrix: Array<BooleanArray>): String =
        MessageDigest.getInstance("SHA-256")
            .digest(QrRules.serialize(matrix).toByteArray(Charsets.US_ASCII))
            .joinToString("") { "%02x".format(it) }

    /** §6.1 全表:18 条锚点 version/modules/SHA-256 逐字段断言(一次断言覆盖整表)。 */
    @Test
    fun `encodeMatrix 18 锚点全表`() {
        assertEquals(18, QrAnchors.all.size)
        QrAnchors.all.forEach { a ->
            val r = QrEncoder.encodeMatrix(a.content, a.ec)
            assertEquals("${a.key}@${a.ec} version", a.version, r.meta.version)
            assertEquals("${a.key}@${a.ec} modules", a.modules, r.meta.modules)
            assertEquals("${a.key}@${a.ec} sha256", a.sha256, sha256(r.matrix))
        }
    }

    /** §6.2:normalizeInput 7 锚点(空/空白/原样/trim/512/513 截断/emoji 代理对安全)。 */
    @Test
    fun `normalizeInput 7 锚点`() {
        assertNull(QrRules.normalizeInput(""))
        assertNull(QrRules.normalizeInput("   "))
        assertEquals("hello", QrRules.normalizeInput("hello"))
        assertEquals("hello", QrRules.normalizeInput("  hello  "))
        assertEquals(512, QrRules.normalizeInput("a".repeat(512))?.length)
        assertEquals("a".repeat(512), QrRules.normalizeInput("a".repeat(513)))
        // 260 emoji = 520 UTF-16 units → 截 512 units = 256 完整 emoji(不劈代理对)
        assertEquals("😀".repeat(256), QrRules.normalizeInput("😀".repeat(260)))
    }

    /** §8 参数直断言:MAX_INPUT_LENGTH / SIZE_TO_EDGE / EC_TO_BITS。 */
    @Test
    fun `参数直断言`() {
        assertEquals(512, MAX_INPUT_LENGTH)
        assertEquals(mapOf(Size.S to 128, Size.M to 200, Size.L to 280), SIZE_TO_EDGE)
        assertEquals(mapOf(ECLevel.M to 0, ECLevel.L to 1, ECLevel.H to 2, ECLevel.Q to 3), EC_TO_BITS)
    }

    /** §6.3:ecLevelToBits 4 档(M=0b00/L=0b01/H=0b10/Q=0b11)。 */
    @Test
    fun `ecLevelToBits 4 档`() {
        assertEquals(0b00, QrRules.ecLevelToBits(ECLevel.M))
        assertEquals(0b01, QrRules.ecLevelToBits(ECLevel.L))
        assertEquals(0b10, QrRules.ecLevelToBits(ECLevel.H))
        assertEquals(0b11, QrRules.ecLevelToBits(ECLevel.Q))
    }

    /** §6.3:sizeToEdgePx 3 档(S=128/M=200/L=280)。 */
    @Test
    fun `sizeToEdgePx 3 档`() {
        assertEquals(128, QrRules.sizeToEdgePx(Size.S))
        assertEquals(200, QrRules.sizeToEdgePx(Size.M))
        assertEquals(280, QrRules.sizeToEdgePx(Size.L))
    }

    /** §6.5 确定性①:同输入同 EC 重复生成,序列化哈希相等。 */
    @Test
    fun `确定性 同输入同EC两次生成一致`() {
        val first = QrEncoder.encodeMatrix(QrAnchors.URL, ECLevel.M)
        val second = QrEncoder.encodeMatrix(QrAnchors.URL, ECLevel.M)
        assertEquals(QrRules.serialize(first.matrix), QrRules.serialize(second.matrix))
    }

    /** §6.5 确定性②:尺寸切换不影响矩阵(尺寸 3 档映射互异且 encodeMatrix 无尺寸入参)。 */
    @Test
    fun `确定性 size 切换不影响矩阵`() {
        val edges = Size.values().map { QrRules.sizeToEdgePx(it) }
        assertEquals(3, edges.toSet().size) // 3 档互异
        val base = QrRules.serialize(QrEncoder.encodeMatrix(QrAnchors.HELLO, ECLevel.H).matrix)
        Size.values().forEach { _ ->
            assertEquals(base, QrRules.serialize(QrEncoder.encodeMatrix(QrAnchors.HELLO, ECLevel.H).matrix))
        }
    }

    /** §6.5:空输入返回 null 不生成(C03 语义锚)。 */
    @Test
    fun `空输入拒绝`() {
        assertNull(QrRules.normalizeInput(""))
        assertNull(QrRules.normalizeInput("   "))
    }

    /** 结构补强:boost 禁令(V2)——空余容量不升 EC,HELLO 四档 version 均为 1 且哈希两两不同。 */
    @Test
    fun `boost 禁令 四档哈希两两不同`() {
        val hashes = ECLevel.values().map { sha256(QrEncoder.encodeMatrix(QrAnchors.HELLO, it).matrix) }
        assertEquals(4, hashes.toSet().size)
        assertTrue(hashes.zip(QrAnchors.all.filter { it.key == "ascii_text" }.map { it.sha256 })
            .all { (actual, expected) -> actual == expected })
    }
}
