import io.eazo.a140e3a4.core.QrEncoder
import io.eazo.a140e3a4.model.ECLevel
fun main() {
    for (n in 1..40) {
        val s = "a".repeat(n)
        for (ec in ECLevel.values()) {
            try { QrEncoder.encodeMatrix(s, ec) } 
            catch (e: Exception) { println("CRASH n=$n ec=$ec: ${e.message}") }
        }
    }
    val url = "https://eazo.example.com/req019"
    for (ec in ECLevel.values()) {
        try { QrEncoder.encodeMatrix(url, ec) } 
        catch (e: Exception) { println("CRASH url(${url.length}) ec=$ec: ${e.message}") }
    }
}
