package io.eazo.a140e3a4.contract

import io.eazo.a140e3a4.core.QrEncoder
import io.eazo.a140e3a4.core.QrRules
import io.eazo.a140e3a4.model.ECLevel
import io.eazo.a140e3a4.model.Size
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

/**
 * 冻结功能用例清单(cases-frozen.json,version eazo-cases-1.0.0,15 条 slug)——
 * 用例名逐字等于 slug,不得增删改/改名/合并拆分(用例契约硬约束)。
 * 全部 JVM 纯逻辑断言(UI 展示态经纯函数映射判定,截图维度归 TR-Accept)。
 */
class CasesFrozenTest {

    private fun sha256(matrix: Array<BooleanArray>): String =
        MessageDigest.getInstance("SHA-256")
            .digest(QrRules.serialize(matrix).toByteArray(Charsets.US_ASCII))
            .joinToString("") { "%02x".format(it) }

    private fun anchorHash(content: String, ec: ECLevel): String =
        QrAnchors.all.first { it.content == content && it.ec == ec }.sha256

    /** C01 输入普通文本生成二维码:预览区展示对应二维码(矩阵生成 + 锚点哈希一致)。 */
    @Test
    fun `generate_text_qr`() {
        val r = QrEncoder.encodeMatrix(QrAnchors.CN, ECLevel.L)
        assertEquals(25, r.meta.modules)
        assertEquals(anchorHash(QrAnchors.CN, ECLevel.L), sha256(r.matrix))
    }

    /** C02 输入链接生成二维码:预览区展示对应二维码(锚点哈希一致)。 */
    @Test
    fun `generate_url_qr`() {
        val r = QrEncoder.encodeMatrix(QrAnchors.URL, ECLevel.M)
        assertEquals(25, r.meta.modules)
        assertEquals(anchorHash(QrAnchors.URL, ECLevel.M), sha256(r.matrix))
    }

    /** C03 空输入拒绝:提示「请输入文本或链接」,不生成。 */
    @Test
    fun `reject_empty_input`() {
        assertNull(QrRules.normalizeInput(""))
    }

    /** C04 纯空白输入拒绝:提示输入错误,不生成。 */
    @Test
    fun `reject_whitespace_input`() {
        assertNull(QrRules.normalizeInput("   "))
    }

    /** C05 尺寸小档映射:预览边长 128vp。 */
    @Test
    fun `size_small`() {
        assertEquals(128, QrRules.sizeToEdgePx(Size.S))
    }

    /** C06 尺寸中档映射:预览边长 200vp。 */
    @Test
    fun `size_medium`() {
        assertEquals(200, QrRules.sizeToEdgePx(Size.M))
    }

    /** C07 尺寸大档映射:预览边长 280vp。 */
    @Test
    fun `size_large`() {
        assertEquals(280, QrRules.sizeToEdgePx(Size.L))
    }

    /** C08 纠错级别 L 映射:矩阵对应 L 档(锚点哈希一致)。 */
    @Test
    fun `ec_level_l`() {
        val r = QrEncoder.encodeMatrix(QrAnchors.HELLO, ECLevel.L)
        assertEquals(anchorHash(QrAnchors.HELLO, ECLevel.L), sha256(r.matrix))
    }

    /** C09 纠错级别 M 映射:矩阵对应 M 档(锚点哈希一致)。 */
    @Test
    fun `ec_level_m`() {
        val r = QrEncoder.encodeMatrix(QrAnchors.HELLO, ECLevel.M)
        assertEquals(anchorHash(QrAnchors.HELLO, ECLevel.M), sha256(r.matrix))
    }

    /** C10 纠错级别 Q 映射:矩阵对应 Q 档(锚点哈希一致)。 */
    @Test
    fun `ec_level_q`() {
        val r = QrEncoder.encodeMatrix(QrAnchors.HELLO, ECLevel.Q)
        assertEquals(anchorHash(QrAnchors.HELLO, ECLevel.Q), sha256(r.matrix))
    }

    /** C11 纠错级别 H 映射:矩阵对应 H 档(锚点哈希一致)。 */
    @Test
    fun `ec_level_h`() {
        val r = QrEncoder.encodeMatrix(QrAnchors.HELLO, ECLevel.H)
        assertEquals(anchorHash(QrAnchors.HELLO, ECLevel.H), sha256(r.matrix))
    }

    /** C12 同输入同输出确定性:两次矩阵完全一致(哈希相等)。 */
    @Test
    fun `deterministic_same_input`() {
        val first = QrEncoder.encodeMatrix(QrAnchors.URL, ECLevel.Q)
        val second = QrEncoder.encodeMatrix(QrAnchors.URL, ECLevel.Q)
        assertEquals(QrRules.serialize(first.matrix), QrRules.serialize(second.matrix))
        assertTrue(first.meta.version == second.meta.version && first.meta.mask == second.meta.mask)
    }

    /** C13 长文本自动升版本:160 字符 → v9 53×53 且可扫(锚点哈希一致)。 */
    @Test
    fun `long_text_version_up`() {
        assertEquals(160, QrAnchors.LONG.length)
        val r = QrEncoder.encodeMatrix(QrAnchors.LONG, ECLevel.M)
        assertEquals(9, r.meta.version)
        assertEquals(53, r.meta.modules)
        assertEquals(anchorHash(QrAnchors.LONG, ECLevel.M), sha256(r.matrix))
    }

    /** C14 特殊字符 UTF-8 编码:中文 + emoji 按 UTF-8 byte mode 编码(锚点哈希一致)。 */
    @Test
    fun `special_chars_utf8`() {
        val r = QrEncoder.encodeMatrix(QrAnchors.SPECIAL, ECLevel.M)
        assertEquals(3, r.meta.version)
        assertEquals(29, r.meta.modules)
        assertEquals(anchorHash(QrAnchors.SPECIAL, ECLevel.M), sha256(r.matrix))
    }

    /** C15 超 512 字符截取:截取前 512 UTF-16 units 后生成(与 512 输入矩阵全等)。 */
    @Test
    fun `max_length_truncate`() {
        assertEquals("a".repeat(512), QrRules.normalizeInput("a".repeat(513)))
        val truncated = QrEncoder.encodeMatrix("a".repeat(513), ECLevel.M)
        val exact = QrEncoder.encodeMatrix("a".repeat(512), ECLevel.M)
        assertEquals(QrRules.serialize(exact.matrix), QrRules.serialize(truncated.matrix))
    }
}
