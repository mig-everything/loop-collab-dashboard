package io.eazo.a140e3a4.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import io.eazo.a140e3a4.platform.AppRepo

/**
 * 单 Activity + Jetpack Compose(UI 锁死声明式——与鸿蒙 ArkUI 声明式对称,
 * 禁止 XML 布局/drawable 扇出;主题/配色用 Compose MaterialTheme)。
 *
 * 硬规则 ②:onResume 只 refresh()(重读内存态),禁止从持久化 load()。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    QrGeneratorScreen()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②:onResume 只重读内存态刷新,绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(this).refresh()
    }
}

/** 应用主题:精致浅色(indigo 主色 + 靛青辅助,卡片式分区排版)。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF4F46E5),
            onPrimary = Color(0xFFFFFFFF),
            primaryContainer = Color(0xFFE0E7FF),
            onPrimaryContainer = Color(0xFF1E1B4B),
            secondary = Color(0xFF0D9488),
            secondaryContainer = Color(0xFFCCFBF1),
            background = Color(0xFFF6F7FB),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFEEF0F7),
            outline = Color(0xFF6B7280),
            outlineVariant = Color(0xFFE5E7EB),
        ),
        content = content,
    )
}
