package io.eazo.a140e3a4.platform

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import io.eazo.a140e3a4.core.QrEncoder
import io.eazo.a140e3a4.core.QrRules
import io.eazo.a140e3a4.model.ECLevel
import io.eazo.a140e3a4.model.QrResult
import io.eazo.a140e3a4.model.Size

/**
 * 平台层:AppRepo 进程内单例(生成器硬规则 ①——UI/卡片层禁止 new XxxRepository(...),
 * 一律经 AppRepo.getRepo(context) 获取)。
 *
 * 契约 §3:当前输入/EC/size 状态;无持久化(Out of Scope)。内存态用 Compose
 * snapshot state 承载,UI 层零镜像同步。硬规则 ②:onResume 只 refresh()(重读
 * 内存态),绝不从持久化 load()。
 */
object AppRepo {

    /** 当前输入(原始文本,规范化在生成路径做)。 */
    var input by mutableStateOf("")

    /** 当前纠错级别(影响矩阵,切换即重算)。 */
    var ecLevel by mutableStateOf(ECLevel.M)

    /** 当前尺寸档(纯展示态:只影响预览边长,不影响矩阵)。 */
    var size by mutableStateOf(Size.M)

    /** 最近一次成功生成结果;输入无效/超容量时为 null。 */
    var result by mutableStateOf<QrResult?>(null)

    /** 最近一次生成尝试的错误提示(空/纯空白输入或内容超容量);有效输入即清除。 */
    var error by mutableStateOf<String?>(null)

    /** 进程内单例入口(硬规则 ① 落点)——UI/卡片层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo = this

    /** 输入变更:实时重算预览(输入有效即出码,无效清空并清错)。 */
    fun updateInput(value: String) {
        input = value
        error = null
        recompute()
    }

    /** 切换纠错级别:矩阵随之重算。 */
    fun selectEc(level: ECLevel) {
        ecLevel = level
        recompute()
    }

    /** 切换尺寸档:纯展示态,不触发重算。 */
    fun selectSize(newSize: Size) {
        size = newSize
    }

    /** 确认生成(C01/C02 路径):无效输入提示「请输入文本或链接」且不生成(C03/C04)。 */
    fun generate(): QrResult? {
        if (QrRules.normalizeInput(input) == null) {
            error = "请输入文本或链接"
            result = null
            return null
        }
        recompute()
        return result
    }

    private fun recompute() {
        result = if (QrRules.normalizeInput(input) == null) null
        else try {
            QrEncoder.encodeMatrix(input, ecLevel)
        } catch (e: IllegalArgumentException) {
            error = e.message
            null
        }
    }

    /** 硬规则 ②:onResume 只重读内存态刷新;本应用无持久化,空实现即语义正确。 */
    fun refresh() {
    }
}
