package io.eazo.a140e3a4.model

/**
 * REQ-019 数据模型与常量面(契约 02-interface-contract.md §1,冻结 commit d853fef)。
 * 与鸿蒙端 model 1:1:枚举字面量/字段名/常量值双端完全一致。
 */

/** 纠错级别 4 档(ISO 恢复率 L≈7% / M≈15% / Q≈25% / H≈30%)。 */
enum class ECLevel(val recovery: String) {
    L("≈7%"), M("≈15%"), Q("≈25%"), H("≈30%"),
}

/** 尺寸 3 档(纯展示态:渲染边长映射,不影响矩阵内容)。 */
enum class Size { S, M, L }

/** 编码模式(mixed-mode 自动选择:numeric > alphanumeric > byte;kanji 不启用)。 */
enum class Mode(val indicator: Int, val wireName: String) {
    NUMERIC(0b0001, "numeric"),
    ALPHANUMERIC(0b0010, "alphanumeric"),
    BYTE(0b0100, "byte"),
}

/** 编码结果元数据。 */
data class QRMeta(
    val version: Int,   // 1..40
    val modules: Int,   // N = version*4+17(21..177)
    val mask: Int,      // 0..7
    val mode: String,   // numeric / alphanumeric / byte
)

/** 编码结果:boolean[N][N] 暗块=true 亮块=false。 */
data class QrResult(
    val matrix: Array<BooleanArray>,
    val meta: QRMeta,
)

/** UTF-16 code unit 输入上限(超长截取前 512;双端 .length/.substring 天然同口径)。 */
const val MAX_INPUT_LENGTH = 512

/** 渲染边长映射(vp):尺寸 3 档,纯展示态。 */
val SIZE_TO_EDGE: Map<Size, Int> = mapOf(Size.S to 128, Size.M to 200, Size.L to 280)

/** 格式信息 2-bit 映射(ISO 18004)。 */
val EC_TO_BITS: Map<ECLevel, Int> = mapOf(
    ECLevel.M to 0b00, ECLevel.L to 0b01, ECLevel.H to 0b10, ECLevel.Q to 0b11,
)

/** alphanumeric 模式 45 字符集(ISO 18004)。 */
const val ALNUM_CHARSET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:"
