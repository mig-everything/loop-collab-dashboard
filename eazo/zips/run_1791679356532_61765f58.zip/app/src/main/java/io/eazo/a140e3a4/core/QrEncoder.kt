package io.eazo.a140e3a4.core

import io.eazo.a140e3a4.model.ALNUM_CHARSET
import io.eazo.a140e3a4.model.ECLevel
import io.eazo.a140e3a4.model.Mode
import io.eazo.a140e3a4.model.QRMeta
import io.eazo.a140e3a4.model.QrResult

/**
 * 确定性 QR 编码器(契约 §2.1,参考实现 segno 1.6.6 口径,§1.3 八条语义逐条对齐):
 * mixed-mode 自动选择 + 最小版本 + GF(256)/0x11D Reed-Solomon + 标准掩码罚分选择。
 * 纯函数:零 IO/网络/随机/时钟/UI API;禁 boost_error、禁 Micro QR(§5 禁用清单)。
 * 算法逐行移植自 sa_req019_design_verify.py 独立编码器(26 输入组合与 segno
 * 全矩阵位级对撞实证);RS/对位常量面由生成器从 segno 1.6.6 本体提取(QrTables.kt)。
 */
object QrEncoder {

    // ---- GF(256),本原多项式 0x11D(x^8+x^4+x^3+x^2+1),程序化生成 ----
    private val GF_EXP = IntArray(512)
    private val GF_LOG = IntArray(256)

    init {
        var x = 1
        for (i in 0 until 255) {
            GF_EXP[i] = x
            GF_LOG[x] = i
            x = x shl 1
            if (x and 0x100 != 0) x = x xor 0x11D
        }
        for (i in 255 until 512) GF_EXP[i] = GF_EXP[i - 255]
    }

    private fun gfMul(a: Int, b: Int): Int =
        if (a == 0 || b == 0) 0 else GF_EXP[GF_LOG[a] + GF_LOG[b]]

    /** RS 生成多项式,降幂首一存放 poly[0]=1(最高次):G(x)=∏(x+α^i)。 */
    private val genPolyCache = HashMap<Int, IntArray>()

    private fun rsGenerator(degree: Int): IntArray {
        genPolyCache[degree]?.let { return it }
        var poly = intArrayOf(1)
        for (i in 0 until degree) {
            val xp = poly + 0                          // x*p:p 末尾补 0
            val ap = IntArray(poly.size) { gfMul(poly[it], GF_EXP[i]) } // α^i*p
            val out = IntArray(xp.size)
            out[0] = xp[0]
            for (t in 1 until xp.size) out[t] = xp[t] xor ap[t - 1]
            poly = out
        }
        genPolyCache[degree] = poly
        return poly
    }

    /** 数据块 RS 余数(综合除法),返回 degree 个 EC 码字。 */
    private fun rsRemainder(data: ByteArray, degree: Int): IntArray {
        val gen = rsGenerator(degree)
        val rem = IntArray(data.size + degree)
        for (i in data.indices) rem[i] = data[i].toInt() and 0xFF
        for (i in data.indices) {
            val factor = rem[i]
            if (factor != 0) {
                for (j in 1 until gen.size) rem[i + j] = rem[i + j] xor gfMul(gen[j], factor)
            }
        }
        return rem.copyOfRange(data.size, rem.size)
    }

    // ---- 模式选择(§1.3-1:numeric > alphanumeric > byte)----
    private val alnumIndex = IntArray(256) { -1 }.also {
        for (i in ALNUM_CHARSET.indices) it[ALNUM_CHARSET[i].code] = i
    }

    private fun selectMode(data: ByteArray): Mode {
        if (data.isNotEmpty() && data.all { it in '0'.code..'9'.code }) return Mode.NUMERIC
        if (data.isNotEmpty() && data.all { alnumIndex[it.toInt() and 0xFF] >= 0 }) return Mode.ALPHANUMERIC
        return Mode.BYTE
    }

    /** 数据位流(§1.3-2/3):计数位宽按模式 × 版本段;字符计数按所选模式计(byte 按 UTF-8 字节数)。 */
    private fun payloadBits(data: ByteArray, mode: Mode, v: Int): Pair<Int, StringBuilder> {
        val sb = StringBuilder()
        when (mode) {
            Mode.NUMERIC -> {
                val cb = if (v <= 9) 10 else if (v <= 26) 12 else 14
                var i = 0
                while (i < data.size) {
                    val end = minOf(i + 3, data.size)
                    var value = 0
                    for (k in i until end) value = value * 10 + (data[k] - '0'.code)
                    appendBits(sb, value, (end - i) * 3 + 1) // 3 位一组 10bit,尾组 2→7bit、1→4bit
                    i = end
                }
                return cb to sb
            }
            Mode.ALPHANUMERIC -> {
                val cb = if (v <= 9) 9 else if (v <= 26) 11 else 13
                var i = 0
                while (i < data.size) {
                    if (i + 1 < data.size) {
                        val v1 = alnumIndex[data[i].toInt() and 0xFF]
                        val v2 = alnumIndex[data[i + 1].toInt() and 0xFF]
                        appendBits(sb, v1 * 45 + v2, 11)    // 2 字符一组 c1*45+c2 → 11bit
                        i += 2
                    } else {
                        appendBits(sb, alnumIndex[data[i].toInt() and 0xFF], 6) // 尾单字符 6bit
                        i += 1
                    }
                }
                return cb to sb
            }
            Mode.BYTE -> {
                val cb = if (v <= 9) 8 else 16             // v10+ 计数带 16bit(§1.3-2)
                for (b in data) appendBits(sb, b.toInt() and 0xFF, 8)
                return cb to sb
            }
        }
    }

    private fun appendBits(sb: StringBuilder, value: Int, width: Int) {
        for (k in width - 1 downTo 0) sb.append(if ((value shr k) and 1 == 1) '1' else '0')
    }

    /**
     * encodeMatrix(契约 §2.1):normalize → 选模式 → 最小版本 → 位流(终止符/padding/pad
     * codewords)→ RS 分块交织 → 功能图形 → 蛇形放置 → 8 掩码罚分择优 → format/version 信息。
     *
     * @throws IllegalArgumentException 空白输入(拒绝)或内容超出 v40@EC 容量。
     */
    fun encodeMatrix(text: String, ec: ECLevel): QrResult {
        val normalized = QrRules.normalizeInput(text)
            ?: throw IllegalArgumentException("请输入文本或链接")
        val data = normalized.toByteArray(Charsets.UTF_8)
        val mode = selectMode(data)

        // 最小版本:头(4+计数位宽)+ 数据位 ≤ 数据码字容量(§1.3 试编码法)
        var v = 1
        var cb = 0
        var bs: StringBuilder
        var groups: List<Pair<Int, Int>>
        var dataCw = 0
        while (true) {
            if (v > 40) throw IllegalArgumentException("内容超出二维码最大容量")
            groups = QrTables.rsBlocks[v - 1].getValue(ec)
            dataCw = groups.sumOf { it.first * it.second }
            val payload = payloadBits(data, mode, v)
            cb = payload.first
            bs = payload.second
            if (4 + cb + bs.length <= dataCw * 8) break
            v++
        }

        // 位流:模式 + 计数 + 数据 + 终止符 + padding bits(恒 8-(len%8),对齐时加整字节 0)
        val bits = StringBuilder(dataCw * 8)
        appendBits(bits, mode.indicator, 4)
        appendBits(bits, data.size, cb)
        bits.append(bs)
        val capacityBits = dataCw * 8
        repeat(minOf(4, capacityBits - bits.length)) { bits.append('0') }
        repeat(8 - (bits.length % 8)) { bits.append('0') }
        val padBytes = capacityBits / 8 - bits.length / 8
        for (i in 0 until padBytes) bits.append(if (i % 2 == 0) "11101100" else "00010001") // 0xEC/0x11
        check(bits.length == capacityBits) { "位流长度须等于数据码字容量" }
        val codewords = ByteArray(dataCw) { k ->
            var b = 0
            for (j in 0 until 8) b = (b shl 1) or (bits[k * 8 + j] - '0')
            b.toByte()
        }

        // RS 分块(游标切块:异构块组跨界不错位)+ 数据块列间交织(短块尾部跳过)+ EC 列间交织
        val ecpb = QrTables.ecPerBlock.getValue(ec)[v - 1]
        val blocks = ArrayList<ByteArray>()
        var off = 0
        for ((n, d) in groups) repeat(n) { blocks.add(codewords.copyOfRange(off, off + d)); off += d }
        val ecBlocks = blocks.map { rsRemainder(it, ecpb) }
        val maxD = groups.maxOf { it.second }
        val final = ArrayList<Int>(QrTables.totalCodewords[v - 1])
        for (i in 0 until maxD) for (b in blocks) if (i < b.size) final.add(b[i].toInt() and 0xFF)
        for (i in 0 until ecpb) for (e in ecBlocks) final.add(e[i])

        // ---- 矩阵构建 ----
        val size = v * 4 + 17
        val m = Array(size) { BooleanArray(size) }
        val reserved = Array(size) { BooleanArray(size) }

        // finder 三角 7×7(环 + 3×3 实心核)+ 8×8 角落保留(finder+分隔带)
        for ((fr, fc) in listOf(0 to 0, 0 to size - 7, size - 7 to 0)) {
            for (dr in 0..6) for (dc in 0..6) {
                m[fr + dr][fc + dc] = dr == 0 || dr == 6 || dc == 0 || dc == 6 ||
                    (dr in 2..4 && dc in 2..4)
            }
        }
        for ((r0, c0) in listOf(0 to 0, 0 to size - 8, size - 8 to 0)) {
            for (dr in 0..7) for (dc in 0..7) reserved[r0 + dr][c0 + dc] = true
        }

        // timing(行 6 / 列 6,暗起交替)
        for (i in 8 until size - 8) {
            m[6][i] = i % 2 == 0
            m[i][6] = i % 2 == 0
            reserved[6][i] = true
            reserved[i][6] = true
        }

        // alignment 5×5(实心核 + 环,跳过与 finder 重叠的三个角)
        val centers = QrTables.alignmentCenters[v - 1]
        for (cr in centers) for (cc in centers) {
            if ((cr <= 8 && cc <= 8) || (cr <= 8 && cc >= size - 9) || (cr >= size - 9 && cc <= 8)) continue
            for (dr in -2..2) for (dc in -2..2) {
                m[cr + dr][cc + dc] = maxOf(kotlin.math.abs(dr), kotlin.math.abs(dc)) != 1
                reserved[cr + dr][cc + dc] = true
            }
        }

        // dark module(最终态=暗;罚分评估态按亮 0 参与,见掩码候选构造)+ format 区保留(评估态=亮)
        m[size - 8][8] = true
        reserved[size - 8][8] = true
        for (i in 0..8) {
            if (!reserved[8][i]) { reserved[8][i] = true; m[8][i] = false }
            if (!reserved[i][8]) { reserved[i][8] = true; m[i][8] = false }
        }
        for (i in 0..7) {
            if (!reserved[8][size - 1 - i]) { reserved[8][size - 1 - i] = true; m[8][size - 1 - i] = false }
            if (!reserved[size - 1 - i][8]) { reserved[size - 1 - i][8] = true; m[size - 1 - i][8] = false }
        }

        // version 信息 v≥7:BCH(18,6),LL 三行 + UR 镜像(§1.3-8)
        if (v >= 7) {
            var rem = v
            repeat(12) { rem = (rem shl 1) xor (if ((rem shr 11) and 1 == 1) 0x1F25 else 0) }
            val vi = (v shl 12) or rem
            for (i in 0..5) {
                val b1 = (vi shr (i * 3)) and 1
                val b2 = (vi shr (i * 3 + 1)) and 1
                val b3 = (vi shr (i * 3 + 2)) and 1
                m[size - 11][i] = b1 == 1; m[size - 10][i] = b2 == 1; m[size - 9][i] = b3 == 1
                m[i][size - 11] = b1 == 1; m[i][size - 10] = b2 == 1; m[i][size - 9] = b3 == 1
                for ((r, c) in listOf(size - 11 to i, size - 10 to i, size - 9 to i,
                    i to size - 11, i to size - 10, i to size - 9)) reserved[r][c] = true
            }
        }

        // 数据放置:两列蛇形自右向左,col 6 为 timing 就地跳过(随后 -2 基于跳后值);余位置留亮(参与掩码)
        val totalBits = final.size * 8
        var bitIdx = 0
        var col = size - 1
        var upward = true
        while (col > 0) {
            if (col == 6) col--
            val rows = if (upward) (size - 1) downTo 0 else 0 until size
            for (r in rows) {
                for (c in intArrayOf(col, col - 1)) {
                    if (!reserved[r][c]) {
                        if (bitIdx < totalBits) {
                            val bit = (final[bitIdx shr 3] shr (7 - (bitIdx and 7))) and 1
                            m[r][c] = bit == 1
                        }
                        bitIdx++
                    }
                }
            }
            upward = !upward
            col -= 2
        }
        check(bitIdx >= totalBits) { "码字放置溢出" }

        // ---- 掩码选择:评估态矩阵 = 未写 format 信息(version 信息保留),format 区与
        // dark module 按亮 0 参与罚分;N1~N4 segno 口径;平局取最小掩码号(§1.3-6)----
        var bestMask = 0
        var bestPenalty = Int.MAX_VALUE
        var best: Array<BooleanArray>? = null
        for (mk in 0 until 8) {
            val cand = Array(size) { r ->
                BooleanArray(size) { c ->
                    when {
                        !reserved[r][c] -> maskBit(mk, r, c) != m[r][c]
                        r == size - 8 && c == 8 -> false       // dark module 评估态=亮
                        else -> m[r][c]
                    }
                }
            }
            val p = penalty(cand)
            if (p < bestPenalty) { bestPenalty = p; bestMask = mk; best = cand }
        }
        val result = best!!

        // ---- format 信息:BCH(15,5),放置四臂,i≥6 跳 timing 后偏移恒 +1(§1.3-7)----
        val fmt = (QrRules.ecLevelToBits(ec) shl 3) or bestMask
        var rem = fmt
        repeat(10) { rem = (rem shl 1) xor (if ((rem shr 9) and 1 == 1) 0x537 else 0) }
        val fmtFull = ((fmt shl 10) or rem) xor 0x5412
        for (i in 0..7) {
            val vbit = (fmtFull shr i) and 1          // 低位段
            val hbit = (fmtFull shr (14 - i)) and 1   // 高位段
            val voff = if (i >= 6) 1 else 0
            val hoff = if (i >= 6) 1 else 0
            result[i + voff][8] = vbit == 1           // 左上竖臂
            result[8][i + hoff] = hbit == 1           // 左上横臂
            result[8][size - 1 - i] = vbit == 1       // 右上横臂
            result[size - 1 - i][8] = hbit == 1       // 左下竖臂
        }
        result[size - 8][8] = true                    // dark module 最终态=暗

        return QrResult(result, QRMeta(v, size, bestMask, mode.wireName))
    }

    /** ISO 18004 八掩码条件(§7.8.2)。 */
    private fun maskBit(mask: Int, r: Int, c: Int): Boolean = when (mask) {
        0 -> (r + c) % 2 == 0
        1 -> r % 2 == 0
        2 -> c % 3 == 0
        3 -> (r + c) % 3 == 0
        4 -> (r / 2 + c / 3) % 2 == 0
        5 -> (r * c) % 2 + (r * c) % 3 == 0
        6 -> ((r * c) % 2 + (r * c) % 3) % 2 == 0
        else -> ((r + c) % 2 + (r * c) % 3) % 2 == 0
    }

    /**
     * 掩码罚分(ISO 18004 表 11,segno 同构;评估态边界见 §1.3-6):
     * N1=行/列同色连 5+(run-2)/N2=2×2 同色块(3/块)/N3=1:1:3:1:1 侦察段(40/次,
     * 越界切片=全亮通过;命中计分后 idx+7 推进,未计分 idx+4)/N4=浮点百分比(禁整数化)。
     */
    private fun penalty(mat: Array<BooleanArray>): Int {
        val n = mat.size
        var p = 0
        // N1 行
        for (row in mat) {
            var run = 1
            for (i in 1 until n) {
                if (row[i] == row[i - 1]) run++ else {
                    if (run >= 5) p += run - 2
                    run = 1
                }
            }
            if (run >= 5) p += run - 2
        }
        // N1 列
        for (c in 0 until n) {
            var run = 1
            for (i in 1 until n) {
                if (mat[i][c] == mat[i - 1][c]) run++ else {
                    if (run >= 5) p += run - 2
                    run = 1
                }
            }
            if (run >= 5) p += run - 2
        }
        // N2
        for (r in 0 until n - 1) for (c in 0 until n - 1) {
            if (mat[r][c] == mat[r][c + 1] && mat[r][c] == mat[r + 1][c] &&
                mat[r][c] == mat[r + 1][c + 1]) p += 3
        }
        // N3:dark-light-dark-dark-dark-light-dark,前 4 或后 4 全亮即计分
        for (r in 0 until n) p += scanN3(mat[r])
        for (c in 0 until n) {
            val col = BooleanArray(n) { mat[it][c] }
            p += scanN3(col)
        }
        // N4:暗比例罚分——浮点百分比口径(percent*100 浮点,禁整数化)
        val dark = mat.sumOf { row -> row.count { it } }
        val percent = dark.toDouble() / (n * n)
        p += 10 * (kotlin.math.abs(percent * 100 - 50) / 5).toInt()
        return p
    }

    private val n3Pattern = booleanArrayOf(true, false, true, true, true, false, true)

    private fun matchesPattern(line: BooleanArray, i: Int): Boolean {
        for (k in 0 until 7) if (line[i + k] != n3Pattern[k]) return false
        return true
    }

    private fun scanN3(line: BooleanArray): Int {
        val n = line.size
        fun findFrom(start: Int): Int {
            var i = start
            while (i <= n - 7) {
                if (matchesPattern(line, i)) return i
                i++
            }
            return -1
        }
        var pp = 0
        var idx = findFrom(0)
        while (idx >= 0) {
            val off = idx + 7
            val beforeAllLight = runAllLight(line, maxOf(idx - 4, 0), idx)
            val afterAllLight = runAllLight(line, off, minOf(off + 4, n))
            if (idx == 0 || idx == n - 7 || beforeAllLight || afterAllLight) {
                pp += 40
                idx = findFrom(idx + 7)
            } else {
                idx = findFrom(idx + 4)
            }
        }
        return pp
    }

    /** [from, until) 全亮(空区间视同全亮,越界切片=通过)。 */
    private fun runAllLight(line: BooleanArray, from: Int, until: Int): Boolean {
        for (i in from until until) if (line[i]) return false
        return true
    }
}
