package io.eazo.a140e3a4.core

import io.eazo.a140e3a4.model.ECLevel

/**
 * ISO/IEC 18004 常量数据面(RS 块结构 / EC 每块码字 / 总码字 / 对位图案中心)。
 *
 * 由 scripts/gen_qr_contract_artifacts.py 从契约钦定参考实现 segno 1.6.6 本体
 * (segno.consts.ECC / ALIGNMENT_POS)机械提取生成,并经 40×4 结构自检
 * (dataCw+ec==totalCodewords)与 sa_req019_design_verify.py v1..16 位级实证区
 * 逐行全等交叉核验——禁手改,重跑生成器应零 diff。
 */
internal object QrTables {

    /** v1..v40 每版本总码字数(数据码字 + EC 码字)。 */
    val totalCodewords = intArrayOf(
        26, 44, 70, 100, 134, 172, 196, 242, 292, 346, 404, 466, 532, 581, 655, 733, 815, 901, 991, 1085, 1156, 1258, 1364, 1474, 1588, 1706, 1828, 1921, 2051, 2185, 2323, 2465, 2611, 2761, 2876, 3034, 3196, 3362, 3532, 3706,
    )

    /** 每 EC 每版本「单块 EC 码字数」。 */
    val ecPerBlock: Map<ECLevel, IntArray> = mapOf(
        ECLevel.L to intArrayOf(
            7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30,
        ),
        ECLevel.M to intArrayOf(
            10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28,
        ),
        ECLevel.Q to intArrayOf(
            13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30,
        ),
        ECLevel.H to intArrayOf(
            17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30,
        ),
    )

    /** 每版本每 EC 的 RS 块结构:(块数, 每块数据码字数);异构块组(如 v9@M 3×36+2×37)须游标切块。 */
    val rsBlocks: Array<Map<ECLevel, List<Pair<Int, Int>>>> = arrayOf(
        mapOf(ECLevel.L to listOf(1 to 19), ECLevel.M to listOf(1 to 16), ECLevel.Q to listOf(1 to 13), ECLevel.H to listOf(1 to 9)), // v1
        mapOf(ECLevel.L to listOf(1 to 34), ECLevel.M to listOf(1 to 28), ECLevel.Q to listOf(1 to 22), ECLevel.H to listOf(1 to 16)), // v2
        mapOf(ECLevel.L to listOf(1 to 55), ECLevel.M to listOf(1 to 44), ECLevel.Q to listOf(2 to 17), ECLevel.H to listOf(2 to 13)), // v3
        mapOf(ECLevel.L to listOf(1 to 80), ECLevel.M to listOf(2 to 32), ECLevel.Q to listOf(2 to 24), ECLevel.H to listOf(4 to 9)), // v4
        mapOf(ECLevel.L to listOf(1 to 108), ECLevel.M to listOf(2 to 43), ECLevel.Q to listOf(2 to 15, 2 to 16), ECLevel.H to listOf(2 to 11, 2 to 12)), // v5
        mapOf(ECLevel.L to listOf(2 to 68), ECLevel.M to listOf(4 to 27), ECLevel.Q to listOf(4 to 19), ECLevel.H to listOf(4 to 15)), // v6
        mapOf(ECLevel.L to listOf(2 to 78), ECLevel.M to listOf(4 to 31), ECLevel.Q to listOf(2 to 14, 4 to 15), ECLevel.H to listOf(4 to 13, 1 to 14)), // v7
        mapOf(ECLevel.L to listOf(2 to 97), ECLevel.M to listOf(2 to 38, 2 to 39), ECLevel.Q to listOf(4 to 18, 2 to 19), ECLevel.H to listOf(4 to 14, 2 to 15)), // v8
        mapOf(ECLevel.L to listOf(2 to 116), ECLevel.M to listOf(3 to 36, 2 to 37), ECLevel.Q to listOf(4 to 16, 4 to 17), ECLevel.H to listOf(4 to 12, 4 to 13)), // v9
        mapOf(ECLevel.L to listOf(2 to 68, 2 to 69), ECLevel.M to listOf(4 to 43, 1 to 44), ECLevel.Q to listOf(6 to 19, 2 to 20), ECLevel.H to listOf(6 to 15, 2 to 16)), // v10
        mapOf(ECLevel.L to listOf(4 to 81), ECLevel.M to listOf(1 to 50, 4 to 51), ECLevel.Q to listOf(4 to 22, 4 to 23), ECLevel.H to listOf(3 to 12, 8 to 13)), // v11
        mapOf(ECLevel.L to listOf(2 to 92, 2 to 93), ECLevel.M to listOf(6 to 36, 2 to 37), ECLevel.Q to listOf(4 to 20, 6 to 21), ECLevel.H to listOf(7 to 14, 4 to 15)), // v12
        mapOf(ECLevel.L to listOf(4 to 107), ECLevel.M to listOf(8 to 37, 1 to 38), ECLevel.Q to listOf(8 to 20, 4 to 21), ECLevel.H to listOf(12 to 11, 4 to 12)), // v13
        mapOf(ECLevel.L to listOf(3 to 115, 1 to 116), ECLevel.M to listOf(4 to 40, 5 to 41), ECLevel.Q to listOf(11 to 16, 5 to 17), ECLevel.H to listOf(11 to 12, 5 to 13)), // v14
        mapOf(ECLevel.L to listOf(5 to 87, 1 to 88), ECLevel.M to listOf(5 to 41, 5 to 42), ECLevel.Q to listOf(5 to 24, 7 to 25), ECLevel.H to listOf(11 to 12, 7 to 13)), // v15
        mapOf(ECLevel.L to listOf(5 to 98, 1 to 99), ECLevel.M to listOf(7 to 45, 3 to 46), ECLevel.Q to listOf(15 to 19, 2 to 20), ECLevel.H to listOf(3 to 15, 13 to 16)), // v16
        mapOf(ECLevel.L to listOf(1 to 107, 5 to 108), ECLevel.M to listOf(10 to 46, 1 to 47), ECLevel.Q to listOf(1 to 22, 15 to 23), ECLevel.H to listOf(2 to 14, 17 to 15)), // v17
        mapOf(ECLevel.L to listOf(5 to 120, 1 to 121), ECLevel.M to listOf(9 to 43, 4 to 44), ECLevel.Q to listOf(17 to 22, 1 to 23), ECLevel.H to listOf(2 to 14, 19 to 15)), // v18
        mapOf(ECLevel.L to listOf(3 to 113, 4 to 114), ECLevel.M to listOf(3 to 44, 11 to 45), ECLevel.Q to listOf(17 to 21, 4 to 22), ECLevel.H to listOf(9 to 13, 16 to 14)), // v19
        mapOf(ECLevel.L to listOf(3 to 107, 5 to 108), ECLevel.M to listOf(3 to 41, 13 to 42), ECLevel.Q to listOf(15 to 24, 5 to 25), ECLevel.H to listOf(15 to 15, 10 to 16)), // v20
        mapOf(ECLevel.L to listOf(4 to 116, 4 to 117), ECLevel.M to listOf(17 to 42), ECLevel.Q to listOf(17 to 22, 6 to 23), ECLevel.H to listOf(19 to 16, 6 to 17)), // v21
        mapOf(ECLevel.L to listOf(2 to 111, 7 to 112), ECLevel.M to listOf(17 to 46), ECLevel.Q to listOf(7 to 24, 16 to 25), ECLevel.H to listOf(34 to 13)), // v22
        mapOf(ECLevel.L to listOf(4 to 121, 5 to 122), ECLevel.M to listOf(4 to 47, 14 to 48), ECLevel.Q to listOf(11 to 24, 14 to 25), ECLevel.H to listOf(16 to 15, 14 to 16)), // v23
        mapOf(ECLevel.L to listOf(6 to 117, 4 to 118), ECLevel.M to listOf(6 to 45, 14 to 46), ECLevel.Q to listOf(11 to 24, 16 to 25), ECLevel.H to listOf(30 to 16, 2 to 17)), // v24
        mapOf(ECLevel.L to listOf(8 to 106, 4 to 107), ECLevel.M to listOf(8 to 47, 13 to 48), ECLevel.Q to listOf(7 to 24, 22 to 25), ECLevel.H to listOf(22 to 15, 13 to 16)), // v25
        mapOf(ECLevel.L to listOf(10 to 114, 2 to 115), ECLevel.M to listOf(19 to 46, 4 to 47), ECLevel.Q to listOf(28 to 22, 6 to 23), ECLevel.H to listOf(33 to 16, 4 to 17)), // v26
        mapOf(ECLevel.L to listOf(8 to 122, 4 to 123), ECLevel.M to listOf(22 to 45, 3 to 46), ECLevel.Q to listOf(8 to 23, 26 to 24), ECLevel.H to listOf(12 to 15, 28 to 16)), // v27
        mapOf(ECLevel.L to listOf(3 to 117, 10 to 118), ECLevel.M to listOf(3 to 45, 23 to 46), ECLevel.Q to listOf(4 to 24, 31 to 25), ECLevel.H to listOf(11 to 15, 31 to 16)), // v28
        mapOf(ECLevel.L to listOf(7 to 116, 7 to 117), ECLevel.M to listOf(21 to 45, 7 to 46), ECLevel.Q to listOf(1 to 23, 37 to 24), ECLevel.H to listOf(19 to 15, 26 to 16)), // v29
        mapOf(ECLevel.L to listOf(5 to 115, 10 to 116), ECLevel.M to listOf(19 to 47, 10 to 48), ECLevel.Q to listOf(15 to 24, 25 to 25), ECLevel.H to listOf(23 to 15, 25 to 16)), // v30
        mapOf(ECLevel.L to listOf(13 to 115, 3 to 116), ECLevel.M to listOf(2 to 46, 29 to 47), ECLevel.Q to listOf(42 to 24, 1 to 25), ECLevel.H to listOf(23 to 15, 28 to 16)), // v31
        mapOf(ECLevel.L to listOf(17 to 115), ECLevel.M to listOf(10 to 46, 23 to 47), ECLevel.Q to listOf(10 to 24, 35 to 25), ECLevel.H to listOf(19 to 15, 35 to 16)), // v32
        mapOf(ECLevel.L to listOf(17 to 115, 1 to 116), ECLevel.M to listOf(14 to 46, 21 to 47), ECLevel.Q to listOf(29 to 24, 19 to 25), ECLevel.H to listOf(11 to 15, 46 to 16)), // v33
        mapOf(ECLevel.L to listOf(13 to 115, 6 to 116), ECLevel.M to listOf(14 to 46, 23 to 47), ECLevel.Q to listOf(44 to 24, 7 to 25), ECLevel.H to listOf(59 to 16, 1 to 17)), // v34
        mapOf(ECLevel.L to listOf(12 to 121, 7 to 122), ECLevel.M to listOf(12 to 47, 26 to 48), ECLevel.Q to listOf(39 to 24, 14 to 25), ECLevel.H to listOf(22 to 15, 41 to 16)), // v35
        mapOf(ECLevel.L to listOf(6 to 121, 14 to 122), ECLevel.M to listOf(6 to 47, 34 to 48), ECLevel.Q to listOf(46 to 24, 10 to 25), ECLevel.H to listOf(2 to 15, 64 to 16)), // v36
        mapOf(ECLevel.L to listOf(17 to 122, 4 to 123), ECLevel.M to listOf(29 to 46, 14 to 47), ECLevel.Q to listOf(49 to 24, 10 to 25), ECLevel.H to listOf(24 to 15, 46 to 16)), // v37
        mapOf(ECLevel.L to listOf(4 to 122, 18 to 123), ECLevel.M to listOf(13 to 46, 32 to 47), ECLevel.Q to listOf(48 to 24, 14 to 25), ECLevel.H to listOf(42 to 15, 32 to 16)), // v38
        mapOf(ECLevel.L to listOf(20 to 117, 4 to 118), ECLevel.M to listOf(40 to 47, 7 to 48), ECLevel.Q to listOf(43 to 24, 22 to 25), ECLevel.H to listOf(10 to 15, 67 to 16)), // v39
        mapOf(ECLevel.L to listOf(19 to 118, 6 to 119), ECLevel.M to listOf(18 to 47, 31 to 48), ECLevel.Q to listOf(34 to 24, 34 to 25), ECLevel.H to listOf(20 to 15, 61 to 16)), // v40
    )

    /** 对位图案中心坐标(笛卡尔积铺 5×5;v1 无对位图案)。 */
    val alignmentCenters: Array<IntArray> = arrayOf(
        intArrayOf(), // v1
        intArrayOf(6, 18), // v2
        intArrayOf(6, 22), // v3
        intArrayOf(6, 26), // v4
        intArrayOf(6, 30), // v5
        intArrayOf(6, 34), // v6
        intArrayOf(6, 22, 38), // v7
        intArrayOf(6, 24, 42), // v8
        intArrayOf(6, 26, 46), // v9
        intArrayOf(6, 28, 50), // v10
        intArrayOf(6, 30, 54), // v11
        intArrayOf(6, 32, 58), // v12
        intArrayOf(6, 34, 62), // v13
        intArrayOf(6, 26, 46, 66), // v14
        intArrayOf(6, 26, 48, 70), // v15
        intArrayOf(6, 26, 50, 74), // v16
        intArrayOf(6, 30, 54, 78), // v17
        intArrayOf(6, 30, 56, 82), // v18
        intArrayOf(6, 30, 58, 86), // v19
        intArrayOf(6, 34, 62, 90), // v20
        intArrayOf(6, 28, 50, 72, 94), // v21
        intArrayOf(6, 26, 50, 74, 98), // v22
        intArrayOf(6, 30, 54, 78, 102), // v23
        intArrayOf(6, 28, 54, 80, 106), // v24
        intArrayOf(6, 32, 58, 84, 110), // v25
        intArrayOf(6, 30, 58, 86, 114), // v26
        intArrayOf(6, 34, 62, 90, 118), // v27
        intArrayOf(6, 26, 50, 74, 98, 122), // v28
        intArrayOf(6, 30, 54, 78, 102, 126), // v29
        intArrayOf(6, 26, 52, 78, 104, 130), // v30
        intArrayOf(6, 30, 56, 82, 108, 134), // v31
        intArrayOf(6, 34, 60, 86, 112, 138), // v32
        intArrayOf(6, 30, 58, 86, 114, 142), // v33
        intArrayOf(6, 34, 62, 90, 118, 146), // v34
        intArrayOf(6, 30, 54, 78, 102, 126, 150), // v35
        intArrayOf(6, 24, 50, 76, 102, 128, 154), // v36
        intArrayOf(6, 28, 54, 80, 106, 132, 158), // v37
        intArrayOf(6, 32, 58, 84, 110, 136, 162), // v38
        intArrayOf(6, 26, 54, 82, 110, 138, 166), // v39
        intArrayOf(6, 30, 58, 86, 114, 142, 170), // v40
    )
}
