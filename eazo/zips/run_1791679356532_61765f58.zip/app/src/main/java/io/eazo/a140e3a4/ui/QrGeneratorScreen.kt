package io.eazo.a140e3a4.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import io.eazo.a140e3a4.core.QrRules
import io.eazo.a140e3a4.model.ECLevel
import io.eazo.a140e3a4.model.Size
import io.eazo.a140e3a4.platform.AppRepo

/**
 * 二维码生成器单页(契约 §3:输入框 + 尺寸/纠错控制 + Canvas 逐格绘制预览,
 * 三区清晰分区)。输入有效即实时出码;「生成」确认走 AppRepo.generate()。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrGeneratorScreen() {
    val repo = AppRepo.getRepo(LocalContext.current)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Header()
        InputCard(repo)
        ControlCard(repo)
        Button(
            onClick = { repo.generate() },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(),
        ) {
            Text(text = "生成二维码", style = MaterialTheme.typography.titleMedium)
        }
        PreviewCard(repo)
        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
private fun Header() {
    Column {
        Text(
            text = "二维码生成器",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "输入文本或链接,实时生成二维码;尺寸与纠错级别即时可调",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.outline,
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold,
    )
}

@Composable
private fun InputCard(repo: AppRepo) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionLabel("输入")
            OutlinedTextField(
                value = repo.input,
                onValueChange = repo::updateInput,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("文本或链接") },
                placeholder = { Text("请输入文本或链接") },
                minLines = 2,
                isError = repo.error != null,
                supportingText = {
                    repo.error?.let {
                        Text(text = it, color = MaterialTheme.colorScheme.error)
                    }
                },
                shape = RoundedCornerShape(12.dp),
            )
        }
    }
}

@Composable
private fun ControlCard(repo: AppRepo) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionLabel("尺寸")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Size.values().forEach { s ->
                        FilterChip(
                            selected = repo.size == s,
                            onClick = { repo.selectSize(s) },
                            label = { Text("${sizeLabel(s)} · ${QrRules.sizeToEdgePx(s)}") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            ),
                        )
                    }
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionLabel("纠错级别")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ECLevel.values().forEach { ec ->
                        FilterChip(
                            selected = repo.ecLevel == ec,
                            onClick = { repo.selectEc(ec) },
                            label = { Text("${ec.name} ${ec.recovery}") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onSecondaryContainer,
                            ),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PreviewCard(repo: AppRepo) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            SectionLabel("预览")
            val result = repo.result
            if (result == null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .border(
                            width = 1.dp,
                            color = MaterialTheme.colorScheme.outlineVariant,
                            shape = RoundedCornerShape(12.dp),
                        )
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = if (repo.error != null) "生成失败,请检查输入" else "输入内容后将实时生成二维码预览",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.outline,
                    )
                }
            } else {
                QrPreview(matrix = result.matrix, edgeDp = QrRules.sizeToEdgePx(repo.size))
                Text(
                    text = "v${result.meta.version} · ${result.meta.modules}×${result.meta.modules}" +
                        " · 掩码 ${result.meta.mask} · ${result.meta.mode}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.outline,
                )
                Text(
                    text = "预览边长 ${QrRules.sizeToEdgePx(repo.size)}vp · 纠错 ${repo.ecLevel.name}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.outline,
                )
            }
        }
    }
}

/** Canvas 逐格绘制矩阵(契约 §3:渲染层只做位图绘制,不做编码)。 */
@Composable
private fun QrPreview(matrix: Array<BooleanArray>, edgeDp: Int) {
    Box(
        modifier = Modifier
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outlineVariant,
                shape = RoundedCornerShape(12.dp),
            )
            .padding(8.dp),
    ) {
        Canvas(modifier = Modifier.size(edgeDp.dp)) {
            val n = matrix.size
            val quiet = 4 // 静区 4 模块(可扫性)
            val cell = size.width / (n + quiet * 2)
            drawRect(color = Color.White, size = size)
            for (r in 0 until n) {
                for (c in 0 until n) {
                    if (matrix[r][c]) {
                        drawRect(
                            color = Color(0xFF111827),
                            topLeft = Offset((c + quiet) * cell, (r + quiet) * cell),
                            size = androidx.compose.ui.geometry.Size(cell + 0.5f, cell + 0.5f),
                        )
                    }
                }
            }
        }
    }
}

private fun sizeLabel(size: Size): String = when (size) {
    Size.S -> "小"
    Size.M -> "中"
    Size.L -> "大"
}
