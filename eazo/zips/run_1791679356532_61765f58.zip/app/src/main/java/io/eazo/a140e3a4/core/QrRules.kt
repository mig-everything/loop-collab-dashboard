package io.eazo.a140e3a4.core

import io.eazo.a140e3a4.model.ECLevel
import io.eazo.a140e3a4.model.MAX_INPUT_LENGTH
import io.eazo.a140e3a4.model.Size

/**
 * 规则纯函数族(契约 §2.2~§2.4 + §4 序列化):与鸿蒙端 QrRules 逐条同构。
 * 零 IO/网络/随机/时钟/UI API——确定性核心,JUnit 直接单测。
 */
object QrRules {

    /**
     * 输入规范化(契约 §2.4):trim 首尾空白;空/纯空白 → null(拒绝);
     * 超 MAX_INPUT_LENGTH(UTF-16 code unit 口径)截取前 512——
     * Kotlin String.length/substring 与 ArkTS string.length/substring 天然 UTF-16,零分叉。
     */
    fun normalizeInput(raw: String): String? {
        val t = raw.trim()
        if (t.isEmpty()) return null
        return if (t.length > MAX_INPUT_LENGTH) t.substring(0, MAX_INPUT_LENGTH) else t
    }

    /** 纠错级别 → 格式信息 2-bit(契约 §2.2:M=0b00 / L=0b01 / H=0b10 / Q=0b11)。 */
    fun ecLevelToBits(ec: ECLevel): Int = when (ec) {
        ECLevel.M -> 0b00
        ECLevel.L -> 0b01
        ECLevel.H -> 0b10
        ECLevel.Q -> 0b11
    }

    /** 尺寸档 → 渲染边长 vp(契约 §2.3:S=128 / M=200 / L=280;纯展示态,不影响矩阵)。 */
    fun sizeToEdgePx(size: Size): Int = when (size) {
        Size.S -> 128
        Size.M -> 200
        Size.L -> 280
    }

    /** 规范序列化(契约 §4):row-major 逐位暗'1'/亮'0',无分隔符无换行(哈希口径)。 */
    fun serialize(matrix: Array<BooleanArray>): String {
        val sb = StringBuilder(matrix.size * matrix.size)
        for (row in matrix) for (cell in row) sb.append(if (cell) '1' else '0')
        return sb.toString()
    }
}
