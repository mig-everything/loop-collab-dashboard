package io.eazo.counter.model

import io.eazo.counter.core.CounterLogic

/**
 * 极简点击计数器 · 数据模型（req_1791015255622，双端 1:1，生成器硬规则 ③）。
 * 单标量状态：count（≥0 整数）；无枚举、无列表排序（规则 ③ 在本 REQ 退化为
 * 字段名/默认值/校验规则双端对齐——与鸿蒙 model/Models.ets 同字段名 "count"）。
 * 不变量：count 为整数且 ≥ 0；非法值（负数/非整数/NaN/缺失）一律归零，不崩溃。
 */

/** 计数器状态（持久化 JSON：{"count":N}，与鸿蒙 CounterState 1:1）。 */
data class CounterState(
    val count: Int = 0   // ≥0 整数；初始 0
) {
    /** DTO 序列化（落盘/差分测试共用口径；键 "count" 双端一致）。 */
    fun toDto(): Map<String, Any> = mapOf("count" to count)

    companion object {
        fun initial(): CounterState = CounterState(0)

        /** DTO 反序列化：非法 count 归零（镜像鸿蒙 CounterState.fromDto）。 */
        fun fromDto(dto: Map<String, Any?>): CounterState =
            CounterState(CounterLogic.normalize(dto["count"]))
    }
}
