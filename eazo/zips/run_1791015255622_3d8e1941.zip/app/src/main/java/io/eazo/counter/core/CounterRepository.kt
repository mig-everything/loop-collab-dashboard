package io.eazo.counter.core

import io.eazo.counter.model.CounterState

/**
 * 计数器仓储（与鸿蒙 core/CounterRepository.ets 1:1）。
 *
 * ★ 生成器硬规则 ①：进程内单例——经 platform/AppRepo.getRepo(context) 获取；
 *   页面/卡片层禁止 new CounterRepository(...)，该构造仅出现在 AppRepo 内部
 *   与测试注入豁免面。
 * ★ 生成器硬规则 ②：写即落盘（写穿 store）；读一律走内存态 read()——
 *   onResume/onPageShow 只 read() 刷新，禁止再 load() 持久化
 *   （load 仅构造期 reload() 执行一次，此后内存态为真相源）。
 */

/** 持久化端口（platform/PreferencesStore 实现；测试可注入内存实现）。 */
interface CounterStore {
    fun load(): CounterState
    fun save(state: CounterState)
}

class CounterRepository(private val store: CounterStore) {

    private var state: CounterState = CounterState.initial()   // 构造期 reload() 覆盖为读档值

    init {
        reload()   // 读档仅此一次（冷启动）；此后内存态为真相源
    }

    /** 读档：损坏数据由 CounterJson/CounterLogic.normalize 归零兜底。 */
    fun reload() {
        state = store.load()
    }

    /** 内存态读取（页面 refresh 面，规则 ②）。 */
    fun read(): CounterState = state

    /** +1（US-1）：更新内存态 → 写穿落盘 → 返回新状态。 */
    fun increment(): CounterState {
        state = CounterState(CounterLogic.increment(state.count))
        store.save(state)
        return state
    }

    /** 清零（US-2）：回到 0 → 写穿落盘 → 返回新状态。 */
    fun reset(): CounterState {
        state = CounterState(CounterLogic.reset())
        store.save(state)
        return state
    }
}
