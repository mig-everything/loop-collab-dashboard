package io.eazo.counter.ui

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.counter.R
import io.eazo.counter.core.CounterLogic
import io.eazo.counter.platform.AppRepo

/**
 * 极简点击计数器主界面（US-1/US-2）：页面中央大数字 + 「+1」/「清零」
 * （镜像鸿蒙 pages/Index.ets：96fp Bold #1A1A1A、#1976D2/#ECEFF1 按钮、40/16 间距）。
 *
 * ★ 生成器硬规则 ④（两路竞态）：冷启动 onCreate(intent) 与热启动 onNewIntent(intent)
 *   （鸿蒙 onCreate(want)/onNewWant(want)）都只从【当前 intent】读取原始参数值，
 *   同走纯函数 readOpenCreate（严格布尔判定）；launchMode=singleTask 保证重入拉起
 *   走 onNewIntent 热启动路径；不依赖上一次生命周期残留成员变量（竞态防护）。
 * ★ 生成器硬规则 ②：onResume 只 refresh()（重读单例内存态 read()），绝不触持久化 load。
 * ★ 生成器硬规则 ①：仓储一律 AppRepo.getRepo(this)，全类 0 处 new CounterRepository。
 */
class MainActivity : ComponentActivity() {

    private var count by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ★ 冷启动路径：与 onNewIntent 同走 readOpenCreate 纯函数（规则 ④）
        Log.i(TAG, "Ability onCreate openCreate=" + readOpenCreate(intent))
        setContent { CounterScreen() }
    }

    override fun onNewIntent(intent: Intent) {   // ★ 热启动路径（singleTask 重入）
        super.onNewIntent(intent)
        setIntent(intent)
        Log.i(TAG, "Ability onNewWant openCreate=" + readOpenCreate(intent))
    }

    override fun onResume() {
        super.onResume()
        refresh()                                 // ★ 规则②：仅重读单例内存态
    }

    /** refresh 出口（规则②）：单例内存读 read()，无任何持久化 load。 */
    private fun refresh() {
        count = AppRepo.getRepo(this).read().count
    }

    /** +1（US-1）：仓储写穿落盘 → 刷新展示。 */
    private fun onIncrement() {
        AppRepo.getRepo(this).increment()
        refresh()
    }

    /** 清零（US-2）。 */
    private fun onReset() {
        AppRepo.getRepo(this).reset()
        refresh()
    }

    @Composable
    fun CounterScreen() {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFFAFAFA)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // 页面中央大数字（US-1 展示面）
            Text(
                count.toString(),
                fontSize = 96.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1A1A1A),
                maxLines = 1
            )
            Spacer(Modifier.height(40.dp))       // 鸿蒙 Column space 40
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(
                    onClick = { onIncrement() },
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1976D2),
                        contentColor = Color(0xFFFFFFFF)
                    ),
                    contentPadding = PaddingValues(horizontal = 32.dp, vertical = 12.dp)
                ) {
                    Text(getString(R.string.button_plus), fontSize = 18.sp, fontWeight = FontWeight.Medium)
                }
                Button(
                    onClick = { onReset() },
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFECEFF1),
                        contentColor = Color(0xFF455A64)
                    ),
                    contentPadding = PaddingValues(horizontal = 32.dp, vertical = 12.dp)
                ) {
                    Text(getString(R.string.button_reset), fontSize = 18.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }

    companion object {
        private const val TAG = "EntryAbility"
        private const val OPEN_PARAM_OPEN_CREATE = "openCreate"   // 鸿蒙 want 参数名同字面量（规则 ③/④）

        /** ★ 规则 ④ 纯函数（镜像鸿蒙 EntryAbility.readOpenCreate(want)）：
         *  null intent / 无 extras / 参数缺失均判假；严格判定核心在 CounterLogic.readOpenCreate。 */
        fun readOpenCreate(intent: Intent?): Boolean =
            CounterLogic.readOpenCreate(intent?.extras?.get(OPEN_PARAM_OPEN_CREATE))
    }
}
