package io.eazo.counter.platform

import android.content.Context
import android.content.SharedPreferences
import io.eazo.counter.core.CounterJson
import io.eazo.counter.core.CounterRepository
import io.eazo.counter.core.CounterStore
import io.eazo.counter.model.CounterState

/**
 * SharedPreferences 持久化（与鸿蒙 PreferencesStore 1:1，存储键/值形态双端一致，
 * 生成器硬规则 ③）：prefs 文件 "counter"，键 "counter_state"，值 JSON 字符串 {"count":N}。
 * 损坏数据（读取异常/解析失败/字段非法）归零兜底，不崩溃。
 */
class PreferencesStore(context: Context) : CounterStore {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    override fun load(): CounterState = try {
        CounterJson.deserialize(prefs.getString(KEY, DEFAULT_JSON) ?: DEFAULT_JSON)
    } catch (e: Exception) {
        CounterState.initial()   // 损坏数据不崩溃，归零
    }

    override fun save(state: CounterState) {
        prefs.edit().putString(KEY, CounterJson.serialize(state)).apply()
    }

    companion object {
        private const val PREF_NAME = "counter"           // 鸿蒙 preferences 文件名同值
        private const val KEY = "counter_state"           // 鸿蒙键同字面量
        private const val DEFAULT_JSON = "{\"count\":0}"  // 鸿蒙 DEFAULT_JSON 同值
    }
}

/**
 * ★ 进程内单例仓储入口（生成器硬规则 ①）：UI 与卡片层禁止 CounterRepository(...) 直构，
 * 一律 AppRepo.getRepo(context)。@Volatile 双检锁——全进程共享同一内存态，
 * 是「写后即时可见」（规则 ②）的前提。getOrCreate 为唯一创建点（单例性经注入槽单测验证）。
 */
object AppRepo {
    @Volatile
    private var repo: CounterRepository? = null

    internal fun getOrCreate(create: () -> CounterRepository): CounterRepository =
        repo ?: synchronized(this) {
            repo ?: create().also { repo = it }
        }

    fun getRepo(context: Context): CounterRepository =
        getOrCreate { CounterRepository(PreferencesStore(context.applicationContext)) }
}
