package io.eazo.counter.core

import kotlin.math.floor

/**
 * 计数纯函数（与鸿蒙 core/CounterLogic.ets 同款 1:1，差分测试对账面；生成器硬规则 ③）。
 * 全部为确定性纯函数：无 IO、无时钟、无 random，相同输入相同输出，对任意输入不抛异常。
 * 域适配：鸿蒙 number（f64）域在 Android 侧收敛为 Int 域；判定/归一化在 Any?
 * （数值宽域）上进行，语义与 typeof v === 'number' && Number.isInteger(v) && v >= 0
 * 逐条等价（NaN/±∞/负数/小数/非数值均非法）。
 */
object CounterLogic {

    /** 合法计数判定：数值、整数、≥0 三者同时成立（镜像鸿蒙 isValidCount）。 */
    fun isValidCount(v: Any?): Boolean {
        if (v !is Number) return false                            // typeof v === 'number'
        val d = v.toDouble()
        return !d.isNaN() && !d.isInfinite() && d == floor(d) && d >= 0.0   // Number.isInteger(v) && v >= 0
    }

    /** 归一化：非法入参（含缺失 null）一律归 0，保证读档损坏数据不崩溃。 */
    fun normalize(raw: Any?): Int = if (isValidCount(raw)) (raw as Number).toInt() else 0

    /** +1（US-1）：入参先归一化，恒返回 count+1 且 ≥ 1。 */
    fun increment(count: Int): Int = normalize(count) + 1

    /** 清零（US-2）：恒返回 0。 */
    fun reset(): Int = 0

    /** ★ 生成器硬规则 ④（onNewWant 热启动两路竞态）：want/intent 布尔参数严格判定——
     *  仅 Boolean true 判真；'true'/'1'/'True'/数字 1/null 全拒
     *  （typeof v === 'boolean' && v === true 口径的 Kotlin 等价式）。 */
    fun readOpenCreate(rawOpenCreate: Any?): Boolean =
        rawOpenCreate is Boolean && rawOpenCreate == true
}
