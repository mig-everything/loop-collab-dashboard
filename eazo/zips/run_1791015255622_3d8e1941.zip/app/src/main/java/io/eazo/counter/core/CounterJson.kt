package io.eazo.counter.core

import io.eazo.counter.model.CounterState

/**
 * {"count":N} 最小编解码（落盘/差分测试共用口径，与鸿蒙侧 JSON.parse/JSON.stringify
 * 作用于 CounterState.toDto()/fromDto() 的用法逐语义对齐，生成器硬规则 ③）。
 * 自实现而非 org.json：JVM 单测（testDebugUnitTest）无 Android 框架，org.json 桩
 * 不可执行；本实现纯 Kotlin、确定性、对任意输入不抛异常。
 * 契约：serialize 恒产出 '{"count":N}' 紧凑整数形（与鸿蒙 JSON.stringify 同形）；
 * deserialize 解析失败/字段非法 → initial()（损坏归零兜底）。
 */
object CounterJson {

    private val FORM: Regex =
        Regex("""^\s*\{\s*"count"\s*:\s*(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)\s*\}\s*$""")

    fun serialize(state: CounterState): String = "{\"count\":${state.count}}"

    fun deserialize(json: String): CounterState {
        val raw: Double? = FORM.find(json)?.groupValues?.get(1)?.toDoubleOrNull()
        // 未命中（损坏形）→ 空DTO → 归零；命中则经 fromDto/normalize 再校验（2.5/-2 → 0）
        return CounterState.fromDto(if (raw == null) emptyMap() else mapOf("count" to raw))
    }
}
