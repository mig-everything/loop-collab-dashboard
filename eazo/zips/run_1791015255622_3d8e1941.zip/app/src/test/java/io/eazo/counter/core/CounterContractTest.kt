package io.eazo.counter.core

import io.eazo.counter.model.CounterState
import io.eazo.counter.platform.AppRepo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 极简点击计数器 契约单测（Android 侧 JUnit；与鸿蒙 CounterContract.test.ets 同集断言，
 * 生成器硬规则 ③——用例编号/语义逐条镜像 #1..#17）。
 * 覆盖：①纯函数（increment/reset/normalize/isValidCount）②状态 DTO（round-trip/非法归零）
 * ③仓储（新档为 0/连击/清零/写穿透/读档恢复/损坏兜底）④规则 4 严格布尔 readOpenCreate
 * ⑤规则 1 AppRepo 单例。注：测试内 new CounterRepository(内存Store) 为注入豁免面（UI 层仍禁 new）。
 */
class CounterContractTest {

    /** 内存假 Store（镜像鸿蒙 MemoryStore 口径：JSON 字符串中转，损坏归零）。 */
    private class MemoryStore : CounterStore {
        var json: String = "{\"count\":0}"
        override fun load(): CounterState = CounterJson.deserialize(json)
        override fun save(state: CounterState) { json = CounterJson.serialize(state) }
    }

    // ---------- 纯函数 ----------

    @Test fun `1_logic_increment_from0`() {
        assertEquals(1, CounterLogic.increment(0))
    }

    @Test fun `2_logic_increment_from5`() {
        assertEquals(6, CounterLogic.increment(5))
    }

    @Test fun `3_logic_increment_invalid_normalized_to1`() {
        assertEquals(1, CounterLogic.increment(-3))
        assertEquals(0, CounterLogic.normalize(Double.NaN))   // NaN 归 0（镜像鸿蒙 number 域）
        assertEquals(1, CounterLogic.increment(CounterLogic.normalize(Double.NaN)))
    }

    @Test fun `4_logic_reset_zero`() {
        assertEquals(0, CounterLogic.reset())
    }

    @Test fun `5_logic_normalize_and_valid`() {
        assertEquals(7, CounterLogic.normalize(7))
        assertEquals(0, CounterLogic.normalize(-1))
        assertEquals(0, CounterLogic.normalize(1.5))
        assertEquals(0, CounterLogic.normalize(Double.NaN))
        assertTrue(CounterLogic.isValidCount(0))
        assertTrue(CounterLogic.isValidCount(2026))
        assertFalse(CounterLogic.isValidCount(-1))
        assertFalse(CounterLogic.isValidCount(1.5))
        assertFalse(CounterLogic.isValidCount(Double.NaN))
    }

    // ---------- 状态 DTO ----------

    @Test fun `6_state_initial_zero`() {
        assertEquals(0, CounterState.initial().count)
    }

    @Test fun `7_state_dto_roundtrip`() {
        val s = CounterState(42)
        assertEquals(42, s.toDto()["count"])
        assertEquals(42, CounterState.fromDto(s.toDto()).count)
    }

    @Test fun `8_state_fromDto_invalid_to_zero`() {
        assertEquals(0, CounterState.fromDto(mapOf("count" to -2)).count)
        assertEquals(0, CounterState.fromDto(mapOf("count" to 2.5)).count)
        assertEquals(0, CounterState.fromDto(mapOf("count" to "9")).count)
        assertEquals(0, CounterState.fromDto(emptyMap<String, Any?>()).count)
    }

    // ---------- 仓储 ----------

    @Test fun `9_repo_fresh_reads_zero`() {
        val repo = CounterRepository(MemoryStore())
        assertEquals(0, repo.read().count)
    }

    @Test fun `10_repo_increment_thrice`() {
        val repo = CounterRepository(MemoryStore())
        repo.increment()
        repo.increment()
        assertEquals(3, repo.increment().count)
        assertEquals(3, repo.read().count)
    }

    @Test fun `11_repo_reset_after_increments`() {
        val repo = CounterRepository(MemoryStore())
        repo.increment(); repo.increment(); repo.increment()
        assertEquals(0, repo.reset().count)
        assertEquals(0, repo.read().count)
    }

    @Test fun `12_repo_write_through_persisted`() {
        val store = MemoryStore()
        val repo = CounterRepository(store)
        repo.increment(); repo.increment(); repo.increment()
        assertEquals("{\"count\":3}", store.json)
        repo.reset()
        assertEquals("{\"count\":0}", store.json)
    }

    @Test fun `13_repo_reload_restores_persisted`() {
        val store = MemoryStore()
        store.json = "{\"count\":7}"
        val repo = CounterRepository(store)
        assertEquals(7, repo.read().count)
    }

    @Test fun `14_repo_corrupt_data_defaults_zero`() {
        val broken = MemoryStore(); broken.json = "{oops-not-json"
        assertEquals(0, CounterRepository(broken).read().count)
        val negative = MemoryStore(); negative.json = "{\"count\":-2}"
        assertEquals(0, CounterRepository(negative).read().count)
        val float = MemoryStore(); float.json = "{\"count\":2.5}"
        assertEquals(0, CounterRepository(float).read().count)
    }

    // ---------- 规则 4：readOpenCreate 严格布尔（附则口径） ----------

    @Test fun `15_want_strict_boolean_only_true`() {
        assertTrue(CounterLogic.readOpenCreate(true))
        assertFalse(CounterLogic.readOpenCreate("true"))
        assertFalse(CounterLogic.readOpenCreate("1"))
        assertFalse(CounterLogic.readOpenCreate(1))
        assertFalse(CounterLogic.readOpenCreate("True"))
        assertFalse(CounterLogic.readOpenCreate(null))   // 参数值 undefined 口径
    }

    @Test fun `16_want_missing_params_or_null`() {
        // 裸 want（无 parameters）/null/undefined 同判假 —— 值缺失统一走 null 口径
        assertFalse(CounterLogic.readOpenCreate(null))
    }

    // ---------- 规则 1：AppRepo 进程内单例 ----------

    @Test fun `17_apprepo_singleton_same_instance`() {
        var created = 0
        val first = AppRepo.getOrCreate { created++; CounterRepository(MemoryStore()) }
        val second = AppRepo.getOrCreate { created++; CounterRepository(MemoryStore()) }
        assertSame(first, second)   // 任意两次获取同实例（镜像鸿蒙 #17 语义）
        assertEquals(1, created)    // 创建工厂仅执行一次（惰性单例）
    }
}
