package io.eazo.quicknotes.core

import io.eazo.quicknotes.model.Note
import io.eazo.quicknotes.model.NoteFilter
import io.eazo.quicknotes.model.NoteSort
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * REQ-003 Android 基线 NoteRepository 纯逻辑差分单测（IPD-61 TR-Accept）。
 *
 * 与鸿蒙 ohosTest 的 NoteRepository.test.ets（Hypium 15 例）1:1 镜像断言，
 * 证明「同一操作序列 + 同一断言点 + list()/CRUD 返回序列逐项一致」。
 * 纯 Kotlin、无 Android 平台依赖（NoteRepository 仅注入 NoteStore + 可注入 clock）。
 */
class MemoryStore : NoteStore {
    val data: MutableList<Note> = mutableListOf()
    override fun load(): List<Note> = data.toList()
    override fun save(notes: List<Note>) {
        data.clear()
        data.addAll(notes)
    }
}

class NoteRepositoryDiffTest {

    private fun clock(start: Long = 0, step: Long = 1000): () -> Long {
        var now = start
        return { now += step; now }
    }

    @Test fun createEmptyTitleReturnsError() {
        val repo = NoteRepository(MemoryStore())
        val r = repo.create("   ")
        assertTrue(r is CreateResult.Err)
        assertEquals("empty", (r as CreateResult.Err).reason)
    }

    @Test fun createTooLongTitleReturnsError() {
        val repo = NoteRepository(MemoryStore())
        val r = repo.create("x".repeat(201))
        assertTrue(r is CreateResult.Err)
        assertEquals("too_long", (r as CreateResult.Err).reason)
    }

    @Test fun createSummaryTooLongReturnsError() {
        val repo = NoteRepository(MemoryStore())
        val r = repo.create("标题", "y".repeat(1001))
        assertTrue(r is CreateResult.Err)
        assertEquals("summary_too_long", (r as CreateResult.Err).reason)
    }

    @Test fun createValidUsesTrimAndDefaults() {
        val repo = NoteRepository(MemoryStore())
        val r = repo.create("  灵感A  ")
        assertTrue(r is CreateResult.Ok)
        val n = (r as CreateResult.Ok).note
        assertEquals("灵感A", n.title)
        assertEquals("", n.summary)
        assertEquals(0, n.tags.size)
    }

    @Test fun createNormalizesTagsTrimDedupSort() {
        val repo = NoteRepository(MemoryStore())
        val r = repo.create("标题", "", listOf("灵感", "工作", "灵感", "  ", "AI"))
        assertTrue(r is CreateResult.Ok)
        val n = (r as CreateResult.Ok).note
        assertEquals(listOf("AI", "工作", "灵感"), n.tags)
    }

    @Test fun listTimeDescSortsNewestFirst() {
        val repo = NoteRepository(MemoryStore(), clock())
        repo.create("A"); repo.create("B"); repo.create("C")
        val list = repo.list(NoteFilter.All, NoteSort.TIME_DESC)
        assertEquals(listOf("C", "B", "A"), list.map { it.title })
    }

    @Test fun listTimeAscSortsOldestFirst() {
        val repo = NoteRepository(MemoryStore(), clock())
        repo.create("A"); repo.create("B"); repo.create("C")
        val list = repo.list(NoteFilter.All, NoteSort.TIME_ASC)
        assertEquals(listOf("A", "B", "C"), list.map { it.title })
    }

    @Test fun listTagGroupSortsByPrimaryTagThenTimeDesc() {
        val repo = NoteRepository(MemoryStore(), clock())
        repo.create("g1", "", listOf("工作"))          // primaryTag 工作, t1000
        repo.create("l1", "", listOf("灵感"))          // primaryTag 灵感, t2000
        repo.create("n1")                              // primaryTag "", t3000
        repo.create("g2", "", listOf("工作", "灵感"))   // primaryTag 工作, t4000
        val list = repo.list(NoteFilter.All, NoteSort.TAG_GROUP)
        assertEquals(listOf("n1", "g2", "g1", "l1"), list.map { it.title })
    }

    @Test fun filterByTagKeepsOnlyMatching() {
        val repo = NoteRepository(MemoryStore())
        repo.create("A", "", listOf("工作"))
        repo.create("B", "", listOf("灵感"))
        repo.create("C", "", emptyList())
        val list = repo.list(NoteFilter.ByTag("工作"), NoteSort.TIME_DESC)
        assertEquals(listOf("A"), list.map { it.title })
    }

    @Test fun updateEditsFieldsAndRefreshesUpdatedAt() {
        val repo = NoteRepository(MemoryStore(), clock())
        val n = (repo.create("旧标题") as CreateResult.Ok).note
        val updated = repo.update(n.id, "新标题", "新摘要", listOf("工作"))
        assertNotNull(updated)
        assertEquals("新标题", updated!!.title)
        assertEquals("新摘要", updated.summary)
        assertEquals(listOf("工作"), updated.tags)
        assertEquals(n.createdAt, updated.createdAt)
        assertTrue(updated.updatedAt > n.updatedAt)
    }

    @Test fun updateInvalidTitleReturnsNull() {
        val repo = NoteRepository(MemoryStore())
        val n = (repo.create("旧标题") as CreateResult.Ok).note
        assertNull(repo.update(n.id, ""))
    }

    @Test fun updateMissingIdReturnsNull() {
        val repo = NoteRepository(MemoryStore())
        assertNull(repo.update("no-such-id", "x"))
    }

    @Test fun removeExistingReturnsTrueMissingFalse() {
        val repo = NoteRepository(MemoryStore())
        val n = (repo.create("A") as CreateResult.Ok).note
        assertTrue(repo.remove(n.id))
        assertFalse(repo.remove(n.id))
    }

    @Test fun allTagsReturnsDedupSorted() {
        val repo = NoteRepository(MemoryStore())
        repo.create("A", "", listOf("灵感", "工作"))
        repo.create("B", "", listOf("工作", "AI"))
        assertEquals(listOf("AI", "工作", "灵感"), repo.allTags())
    }

    @Test fun getByIdReturnsNoteOrNull() {
        val repo = NoteRepository(MemoryStore())
        val n = (repo.create("A") as CreateResult.Ok).note
        assertNotNull(repo.getById(n.id))
        assertNull(repo.getById("nope"))
    }
}
