package io.eazo.quicknotes.platform

import android.content.Context
import android.content.SharedPreferences
import io.eazo.quicknotes.core.NoteStore
import io.eazo.quicknotes.model.Note
import org.json.JSONArray
import org.json.JSONObject

/**
 * SharedPreferences 持久化实现（契约 §6）。全量 JSON 序列化，键为 "notes"。
 */
class PrefsStore(context: Context) : NoteStore {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("notes", Context.MODE_PRIVATE)

    override fun load(): List<Note> {
        val json = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val tagsArr = o.optJSONArray("tags") ?: JSONArray()
                val tags = (0 until tagsArr.length()).map { j -> tagsArr.getString(j) }
                Note(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    summary = o.optString("summary", ""),
                    tags = tags,
                    createdAt = o.getLong("createdAt"),
                    updatedAt = o.getLong("updatedAt")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    override fun save(notes: List<Note>) {
        val arr = JSONArray()
        notes.forEach { n ->
            arr.put(
                JSONObject().apply {
                    put("id", n.id)
                    put("title", n.title)
                    put("summary", n.summary)
                    put("tags", JSONArray().apply { n.tags.forEach { put(it) } })
                    put("createdAt", n.createdAt)
                    put("updatedAt", n.updatedAt)
                }
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    companion object {
        private const val KEY = "notes"
    }
}
