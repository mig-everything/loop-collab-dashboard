package io.eazo.quicknotes.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import io.eazo.quicknotes.core.NoteRepository
import io.eazo.quicknotes.model.Note
import io.eazo.quicknotes.model.NoteFilter
import io.eazo.quicknotes.model.NoteSort
import io.eazo.quicknotes.model.ThemeMode
import io.eazo.quicknotes.platform.AppRepo
import io.eazo.quicknotes.platform.ThemeManager
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * 灵感列表页（US-1 列表 / US-4 标签筛选与排序 / US-5 主题切换）。
 */
class MainActivity : Activity() {

    private lateinit var repo: NoteRepository
    private lateinit var colors: ThemeColors
    private lateinit var listContainer: LinearLayout
    private lateinit var chipContainer: LinearLayout
    private lateinit var sortBtn: Button
    private lateinit var themeBtn: Button
    private var filter: NoteFilter = NoteFilter.All
    private var sort: NoteSort = NoteSort.TIME_DESC

    private val timeFmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = AppRepo.get(this)
        colors = ThemeColors.forMode(ThemeManager.current(this))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(colors.background)
            setPadding(dp(20), dp(28), dp(20), dp(16))
        }

        // 顶栏：标题 + 主题切换
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(
            TextView(this).apply {
                text = "灵感速记"
                textSize = 24f
                setTextColor(colors.text)
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        themeBtn = Button(this).apply {
            text = themeLabel(ThemeManager.current(this@MainActivity))
            textSize = 13f
            setOnClickListener {
                val next = if (ThemeManager.current(this@MainActivity) == ThemeMode.LIGHT) ThemeMode.DARK else ThemeMode.LIGHT
                ThemeManager.set(this@MainActivity, next)
                recreate()
            }
        }
        header.addView(themeBtn)
        root.addView(header)

        // 新建入口（US-2）
        root.addView(
            Button(this).apply {
                text = "＋ 记录灵感"
                textSize = 16f
                setBackgroundColor(colors.accent)
                setTextColor(colors.onAccent)
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, EditActivity::class.java))
                }
            }
        )

        // 标签筛选行（US-4 / AC4.1）
        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        chipContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(12), 0, 0)
        }
        chipScroll.addView(chipContainer)
        root.addView(chipScroll)

        // 排序行（US-4 / AC4.2）
        val sortRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(4), 0, dp(4))
        }
        sortBtn = Button(this).apply {
            text = sortLabel(sort)
            textSize = 13f
            setOnClickListener {
                sort = when (sort) {
                    NoteSort.TIME_DESC -> NoteSort.TIME_ASC
                    NoteSort.TIME_ASC -> NoteSort.TAG_GROUP
                    NoteSort.TAG_GROUP -> NoteSort.TIME_DESC
                }
                text = sortLabel(sort)
                refresh()
            }
        }
        sortRow.addView(sortBtn)
        root.addView(sortRow)

        // 列表（US-1）
        val scroll = ScrollView(this)
        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listContainer)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        setContentView(root)
        window.decorView.setBackgroundColor(colors.background)
        renderChips()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::repo.isInitialized) {
            renderChips()
            refresh()
        }
    }

    // ---- 标签筛选 UI ----

    private fun renderChips() {
        chipContainer.removeAllViews()
        val tags = repo.allTags()
        val allChip = buildChip("全部", NoteFilter.All)
        chipContainer.addView(allChip)
        for (tag in tags) {
            chipContainer.addView(buildChip("#$tag", NoteFilter.ByTag(tag)))
        }
        highlightChip()
    }

    private fun buildChip(label: String, f: NoteFilter): TextView {
        return TextView(this).apply {
            text = label
            textSize = 13f
            setPadding(dp(14), dp(7), dp(14), dp(7))
            setOnClickListener {
                filter = f
                highlightChip()
                refresh()
            }
        }.also { tv ->
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = dp(8)
            tv.layoutParams = lp
        }
    }

    private fun highlightChip() {
        for (i in 0 until chipContainer.childCount) {
            val tv = chipContainer.getChildAt(i) as TextView
            val active = when (val f = filter) {
                is NoteFilter.All -> tv.text.toString() == "全部"
                is NoteFilter.ByTag -> tv.text.toString() == "#${f.tag}"
            }
            tv.background = rounded(if (active) colors.accent else colors.chipBg, dp(16).toFloat())
            tv.setTextColor(if (active) colors.onAccent else colors.chipText)
        }
    }

    // ---- 列表渲染 ----

    private fun refresh() {
        listContainer.removeAllViews()
        val notes = repo.list(filter, sort)
        if (notes.isEmpty()) {
            listContainer.addView(
                TextView(this).apply {
                    text = "还没有灵感\n点「＋ 记录灵感」记下第一条"
                    textSize = 16f
                    gravity = Gravity.CENTER
                    setPadding(0, dp(96), 0, dp(96))
                    setTextColor(colors.textSecondary)
                }
            )
            return
        }
        for (note in notes) {
            listContainer.addView(buildCard(note))
        }
    }

    private fun buildCard(note: Note): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = rounded(colors.surface, dp(14).toFloat())
        }

        // 标题 + 时间
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row1.addView(
            TextView(this).apply {
                text = note.title
                textSize = 17f
                setTextColor(colors.text)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        row1.addView(
            TextView(this).apply {
                text = timeFmt.format(note.createdAt)
                textSize = 12f
                setTextColor(colors.textSecondary)
                setPadding(dp(8), 0, 0, 0)
            }
        )
        card.addView(row1)

        // 摘要（可截断，AC1.2）
        if (note.summary.isNotEmpty()) {
            card.addView(
                TextView(this).apply {
                    text = note.summary
                    textSize = 14f
                    setTextColor(colors.textSecondary)
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(0, dp(6), 0, 0)
                }
            )
        }

        // 标签
        if (note.tags.isNotEmpty()) {
            card.addView(
                TextView(this).apply {
                    text = note.tags.joinToString("   ") { "#$it" }
                    textSize = 13f
                    setTextColor(colors.chipText)
                    setPadding(0, dp(8), 0, 0)
                }
            )
        }

        card.setOnClickListener {
            val i = Intent(this, EditActivity::class.java)
            i.putExtra(EditActivity.EXTRA_ID, note.id)
            startActivity(i)
        }

        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(12)
        card.layoutParams = lp
        return card
    }

    // ---- 工具 ----

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(color)
            cornerRadius = radius
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun sortLabel(s: NoteSort): String = when (s) {
        NoteSort.TIME_DESC -> "排序：时间倒序"
        NoteSort.TIME_ASC -> "排序：时间正序"
        NoteSort.TAG_GROUP -> "排序：标签分组"
    }

    private fun themeLabel(m: ThemeMode): String = if (m == ThemeMode.LIGHT) "☀ 浅色" else "🌙 深色"
}
