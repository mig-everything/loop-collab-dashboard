package io.eazo.quicknotes.model

/**
 * 标签筛选（AC4.1）：
 * - [All]：展示全部灵感。
 * - [ByTag]：仅展示含指定标签的灵感。
 */
sealed class NoteFilter {
    object All : NoteFilter()
    data class ByTag(val tag: String) : NoteFilter()
}
