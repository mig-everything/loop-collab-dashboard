package io.eazo.quicknotes.core

import io.eazo.quicknotes.model.Note
import io.eazo.quicknotes.model.NoteFilter
import io.eazo.quicknotes.model.NoteSort
import java.util.UUID

/**
 * create 返回值（契约 §2）：成功携带 Note，失败携带原因。
 */
sealed class CreateResult {
    data class Ok(val note: Note) : CreateResult()
    data class Err(val reason: String) : CreateResult() // "empty" | "too_long" | "summary_too_long"
}

/**
 * 灵感仓储（纯逻辑，无 UI、无平台 API）。持久化通过 NoteStore 注入，时钟可注入便于测试。
 *
 * 确定性契约（契约 §4，双端 1:1）：
 * 1. 先 filter 后 sort。
 * 2. sort=TIME_DESC：createdAt 降序（最新在前）。
 * 3. sort=TIME_ASC：createdAt 升序（最早在前）。
 * 4. sort=TAG_GROUP：primaryTag 升序（无标签 "" 排最前），次键 createdAt 降序。
 * 5. 任意键相等时用 id 字典序稳定兜底。
 *
 * 生命周期（契约 §2.1，强制）：本类实例必须进程内单例，统一经 [io.eazo.quicknotes.platform.AppRepo.get]
 * 获取；禁止 UI 层直接 new，避免跨 Activity 状态不同步的 stale 缺陷（对标 REQ-002 IPD-39）。
 */
class NoteRepository(
    private val store: NoteStore,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    private val notes: MutableList<Note> = store.load().toMutableList()

    fun create(title: String, summary: String = "", tags: List<String> = emptyList()): CreateResult {
        val t = title.trim()
        val s = summary.trim()
        return when {
            t.isEmpty() -> CreateResult.Err("empty")
            t.length > Note.MAX_TITLE_LEN -> CreateResult.Err("too_long")
            s.length > Note.MAX_SUMMARY_LEN -> CreateResult.Err("summary_too_long")
            else -> {
                val now = clock()
                val note = Note(
                    id = UUID.randomUUID().toString(),
                    title = t,
                    summary = s,
                    tags = normalizeTags(tags),
                    createdAt = now,
                    updatedAt = now
                )
                notes.add(note)
                persist()
                CreateResult.Ok(note)
            }
        }
    }

    fun update(
        id: String,
        title: String? = null,
        summary: String? = null,
        tags: List<String>? = null
    ): Note? {
        val idx = notes.indexOfFirst { it.id == id }
        if (idx < 0) return null
        var n = notes[idx]
        if (title != null) {
            val t = title.trim()
            if (t.isEmpty() || t.length > Note.MAX_TITLE_LEN) return null
            n = n.copy(title = t)
        }
        if (summary != null) {
            val s = summary.trim()
            if (s.length > Note.MAX_SUMMARY_LEN) return null
            n = n.copy(summary = s)
        }
        if (tags != null) n = n.copy(tags = normalizeTags(tags))
        n = n.copy(updatedAt = clock())
        notes[idx] = n
        persist()
        return n
    }

    fun remove(id: String): Boolean {
        val before = notes.size
        notes.removeAll { it.id == id }
        val removed = notes.size < before
        if (removed) persist()
        return removed
    }

    fun list(filter: NoteFilter, sort: NoteSort): List<Note> {
        val filtered = when (filter) {
            is NoteFilter.All -> notes.toList()
            is NoteFilter.ByTag -> notes.filter { it.tags.contains(filter.tag) }
        }
        return when (sort) {
            NoteSort.TIME_DESC -> filtered.sortedWith(
                compareByDescending<Note> { it.createdAt }.thenBy { it.id }
            )
            NoteSort.TIME_ASC -> filtered.sortedWith(
                compareBy<Note> { it.createdAt }.thenBy { it.id }
            )
            NoteSort.TAG_GROUP -> filtered.sortedWith(
                compareBy<Note> { it.primaryTag }
                    .thenByDescending { it.createdAt }
                    .thenBy { it.id }
            )
        }
    }

    fun getById(id: String): Note? = notes.find { it.id == id }

    fun all(): List<Note> = notes.toList()

    /** 去重后的全量标签集（字典序升序），用于标签筛选 UI（AC4.1 / AC7.2 标签集随笔记持久化）。 */
    fun allTags(): List<String> = notes.flatMap { it.tags }.distinct().sorted()

    private fun normalizeTags(tags: List<String>): List<String> =
        tags.map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()
            .sorted()

    private fun persist() {
        store.save(notes.toList())
    }
}
