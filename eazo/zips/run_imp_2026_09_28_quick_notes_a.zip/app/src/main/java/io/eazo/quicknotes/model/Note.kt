package io.eazo.quicknotes.model

/**
 * 灵感实体（契约 §1）。字段名/默认值与鸿蒙 Note 1:1。
 *
 * - title：去首尾空格后 1..200 字符（AC2.1 / AC2.3）。
 * - summary：可选摘要，去首尾空格后 ≤ 1000 字符（AC2.1）。
 * - tags：标签集合，normalize 后为「去空格、去空串、去重、按字典序升序」的有序列表（AC4.1）。
 * - createdAt：创建时间（排序主键之一）；updatedAt：最后修改时间。
 */
data class Note(
    val id: String,
    val title: String,
    val summary: String = "",
    val tags: List<String> = emptyList(),
    val createdAt: Long,
    val updatedAt: Long
) {
    companion object {
        const val MAX_TITLE_LEN = 200
        const val MAX_SUMMARY_LEN = 1000
    }

    /** 主标签（tags 已按字典序存储，取最小者；无标签为 ""）——TAG_GROUP 排序主键。 */
    val primaryTag: String
        get() = tags.firstOrNull() ?: ""
}
