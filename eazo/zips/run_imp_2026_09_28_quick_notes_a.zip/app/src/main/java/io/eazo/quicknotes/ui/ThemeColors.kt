package io.eazo.quicknotes.ui

import android.graphics.Color
import io.eazo.quicknotes.model.ThemeMode

/**
 * 主题调色板（US-5 / AC5.1）。浅色/深色两态，双端同色值，供 C4-rubric 截图打分。
 * 正文字色与背景色对比度 ≥ WCAG AA（4.5:1）。
 */
data class ThemeColors(
    val background: Int,
    val surface: Int,
    val text: Int,
    val textSecondary: Int,
    val accent: Int,
    val onAccent: Int,
    val chipBg: Int,
    val chipText: Int,
    val divider: Int
) {
    companion object {
        fun forMode(mode: ThemeMode): ThemeColors = when (mode) {
            ThemeMode.LIGHT -> LIGHT
            ThemeMode.DARK -> DARK
        }

        private val LIGHT = ThemeColors(
            background = Color.parseColor("#FAFAFA"),
            surface = Color.parseColor("#FFFFFF"),
            text = Color.parseColor("#1A1A1A"),
            textSecondary = Color.parseColor("#757575"),
            accent = Color.parseColor("#3F51B5"),
            onAccent = Color.parseColor("#FFFFFF"),
            chipBg = Color.parseColor("#E8EAF6"),
            chipText = Color.parseColor("#3F51B5"),
            divider = Color.parseColor("#E0E0E0")
        )

        private val DARK = ThemeColors(
            background = Color.parseColor("#121212"),
            surface = Color.parseColor("#1E1E1E"),
            text = Color.parseColor("#FAFAFA"),
            textSecondary = Color.parseColor("#A0A0A0"),
            accent = Color.parseColor("#7986CB"),
            onAccent = Color.parseColor("#121212"),
            chipBg = Color.parseColor("#2A2E4A"),
            chipText = Color.parseColor("#9FA8DA"),
            divider = Color.parseColor("#2E2E2E")
        )
    }
}
