package io.eazo.quicknotes.ui

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import io.eazo.quicknotes.core.CreateResult
import io.eazo.quicknotes.model.Note
import io.eazo.quicknotes.platform.AppRepo
import io.eazo.quicknotes.platform.ThemeManager

/**
 * 新建 / 编辑灵感（US-2 新建 / US-3 编辑与删除）。
 */
class EditActivity : Activity() {

    companion object {
        const val EXTRA_ID = "note_id"
    }

    private lateinit var colors: ThemeColors

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repo = AppRepo.get(this)
        val id = intent.getStringExtra(EXTRA_ID)
        val existing: Note? = id?.let { repo.getById(it) }

        colors = ThemeColors.forMode(ThemeManager.current(this))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(colors.background)
            setPadding(dp(20), dp(28), dp(20), dp(24))
        }

        val scroll = ScrollView(this)
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(form)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        form.addView(
            TextView(this).apply {
                text = if (existing == null) "记录灵感" else "编辑灵感"
                textSize = 24f
                gravity = Gravity.CENTER
                setTextColor(colors.text)
            }
        )

        // 标题（必填 1~200，AC2.1 / AC2.3）
        form.addView(
            TextView(this).apply { text = "标题 *"; textSize = 14f; setTextColor(colors.textSecondary) }
        )
        val titleInput = EditText(this).apply {
            hint = "一句话记下灵感（1~200 字）"
            textSize = 16f
            setTextColor(colors.text)
            setHintTextColor(colors.textSecondary)
            setText(existing?.title ?: "")
        }
        form.addView(titleInput)

        // 摘要（可选 ≤1000，AC2.1）
        form.addView(
            TextView(this).apply { text = "摘要（可选，≤1000 字）"; textSize = 14f; setTextColor(colors.textSecondary) }
        )
        val summaryInput = EditText(this).apply {
            hint = "补充细节…"
            textSize = 15f
            minLines = 3
            gravity = Gravity.TOP
            setTextColor(colors.text)
            setHintTextColor(colors.textSecondary)
            setText(existing?.summary ?: "")
        }
        form.addView(summaryInput)

        // 标签（逗号分隔，AC4.1）
        form.addView(
            TextView(this).apply { text = "标签（逗号分隔，可选）"; textSize = 14f; setTextColor(colors.textSecondary) }
        )
        val tagsInput = EditText(this).apply {
            hint = "如：工作, 灵感, 设计"
            textSize = 15f
            setTextColor(colors.text)
            setHintTextColor(colors.textSecondary)
            setText(existing?.tags?.joinToString(", ") ?: "")
        }
        form.addView(tagsInput)

        // 保存（US-2 / US-3）
        form.addView(
            Button(this).apply {
                text = "保存"
                textSize = 16f
                setBackgroundColor(colors.accent)
                setTextColor(colors.onAccent)
                setOnClickListener {
                    val title = titleInput.text.toString()
                    val summary = summaryInput.text.toString()
                    val tags = parseTags(tagsInput.text.toString())
                    if (existing == null) {
                        when (val r = repo.create(title, summary, tags)) {
                            is CreateResult.Err -> toast(reasonMsg(r.reason))
                            is CreateResult.Ok -> finish()
                        }
                    } else {
                        val updated = repo.update(existing.id, title, summary, tags)
                        if (updated == null) {
                            toast("标题不能为空或过长（≤200 字）")
                        } else {
                            finish()
                        }
                    }
                }
            }
        )

        // 删除（US-3 / AC3.2，二次确认）
        if (existing != null) {
            form.addView(
                Button(this).apply {
                    text = "删除此灵感"
                    textSize = 15f
                    setBackgroundColor(Color.parseColor("#E53935"))
                    setTextColor(Color.WHITE)
                    setOnClickListener {
                        AlertDialog.Builder(this@EditActivity)
                            .setTitle("删除灵感")
                            .setMessage("确定删除「${existing.title}」吗？删除后不可恢复。")
                            .setNegativeButton("取消", null)
                            .setPositiveButton("删除") { _, _ ->
                                repo.remove(existing.id)
                                finish()
                            }
                            .show()
                    }
                }
            )
        }

        setContentView(root)
        window.decorView.setBackgroundColor(colors.background)
    }

    private fun parseTags(raw: String): List<String> =
        raw.split(',', '，', ';', '；', '\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() }

    private fun reasonMsg(reason: String): String = when (reason) {
        "empty" -> "标题不能为空"
        "too_long" -> "标题过长（≤200 字）"
        "summary_too_long" -> "摘要过长（≤1000 字）"
        else -> "保存失败"
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
