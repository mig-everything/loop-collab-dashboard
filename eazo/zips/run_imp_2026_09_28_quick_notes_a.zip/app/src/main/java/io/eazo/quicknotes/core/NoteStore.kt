package io.eazo.quicknotes.core

import io.eazo.quicknotes.model.Note

/**
 * 持久化接口（契约 §3）。全量 JSON 序列化，双端仅存储实现不同。
 */
interface NoteStore {
    fun load(): List<Note>
    fun save(notes: List<Note>)
}
