package io.eazo.quicknotes.platform

import android.content.Context
import io.eazo.quicknotes.core.NoteRepository

/**
 * 进程内仓储单例（对标鸿蒙 platform/AppRepo.ets 的 getRepo 缓存）：
 * 列表页（MainActivity）与编辑页（EditActivity）共享同一 NoteRepository 实例，
 * 避免「各自 new NoteRepository 导致跨 Activity 状态不同步」的 stale 缺陷（对标 REQ-002 IPD-39）。
 */
object AppRepo {

    @Volatile
    private var repo: NoteRepository? = null

    fun get(context: Context): NoteRepository {
        return repo ?: synchronized(this) {
            repo ?: NoteRepository(PrefsStore(context.applicationContext)).also { repo = it }
        }
    }
}
