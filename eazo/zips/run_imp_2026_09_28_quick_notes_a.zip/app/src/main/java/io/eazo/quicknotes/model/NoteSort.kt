package io.eazo.quicknotes.model

/**
 * 排序方式（AC4.2）：
 * - [TIME_DESC]（默认）：createdAt 降序（最新在前）。
 * - [TIME_ASC]：createdAt 升序（最早在前）。
 * - [TAG_GROUP]：按标签分组——主键 primaryTag 升序（无标签 "" 排最前），次键 createdAt 降序。
 */
enum class NoteSort { TIME_DESC, TIME_ASC, TAG_GROUP }
