package io.eazo.quicknotes.model

/**
 * 主题模式（US-5 / AC5.1 / AC5.2）：浅色 / 深色。默认 LIGHT。
 */
enum class ThemeMode { LIGHT, DARK }
