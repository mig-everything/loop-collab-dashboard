package io.eazo.quicknotes.platform

import android.content.Context
import android.content.SharedPreferences
import io.eazo.quicknotes.model.ThemeMode

/**
 * 主题偏好持久化单例（US-5 / AC5.2）：进程内缓存 SharedPreferences，键 "theme"，值 "light"/"dark"。
 * 主题切换后全局 UI 即时生效；重启后保持（AC7.2）。
 */
object ThemeManager {

    @Volatile
    private var prefs: SharedPreferences? = null

    private fun p(context: Context): SharedPreferences {
        return prefs ?: synchronized(this) {
            prefs ?: context.applicationContext
                .getSharedPreferences("theme", Context.MODE_PRIVATE)
                .also { prefs = it }
        }
    }

    fun current(context: Context): ThemeMode =
        if (p(context).getString(KEY, "light") == "dark") ThemeMode.DARK else ThemeMode.LIGHT

    fun set(context: Context, mode: ThemeMode) {
        p(context).edit().putString(KEY, if (mode == ThemeMode.DARK) "dark" else "light").apply()
    }

    private const val KEY = "mode"
}
