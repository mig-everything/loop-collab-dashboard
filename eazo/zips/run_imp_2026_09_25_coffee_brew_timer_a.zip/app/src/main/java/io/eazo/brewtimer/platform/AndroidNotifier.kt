package io.eazo.brewtimer.platform

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import io.eazo.brewtimer.core.Notifier
import io.eazo.brewtimer.model.Recipe
import io.eazo.brewtimer.model.Segment

/**
 * Android 提醒实现（US-6 为 P1，此处先落「震动 + 日志」最小闭环；声音/通知渠道后续扩展）。
 */
class AndroidNotifier(private val context: Context) : Notifier {
    private var enabled = true
    private var sound = true
    private var vibration = true
    private var notification = true

    override fun onSegmentTransition(recipe: Recipe, fromIndex: Int, toIndex: Int, next: Segment) {
        Log.i("BrewTimer", "segment ${fromIndex}->${toIndex}: ${next.name}")
        if (enabled && vibration) vibrate()
    }

    override fun onComplete(recipe: Recipe, totalElapsedSec: Int) {
        Log.i("BrewTimer", "complete: ${recipe.name} in ${totalElapsedSec}s")
        if (enabled && vibration) vibrate()
    }

    override fun configure(enabled: Boolean, sound: Boolean, vibration: Boolean, notification: Boolean) {
        this.enabled = enabled
        this.sound = sound
        this.vibration = vibration
        this.notification = notification
    }

    private fun vibrate() {
        // API 31+ 走 VibratorManager（避免 VIBRATOR_SERVICE 弃用告警）；低版本兜底旧接口。
        val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        vibrator?.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
    }
}
