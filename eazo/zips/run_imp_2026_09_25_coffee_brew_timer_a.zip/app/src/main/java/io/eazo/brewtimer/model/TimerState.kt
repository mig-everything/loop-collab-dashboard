package io.eazo.brewtimer.model

/**
 * 计时核心状态机状态（契约 02 §1.1）。
 */
enum class TimerState {
    IDLE,
    RUNNING,
    PAUSED,
    COMPLETED
}
