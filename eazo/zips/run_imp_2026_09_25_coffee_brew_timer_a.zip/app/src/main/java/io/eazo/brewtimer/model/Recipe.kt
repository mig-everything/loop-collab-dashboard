package io.eazo.brewtimer.model

/**
 * 配方（契约 02 §2）：segments ≥ 2（AC2.1）。
 * 派生字段 totalDurationSeconds = sum(segments.durationSeconds)，不存储。
 */
data class Recipe(
    val id: String,
    val name: String,
    val brewMethod: BrewMethod,
    val segments: List<Segment>,
    val isPreset: Boolean,
    val createdAt: Long,
    val updatedAt: Long
) {
    fun totalDurationSeconds(): Int = segments.sumOf { it.durationSeconds }
}
