package io.eazo.brewtimer.platform

import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * 定时器驱动封装（契约 03 §2.1）：`ScheduledExecutorService.scheduleAtFixedRate(1s)` 仅驱动刷新，
 * 时间取自 `MonotonicClock`，绝不用定时器累计次数当时间。
 */
class Ticker(private val onTick: () -> Unit) {
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private var future: ScheduledFuture<*>? = null

    fun start() {
        if (future != null) return
        future = executor.scheduleAtFixedRate(onTick, 0L, 1L, TimeUnit.SECONDS)
    }

    fun stop() {
        future?.cancel(false)
        future = null
    }

    fun shutdown() {
        stop()
        executor.shutdown()
    }
}
