package io.eazo.brewtimer.core

import io.eazo.brewtimer.model.Recipe
import io.eazo.brewtimer.model.Segment
import io.eazo.brewtimer.model.TimerSnapshot
import io.eazo.brewtimer.model.TimerState

/**
 * 分段计时状态机（契约 02 §1）。纯逻辑、无 UI、无平台 API。
 *
 * 关键确定性契约（严格 1:1 实现）：
 * 1. 段边界等值：`elapsedInSegmentMs >= segmentDurationMs`（含等号）即触发，与秒值 floor 一致。
 * 2. tick 跨多段：逐段 while 循环、按段序推进，每跨一段按序补发一次 segmentCompleted → onSegmentTransition；
 *    末段走完 state=COMPLETED 终止，不再产生后续段事件。
 * 3. 时间账本基于单调时钟（clock() 注入），定时器只驱动 tick，绝不累加计数。
 */
class TimerEngine(
    private val recipe: Recipe,
    private val clock: () -> Long,
    private val notifier: Notifier
) {
    private var state: TimerState = TimerState.IDLE
    private var accumulatedElapsedMs: Long = 0L
    private var elapsedInSegmentMs: Long = 0L
    private var segmentIndex: Int = 0
    private var lastResumeRefMs: Long? = null

    private val lastIndex: Int get() = recipe.segments.size - 1

    fun start() {
        if (state != TimerState.IDLE) return
        state = TimerState.RUNNING
        segmentIndex = 0
        accumulatedElapsedMs = 0L
        elapsedInSegmentMs = 0L
        lastResumeRefMs = clock()
    }

    fun pause() {
        if (state != TimerState.RUNNING) return
        val now = clock()
        val delta = now - (lastResumeRefMs ?: now)
        accumulatedElapsedMs += delta
        elapsedInSegmentMs += delta
        lastResumeRefMs = null
        state = TimerState.PAUSED
    }

    fun resume() {
        if (state != TimerState.PAUSED) return
        lastResumeRefMs = clock()
        state = TimerState.RUNNING
    }

    fun reset() {
        if (state == TimerState.IDLE) return
        state = TimerState.IDLE
        segmentIndex = 0
        accumulatedElapsedMs = 0L
        elapsedInSegmentMs = 0L
        lastResumeRefMs = null
    }

    /**
     * 时钟推进（内部驱动）。一次 tick 只做「判定 + 推进」，按序补发段事件。
     */
    fun tick(nowMs: Long) {
        if (state != TimerState.RUNNING) return
        val ref = lastResumeRefMs ?: return
        val delta = nowMs - ref
        lastResumeRefMs = nowMs
        accumulatedElapsedMs += delta
        elapsedInSegmentMs += delta

        val segments = recipe.segments
        while (state == TimerState.RUNNING &&
            elapsedInSegmentMs >= segments[segmentIndex].durationSeconds * 1000L
        ) {
            elapsedInSegmentMs -= segments[segmentIndex].durationSeconds * 1000L
            if (segmentIndex == lastIndex) {
                state = TimerState.COMPLETED
                lastResumeRefMs = null
                notifier.onComplete(recipe, (accumulatedElapsedMs / 1000L).toInt())
                break
            } else {
                val from = segmentIndex
                segmentIndex += 1
                notifier.onSegmentTransition(recipe, from, segmentIndex, segments[segmentIndex])
            }
        }
    }

    fun currentState(): TimerState = state

    fun snapshot(): TimerSnapshot {
        val segments = recipe.segments
        val totalDurationSec = recipe.totalDurationSeconds()
        val totalElapsedSec = (accumulatedElapsedMs / 1000L).toInt()
        val totalRemainSec = (totalDurationSec - totalElapsedSec).coerceAtLeast(0)

        val idx = if (state == TimerState.COMPLETED) lastIndex else segmentIndex
        val segDuration = segments[idx].durationSeconds
        val segElapsedSec = if (state == TimerState.COMPLETED) {
            segDuration
        } else {
            (elapsedInSegmentMs / 1000L).toInt().coerceAtMost(segDuration)
        }
        val segRemainSec = (segDuration - segElapsedSec).coerceAtLeast(0)

        return TimerSnapshot(
            state = state,
            recipeId = recipe.id,
            recipeName = recipe.name,
            brewMethod = recipe.brewMethod,
            segmentIndex = idx,
            segmentName = segments[idx].name,
            segmentElapsedSec = segElapsedSec,
            segmentRemainSec = segRemainSec,
            totalElapsedSec = totalElapsedSec,
            totalRemainSec = totalRemainSec,
            isLastSegment = idx == lastIndex
        )
    }
}
