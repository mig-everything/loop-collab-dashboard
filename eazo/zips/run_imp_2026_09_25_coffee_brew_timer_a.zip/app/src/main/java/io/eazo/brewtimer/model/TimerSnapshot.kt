package io.eazo.brewtimer.model

/**
 * 计时快照 DTO（契约 02 §3）：状态唯一来源，UI 只读快照。
 * 所有秒值由单调时间戳差值取整（floor）。
 */
data class TimerSnapshot(
    val state: TimerState,
    val recipeId: String,
    val recipeName: String,
    val brewMethod: BrewMethod,
    val segmentIndex: Int,
    val segmentName: String,
    val segmentElapsedSec: Int,
    val segmentRemainSec: Int,
    val totalElapsedSec: Int,
    val totalRemainSec: Int,
    val isLastSegment: Boolean
) {
    /**
     * AC7.2 卡片「剩余分钟」口径：总剩余 ceil(totalRemainSec / 60)（不采用当前段剩余）。
     * 见契约 05 §1.3。
     */
    val totalRemainMin: Int
        get() = (totalRemainSec + 59) / 60
}
