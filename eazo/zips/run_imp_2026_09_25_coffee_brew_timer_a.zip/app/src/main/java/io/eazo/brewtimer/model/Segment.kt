package io.eazo.brewtimer.model

/**
 * 计时段（契约 02 §2）：name 为段名（如「闷蒸」「注水」），durationSeconds > 0。
 */
data class Segment(
    val name: String,
    val durationSeconds: Int
)
