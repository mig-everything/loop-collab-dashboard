package io.eazo.brewtimer.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import io.eazo.brewtimer.core.RecipeRepository

/**
 * US-1 冲煮方式选择：首屏列出 5 种冲煮方式，点击进入对应计时页（AC1.1/AC1.2）。
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        val title = TextView(this).apply {
            text = "咖啡冲煮计时器"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "选择冲煮方式"
            textSize = 16f
            gravity = Gravity.CENTER
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(TextView(this).apply { text = " "; textSize = 16f })

        for (method in RecipeRepository.allMethods()) {
            val btn = Button(this).apply {
                text = method.displayName
                textSize = 18f
                setOnClickListener {
                    val intent = Intent(this@MainActivity, TimerActivity::class.java)
                    intent.putExtra(TimerActivity.EXTRA_METHOD, method.name)
                    startActivity(intent)
                }
            }
            root.addView(btn)
        }

        setContentView(root)
    }
}
