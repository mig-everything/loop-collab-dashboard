package io.eazo.brewtimer.core

import io.eazo.brewtimer.model.Recipe
import io.eazo.brewtimer.model.Segment

/**
 * 提醒触发接口（契约 02 §4）。
 * 触发点：段边界切换 → onSegmentTransition；整体结束 → onComplete。
 */
interface Notifier {
    fun onSegmentTransition(recipe: Recipe, fromIndex: Int, toIndex: Int, next: Segment)
    fun onComplete(recipe: Recipe, totalElapsedSec: Int)
    fun configure(enabled: Boolean, sound: Boolean, vibration: Boolean, notification: Boolean)
}
