package io.eazo.brewtimer.core

import io.eazo.brewtimer.model.BrewMethod
import io.eazo.brewtimer.model.Recipe
import io.eazo.brewtimer.model.Segment

/**
 * 配方库（US-4）：每种冲煮方式内置 ≥1 个多段配方（isPreset=true，只读）。
 * 自定义配方持久化（US-5，P1）后续扩展。
 */
object RecipeRepository {

    private val presets: Map<BrewMethod, Recipe> = BrewMethod.entries.associateWith { method ->
        val epoch = 0L
        Recipe(
            id = "preset-${method.name.lowercase()}",
            name = "${method.displayName}·默认配方",
            brewMethod = method,
            segments = defaultSegments(method),
            isPreset = true,
            createdAt = epoch,
            updatedAt = epoch
        )
    }

    fun allMethods(): List<BrewMethod> = BrewMethod.entries.toList()

    fun presetByMethod(method: BrewMethod): Recipe = presets.getValue(method)

    fun allPresets(): List<Recipe> = presets.values.toList()

    private fun defaultSegments(method: BrewMethod): List<Segment> = when (method) {
        BrewMethod.POUR_OVER -> listOf(
            Segment("闷蒸", 30),
            Segment("注水", 90),
            Segment("等待", 60)
        )
        BrewMethod.FRENCH_PRESS -> listOf(
            Segment("注水", 30),
            Segment("浸泡", 240)
        )
        BrewMethod.AEROPRESS -> listOf(
            Segment("注水", 30),
            Segment("搅拌", 10),
            Segment("等待", 60),
            Segment("压出", 30)
        )
        BrewMethod.ESPRESSO -> listOf(
            Segment("预浸泡", 5),
            Segment("萃取", 25)
        )
        BrewMethod.COLD_BREW -> listOf(
            Segment("注水", 60),
            Segment("浸泡", 3600)
        )
    }
}
