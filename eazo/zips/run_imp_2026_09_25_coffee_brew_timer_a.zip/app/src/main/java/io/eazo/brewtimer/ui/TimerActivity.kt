package io.eazo.brewtimer.ui

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import io.eazo.brewtimer.core.RecipeRepository
import io.eazo.brewtimer.core.TimerEngine
import io.eazo.brewtimer.model.BrewMethod
import io.eazo.brewtimer.model.TimerSnapshot
import io.eazo.brewtimer.model.TimerState
import io.eazo.brewtimer.platform.AndroidNotifier
import io.eazo.brewtimer.platform.MonotonicClock
import io.eazo.brewtimer.platform.Ticker

/**
 * US-2/US-3 分段计时 + 开始/暂停/继续/重置。
 */
class TimerActivity : Activity() {

    companion object {
        const val EXTRA_METHOD = "method"
    }

    private lateinit var engine: TimerEngine
    private lateinit var ticker: Ticker

    private lateinit var methodLabel: TextView
    private lateinit var segmentLabel: TextView
    private lateinit var segmentTimeLabel: TextView
    private lateinit var totalTimeLabel: TextView
    private lateinit var stateLabel: TextView
    private lateinit var startBtn: Button
    private lateinit var pauseBtn: Button
    private lateinit var resumeBtn: Button
    private lateinit var resetBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val methodName = intent.getStringExtra(EXTRA_METHOD) ?: BrewMethod.POUR_OVER.name
        val method = BrewMethod.valueOf(methodName)
        val recipe = RecipeRepository.presetByMethod(method)
        val notifier = AndroidNotifier(this)
        engine = TimerEngine(recipe, { MonotonicClock.nowMs() }, notifier)
        ticker = Ticker {
            runOnUiThread {
                engine.tick(MonotonicClock.nowMs())
                render()
                if (engine.currentState() == TimerState.COMPLETED) ticker.stop()
            }
        }

        buildUi()
        render()
    }

    override fun onDestroy() {
        super.onDestroy()
        ticker.shutdown()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
        }

        methodLabel = TextView(this).apply { textSize = 18f; gravity = Gravity.CENTER }
        segmentLabel = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER }
        segmentTimeLabel = TextView(this).apply { textSize = 40f; gravity = Gravity.CENTER }
        totalTimeLabel = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER }
        stateLabel = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER }

        startBtn = Button(this).apply { text = "开始" }
        pauseBtn = Button(this).apply { text = "暂停" }
        resumeBtn = Button(this).apply { text = "继续" }
        resetBtn = Button(this).apply { text = "重置" }

        startBtn.setOnClickListener { engine.start(); ticker.start(); render() }
        pauseBtn.setOnClickListener { engine.pause(); render() }
        resumeBtn.setOnClickListener { engine.resume(); render() }
        resetBtn.setOnClickListener { engine.reset(); ticker.stop(); render() }

        listOf(
            methodLabel, segmentLabel, segmentTimeLabel, totalTimeLabel, stateLabel
        ).forEach { root.addView(it) }

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(startBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row1.addView(pauseBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(resumeBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row2.addView(resetBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row2)

        setContentView(root)
    }

    private fun render() {
        val s: TimerSnapshot = engine.snapshot()
        methodLabel.text = "${s.recipeName}（${s.brewMethod.displayName}）"
        segmentLabel.text = "第 ${s.segmentIndex + 1} 段 · ${s.segmentName}"
        segmentTimeLabel.text = fmt(s.segmentElapsedSec)
        totalTimeLabel.text =
            "本段 ${fmt(s.segmentElapsedSec)} / ${fmt(s.totalElapsedSec)} · 剩余 ${fmt(s.totalRemainSec)}（${s.totalRemainMin} 分钟）"
        stateLabel.text = when (s.state) {
            TimerState.IDLE -> "就绪"
            TimerState.RUNNING -> "计时中"
            TimerState.PAUSED -> "已暂停"
            TimerState.COMPLETED -> "已完成"
        }
        updateButtons(s.state)
    }

    private fun updateButtons(state: TimerState) {
        startBtn.isEnabled = state == TimerState.IDLE
        pauseBtn.isEnabled = state == TimerState.RUNNING
        resumeBtn.isEnabled = state == TimerState.PAUSED
        resetBtn.isEnabled = state != TimerState.IDLE
    }

    private fun fmt(totalSec: Int): String {
        val m = totalSec / 60
        val s = totalSec % 60
        return "%d:%02d".format(m, s)
    }
}
