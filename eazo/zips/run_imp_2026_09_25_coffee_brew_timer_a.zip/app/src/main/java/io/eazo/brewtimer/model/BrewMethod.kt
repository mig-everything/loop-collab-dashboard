package io.eazo.brewtimer.model

/**
 * 冲煮方式（与契约 02 §2 对齐，双端枚举取值一致）。
 */
enum class BrewMethod(val displayName: String) {
    POUR_OVER("手冲"),
    FRENCH_PRESS("法压"),
    AEROPRESS("爱乐压"),
    ESPRESSO("意式"),
    COLD_BREW("冷萃")
}
