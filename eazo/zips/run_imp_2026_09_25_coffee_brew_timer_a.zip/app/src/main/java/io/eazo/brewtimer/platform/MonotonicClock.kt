package io.eazo.brewtimer.platform

import android.os.SystemClock

/**
 * 单调时钟封装（契约 03 §2.1）：`SystemClock.elapsedRealtime()` 单调递增，
 * 与鸿蒙 `systemDateTime.getUptime` 同口径。
 */
object MonotonicClock {
    fun nowMs(): Long = SystemClock.elapsedRealtime()
}
