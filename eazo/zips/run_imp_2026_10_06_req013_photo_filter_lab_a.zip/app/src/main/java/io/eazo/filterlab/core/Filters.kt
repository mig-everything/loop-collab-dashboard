package io.eazo.filterlab.core

import io.eazo.filterlab.model.Pixel

/**
 * REQ-013 7 滤镜像素纯函数 + blend + applyFilter(契约 §3,对账主战场)。
 *
 * 禁用清单(契约 §9):全程整数运算禁浮点;一切除法走 floorDiv(Kotlin `Int./` 负商向零
 * 截断即违约,一律 Math.floorDiv);blend 禁四舍五入;alpha 除 invert 透传外不得修改
 * (blend 取 orig);core 禁 IO/网络/随机/系统时钟/图像编解码 API。
 */
object Filters {

    /** 灰度(Rec.709 亮度权重 299/587/114,除 1000)。 */
    fun grayscale(p: Pixel): Pixel {
        val y = Math.floorDiv(299 * p.r + 587 * p.g + 114 * p.b, 1000)
        return Pixel(y, y, y, p.a)
    }

    /** 反色(alpha 透传)。 */
    fun invert(p: Pixel): Pixel = Pixel(255 - p.r, 255 - p.g, 255 - p.b, p.a)

    /** 怀旧(经典系数矩阵 393/769/189、349/686/168、272/534/131,各除 1000,clamp)。 */
    fun sepia(p: Pixel): Pixel = Pixel(
        clamp(Math.floorDiv(393 * p.r + 769 * p.g + 189 * p.b, 1000)),
        clamp(Math.floorDiv(349 * p.r + 686 * p.g + 168 * p.b, 1000)),
        clamp(Math.floorDiv(272 * p.r + 534 * p.g + 131 * p.b, 1000)),
        p.a,
    )

    /** 亮度:delta ∈ [-100,100],全通道加后 clamp。 */
    fun brightness(p: Pixel, delta: Int): Pixel = Pixel(
        clamp(p.r + delta), clamp(p.g + delta), clamp(p.b + delta), p.a,
    )

    /** 对比度:factor ∈ [0,300](100=不变;128 灰点),c(v)=clamp(floorDiv((v-128)*factor,100)+128)。 */
    fun contrast(p: Pixel, factor: Int): Pixel = Pixel(c128(p.r, factor), c128(p.g, factor), c128(p.b, factor), p.a)

    private fun c128(v: Int, factor: Int): Int =
        clamp(Math.floorDiv((v - 128) * factor, 100) + 128)

    /** 暖色:amount ∈ [0,100],R+/B−,G 不动。 */
    fun warm(p: Pixel, amount: Int): Pixel =
        Pixel(clamp(p.r + amount), p.g, clamp(p.b - amount), p.a)

    /** 冷色:amount ∈ [0,100],R−/B+,G 不动。 */
    fun cool(p: Pixel, amount: Int): Pixel =
        Pixel(clamp(p.r - amount), p.g, clamp(p.b + amount), p.a)

    /** blend 强度混入(契约 §3.2):intensity ∈ [0,100],100=全量滤镜,0=原图;alpha 取 orig;禁四舍五入。 */
    fun blend(orig: Pixel, filtered: Pixel, intensity: Int): Pixel = Pixel(
        Math.floorDiv(orig.r * (100 - intensity) + filtered.r * intensity, 100),
        Math.floorDiv(orig.g * (100 - intensity) + filtered.g * intensity, 100),
        Math.floorDiv(orig.b * (100 - intensity) + filtered.b * intensity, 100),
        orig.a,
    )

    /** clamp(v,0,255) = max(0, min(255, v))。 */
    fun clamp(v: Int): Int = v.coerceIn(0, 255)

    /** 按 filterId 分发逐像素滤镜;固定滤镜忽略 param(契约 §3.3)。 */
    fun dispatch(filterId: String, p: Pixel, param: Int): Pixel = when (filterId) {
        "grayscale" -> grayscale(p)
        "invert" -> invert(p)
        "sepia" -> sepia(p)
        "brightness" -> brightness(p, param)
        "contrast" -> contrast(p, param)
        "warm" -> warm(p, param)
        "cool" -> cool(p, param)
        else -> throw IllegalArgumentException("unknown filterId: $filterId")
    }
}
