package io.eazo.filterlab.core

import io.eazo.filterlab.model.Image
import io.eazo.filterlab.model.Pixel

/**
 * REQ-013 内置示例图(契约 §4,常量数据面①):按生成公式推导,禁手打像素。
 * 公式:pixel(i,j) = { (j*36)%256, (i*51)%256, (j*17+i*34)%256, 255 },i∈[0,5] 行 j∈[0,7] 列。
 * 哈希锁:§4.2 序列化(每像素一行 `idx|r|g|b|a`,LF 连接,行尾无换行,UTF-8)
 * → SHA-256 = f80a56c80160051ff42ae94904f9842bf7e23e1a21533410c66a5ac233491ec5 / 838 字节(单测 case10)。
 */
object ImageData {

    const val CANON_W = 8
    const val CANON_H = 6
    const val CANON_PIXELS = 48
    const val CANONICAL_SHA256 = "f80a56c80160051ff42ae94904f9842bf7e23e1a21533410c66a5ac233491ec5"
    const val CANONICAL_BYTES = 838

    /** 规范序列化:双端各跑一次,哈希与字节数双断言(错 1 像素/乱 1 序必 FAIL)。 */
    fun serialize(pixels: List<Pixel>): String =
        pixels.mapIndexed { idx, p -> "$idx|${p.r}|${p.g}|${p.b}|${p.a}" }.joinToString("\n")

    /** 按契约 §4.1 公式生成 8×6 示例图(row-major)。 */
    fun canonicalImage(): Image = Image(CANON_W, CANON_H, canonicalPixels())

    fun canonicalPixels(): List<Pixel> {
        val out = ArrayList<Pixel>(CANON_PIXELS)
        for (i in 0 until CANON_H) {
            for (j in 0 until CANON_W) {
                out.add(Pixel((j * 36) % 256, (i * 51) % 256, (j * 17 + i * 34) % 256, 255))
            }
        }
        return out
    }
}
