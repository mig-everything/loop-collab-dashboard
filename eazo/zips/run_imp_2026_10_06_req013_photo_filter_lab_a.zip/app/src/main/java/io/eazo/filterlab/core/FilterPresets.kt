package io.eazo.filterlab.core

/**
 * REQ-013 7 滤镜预设表常量 —— 本文件由 scripts/gen_filter_constants.py 从
 * docs/arch/req013/seed/filter-presets-frozen.json 生成,禁手打(契约 §5.4 转录纪律,81ce715 契约 v1.0)。
 * 哈希锁:规范序列化(每行 `filterId|name|kind|defaultParam`,LF 连接,行尾无换行,UTF-8)
 * → SHA-256 = 12772cefe6498523f12ed1b5edea15a9dbcc1a0ac44d27e33ef607bb6a6bd8c8 / 162 字节,单测 case11 断言。
 * defaultParam 序列化为 str(int) 无符号(契约 §5.3);固定滤镜为 null(序列化空串)。
 */
object FilterPresets {

    const val FILTER_COUNT = 7
    const val PRESETS_SHA256 = "12772cefe6498523f12ed1b5edea15a9dbcc1a0ac44d27e33ef607bb6a6bd8c8"
    const val PRESETS_BYTES = 162

    val ENTRIES: List<PresetEntry> = listOf(
        PresetEntry("grayscale", "灰度", "fixed", null),
        PresetEntry("invert", "反色", "fixed", null),
        PresetEntry("sepia", "怀旧", "fixed", null),
        PresetEntry("brightness", "亮度", "param", 30),
        PresetEntry("contrast", "对比度", "param", 130),
        PresetEntry("warm", "暖色", "param", 40),
        PresetEntry("cool", "冷色", "param", 40),
    )

    fun byId(filterId: String): PresetEntry? = ENTRIES.firstOrNull { it.filterId == filterId }

    fun defaultParamOf(filterId: String): Int = byId(filterId)?.defaultParam ?: 0
}

data class PresetEntry(
    val filterId: String,
    val name: String,
    val kind: String,
    val defaultParam: Int?,
)
