package io.eazo.filterlab.platform

import android.content.Context
import io.eazo.filterlab.core.ApplyFilter
import io.eazo.filterlab.core.ImageData
import io.eazo.filterlab.model.Image
import io.eazo.filterlab.model.Pixel

/**
 * REQ-013 进程内单例(骨架模板硬规则 ①;契约 §2 AppRepo):滤镜实验室无跨日状态,
 * 内存态即可——当前图/当前滤镜/强度滑杆位,无持久化必要(契约 §2 本 REQ 持久化差异)。
 */
object AppRepo {

    /** 当前图(默认内置示例图;US-4 相册导入可替换,解码不入对账面)。 */
    private var currentImage: Image = ImageData.canonicalImage()

    /** 当前滤镜 id(默认表首)。 */
    private var currentFilterId: String = "grayscale"

    /** 当前参数滑杆位(参数滤镜 0..100,固定滤镜忽略)。 */
    private var currentParam: Int = 30

    /** 当前强度滑杆位 0..100(US-2 主径,与 param 互不干扰)。 */
    private var currentIntensity: Int = 100

    fun getRepo(context: Context): AppRepo = this

    fun image(): Image = currentImage

    fun setImage(image: Image) { currentImage = image }

    fun filterId(): String = currentFilterId

    fun setFilterId(filterId: String) { currentFilterId = filterId }

    fun param(): Int = currentParam

    fun setParam(param: Int) { currentParam = param.coerceIn(0, 100) }

    fun intensity(): Int = currentIntensity

    fun setIntensity(intensity: Int) { currentIntensity = intensity.coerceIn(0, 100) }

    /** 预览输出 = applyFilter(当前图, 当前滤镜, resolveParam, 当前强度)——数据纯推导,展示态只渲染。 */
    fun previewPixels(): List<Pixel> =
        ApplyFilter.apply(currentImage, currentFilterId, ApplyFilter.resolveParam(currentFilterId, currentParam), currentIntensity).pixels

    /** 硬规则 ②:refresh 只重读内存态(本 REQ 无持久化,空实现)。 */
    fun refresh() {}
}
