package io.eazo.filterlab.model

/**
 * REQ-013 数据模型(契约 §1,与 ArkTS model/Models.ets 1:1)。
 * 像素四通道全部 Int ∈ [0,255];Image row-major:index = i*width + j,len == width*height。
 */

/** 四通道像素。滤镜纯函数的输入/输出(契约 §3.1)。 */
data class Pixel(val r: Int, val g: Int, val b: Int, val a: Int)

/** 图像:像素按 row-major 一维存放。 */
data class Image(val width: Int, val height: Int, val pixels: List<Pixel>) {
    init {
        require(pixels.size == width * height) { "pixels.size must equal width*height" }
    }
}

/** 滤镜预设(契约 §5:kind ∈ {"fixed","param"};fixed 的 defaultParam 为 null)。 */
data class FilterPreset(val filterId: String, val name: String, val kind: String, val defaultParam: Int?)
