package io.eazo.filterlab.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.filterlab.core.ApplyFilter
import io.eazo.filterlab.core.FilterPresets
import io.eazo.filterlab.model.Pixel
import io.eazo.filterlab.platform.AppRepo
import io.eazo.filterlab.platform.CardDataBuilder
import io.eazo.filterlab.platform.Clock
import kotlin.math.floor

/**
 * REQ-013 主界面(US-1/2/3):单 Activity + Compose 声明式(骨架纪律:禁 XML 布局扇出)。
 * 三区:①滤镜横滑栏(US-1,7 预设 chip)②预览画布(AC-S3.1 原图/效果对比)
 * ③参数/强度双滑杆(US-2 主径:param 与 intensity 互不干扰,E9 接线口径)。
 * 数据全部经 AppRepo → core 纯函数推导,UI 只渲染(展示态,不入对账面)。
 * 600dp 自适应:宽屏(≥600dp)预览左右分栏,窄屏上下堆叠(AC-S7.1)。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    FilterLabScreen()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 骨架硬规则 ②:onResume 只重读内存态刷新。 */
    private fun render() {}
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(content = content)
}

@Composable
private fun FilterLabScreen() {
    var filterId by remember { mutableStateOf(AppRepo.filterId()) }
    var param by remember { mutableStateOf(AppRepo.param()) }
    var intensity by remember { mutableStateOf(AppRepo.intensity()) }
    val isWide = LocalConfiguration.current.screenWidthDp >= 600

    val original = remember { AppRepo.image().pixels }
    val preview = remember(filterId, param, intensity) {
        ApplyFilter.apply(
            AppRepo.image(), filterId, ApplyFilter.resolveParam(filterId, param), intensity,
        ).pixels
    }
    val card = remember { CardDataBuilder.build(Clock.todayEpochDay()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
    ) {
        Text("图片滤镜实验室", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("今日滤镜推荐:${card.filterName}", fontSize = 13.sp, color = Color(0xFF666666))
        Spacer(Modifier.height(10.dp))

        // ① 滤镜横滑栏(US-1:灰度/反色/怀旧/亮度/对比度/暖色/冷色,表序)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterPresets.ENTRIES.forEach { preset ->
                val selected = preset.filterId == filterId
                Text(
                    text = preset.name,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    color = if (selected) Color.White else Color(0xFF333333),
                    modifier = Modifier
                        .background(
                            if (selected) Color(0xFF1E88E5) else Color(0xFFEEEEEE),
                            RoundedCornerShape(16.dp),
                        )
                        .border(
                            1.dp,
                            if (selected) Color(0xFF1E88E5) else Color(0xFFDDDDDD),
                            RoundedCornerShape(16.dp),
                        )
                        .clickable {
                            filterId = preset.filterId
                            AppRepo.setFilterId(preset.filterId)
                        }
                        .padding(horizontal = 14.dp, vertical = 7.dp),
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        // ② 预览对比(AC-S3.1):原图 vs 效果,宽屏左右分栏 / 窄屏上下堆叠
        if (isWide) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PixelCanvas(original, Modifier.weight(1f).aspectRatio(4f / 3f), "原图")
                PixelCanvas(preview, Modifier.weight(1f).aspectRatio(4f / 3f), "效果")
            }
        } else {
            PixelCanvas(original, Modifier.fillMaxWidth().aspectRatio(4f / 3f), "原图")
            Spacer(Modifier.height(8.dp))
            PixelCanvas(preview, Modifier.fillMaxWidth().aspectRatio(4f / 3f), "效果")
        }
        Spacer(Modifier.height(12.dp))

        // ③ 滑杆区:参数(参数滤镜可见)+ 强度(US-2,0~100 → intensity)
        val entry = FilterPresets.byId(filterId)
        if (entry?.kind == "param") {
            SliderLabel("参数 ${entry.name} $param")
            Slider(
                value = param.toFloat(),
                onValueChange = {
                    param = floor(it).toInt().coerceIn(0, 100)
                    AppRepo.setParam(param)
                },
                valueRange = 0f..100f,
            )
        }
        SliderLabel("强度 $intensity%")
        Slider(
            value = intensity.toFloat(),
            onValueChange = {
                intensity = floor(it).toInt().coerceIn(0, 100)
                AppRepo.setIntensity(intensity)
            },
            valueRange = 0f..100f,
        )
    }
}

@Composable
private fun SliderLabel(text: String) {
    Text(text, fontSize = 13.sp, color = Color(0xFF444444))
}

/** 8×6 像素网格画布:逐格填色展示(展示态渲染,数据 = applyFilter 纯推导)。 */
@Composable
private fun PixelCanvas(pixels: List<Pixel>, modifier: Modifier = Modifier, label: String) {
    Column(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxWidth().height(160.dp).background(Color(0xFF222222))) {
            val cellW = size.width / 8f
            val cellH = size.height / 6f
            for (i in 0 until 6) {
                for (j in 0 until 8) {
                    val p = pixels[i * 8 + j]
                    drawRect(
                        color = Color(p.r, p.g, p.b, p.a),
                        topLeft = Offset(j * cellW, i * cellH),
                        size = Size(cellW + 0.5f, cellH + 0.5f),
                    )
                }
            }
        }
        Text(label, fontSize = 12.sp, color = Color(0xFF888888), modifier = Modifier.padding(top = 4.dp))
    }
}
