package io.eazo.filterlab.core

import io.eazo.filterlab.model.Image
import io.eazo.filterlab.model.Pixel

/**
 * REQ-013 applyFilter 端到端(契约 §3.3):row-major 遍历序不变 + intensity 分支。
 * intensity=100 直出滤镜输出;<100 逐像素 blend(orig, filtered, intensity)。
 * 禁非 row-major 遍历;param 与 intensity 互不干扰(E9 双变量锚点专判接线混淆)。
 */
object ApplyFilter {

    data class Result(val width: Int, val height: Int, val pixels: List<Pixel>)

    fun apply(image: Image, filterId: String, param: Int, intensity: Int = 100): Result {
        val out = ArrayList<Pixel>(image.pixels.size)
        for (p in image.pixels) {                     // row-major,序不变
            val filtered = Filters.dispatch(filterId, p, param)
            out.add(if (intensity < 100) Filters.blend(p, filtered, intensity) else filtered)
        }
        return Result(image.width, image.height, out)
    }

    /** 参数滤镜缺省 param 取预设表 defaultParam(契约 §3.3 参数口径);固定滤镜 param 忽略。 */
    fun resolveParam(filterId: String, param: Int?): Int =
        param ?: FilterPresets.defaultParamOf(filterId)
}
