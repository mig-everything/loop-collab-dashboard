package io.eazo.filterlab.platform

/**
 * REQ-013 平台时钟端口(core 禁系统时钟,契约 §2):日序号注入口径同 REQ-012(toEpochDay)。
 * 今日滤镜推荐 presetIndex(date) = date % 7 是纯推导,Clock 只负责注入"今天是第几天"。
 */
object Clock {

    /** 当前日序号(LocalDate.toEpochDay 口径,测试可注入替代)。 */
    fun todayEpochDay(): Long = java.time.LocalDate.now().toEpochDay()

    /** 日序号 → 0..6 预设下标(契约 §5.2;Kotlin % 对负值向零取余,先归非负再模,与 ArkTS ((d%7)+7)%7 同语义)。 */
    fun presetIndex(epochDay: Long): Int = (epochDay % 7).toInt().let { if (it < 0) it + 7 else it }
}
