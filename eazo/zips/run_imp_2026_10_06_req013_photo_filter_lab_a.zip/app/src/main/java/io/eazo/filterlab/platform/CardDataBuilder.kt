package io.eazo.filterlab.platform

import io.eazo.filterlab.core.FilterPresets

/**
 * REQ-013 今日滤镜推荐(US-6 Should,契约 §5.2):presetIndex(date) = date % 7 纯推导,
 * 推荐名 = 预设表[presetIndex].name。零新增契约语义。
 */
object CardDataBuilder {

    data class CardData(val title: String, val filterId: String, val filterName: String)

    fun presetIndex(date: Long): Int = Clock.presetIndex(date)

    fun build(date: Long): CardData {
        val idx = presetIndex(date)
        val entry = FilterPresets.ENTRIES[idx]
        return CardData("今日滤镜", entry.filterId, entry.name)
    }
}
