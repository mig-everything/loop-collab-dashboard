package io.eazo.filterlab.core

import io.eazo.filterlab.model.Pixel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

/**
 * REQ-013 契约双端单测(Android 基线侧,02-interface-contract.md §6 全集)。
 * 期望值全部取 scripts/gen_filter_constants.py 本机重算锚点(seed/req013-anchors.json,禁手抄):
 *   示例图 SHA-256 = f80a56c80160051ff42ae94904f9842bf7e23e1a21533410c66a5ac233491ec5 / 838B
 *   预设表 SHA-256 = 12772cefe6498523f12ed1b5edea15a9dbcc1a0ac44d27e33ef607bb6a6bd8c8 / 162B
 *   端到端 E1~E9 与 SA 参照机(sa_req013_design_verify.py 68/68)一致。
 * 与鸿蒙 Hypium(FilterContract.test.ets)一一同源同集同期望(差分执行基准)。
 */
class FilterContractTest {

    private fun px(r: Int, g: Int, b: Int, a: Int = 255) = Pixel(r, g, b, a)

    private fun assertPx(expected: IntArray, actual: Pixel) {
        assertEquals(expected.joinToString(","), intArrayOf(actual.r, actual.g, actual.b, actual.a).joinToString(","))
    }

    private fun sha256(text: String): String =
        MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
            .joinToString("") { b -> "%02x".format(b) }

    // ---------- §6.1 灰度 G / 反色 I / 亮度 B ----------

    /** case1 G1: 纯红权重 299/1000。 */
    @Test fun `case1_G1_grayscale_pure_red`() =
        assertPx(intArrayOf(76, 76, 76, 255), Filters.grayscale(px(255, 0, 0)))

    /** case2 G2: 纯绿权重 587/1000;round 真捕手(149.685 非整商)。 */
    @Test fun `case2_G2_grayscale_pure_green`() =
        assertPx(intArrayOf(149, 149, 149, 255), Filters.grayscale(px(0, 255, 0)))

    /** case3 G3: 纯蓝权重 114/1000。 */
    @Test fun `case3_G3_grayscale_pure_blue`() =
        assertPx(intArrayOf(29, 29, 29, 255), Filters.grayscale(px(0, 0, 255)))

    /** case4 G4: 白色不变。 */
    @Test fun `case4_G4_grayscale_white`() =
        assertPx(intArrayOf(255, 255, 255, 255), Filters.grayscale(px(255, 255, 255)))

    /** case5 I1: 黑↔白。 */
    @Test fun `case5_I1_invert_black`() =
        assertPx(intArrayOf(255, 255, 255, 255), Filters.invert(px(0, 0, 0)))

    /** case6 I2: 中间值 + alpha 透传。 */
    @Test fun `case6_I2_invert_alpha_passthrough`() =
        assertPx(intArrayOf(0, 127, 191, 200), Filters.invert(px(255, 128, 64, 200)))

    /** case7 B1: 正向加亮 delta=50。 */
    @Test fun `case7_B1_brightness_plus50`() =
        assertPx(intArrayOf(150, 200, 250, 255), Filters.brightness(px(100, 150, 200), 50))

    /** case8 B2: 下溢 clamp 0。 */
    @Test fun `case8_B2_brightness_underflow`() =
        assertPx(intArrayOf(0, 0, 0, 255), Filters.brightness(px(10, 20, 30), -100))

    /** case9 B3: 上溢 clamp 255。 */
    @Test fun `case9_B3_brightness_overflow`() =
        assertPx(intArrayOf(255, 255, 255, 255), Filters.brightness(px(200, 200, 200), 100))

    // ---------- §6.2 对比度 C / 怀旧 S / 暖冷 W·Co ----------

    /** case10 C1: 负差向下取整(−4200/100 整除,floor=trunc)。 */
    @Test fun `case10_C1_contrast_floor`() =
        assertPx(intArrayOf(86, 86, 86, 255), Filters.contrast(px(100, 100, 100), 150))

    /** case11 C2: 下溢 clamp。 */
    @Test fun `case11_C2_contrast_underflow`() =
        assertPx(intArrayOf(0, 0, 0, 255), Filters.contrast(px(64, 64, 64), 200))

    /** case12 C3: 上溢 clamp。 */
    @Test fun `case12_C3_contrast_overflow`() =
        assertPx(intArrayOf(255, 255, 255, 255), Filters.contrast(px(192, 192, 192), 200))

    /** case13 C4': TR-Req C1 补锚点,−4228/100 非整商,floor=−43→85;trunc→86 被抓。 */
    @Test fun `case13_C4p_contrast_floor_vs_trunc`() =
        assertPx(intArrayOf(85, 85, 85, 255), Filters.contrast(px(100, 100, 100), 151))

    /** case14 S1: 白色暖化。 */
    @Test fun `case14_S1_sepia_white`() =
        assertPx(intArrayOf(255, 255, 238, 255), Filters.sepia(px(255, 255, 255)))

    /** case15 S2: 中灰矩阵。 */
    @Test fun `case15_S2_sepia_midgray`() =
        assertPx(intArrayOf(172, 153, 119, 255), Filters.sepia(px(128, 128, 128)))

    /** case16 W1: R+/B−,G 不动。 */
    @Test fun `case16_W1_warm`() =
        assertPx(intArrayOf(150, 100, 50, 255), Filters.warm(px(100, 100, 100), 50))

    /** case17 Co1: R−/B+,G 不动。 */
    @Test fun `case17_Co1_cool`() =
        assertPx(intArrayOf(50, 100, 150, 255), Filters.cool(px(100, 100, 100), 50))

    // ---------- §6.3 强度混入 BL ----------

    /** case18 BL1: 中值(整除精确)。 */
    @Test fun `case18_BL1_blend_mid`() =
        assertPx(intArrayOf(150, 150, 150, 255), Filters.blend(px(200, 200, 200), px(100, 100, 100), 50))

    /** case19 BL2: intensity=0 即原图。 */
    @Test fun `case19_BL2_blend_zero`() =
        assertPx(intArrayOf(10, 20, 30, 255), Filters.blend(px(10, 20, 30), px(250, 240, 230), 0))

    /** case20 BL3: intensity=100 即纯滤镜。 */
    @Test fun `case20_BL3_blend_full`() =
        assertPx(intArrayOf(250, 240, 230, 255), Filters.blend(px(10, 20, 30), px(250, 240, 230), 100))

    /** case21 BL4': TR-Req C1 补锚点,通道商 12.5/22.5/32.5 非整商,floor=12/22/32;round→13/23/33 被抓。 */
    @Test fun `case21_BL4p_blend_floor_vs_round`() =
        assertPx(intArrayOf(12, 22, 32, 255), Filters.blend(px(10, 20, 30), px(15, 25, 35), 50))

    // ---------- §6.4 常量数据面哈希 H ----------

    /** case22 H1: 内置示例图规范序列化 SHA-256 全量锁(838B,错 1 像素/乱 1 序必 FAIL)。 */
    @Test fun `case22_H1_canonical_img_sha256_lock`() {
        val pixels = ImageData.canonicalPixels()
        assertEquals(48, pixels.size)
        assertPx(intArrayOf(0, 0, 0, 255), pixels.first())
        assertPx(intArrayOf(252, 255, 33, 255), pixels.last())
        val ser = ImageData.serialize(pixels)
        assertEquals(ImageData.CANONICAL_BYTES, ser.toByteArray(Charsets.UTF_8).size)
        assertEquals("f80a56c80160051ff42ae94904f9842bf7e23e1a21533410c66a5ac233491ec5", sha256(ser))
        assertEquals(ImageData.CANONICAL_SHA256, sha256(ser))
    }

    /** case23 H2: 7 滤镜预设表规范序列化 SHA-256 全量锁(162B)。 */
    @Test fun `case23_H2_presets_sha256_lock`() {
        val ser = FilterPresets.ENTRIES.joinToString("\n") {
            "${it.filterId}|${it.name}|${it.kind}|${it.defaultParam ?: ""}"
        }
        assertEquals(FilterPresets.PRESETS_BYTES, ser.toByteArray(Charsets.UTF_8).size)
        assertEquals("12772cefe6498523f12ed1b5edea15a9dbcc1a0ac44d27e33ef607bb6a6bd8c8", sha256(ser))
        assertEquals(FilterPresets.PRESETS_SHA256, sha256(ser))
        // 结构断言:7 条、3 fixed + 4 param、表序、字符域禁令(契约 §5.3)
        assertEquals(7, FilterPresets.ENTRIES.size)
        assertEquals(3, FilterPresets.ENTRIES.count { it.kind == "fixed" })
        assertEquals(4, FilterPresets.ENTRIES.count { it.kind == "param" })
        assertEquals(
            listOf("grayscale", "invert", "sepia", "brightness", "contrast", "warm", "cool"),
            FilterPresets.ENTRIES.map { it.filterId },
        )
        assertEquals("grayscale|灰度|fixed|", ser.lines().first())
        assertEquals("cool|冷色|param|40", ser.lines().last())
        FilterPresets.ENTRIES.forEach {
            listOf(it.filterId, it.name, it.kind).forEach { f ->
                assertFalse(f.contains('|') || f.contains('\n') || f.contains('\r'))
            }
        }
        assertEquals(30, FilterPresets.defaultParamOf("brightness"))
        assertEquals(130, FilterPresets.defaultParamOf("contrast"))
        assertEquals(40, FilterPresets.defaultParamOf("warm"))
        assertEquals(40, FilterPresets.defaultParamOf("cool"))
    }

    // ---------- §6.5 applyFilter 端到端 E1~E9(示例图输入,输出序列化哈希) ----------

    private fun eHash(filterId: String, param: Int?, intensity: Int): String {
        val image = ImageData.canonicalImage()
        val result = ApplyFilter.apply(image, filterId, ApplyFilter.resolveParam(filterId, param), intensity)
        assertEquals(image.width, result.width)
        assertEquals(image.height, result.height)
        return sha256(ImageData.serialize(result.pixels))
    }

    /** case24 E1: 端到端灰度。 */
    @Test fun `case24_E1_grayscale_full`() =
        assertEquals("5de7daea96d868fb97424b95764c9d754afa1ad49896afb146a8bdc728d7062b", eHash("grayscale", null, 100))

    /** case25 E2: 端到端怀旧。 */
    @Test fun `case25_E2_sepia_full`() =
        assertEquals("8d18b1b8d02597ae3be82481c08f33cad7cbe601fb0c1109c844d06bad54a4c0", eHash("sepia", null, 100))

    /** case26 E3: 端到端反色。 */
    @Test fun `case26_E3_invert_full`() =
        assertEquals("18b3e057a2875337b433416022cd01ffc555680b1a22b053ce197fcc83652a6f", eHash("invert", null, 100))

    /** case27 E4: 端到端亮度 30。 */
    @Test fun `case27_E4_brightness_full`() =
        assertEquals("5dbf508375ab8bad4d16a9d5407790baacb1d43608841dbecd73e5540e3ea791", eHash("brightness", 30, 100))

    /** case28 E5: 端到端对比度 130。 */
    @Test fun `case28_E5_contrast_full`() =
        assertEquals("ae95ba7bd0df3c5d73cc301f86acf5655ed31a200bf933c7ad95f4af9bd60295", eHash("contrast", 130, 100))

    /** case29 E6: 端到端暖色 40。 */
    @Test fun `case29_E6_warm_full`() =
        assertEquals("3ff5492fd56ea4bda21765dfc00eaf62e8f8e3a105ca26030ad0cc3629b1eebc", eHash("warm", 40, 100))

    /** case30 E7: 端到端冷色 40。 */
    @Test fun `case30_E7_cool_full`() =
        assertEquals("fd1557a3c1d5b317f2a701d40172c3d32873251c07d0a638f5f28ac82dd59515", eHash("cool", 40, 100))

    /** case31 E8: TR-Req C2 补锚点,强度分支端到端(grayscale/50);「忽略 intensity」错误实现被抓获。 */
    @Test fun `case31_E8_grayscale_intensity50`() =
        assertEquals("5fe15e7a21d703e26f604c7636069eb82515f60741cd16d7a140c093af4782cc", eHash("grayscale", null, 50))

    /** case32 E9: TR-Req C2 补锚点,参数滤镜+强度双变量(warm 40/30);判别 param 与 intensity 接线混淆。 */
    @Test fun `case32_E9_warm_param40_intensity30`() =
        assertEquals("5ead56e3074a1af8eb4c3998b41ff4b7e78deffa4aeb9bd18a0baf328cea1ea9", eHash("warm", 40, 30))

    // ---------- §8 参数直断言 + 判别力佐证 ----------

    /** case33 §8 参数直断言(常量面 + floorDiv 负值语义 + 三补锚点单点重断)。 */
    @Test fun `case33_params_direct`() {
        assertEquals(8, ImageData.CANON_W)
        assertEquals(6, ImageData.CANON_H)
        assertEquals(48, ImageData.CANON_PIXELS)
        assertEquals(7, FilterPresets.FILTER_COUNT)
        assertEquals(838, ImageData.CANONICAL_BYTES)
        assertEquals(162, FilterPresets.PRESETS_BYTES)
        assertEquals(-43, Math.floorDiv(-4228, 100))   // 负值向下取整;截断给 -42 即违约
        assertPx(intArrayOf(149, 149, 149, 255), Filters.grayscale(px(0, 255, 0)))
        assertPx(intArrayOf(85, 85, 85, 255), Filters.contrast(px(100, 100, 100), 151))
        assertPx(intArrayOf(12, 22, 32, 255), Filters.blend(px(10, 20, 30), px(15, 25, 35), 50))
    }

    /** case34 判别力佐证:floor 实现 ≠ round/trunc 错误实现(G2/C4'/BL4' 三捕手双值差)。 */
    @Test fun `case34_discriminators_floor_not_round_trunc`() {
        // G2:round(149.685)=150 被 G2 抓
        assertEquals(149, Filters.grayscale(px(0, 255, 0)).r)
        assertTrue(149.0 != kotlin.math.round(0.299 * 0 + 0.587 * 255 + 0.114 * 0))
        // C4':trunc(-42.28)=-42 → 86 被 C4' 抓(floor=-43 → 85)
        assertEquals(-43, Math.floorDiv(-4228, 100))
        assertEquals(-42, -4228 / 100)                 // Kotlin 裸 / 即向零截断(违约写法,反例留证)
        // BL4':round(12.5)=13 被 BL4' 抓
        assertPx(intArrayOf(12, 22, 32, 255), Filters.blend(px(10, 20, 30), px(15, 25, 35), 50))
    }

    /** case35 row-major 遍历序:E3 反色首末像素与直接反色一致(序不变)。 */
    @Test fun `case35_row_major_order`() {
        val src = ImageData.canonicalImage()
        val out = ApplyFilter.apply(src, "invert", 0, 100).pixels
        assertEquals(48, out.size)
        assertPx(intArrayOf(255, 255, 255, 255), out.first())
        assertPx(intArrayOf(3, 0, 222, 255), out.last())   // 255-{252,255,33}
        for (i in out.indices) {
            val p = src.pixels[i]
            assertEquals(255 - p.r, out[i].r)
            assertEquals(255 - p.g, out[i].g)
            assertEquals(255 - p.b, out[i].b)
            assertEquals(p.a, out[i].a)
        }
    }

    /** case36 今日推荐 presetIndex(date)=date%7 纯推导(US-6;0..6 循环)。 */
    @Test fun `case36_preset_index_recommendation`() {
        assertEquals(0, io.eazo.filterlab.platform.Clock.presetIndex(0))
        assertEquals(1, io.eazo.filterlab.platform.Clock.presetIndex(1))
        assertEquals(6, io.eazo.filterlab.platform.Clock.presetIndex(6))
        assertEquals(0, io.eazo.filterlab.platform.Clock.presetIndex(7))
        assertEquals(3, io.eazo.filterlab.platform.Clock.presetIndex(10))
        val card = io.eazo.filterlab.platform.CardDataBuilder.build(10)
        assertEquals("brightness", card.filterId)
        assertEquals("亮度", card.filterName)
    }
}
