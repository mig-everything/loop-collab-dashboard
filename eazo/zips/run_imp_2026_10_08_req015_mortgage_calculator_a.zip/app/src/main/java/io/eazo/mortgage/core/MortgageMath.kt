package io.eazo.mortgage.core

import io.eazo.mortgage.model.Mode
import io.eazo.mortgage.model.PlanRow
import io.eazo.mortgage.model.Summary

/**
 * REQ-015 纯函数核心（契约 §3 逐行落码，02-interface-contract.md v1.0）。
 * 差分主战场：无 IO/网络/随机/系统时钟/UI API；同一输入恒得同一输出。
 *
 * 舍入/整数纪律（契约 §9 禁用清单）：
 * - 金额全程 Long 定点「分」（禁 Int——中间积 10^14 > 2^31；禁浮点承载）。
 * - 利息整数分数式 roundHalfUp（禁浮点式/银行家舍入/截断除法）。
 * - 唯一浮点量 = 等额本息月供 M 的一次 double pow，写法锁定（禁拆项重排）。
 * - 总利息 = Σ payment 整数累加 − P_分（禁 M×n−P 浮点捷径）。
 */
object MortgageMath {

    const val RATE_DENOM: Long = 12000000L        // 月利率分母：R4/12000000 = 月利率
    const val HALF_RATE_DENOM: Long = 6000000L    // = RATE_DENOM/2，精确（分母偶数）
    const val DEFAULT_P_YUAN: Double = 1000000.0  // 非法输入回退默认（AC-S1.2）
    const val DEFAULT_RATE: Double = 4.9          // %
    const val DEFAULT_YEARS: Int = 30
    const val P_MAX_FEN: Long = 1000000000L       // 输入域上界（1000 万元），校验用
    const val R4_MAX: Long = 100000L              // 利率域上界（10%），校验用
    const val N_MAX: Int = 360                    // 年限域上界（30 年），校验用

    // ===== 定点转换（契约 §3.0）=====

    /** 元 → 分；仅两处用（P_分/R4 转换 + M 锁整数）。 */
    fun roundHalfUpFloat(x: Double): Long = Math.floor(x + 0.5).toLong()

    /** 整数分数四舍五入（b 恒为偶数，b/2 精确）；正值域。 */
    fun roundHalfUpFrac(a: Long, b: Long): Long = (a + b / 2) / b

    /** 元 → 分定点。 */
    fun toFen(yuan: Double): Long = roundHalfUpFloat(yuan * 100.0)

    /** % → 万分之一（4.9% → 49000）。 */
    fun toRate4(percent: Double): Long = roundHalfUpFloat(percent * 10000.0)

    // ===== 逐月利息（契约 §3.1，★全整数无浮点）=====

    /** 计息基 = 本期期初剩余本金（期 1 的计息基 = P_分）。 */
    fun interestOf(remaining: Long, r4: Long): Long = (remaining * r4 + HALF_RATE_DENOM) / RATE_DENOM

    // ===== 等额本息月供 M（契约 §3.2，★唯一浮点量）=====

    /** 写法锁定（C2）：r = R4/12e6；q = pow(1+r, n)；M = roundHalfUp(P*r*q/(q−1))。 */
    fun equalPayment(pFen: Long, r4: Long, n: Int): Long {
        if (r4 == 0L) return roundHalfUpFrac(pFen, n.toLong())  // 契约 §6.6：R=0 合法域退化（q−1=0），M=P/n 无息分期
        val r: Double = r4 / 12000000.0
        val q: Double = Math.pow(1.0 + r, n.toDouble())
        return Math.floor(pFen * r * q / (q - 1.0) + 0.5).toLong()
    }

    // ===== 计划表递推（契约 §3.3/§3.4，整数 + 尾差归零）=====

    /** 等额本息逐月递推：末月 principal = remaining（尾差归零），末月 payment ≠ M 正常。 */
    fun amortizeEqualTotal(pFen: Long, r4: Long, n: Int): List<PlanRow> {
        val m = equalPayment(pFen, r4, n)
        val rows = ArrayList<PlanRow>(n)
        var remaining = pFen
        for (i in 1..n) {
            val interest = interestOf(remaining, r4)
            val principal = if (i == n) remaining else m - interest
            rows.add(PlanRow(i, principal + interest, principal, interest, remaining - principal))
            remaining -= principal
        }
        return rows
    }

    /** 等额本金逐月递推：base = roundHalfUpFrac(P, n)；末月 principal = remaining。 */
    fun amortizeEqualPrincipal(pFen: Long, r4: Long, n: Int): List<PlanRow> {
        val base = roundHalfUpFrac(pFen, n.toLong())
        val rows = ArrayList<PlanRow>(n)
        var remaining = pFen
        for (i in 1..n) {
            val interest = interestOf(remaining, r4)
            val principal = if (i == n) remaining else base
            rows.add(PlanRow(i, principal + interest, principal, interest, remaining - principal))
            remaining -= principal
        }
        return rows
    }

    /** 契约 §3.3/§3.4 统一入口（mode 分派）。 */
    fun amortize(pFen: Long, r4: Long, n: Int, mode: Mode): List<PlanRow> =
        if (mode == Mode.ET) amortizeEqualTotal(pFen, r4, n) else amortizeEqualPrincipal(pFen, r4, n)

    // ===== 汇总（契约 §3.5）=====

    /**
     * 总还款 = Σ payment_i 整数累加（★禁 M×n−P 浮点捷径）；总利息 = 总还款 − P_分。
     * monthly：ET = M_分（= rows[0].payment，§3.3 前 n−1 行 payment 恒等于 M，n≥12 恒成立）；
     * EP = 首月月供（展示口径，Summary 不承担 EP 全序列）。
     */
    fun summarize(rows: List<PlanRow>, pFen: Long, mode: Mode): Summary {
        var totalPayment = 0L
        for (row in rows) totalPayment += row.payment
        return Summary(rows[0].payment, totalPayment - pFen, totalPayment)
    }
}
