package io.eazo.mortgage.platform

import io.eazo.mortgage.model.MortgageInput

/**
 * 进程内单例（契约 §2 platform 端口）：当前输入参数，内存态，无跨日状态（本 REQ 无会话语义）。
 */
object AppRepo {

    @Volatile
    private var current: MortgageInput = MortgageInput(1000000.0, 4.9, 30, io.eazo.mortgage.model.Mode.ET)

    fun get(): MortgageInput = current

    fun update(input: MortgageInput) {
        current = input
    }
}
