package io.eazo.mortgage.platform

import io.eazo.mortgage.core.MortgageCore
import io.eazo.mortgage.model.CalcResult
import io.eazo.mortgage.model.MortgageInput

/**
 * 桌面卡片数据（契约 §2 platform 端口，US-7 Should）：本月月供 + 剩余本金（首月口径，纯推导）。
 */
object CardDataBuilder {

    data class CardData(val monthlyPaymentFen: Long, val remainingPrincipalFen: Long)

    /** 首月口径：月供 = rows[0].payment；剩余本金 = rows[0].remaining。 */
    fun build(input: MortgageInput): CardData {
        val result: CalcResult = MortgageCore.calc(MortgageCore.validate(input))
        val first = result.rows.first()
        return CardData(first.payment, first.remaining)
    }
}
