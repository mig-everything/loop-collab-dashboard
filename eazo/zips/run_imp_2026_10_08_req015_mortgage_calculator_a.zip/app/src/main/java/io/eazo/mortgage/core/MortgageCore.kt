package io.eazo.mortgage.core

import io.eazo.mortgage.model.CalcResult
import io.eazo.mortgage.model.CompareResult
import io.eazo.mortgage.model.Mode
import io.eazo.mortgage.model.MortgageInput
import io.eazo.mortgage.model.PlanRow
import io.eazo.mortgage.model.Summary

/**
 * REQ-015 组合入口（契约 §2/§3.5/§3.6）：validate（输入校验+默认值回退）/
 * calc（输入→PlanRow[]+Summary）/ compare（双方式对比，AC-S6.1）。
 */
object MortgageCore {

    /** 输入校验（契约 §3.6，AC-S1.2）：任一非法 → 回退默认 (100 万/4.9%/30 年，mode 不变)。 */
    fun validate(input: MortgageInput): MortgageInput {
        val pOk = input.principalYuan > 0.0 && MortgageMath.toFen(input.principalYuan) <= MortgageMath.P_MAX_FEN
        val rOk = input.ratePercent in 0.0..10.0
        val yOk = input.years > 0 && input.years <= 30
        return if (pOk && rOk && yOk) input
        else MortgageInput(MortgageMath.DEFAULT_P_YUAN, MortgageMath.DEFAULT_RATE, MortgageMath.DEFAULT_YEARS, input.mode)
    }

    /** 输入 → 计划表 + 汇总（US-1/4/5）。调用方负责先 validate（本函数不复核，纯函数纪律）。 */
    fun calc(input: MortgageInput): CalcResult {
        val pFen = MortgageMath.toFen(input.principalYuan)
        val r4 = MortgageMath.toRate4(input.ratePercent)
        val n = input.years * 12
        val rows: List<PlanRow> = MortgageMath.amortize(pFen, r4, n, input.mode)
        return CalcResult(rows, MortgageMath.summarize(rows, pFen, input.mode))
    }

    /** 双方式对比（契约 §3.5，AC-S6.1）：totalInterestDiff = 总息_ET − 总息_EP（案例 A = 17357404）。 */
    fun compare(input: MortgageInput): CompareResult {
        val et = calc(MortgageInput(input.principalYuan, input.ratePercent, input.years, Mode.ET))
        val ep = calc(MortgageInput(input.principalYuan, input.ratePercent, input.years, Mode.EP))
        return CompareResult(et, ep, et.summary.totalInterest - ep.summary.totalInterest)
    }
}
