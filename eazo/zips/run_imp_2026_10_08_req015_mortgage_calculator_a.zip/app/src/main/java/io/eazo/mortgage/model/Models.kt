package io.eazo.mortgage.model

/**
 * REQ-015 数据模型（契约 §1.1，与鸿蒙 ArkTS model/Models.ets 1:1）。
 * 金额一律整数「分」(Long)；年利率整数「万分之一」R4；月数 n 恒为偶数（Y 整年）。
 */
enum class Mode { ET, EP }

/** UI 层输入（元/%/年）；core 层先转 (P_分, R4, n) 再计算。 */
data class MortgageInput(
    val principalYuan: Double,
    val ratePercent: Double,
    val years: Int,
    val mode: Mode,
)

/** 计划表行（period 从 1 起；remaining 为本期还款后余额）。 */
data class PlanRow(
    val period: Int,
    val payment: Long,
    val principal: Long,
    val interest: Long,
    val remaining: Long,
)

/** 汇总：ET monthly = M_分；EP monthly = 首月月供（展示口径，契约 §3.5 注）。 */
data class Summary(
    val monthly: Long,
    val totalInterest: Long,
    val totalPayment: Long,
)

/** calc 组合产物：计划表 + 汇总（契约 §3.5）。 */
data class CalcResult(
    val rows: List<PlanRow>,
    val summary: Summary,
)

/** compare 组合产物：双方式对比（契约 §3.5，AC-S6.1）。 */
data class CompareResult(
    val et: CalcResult,
    val ep: CalcResult,
    val totalInterestDiff: Long,
)
