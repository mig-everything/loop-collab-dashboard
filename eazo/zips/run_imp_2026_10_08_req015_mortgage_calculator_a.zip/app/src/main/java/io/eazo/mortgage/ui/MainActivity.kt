package io.eazo.mortgage.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.mortgage.core.MortgageCore
import io.eazo.mortgage.model.CalcResult
import io.eazo.mortgage.model.Mode
import io.eazo.mortgage.model.MortgageInput
import io.eazo.mortgage.model.PlanRow
import io.eazo.mortgage.model.Summary

/**
 * REQ-015 房贷计算器（Android Compose 基线，展示态）：
 * 输入表单 + 结果汇总（本息构成环形图）+ 逐月还款计划表（LazyColumn）。
 * 数据态全部来自 core 纯函数（MortgageCore.calc），UI 零业务逻辑（契约 §2 展示态边界）。
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MortgageApp() }
    }
}

private val ink = Color(0xFF17203A)
private val inkWeak = Color(0xFF8A93A6)
private val cardBg = Color(0xFFFFFFFF)
private val pageBg = Color(0xFFF7F5F0)
private val etColor = Color(0xFF3D6BE0)
private val epColor = Color(0xFFE8A33D)

@Composable
fun MortgageApp() {
    var principalText by remember { mutableStateOf("1000000") }
    var rateText by remember { mutableStateOf("4.9") }
    var yearsText by remember { mutableStateOf("30") }
    var isEp by remember { mutableStateOf(false) }

    val input = MortgageInput(
        principalText.toDoubleOrNull() ?: 0.0,
        rateText.toDoubleOrNull() ?: 0.0,
        yearsText.toIntOrNull() ?: 0,
        if (isEp) Mode.EP else Mode.ET,
    )
    val validated = MortgageCore.validate(input)
    val et: CalcResult = MortgageCore.calc(validated.copy(mode = Mode.ET))
    val ep: CalcResult = MortgageCore.calc(validated.copy(mode = Mode.EP))
    val current = if (isEp) ep else et
    val other = if (isEp) et else ep

    MaterialTheme {
        Box(Modifier.fillMaxSize().background(pageBg)) {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                item {
                    Spacer(Modifier.height(24.dp))
                    Text("房贷计算器", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = ink)
                    Spacer(Modifier.height(4.dp))
                    Text("等额本息 / 等额本金 · 定点整数对账", fontSize = 13.sp, color = inkWeak)
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = principalText, onValueChange = { principalText = it },
                            label = { Text("贷款金额(元)") }, modifier = Modifier.weight(1.4f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                        )
                        OutlinedTextField(
                            value = rateText, onValueChange = { rateText = it },
                            label = { Text("年利率(%)") }, modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                        )
                        OutlinedTextField(
                            value = yearsText, onValueChange = { yearsText = it },
                            label = { Text("年限(年)") }, modifier = Modifier.weight(0.9f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (isEp) "等额本金" else "等额本息",
                            fontWeight = FontWeight.SemiBold, color = ink,
                        )
                        Spacer(Modifier.width(8.dp))
                        Switch(checked = isEp, onCheckedChange = { isEp = it })
                        Spacer(Modifier.weight(1f))
                        Text(
                            if (validated != input) "已回退默认(100万/4.9%/30年)" else "",
                            fontSize = 12.sp, color = Color(0xFFC0653A),
                        )
                    }
                    Spacer(Modifier.height(16.dp))
                    SummaryCard(current.summary, if (isEp) epColor else etColor)
                    Spacer(Modifier.height(12.dp))
                    DonutCard(current.summary)
                    Spacer(Modifier.height(12.dp))
                    // 双方式对比卡:标签与值按方式固定绑定(IPD-416 P1-2 修复:此前传 current/other,
                    // EP 态时 current=EP 导致「等额本息总利息」行显示 ¥737041.08(实为 EP 值)标签互换;
                    // 现恒传 et/ep 两结果,行序与标签语义一致,与鸿蒙 MortgagePage 对比卡同构)。
                    CompareCard(et.summary, ep.summary)
                    Spacer(Modifier.height(12.dp))
                    Text("还款计划表（${current.rows.size} 期）", fontWeight = FontWeight.SemiBold, color = ink)
                    Spacer(Modifier.height(8.dp))
                }
                items(current.rows) { row ->
                    PlanRowItem(row)
                    Divider(color = Color(0x118A93A6))
                }
                item { Spacer(Modifier.height(32.dp)) }
            }
        }
    }
}

private fun fenToYuanText(fen: Long): String {
    val neg = fen < 0
    val abs = if (neg) -fen else fen
    val s = (abs / 100).toString() + "." + (abs % 100).toString().padStart(2, '0')
    return if (neg) "-$s" else s
}

@Composable
private fun SummaryCard(s: Summary, accent: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = cardBg), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("月供", fontSize = 12.sp, color = inkWeak)
            Text(
                "¥" + fenToYuanText(s.monthly),
                fontSize = 30.sp, fontWeight = FontWeight.Bold, color = accent,
            )
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("总还款", fontSize = 12.sp, color = inkWeak)
                    Text("¥" + fenToYuanText(s.totalPayment), fontWeight = FontWeight.SemiBold, color = ink)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("总利息", fontSize = 12.sp, color = inkWeak)
                    Text("¥" + fenToYuanText(s.totalInterest), fontWeight = FontWeight.SemiBold, color = ink)
                }
            }
        }
    }
}

@Composable
private fun DonutCard(s: Summary) {
    Card(colors = CardDefaults.cardColors(containerColor = cardBg), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("本息构成", fontSize = 12.sp, color = inkWeak)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(110.dp), contentAlignment = Alignment.Center) {
                    androidx.compose.foundation.Canvas(Modifier.size(110.dp)) {
                        val principalRatio = s.totalPayment.toFloat().let { if (it == 0f) 0f else 1f - s.totalInterest.toFloat() / it }
                        drawArc(
                            color = etColor, startAngle = -90f,
                            sweepAngle = 360f * principalRatio, useCenter = false,
                            style = Stroke(width = 16.dp.toPx()),
                        )
                        drawArc(
                            color = Color(0xFFE8A33D), startAngle = -90f + 360f * principalRatio,
                            sweepAngle = 360f * (1f - principalRatio), useCenter = false,
                            style = Stroke(width = 16.dp.toPx()),
                        )
                    }
                    Text("本金\n利息", fontSize = 11.sp, color = inkWeak, textAlign = TextAlign.Center)
                }
                Spacer(Modifier.width(20.dp))
                Column {
                    DonutLegend(etColor, "本金", s.totalPayment - s.totalInterest)
                    Spacer(Modifier.height(6.dp))
                    DonutLegend(Color(0xFFE8A33D), "利息", s.totalInterest)
                }
            }
        }
    }
}

@Composable
private fun DonutLegend(color: Color, label: String, fen: Long) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(color, RoundedCornerShape(3.dp)))
        Spacer(Modifier.width(6.dp))
        Text("$label  ¥" + fenToYuanText(fen), fontSize = 13.sp, color = ink)
    }
}

@Composable
private fun CompareCard(et: Summary, ep: Summary) {
    Card(colors = CardDefaults.cardColors(containerColor = cardBg), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("两种方式对比", fontSize = 12.sp, color = inkWeak)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("等额本息总利息", fontSize = 13.sp, color = ink)
                Text("¥" + fenToYuanText(et.totalInterest), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = ink)
            }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("等额本金总利息", fontSize = 13.sp, color = ink)
                Text("¥" + fenToYuanText(ep.totalInterest), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = ink)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "总利息差  ¥" + fenToYuanText(kotlin.math.abs(et.totalInterest - ep.totalInterest)),
                fontSize = 13.sp, color = Color(0xFFC0653A), fontWeight = FontWeight.Medium,
            )
        }
    }
}

@Composable
private fun PlanRowItem(row: PlanRow) {
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp, horizontal = 2.dp)) {
        Text("第${row.period}期", fontSize = 12.sp, color = inkWeak, modifier = Modifier.width(56.dp))
        Text("月供 " + fenToYuanText(row.payment), fontSize = 12.sp, color = ink, modifier = Modifier.weight(1.1f))
        Text("本金 " + fenToYuanText(row.principal), fontSize = 12.sp, color = inkWeak, modifier = Modifier.weight(1.1f))
        Text("利息 " + fenToYuanText(row.interest), fontSize = 12.sp, color = inkWeak, modifier = Modifier.weight(1f))
        Text(
            "余 " + fenToYuanText(row.remaining), fontSize = 12.sp, color = inkWeak,
            modifier = Modifier.weight(1.3f), textAlign = TextAlign.End,
        )
    }
}
