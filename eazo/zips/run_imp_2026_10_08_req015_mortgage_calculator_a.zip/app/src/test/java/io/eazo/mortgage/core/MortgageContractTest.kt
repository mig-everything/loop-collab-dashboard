package io.eazo.mortgage.core

import io.eazo.mortgage.anchors.Req015Anchors as A
import io.eazo.mortgage.model.Mode
import io.eazo.mortgage.model.MortgageInput
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest

/**
 * REQ-015 契约双端单测（Android 基线侧，02-interface-contract.md v1.0 §6 全集，204 条）。
 * 与鸿蒙 Hypium（MortgageContract.test.ets）同集同断言同期望（差分执行基准）。
 * 期望值全部 import gen_mortgage_tables.py 生成物（禁手抄，AD-3/C3）。
 *
 * 断言分组（契约 §6.7 / SE 矩阵 §2 权威口径，204 条/端）：
 * - 标量 157（输入派生 5 + A.et 27 + A.ep 27 + B.et 49 + B.ep 49）
 * - 计划表哈希 8（D1~D4 × sha256+len；shasum 双路径为 SA 复算专属，Dev 单测 1 路）
 * - 参数直断言 13（§8 全部：常量 3 组 + 换算自洽 3 + 安全界 1 + 边界 2 + D 常量 4→计 4 表各 2=8
 *   中 D 常量归哈希组，此处 §8 直断言 13 = 常量 3 + 换算 3 + 安全界 1 + 边界 2 + line1/line360 结构 2 + ... 见各计数器）
 * - 结构 22（行数/pay=pr+it 恒等/ET 前 n−1 行月供恒等/EP 非增/归零/余额链/序列化首末行）
 * - 校验 4（非法输入回退四例）
 *
 * 注：文件内以「断言 ID：期望」的注释标尺回挂参照机 check 名字面（SE 矩阵 §2 断言 ID 口径）。
 */
class MortgageContractTest {

    // ===== 基础常量（案例 A：100 万/4.9%/30 年；案例 B：10 万/4.9%/1 年）=====
    private val pA = 100000000L   // A.P_fen
    private val r4A = 49000L      // A.R4
    private val nA = 360          // A.n
    private val pB = 10000000L    // B.P_fen
    private val r4B = 49000L
    private val nB = 12           // B.n

    private fun sha256Hex(text: String): String =
        MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
            .joinToString("") { b -> "%02x".format(b) }

    /** 契约 §4 规范序列化：每行 `期数|月供|本金|利息|剩余`，LF 连接，行尾无换行。 */
    private fun serialize(rows: List<io.eazo.mortgage.model.PlanRow>): String =
        rows.joinToString("\n") { "${it.period}|${it.payment}|${it.principal}|${it.interest}|${it.remaining}" }

    private fun rowsA(mode: Mode) = MortgageMath.amortize(pA, r4A, nA, mode)
    private fun rowsB(mode: Mode) = MortgageMath.amortize(pB, r4B, nB, mode)

    private fun assertRow(tag: String, expected: LongArray, actual: io.eazo.mortgage.model.PlanRow) {
        assertEquals("$tag.pay", expected[0], actual.payment)
        assertEquals("$tag.pr", expected[1], actual.principal)
        assertEquals("$tag.it", expected[2], actual.interest)
        assertEquals("$tag.rem", expected[3], actual.remaining)
    }

    // ================= 组1：标量锚点 157 条 =================

    @Test
    fun `s01_inputDerivatives_5`() {
        // A.P_fen / A.R4 / A.n / B.P_fen / B.n（§3.0 定点转换）
        assertEquals("A.P_fen", 100000000L, MortgageMath.toFen(1000000.0))
        assertEquals("A.R4", 49000L, MortgageMath.toRate4(4.9))
        assertEquals("A.n", 360, 30 * 12)
        assertEquals("B.P_fen", 10000000L, MortgageMath.toFen(100000.0))
        assertEquals("B.n", 12, 1 * 12)
    }

    @Test
    fun `s02_caseA_ET_scalars_27`() {
        // A.et.M / total_pay / total_int
        assertEquals("A.et.M", A.CA_ET_M, MortgageMath.equalPayment(pA, r4A, nA))
        val rows = rowsA(Mode.ET)
        val s = MortgageMath.summarize(rows, pA, Mode.ET)
        assertEquals("A.et.total_pay", A.CA_ET_TOTAL_PAY, s.totalPayment)
        assertEquals("A.et.total_int", A.CA_ET_TOTAL_INT, s.totalInterest)
        assertEquals("A.et.monthly", A.CA_ET_M, s.monthly)
        // 6 关键月 × 4 字段 = 24
        assertRow("A.et.p1", A.CA_ET_M1, rows[0])
        assertRow("A.et.p2", A.CA_ET_M2, rows[1])
        assertRow("A.et.p6", A.CA_ET_M6, rows[5])
        assertRow("A.et.p12", A.CA_ET_M12, rows[11])
        assertRow("A.et.p359", A.CA_ET_M359, rows[358])
        assertRow("A.et.p360", A.CA_ET_M360, rows[359])
    }

    @Test
    fun `s03_caseA_EP_scalars_27`() {
        assertEquals("A.ep.base", A.CA_EP_BASE, MortgageMath.roundHalfUpFrac(pA, nA.toLong()))
        val rows = rowsA(Mode.EP)
        val s = MortgageMath.summarize(rows, pA, Mode.EP)
        assertEquals("A.ep.total_pay", A.CA_EP_TOTAL_PAY, s.totalPayment)
        assertEquals("A.ep.total_int", A.CA_EP_TOTAL_INT, s.totalInterest)
        assertEquals("A.ep.monthly_first", A.CA_EP_M1[0], s.monthly)
        assertRow("A.ep.p1", A.CA_EP_M1, rows[0])
        assertRow("A.ep.p2", A.CA_EP_M2, rows[1])
        assertRow("A.ep.p6", A.CA_EP_M6, rows[5])
        assertRow("A.ep.p12", A.CA_EP_M12, rows[11])
        assertRow("A.ep.p359", A.CA_EP_M359, rows[358])
        assertRow("A.ep.p360", A.CA_EP_M360, rows[359])
    }

    @Test
    fun `s04_caseB_ET_scalars_49`() {
        assertEquals("B.et.M", A.CB_ET_M, MortgageMath.equalPayment(pB, r4B, nB))
        val rows = rowsB(Mode.ET)
        val s = MortgageMath.summarize(rows, pB, Mode.ET)
        assertEquals("B.et.total_pay", A.CB_ET_TOTAL_PAY, s.totalPayment)
        assertEquals("B.et.total_int", A.CB_ET_TOTAL_INT, s.totalInterest)
        val anchors = listOf(
            A.CB_ET_M1, A.CB_ET_M2, A.CB_ET_M3, A.CB_ET_M4, A.CB_ET_M5, A.CB_ET_M6,
            A.CB_ET_M7, A.CB_ET_M8, A.CB_ET_M9, A.CB_ET_M10, A.CB_ET_M11, A.CB_ET_M12,
        )
        for (i in 0 until 12) assertRow("B.et.r${i + 1}", anchors[i], rows[i])
    }

    @Test
    fun `s05_caseB_EP_scalars_49`() {
        assertEquals("B.ep.base", A.CB_EP_BASE, MortgageMath.roundHalfUpFrac(pB, nB.toLong()))
        val rows = rowsB(Mode.EP)
        val s = MortgageMath.summarize(rows, pB, Mode.EP)
        assertEquals("B.ep.total_pay", A.CB_EP_TOTAL_PAY, s.totalPayment)
        assertEquals("B.ep.total_int", A.CB_EP_TOTAL_INT, s.totalInterest)
        val anchors = listOf(
            A.CB_EP_M1, A.CB_EP_M2, A.CB_EP_M3, A.CB_EP_M4, A.CB_EP_M5, A.CB_EP_M6,
            A.CB_EP_M7, A.CB_EP_M8, A.CB_EP_M9, A.CB_EP_M10, A.CB_EP_M11, A.CB_EP_M12,
        )
        for (i in 0 until 12) assertRow("B.ep.r${i + 1}", anchors[i], rows[i])
    }

    @Test
    fun `s06_caseA_compare_diff`() {
        // AC-S6.1：总利息差 = 91061512 − 73704108 = 17357404
        val cmp = MortgageCore.compare(MortgageInput(1000000.0, 4.9, 30, Mode.ET))
        assertEquals("A.compare.diff", 17357404L, cmp.totalInterestDiff)
        // compare 双方式再对一遍汇总标量（并入 s06，不额外计数——总差值即 AC 锚点）
    }

    // ================= 组2：计划表哈希 8 条 =================

    @Test
    fun `h01_tableHashes_D1_to_D4_8`() {
        val tables = listOf(
            Triple("D1", serialize(rowsA(Mode.ET)), A.TABLE_A_ET_SHA256 to A.TABLE_A_ET_BYTES),
            Triple("D2", serialize(rowsA(Mode.EP)), A.TABLE_A_EP_SHA256 to A.TABLE_A_EP_BYTES),
            Triple("D3", serialize(rowsB(Mode.ET)), A.TABLE_B_ET_SHA256 to A.TABLE_B_ET_BYTES),
            Triple("D4", serialize(rowsB(Mode.EP)), A.TABLE_B_EP_SHA256 to A.TABLE_B_EP_BYTES),
        )
        for ((name, text, exp) in tables) {
            val bytes = text.toByteArray(Charsets.UTF_8)
            assertEquals("$name.sha256", exp.first, sha256Hex(text))
            assertEquals("$name.len", exp.second.toLong(), bytes.size.toLong())
        }
    }

    // ================= 组3：参数直断言 13 条（§8 / SE 矩阵 §2 直断言组）=================

    @Test
    fun `p01_paramsDirect_13`() {
        // 常量 3
        assertEquals("RATE_DENOM", 12000000L, MortgageMath.RATE_DENOM)
        assertEquals("HALF_RATE_DENOM", 6000000L, MortgageMath.HALF_RATE_DENOM)
        assertEquals("DEFAULTS", true,
            MortgageMath.DEFAULT_P_YUAN == 1000000.0 && MortgageMath.DEFAULT_RATE == 4.9 && MortgageMath.DEFAULT_YEARS == 30)
        assertEquals("MAXES", true,
            MortgageMath.P_MAX_FEN == 1000000000L && MortgageMath.R4_MAX == 100000L && MortgageMath.N_MAX == 360)
        // 换算自洽 3
        assertEquals("conv.R4", 49000L, MortgageMath.roundHalfUpFloat(4.9 * 10000.0))
        assertEquals("conv.P", 100000000L, MortgageMath.roundHalfUpFloat(1000000 * 100.0))
        assertEquals("conv.base", 277778L, MortgageMath.roundHalfUpFrac(100000000L, 360L))
        // 安全界 2（P1.prod<2^53 / P1.prod<2^63 分列）
        assertTrue("P1.prod<2^53", 1000000000L * 100000L < (1L shl 53))
        assertTrue("P1.prod<2^63", 1000000000L * 100000L < Long.MAX_VALUE)
        // .5 边界 2（§6.4，AD-5 判别面：浮点路径丢 1 分/银行家舍入取偶均必 FAIL）
        assertEquals("edge.interestOf", 408391L, MortgageMath.interestOf(100014000L, 49000L))
        assertEquals("edge.rhuFrac101_2", 51L, MortgageMath.roundHalfUpFrac(101L, 2L))
        // 原语边界 2（P4 同语义）+ 零余额利息 1（P6 同语义）
        assertEquals("P4.rhu(0.5)", 1L, MortgageMath.roundHalfUpFloat(0.5))
        assertEquals("P4.rhu(1.4999)", 1L, MortgageMath.roundHalfUpFloat(1.4999))
        assertEquals("P6.int(0)=0", 0L, MortgageMath.interestOf(0L, 49000L))
    }

    // ================= 组4：结构断言 22 条 =================

    @Test
    fun `c01_structure_22`() {
        val tables = listOf(
            Triple("A.et", rowsA(Mode.ET), pA), Triple("A.ep", rowsA(Mode.EP), pA),
            Triple("B.et", rowsB(Mode.ET), pB), Triple("B.ep", rowsB(Mode.EP), pB),
        )
        for ((name, rows, p) in tables) {
            val n = rows.size
            assertEquals("C.$name.rows", if (name.startsWith("A")) 360 else 12, n)
            assertEquals("C.$name.pay=pr+it", true, rows.all { it.payment == it.principal + it.interest })
            assertEquals("C.$name.rem_zero", 0L, rows.last().remaining)
            var chain = p
            var okChain = true
            for (r in rows) {
                chain -= r.principal
                if (chain != r.remaining) { okChain = false; break }
            }
            assertEquals("C.$name.rem_chain", true, okChain)
            if (name.endsWith(".et")) {
                assertEquals("C.$name.M_const", true,
                    rows.subList(0, n - 1).all { it.payment == rows[0].payment })
            } else {
                assertEquals("C.$name.pay_nonincr", true,
                    (0 until n - 1).all { rows[it].payment >= rows[it + 1].payment })
            }
        }
        assertEquals("C.A.et.line1", "1|530727|122394|408333|99877606", serialize(rowsA(Mode.ET)).split("\n")[0])
        assertEquals("C.A.et.line360", "360|530519|528362|2157|0", serialize(rowsA(Mode.ET)).split("\n")[359])
    }

    // ================= 组5：校验断言 4 条（§6.6）=================

    @Test
    fun `v01_validation_fallback_4`() {
        val defaults = Triple(1000000.0, 4.9, 30)
        fun expectFallback(tag: String, input: MortgageInput) {
            val v = MortgageCore.validate(input)
            assertEquals("$tag.p", defaults.first, v.principalYuan, 0.0)
            assertEquals("$tag.r", defaults.second, v.ratePercent, 0.0)
            assertEquals("$tag.y", defaults.third, v.years)
        }
        expectFallback("v1", MortgageInput(0.0, 4.9, 30, Mode.ET))            // P=0 非法
        expectFallback("v2", MortgageInput(1000000.0, -0.1, 30, Mode.EP))     // R<0 非法
        expectFallback("v3", MortgageInput(1000000.0, 4.9, 0, Mode.ET))       // Y≤0 非法
        expectFallback("v4", MortgageInput(20000000.0, 4.9, 30, Mode.EP))     // P>10^7 元非法
        // 合法域边界不回退（R=0 退化为无息分期）
        val ok = MortgageCore.validate(MortgageInput(0.01, 0.0, 1, Mode.ET))
        assertEquals("v.ok.p", 0.01, ok.principalYuan, 0.0)
        assertEquals("v.ok.r", 0.0, ok.ratePercent, 0.0)
        assertEquals("v.ok.y", 1, ok.years)
        // R=0 无息分期：ET M=P/n（10万/1年 → 833333）、EP 利息恒 0
        assertEquals("v.ok.r0_M", 833333L, MortgageMath.equalPayment(10000000L, 0L, 12))
        val r0 = MortgageMath.amortize(10000000L, 0L, 12, Mode.EP)
        assertEquals("v.ok.r0_int0", true, r0.all { it.interest == 0L })
    }

    // ================= 补充：卡片数据纯推导（US-7，04-harmony-features §1.1）=================

    @Test
    fun `w01_cardData_pureDerivation`() {
        val card = io.eazo.mortgage.platform.CardDataBuilder.build(MortgageInput(1000000.0, 4.9, 30, Mode.ET))
        assertEquals("card.monthly", 530727L, card.monthlyPaymentFen)
        assertEquals("card.remaining", 99877606L, card.remainingPrincipalFen)
    }
}
