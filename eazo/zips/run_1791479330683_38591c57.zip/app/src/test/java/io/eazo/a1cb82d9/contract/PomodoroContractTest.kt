package io.eazo.a1cb82d9.contract

import io.eazo.a1cb82d9.core.logic.PomodoroLogic
import io.eazo.a1cb82d9.core.model.FocusRecord
import io.eazo.a1cb82d9.core.model.PomodoroSettings
import io.eazo.a1cb82d9.core.model.TimerMode
import io.eazo.a1cb82d9.core.model.TimerState
import io.eazo.a1cb82d9.core.model.TimerStatus
import io.eazo.a1cb82d9.core.repo.RecordCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * 番茄钟契约用例（纯 JVM，双端口径锁死）：
 * 状态机流转 / 完成落记录 / 今日统计 / 确定性排序 / 编解码 / 格式化 / 设置边界。
 */
class PomodoroContractTest {

    private val defaults = PomodoroSettings()

    // ---- 初始与时长 ----

    @Test
    fun `默认设置 25 分专注 5 分休息`() {
        assertEquals(25, PomodoroSettings.DEFAULT_FOCUS_MINUTES)
        assertEquals(5, PomodoroSettings.DEFAULT_BREAK_MINUTES)
    }

    @Test
    fun `初始快照 FOCUS_IDLE_打满专注时长`() {
        val s = PomodoroLogic.initial(defaults)
        assertEquals(TimerMode.FOCUS, s.mode)
        assertEquals(TimerStatus.IDLE, s.status)
        assertEquals(1500, s.totalSeconds)
        assertEquals(1500, s.remainingSeconds)
    }

    @Test
    fun `阶段时长等于分钟乘 60`() {
        assertEquals(1500, PomodoroLogic.durationSeconds(TimerMode.FOCUS, defaults))
        assertEquals(300, PomodoroLogic.durationSeconds(TimerMode.BREAK, defaults))
        assertEquals(3000, PomodoroLogic.durationSeconds(TimerMode.FOCUS, PomodoroSettings(50, 10)))
    }

    // ---- 状态机 ----

    @Test
    fun `开始与继续进入 RUNNING 且 RUNNING 幂等`() {
        val idle = PomodoroLogic.initial(defaults)
        val running = PomodoroLogic.start(idle)
        assertEquals(TimerStatus.RUNNING, running.status)
        assertEquals(running, PomodoroLogic.start(running))
    }

    @Test
    fun `暂停仅 RUNNING 生效 非 RUNNING 为 no-op`() {
        val idle = PomodoroLogic.initial(defaults)
        assertEquals(idle, PomodoroLogic.pause(idle))
        val paused = PomodoroLogic.pause(PomodoroLogic.start(idle))
        assertEquals(TimerStatus.PAUSED, paused.status)
        assertEquals(1500, paused.remainingSeconds)
    }

    @Test
    fun `重置回 IDLE 保留阶段并按最新设置打满`() {
        val settings = PomodoroSettings(focusMinutes = 30, breakMinutes = 10)
        val mid = TimerState(TimerMode.FOCUS, TimerStatus.RUNNING, totalSeconds = 1800, remainingSeconds = 417)
        val reset = PomodoroLogic.reset(mid, settings)
        assertEquals(TimerStatus.IDLE, reset.status)
        assertEquals(TimerMode.FOCUS, reset.mode)
        assertEquals(1800, reset.totalSeconds)
        assertEquals(1800, reset.remainingSeconds)
    }

    @Test
    fun `墙钟同步仅在 RUNNING 接受且 clamp 到 0到total`() {
        val idle = PomodoroLogic.initial(defaults)
        assertEquals(idle, PomodoroLogic.syncRemaining(idle, 100))
        val running = PomodoroLogic.start(idle)
        assertEquals(100, PomodoroLogic.syncRemaining(running, 100).remainingSeconds)
        assertEquals(0, PomodoroLogic.syncRemaining(running, -5).remainingSeconds)
        assertEquals(1500, PomodoroLogic.syncRemaining(running, 99999).remainingSeconds)
    }

    @Test
    fun `保存设置仅 IDLE 重载 进行中会话不可变`() {
        val newSettings = PomodoroSettings(focusMinutes = 50, breakMinutes = 10)
        val idle = PomodoroLogic.initial(defaults)
        assertEquals(3000, PomodoroLogic.applySettings(idle, newSettings).remainingSeconds)
        val running = PomodoroLogic.applySettings(PomodoroLogic.start(idle), newSettings)
        assertEquals(1500, running.totalSeconds)
        val paused = PomodoroLogic.applySettings(
            TimerState(TimerMode.FOCUS, TimerStatus.PAUSED, 1500, 700), newSettings,
        )
        assertEquals(700, paused.remainingSeconds)
    }

    @Test
    fun `手动切换阶段仅 IDLE 且目标不同时生效`() {
        val idle = PomodoroLogic.initial(defaults)
        val toBreak = PomodoroLogic.switchMode(idle, TimerMode.BREAK, defaults)
        assertEquals(TimerMode.BREAK, toBreak.mode)
        assertEquals(300, toBreak.remainingSeconds)
        assertEquals(toBreak, PomodoroLogic.switchMode(toBreak, TimerMode.BREAK, defaults))
        val running = PomodoroLogic.switchMode(PomodoroLogic.start(idle), TimerMode.BREAK, defaults)
        assertEquals(TimerMode.FOCUS, running.mode)
    }

    // ---- 完成流转与记录 ----

    @Test
    fun `专注完成产出记录并切到 BREAK 休息完成不产出记录`() {
        val focusDone = TimerState(TimerMode.FOCUS, TimerStatus.RUNNING, 1500, 0)
        val (breakState, record) = PomodoroLogic.advanceOnComplete(focusDone, 1728000000000L, "2026-10-09", defaults)
        assertEquals(TimerMode.BREAK, breakState.mode)
        assertEquals(TimerStatus.IDLE, breakState.status)
        assertEquals(300, breakState.remainingSeconds)
        assertEquals(FocusRecord("1728000000000", "2026-10-09", 1728000000000L, 1500), record)

        val breakDone = TimerState(TimerMode.BREAK, TimerStatus.RUNNING, 300, 0)
        val (focusState, noRecord) = PomodoroLogic.advanceOnComplete(breakDone, 1728000300000L, "2026-10-09", defaults)
        assertEquals(TimerMode.FOCUS, focusState.mode)
        assertEquals(1500, focusState.remainingSeconds)
        assertNull(noRecord)
    }

    // ---- 统计与排序 ----

    @Test
    fun `今日统计按 date 精确匹配计数与求和`() {
        val records = listOf(
            FocusRecord("a1", "2026-10-09", 1000L, 1500),
            FocusRecord("a2", "2026-10-09", 2000L, 3000),
            FocusRecord("a3", "2026-10-08", 3000L, 1500),
        )
        val stats = PomodoroLogic.todayStats(records, "2026-10-09")
        assertEquals(2, stats.rounds)
        assertEquals(4500, stats.totalFocusSeconds)
        assertEquals(TodayStatsZero(), PomodoroLogic.todayStats(records, "2026-10-10"))
    }

    private fun TodayStatsZero() = io.eazo.a1cb82d9.core.model.TodayStats(0, 0)

    @Test
    fun `排序 startTs 降序为主键 id 字典序升序兜底`() {
        val records = listOf(
            FocusRecord("b", "2026-10-09", 1000L, 1500),
            FocusRecord("a", "2026-10-09", 2000L, 1500),
            FocusRecord("z", "2026-10-09", 2000L, 1500),
            FocusRecord("c", "2026-10-09", 3000L, 1500),
        )
        val sorted = PomodoroLogic.sortedDesc(records)
        assertEquals(listOf("c", "a", "z", "b"), sorted.map { it.id })
    }

    // ---- 编解码 ----

    @Test
    fun `编解码往返一致且字段序锁死`() {
        val records = listOf(
            FocusRecord("1728000000000", "2026-10-09", 1728000000000L, 1500),
            FocusRecord("1728003600000", "2026-10-09", 1728003600000L, 3000),
        )
        assertEquals(
            "1728000000000|2026-10-09|1728000000000|1500\n1728003600000|2026-10-09|1728003600000|3000",
            RecordCodec.encode(records),
        )
        assertEquals(records, RecordCodec.decode(RecordCodec.encode(records)))
    }

    @Test
    fun `解码对脏行防御跳过 空串得空表`() {
        assertEquals(emptyList<FocusRecord>(), RecordCodec.decode(""))
        val dirty = "badline\n|||\n1728000000000|2026-10-09|notanumber|1500\n" +
            "1728000000000|2026-10-09|1728000000000|-3\n" +
            "|2026-10-09|1728000000000|1500\n" +
            "1728000000001|2026-10-09|1728000000001|1500"
        assertEquals(
            listOf(FocusRecord("1728000000001", "2026-10-09", 1728000000001L, 1500)),
            RecordCodec.decode(dirty),
        )
    }

    // ---- 设置边界 clamp ----

    @Test
    fun `设置 clamp 到双端锁死边界`() {
        assertEquals(1, PomodoroSettings(focusMinutes = 0, breakMinutes = 0).clamped().focusMinutes)
        assertEquals(1, PomodoroSettings(focusMinutes = 0, breakMinutes = 0).clamped().breakMinutes)
        assertEquals(180, PomodoroSettings(focusMinutes = 999, breakMinutes = 99).clamped().focusMinutes)
        assertEquals(60, PomodoroSettings(focusMinutes = 999, breakMinutes = 99).clamped().breakMinutes)
        assertEquals(25, PomodoroSettings(focusMinutes = 25, breakMinutes = 5).clamped().focusMinutes)
        assertEquals(5, PomodoroSettings(focusMinutes = 25, breakMinutes = 5).clamped().breakMinutes)
    }

    // ---- 格式化 ----

    @Test
    fun `倒计时 MM 冒号 SS 分钟位可超 99`() {
        assertEquals("00:00", PomodoroLogic.formatClock(0))
        assertEquals("00:01", PomodoroLogic.formatClock(1))
        assertEquals("01:05", PomodoroLogic.formatClock(65))
        assertEquals("25:00", PomodoroLogic.formatClock(1500))
        assertEquals("62:05", PomodoroLogic.formatClock(3725))
        assertEquals("90:00", PomodoroLogic.formatClock(5400))
    }

    @Test
    fun `中文时长分段口径`() {
        assertEquals("0 分钟", PomodoroLogic.formatDurationZh(0))
        assertEquals("25 分钟", PomodoroLogic.formatDurationZh(1500))
        assertEquals("59 分钟", PomodoroLogic.formatDurationZh(3540))
        assertEquals("1 小时", PomodoroLogic.formatDurationZh(3600))
        assertEquals("1 小时 23 分", PomodoroLogic.formatDurationZh(4980))
        assertEquals("3 小时 5 分", PomodoroLogic.formatDurationZh(11100))
    }
}
