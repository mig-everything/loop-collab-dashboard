package io.eazo.a1cb82d9.core.logic

import io.eazo.a1cb82d9.core.model.FocusRecord
import io.eazo.a1cb82d9.core.model.PomodoroSettings
import io.eazo.a1cb82d9.core.model.TimerMode
import io.eazo.a1cb82d9.core.model.TimerState
import io.eazo.a1cb82d9.core.model.TimerStatus
import io.eazo.a1cb82d9.core.model.TodayStats
import java.util.Locale

/**
 * 番茄钟纯函数状态机 + 统计/排序/格式化。
 * 确定性算法口径：全整数域、显式语义（无随机/无墙钟/无系统依赖），双端实现同一套。
 */
object PomodoroLogic {

    /** 初始快照：FOCUS / IDLE / 专注时长打满。 */
    fun initial(settings: PomodoroSettings): TimerState {
        val total = durationSeconds(TimerMode.FOCUS, settings)
        return TimerState(
            mode = TimerMode.FOCUS,
            status = TimerStatus.IDLE,
            totalSeconds = total,
            remainingSeconds = total,
        )
    }

    /** 阶段时长（秒）= 分钟 × 60，整数域。 */
    fun durationSeconds(mode: TimerMode, settings: PomodoroSettings): Int =
        (if (mode == TimerMode.FOCUS) settings.focusMinutes else settings.breakMinutes) * 60

    /** 开始/继续：非 RUNNING → RUNNING；RUNNING 为幂等 no-op。 */
    fun start(s: TimerState): TimerState =
        if (s.status == TimerStatus.RUNNING) s else s.copy(status = TimerStatus.RUNNING)

    /** 暂停：RUNNING → PAUSED；非 RUNNING 为 no-op。 */
    fun pause(s: TimerState): TimerState =
        if (s.status == TimerStatus.RUNNING) s.copy(status = TimerStatus.PAUSED) else s

    /** 重置：保持当前阶段，回 IDLE 并补满该阶段时长（按最新设置）。 */
    fun reset(s: TimerState, settings: PomodoroSettings): TimerState {
        val total = durationSeconds(s.mode, settings)
        return s.copy(status = TimerStatus.IDLE, totalSeconds = total, remainingSeconds = total)
    }

    /** 墙钟同步：仅在 RUNNING 下接受剩余秒，域内 clamp [0, total]。 */
    fun syncRemaining(s: TimerState, remaining: Int): TimerState =
        if (s.status != TimerStatus.RUNNING) s
        else s.copy(remainingSeconds = remaining.coerceIn(0, s.totalSeconds))

    /** 保存设置：仅 IDLE 立即重载时长；RUNNING/PAUSED 会话不可变，下一轮生效。 */
    fun applySettings(s: TimerState, settings: PomodoroSettings): TimerState {
        if (s.status != TimerStatus.IDLE) return s
        val total = durationSeconds(s.mode, settings)
        return s.copy(totalSeconds = total, remainingSeconds = total)
    }

    /** 手动切换阶段：仅 IDLE 且目标不同时生效，切到目标阶段完整时长。 */
    fun switchMode(s: TimerState, target: TimerMode, settings: PomodoroSettings): TimerState {
        if (s.status != TimerStatus.IDLE || s.mode == target) return s
        val total = durationSeconds(target, settings)
        return TimerState(
            mode = target,
            status = TimerStatus.IDLE,
            totalSeconds = total,
            remainingSeconds = total,
        )
    }

    /**
     * 一轮走完：FOCUS 完成 → 产出 FocusRecord（focusSeconds=totalSeconds，id=startTs）
     * 并进入 BREAK；BREAK 完成 → 不产出记录回到 FOCUS。均回 IDLE 等待手动开始。
     */
    fun advanceOnComplete(
        s: TimerState,
        sessionStartTs: Long,
        date: String,
        settings: PomodoroSettings,
    ): Pair<TimerState, FocusRecord?> {
        val nextMode = if (s.mode == TimerMode.FOCUS) TimerMode.BREAK else TimerMode.FOCUS
        val total = durationSeconds(nextMode, settings)
        val nextState = TimerState(
            mode = nextMode,
            status = TimerStatus.IDLE,
            totalSeconds = total,
            remainingSeconds = total,
        )
        val record = if (s.mode == TimerMode.FOCUS) {
            FocusRecord(
                id = sessionStartTs.toString(),
                date = date,
                startTs = sessionStartTs,
                focusSeconds = s.totalSeconds,
            )
        } else null
        return nextState to record
    }

    /** 确定性排序：startTs 降序为主键，id 字典序升序兜底。 */
    fun sortedDesc(records: List<FocusRecord>): List<FocusRecord> =
        records.sortedWith(compareByDescending<FocusRecord> { it.startTs }.thenBy { it.id })

    /** 今日统计：date 精确匹配 yyyy-MM-dd；rounds=条数，totalFocusSeconds=秒求和。 */
    fun todayStats(records: List<FocusRecord>, todayDate: String): TodayStats {
        val todays = records.filter { it.date == todayDate }
        return TodayStats(rounds = todays.size, totalFocusSeconds = todays.sumOf { it.focusSeconds })
    }

    /** 剩余秒 → 大字号倒计时 MM:SS（分钟位可自然超过 99；Locale.US 锁死数字形）。 */
    fun formatClock(remainingSeconds: Int): String =
        String.format(Locale.US, "%02d:%02d", remainingSeconds / 60, remainingSeconds % 60)

    /** 秒 → 中文时长：<60 分「M 分钟」；≥60 分整「H 小时」，非整「H 小时 M 分」。 */
    fun formatDurationZh(totalSeconds: Int): String {
        val minutes = totalSeconds / 60
        return if (minutes < 60) {
            "$minutes 分钟"
        } else if (minutes % 60 == 0) {
            "${minutes / 60} 小时"
        } else {
            "${minutes / 60} 小时 ${minutes % 60} 分"
        }
    }
}
