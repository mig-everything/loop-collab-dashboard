package io.eazo.a1cb82d9.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import io.eazo.a1cb82d9.core.logic.PomodoroLogic
import io.eazo.a1cb82d9.core.model.TimerMode
import io.eazo.a1cb82d9.core.model.TimerState
import io.eazo.a1cb82d9.core.model.TimerStatus
import io.eazo.a1cb82d9.platform.AppRepo
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 计时控制器：墙钟端点法（RUNNING 时持有 endTs，每拍由 now 推剩余秒，整数域
 * ceil 语义：rem = ceil((endTs-now)/1000)，与纯逻辑层 syncRemaining 对接）。
 * 会话起点 sessionStartTs 仅在 IDLE→RUNNING 首次开始时记录，暂停/继续不改写。
 */
class PomodoroController(
    private val repo: AppRepo,
    private val now: () -> Long = System::currentTimeMillis,
    private val dateOf: (Long) -> String = { ts -> TsFormat.dateOf(ts) },
) {

    var state by mutableStateOf(PomodoroLogic.initial(repo.settings))
        private set

    private var endTs: Long = 0L
    private var sessionStartTs: Long = 0L

    /** 开始/继续。IDLE 起点 = 当前时刻（记录归属）；PAUSED 续跑保留原会话起点。 */
    fun start() {
        when (state.status) {
            TimerStatus.IDLE -> {
                val t = now()
                sessionStartTs = t
                endTs = t + state.remainingSeconds * 1000L
                state = PomodoroLogic.start(state)
            }
            TimerStatus.PAUSED -> {
                endTs = now() + state.remainingSeconds * 1000L
                state = PomodoroLogic.start(state)
            }
            TimerStatus.RUNNING -> Unit
        }
    }

    /** 暂停：先同步一次剩余，再冻结（若同步瞬间完成则走完成流转，不再暂停）。 */
    fun pause() {
        if (state.status != TimerStatus.RUNNING) return
        syncRemaining(now())
        if (state.status == TimerStatus.RUNNING) {
            endTs = 0L
            state = PomodoroLogic.pause(state)
        }
    }

    fun reset() {
        endTs = 0L
        state = PomodoroLogic.reset(state, repo.settings)
    }

    fun switchMode(target: TimerMode) {
        endTs = 0L
        state = PomodoroLogic.switchMode(state, target, repo.settings)
    }

    /** 设置保存后调用：IDLE 立即重载时长，进行中会话不动。 */
    fun applySettings() {
        state = PomodoroLogic.applySettings(state, repo.settings)
    }

    /** 墙钟同步：rem=0 触发完成流转（FOCUS 落一条 FocusRecord 并自动切阶段）。 */
    fun syncRemaining(nowMs: Long) {
        if (state.status != TimerStatus.RUNNING) return
        val rem = ((endTs - nowMs + 999L) / 1000L).coerceIn(0L, state.totalSeconds.toLong()).toInt()
        if (rem <= 0) complete() else state = PomodoroLogic.syncRemaining(state, rem)
    }

    private fun complete() {
        endTs = 0L
        val (next, record) = PomodoroLogic.advanceOnComplete(
            state, sessionStartTs, dateOf(sessionStartTs), repo.settings,
        )
        record?.let { repo.addFocusRecord(it) }
        state = next
    }

    /** 心跳：LaunchedEffect(status==RUNNING) 驱动，200ms 一拍。 */
    suspend fun runTicker() {
        while (state.status == TimerStatus.RUNNING) {
            syncRemaining(now())
            delay(200)
        }
    }
}

/** 时间格式化（minSdk 24 无 java.time，走 SimpleDateFormat；Locale.US 锁死数字形）。 */
object TsFormat {
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.US)

    fun dateOf(ts: Long): String = synchronized(dayFmt) { dayFmt.format(Date(ts)) }

    fun timeOf(ts: Long): String = synchronized(timeFmt) { timeFmt.format(Date(ts)) }
}
