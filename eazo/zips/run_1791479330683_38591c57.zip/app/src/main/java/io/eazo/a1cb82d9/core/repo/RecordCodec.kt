package io.eazo.a1cb82d9.core.repo

import io.eazo.a1cb82d9.core.model.FocusRecord

/**
 * 记录持久化编解码：不引 JSON 依赖，逐行 "id|date|startTs|focusSeconds"，
 * 字段序/分隔符/换行符与鸿蒙 preferences 端 1:1 锁死（生成器硬规则 ③）。
 * 解码对脏行防御：字段数≠4、数值非法、空 id/date 一律跳过该行。
 */
object RecordCodec {

    private const val SEP = "|"

    fun encode(records: List<FocusRecord>): String = records.joinToString("\n") {
        listOf(it.id, it.date, it.startTs.toString(), it.focusSeconds.toString()).joinToString(SEP)
    }

    fun decode(raw: String): List<FocusRecord> = raw.lines().mapNotNull { line ->
        val parts = line.split(SEP)
        if (parts.size != 4) return@mapNotNull null
        val id = parts[0]
        val date = parts[1]
        val startTs = parts[2].toLongOrNull()
        val focusSeconds = parts[3].toIntOrNull()
        if (id.isEmpty() || date.isEmpty() || startTs == null || focusSeconds == null || focusSeconds <= 0) {
            null
        } else {
            FocusRecord(id = id, date = date, startTs = startTs, focusSeconds = focusSeconds)
        }
    }
}
