package io.eazo.a1cb82d9.platform

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import io.eazo.a1cb82d9.core.logic.PomodoroLogic
import io.eazo.a1cb82d9.core.model.FocusRecord
import io.eazo.a1cb82d9.core.model.PomodoroSettings
import io.eazo.a1cb82d9.core.model.TodayStats
import io.eazo.a1cb82d9.core.repo.RecordCodec

/**
 * 骨架模板平台层：AppRepo 进程内单例（生成器硬规则 ①——UI/卡片层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * 本需求挂接番茄钟仓储：内存态持有 + SharedPreferences 持久化（读写分离，
 * list() 只读内存态；持久化 load 仅冷启动一次，save 先改内存后落盘）。
 * key 与记录行格式双端 1:1（RecordCodec）。
 */
object AppRepo {

    private const val PREFS_NAME = "pomodoro_repo"
    private const val KEY_FOCUS_MINUTES = "pomo_settings_focus_minutes"
    private const val KEY_BREAK_MINUTES = "pomo_settings_break_minutes"
    private const val KEY_RECORDS = "pomo_records"

    private var initialized = false
    private var prefs: SharedPreferences? = null

    /** 内存态（UI 永远读这里）。 */
    private var settingsValue = PomodoroSettings()
    private val recordsValue = mutableListOf<FocusRecord>()

    /** 内存态版本号：任何内存变更 bump；Compose 读它即时重渲（写操作即时可见）。 */
    val version = mutableStateOf(0)

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo {
        ensureInit(context)
        return this
    }

    val settings: PomodoroSettings get() = settingsValue

    /** 保存设置：clamp 后写内存再落盘。RUNNING 会话不受影响（下一轮生效，见 PomodoroLogic）。 */
    fun saveSettings(next: PomodoroSettings) {
        settingsValue = next.clamped()
        persist()
        bump()
    }

    fun listRecords(): List<FocusRecord> = recordsValue.toList()

    /** 新增一条已完成专注记录：内存排序（startTs 降序/id 升序兜底）后落盘。 */
    fun addFocusRecord(record: FocusRecord) {
        recordsValue.add(record)
        val sorted = PomodoroLogic.sortedDesc(recordsValue)
        recordsValue.clear()
        recordsValue.addAll(sorted)
        persist()
        bump()
    }

    fun todayStats(todayDate: String): TodayStats =
        PomodoroLogic.todayStats(recordsValue, todayDate)

    /** 硬规则 ②：refresh 只重读内存态（重排+发布），禁止从持久化 load()。 */
    fun refresh() {
        val sorted = PomodoroLogic.sortedDesc(recordsValue)
        recordsValue.clear()
        recordsValue.addAll(sorted)
        bump()
    }

    /** 冷启动一次性 load（仅 ensureInit 调用；脏数据按 RecordCodec 防御规则跳过）。 */
    @Synchronized
    private fun ensureInit(context: Context) {
        if (initialized) return
        val p = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = p
        settingsValue = PomodoroSettings(
            focusMinutes = p.getInt(KEY_FOCUS_MINUTES, PomodoroSettings.DEFAULT_FOCUS_MINUTES),
            breakMinutes = p.getInt(KEY_BREAK_MINUTES, PomodoroSettings.DEFAULT_BREAK_MINUTES),
        ).clamped()
        recordsValue.addAll(
            PomodoroLogic.sortedDesc(RecordCodec.decode(p.getString(KEY_RECORDS, "") ?: ""))
        )
        initialized = true
    }

    /** 先内存后落盘（apply 异步写，UI 读内存永不阻塞）。 */
    private fun persist() {
        prefs?.edit()
            ?.putInt(KEY_FOCUS_MINUTES, settingsValue.focusMinutes)
            ?.putInt(KEY_BREAK_MINUTES, settingsValue.breakMinutes)
            ?.putString(KEY_RECORDS, RecordCodec.encode(recordsValue))
            ?.apply()
    }

    private fun bump() {
        version.value += 1
    }
}
