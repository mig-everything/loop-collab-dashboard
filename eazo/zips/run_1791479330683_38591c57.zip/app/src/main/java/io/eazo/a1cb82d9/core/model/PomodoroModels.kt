package io.eazo.a1cb82d9.core.model

/**
 * 番茄钟领域模型（纯 Kotlin，JVM 可测）。
 * 字段名/枚举字面量/排序键与鸿蒙端 1:1 锁死（生成器硬规则 ③）。
 */

/** 计时阶段。字面量双端锁死：FOCUS / BREAK。 */
enum class TimerMode { FOCUS, BREAK }

/** 计时状态。字面量双端锁死：IDLE / RUNNING / PAUSED。 */
enum class TimerStatus { IDLE, RUNNING, PAUSED }

/** 专注/休息时长设置（分钟域，整数）。默认 25/5；clamp 边界双端锁死。 */
data class PomodoroSettings(
    val focusMinutes: Int = DEFAULT_FOCUS_MINUTES,
    val breakMinutes: Int = DEFAULT_BREAK_MINUTES,
) {
    fun clamped(): PomodoroSettings = PomodoroSettings(
        focusMinutes = focusMinutes.coerceIn(FOCUS_MIN_MINUTES, FOCUS_MAX_MINUTES),
        breakMinutes = breakMinutes.coerceIn(BREAK_MIN_MINUTES, BREAK_MAX_MINUTES),
    )

    companion object {
        const val DEFAULT_FOCUS_MINUTES = 25
        const val DEFAULT_BREAK_MINUTES = 5
        const val FOCUS_MIN_MINUTES = 1
        const val FOCUS_MAX_MINUTES = 180
        const val BREAK_MIN_MINUTES = 1
        const val BREAK_MAX_MINUTES = 60
    }
}

/** 已完成专注轮次记录。字段名双端锁死：id/date/startTs/focusSeconds。 */
data class FocusRecord(
    val id: String,
    val date: String,      // 本地日期 yyyy-MM-dd（“今日”归属判据）
    val startTs: Long,     // 本轮开始 epoch 毫秒
    val focusSeconds: Int, // 本轮专注秒数（= 完成时的 totalSeconds）
)

/** 今日统计。字段双端锁死：rounds / totalFocusSeconds。 */
data class TodayStats(
    val rounds: Int = 0,
    val totalFocusSeconds: Int = 0,
)

/** 计时器快照（整数秒域；浮点仅出现在渲染层进度换算）。 */
data class TimerState(
    val mode: TimerMode = TimerMode.FOCUS,
    val status: TimerStatus = TimerStatus.IDLE,
    val totalSeconds: Int = 0,
    val remainingSeconds: Int = 0,
)
