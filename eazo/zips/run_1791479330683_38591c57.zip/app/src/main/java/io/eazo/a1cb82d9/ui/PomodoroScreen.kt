package io.eazo.a1cb82d9.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.a1cb82d9.core.logic.PomodoroLogic
import io.eazo.a1cb82d9.core.model.FocusRecord
import io.eazo.a1cb82d9.core.model.PomodoroSettings
import io.eazo.a1cb82d9.core.model.TimerMode
import io.eazo.a1cb82d9.core.model.TimerState
import io.eazo.a1cb82d9.core.model.TimerStatus
import io.eazo.a1cb82d9.platform.AppRepo

/** 深色主题配色局部口径（环/描边），与 AppTheme 底色同族。 */
private val RingTrackColor = Color(0xFF232B37)
private val FocusGradient = listOf(Color(0xFFF5A97F), Color(0xFFF26585))
private val BreakGradient = listOf(Color(0xFF37D0C0), Color(0xFF5B8DEF))
private const val ClockFontFeature = "tnum"

/**
 * 番茄钟首屏：圆形渐变进度环 + 大字号倒计时 + 开始/暂停/重置三主按钮 +
 * 今日统计/记录 + 设置 BottomSheet；BoxWithConstraints 宽窄双布局自适应。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PomodoroScreen() {
    val context = LocalContext.current
    val repo = remember { AppRepo.getRepo(context) }
    val controller = remember { PomodoroController(repo) }

    // 心跳仅 RUNNING 下存在；暂停后重启由 status 变化重建 LaunchedEffect
    LaunchedEffect(controller.state.status) {
        if (controller.state.status == TimerStatus.RUNNING) controller.runTicker()
    }

    val version = repo.version.value // 订阅内存态：任何写（含 onResume refresh）即时重渲
    val today = TsFormat.dateOf(System.currentTimeMillis())
    val settings = remember(version) { repo.settings } // 保存设置后徽标/切换行即时更新
    val stats = remember(version, today) { repo.todayStats(today) }
    val todayRecords = remember(version, today) {
        repo.listRecords().filter { it.date == today }
    }

    var showSettings by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
    ) {
        Header(onSettings = { showSettings = true })
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            if (maxWidth >= 600.dp) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TimerRing(controller, settings, modifier = Modifier.weight(1f))
                    DetailsPane(
                        controller = controller,
                        settings = settings,
                        statsRounds = stats.rounds,
                        statsDurationText = PomodoroLogic.formatDurationZh(stats.totalFocusSeconds),
                        todayRecords = todayRecords,
                        modifier = Modifier
                            .weight(1f)
                            .padding(vertical = 16.dp),
                    )
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    TimerRing(controller, settings, modifier = Modifier.weight(1f))
                    DetailsPane(
                        controller = controller,
                        settings = settings,
                        statsRounds = stats.rounds,
                        statsDurationText = PomodoroLogic.formatDurationZh(stats.totalFocusSeconds),
                        todayRecords = todayRecords,
                        modifier = Modifier
                            .weight(0.9f)
                            .padding(bottom = 16.dp),
                    )
                }
            }
        }
    }

    if (showSettings) {
        SettingsSheet(
            current = settings,
            onDismiss = { showSettings = false },
            onSave = { next ->
                repo.saveSettings(next)
                controller.applySettings()
                showSettings = false
            },
        )
    }
}

@Composable
private fun Header(onSettings: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "番茄钟",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(modifier = Modifier.weight(1f))
        TextButton(onClick = onSettings) { Text("设置") }
    }
}

/** 进度环 + 环心内容（阶段徽标 / 倒计时 / 状态行）。 */
@Composable
private fun TimerRing(
    controller: PomodoroController,
    settings: PomodoroSettings,
    modifier: Modifier = Modifier,
) {
    val state = controller.state
    val progress = if (state.totalSeconds > 0) {
        1f - state.remainingSeconds.toFloat() / state.totalSeconds.toFloat()
    } else 0f

    Box(
        modifier = modifier
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .aspectRatio(1f),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokePx = 22.dp.toPx()
            val inset = strokePx / 2f + 3.dp.toPx()
            val arcSize = Size(size.width - inset * 2f, size.height - inset * 2f)
            val topLeft = Offset(inset, inset)
            // 底轨：整圈弱化描边
            drawArc(
                color = RingTrackColor,
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round),
            )
            // 进度弧：柔和双色渐变（首尾同色消缝），自 12 点方向顺时针充填已进行比例
            if (progress > 0f) {
                val colors = if (state.mode == TimerMode.FOCUS) FocusGradient else BreakGradient
                val center = Offset(topLeft.x + arcSize.width / 2f, topLeft.y + arcSize.height / 2f)
                rotate(degrees = -90f, pivot = center) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            0f to colors[0],
                            0.55f to colors[1],
                            1f to colors[0],
                            center = center,
                        ),
                        startAngle = 0f,
                        sweepAngle = 360f * progress.coerceIn(0f, 1f),
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokePx, cap = StrokeCap.Round),
                    )
                }
            }
        }
        RingContent(state, settings)
    }
}

@Composable
private fun RingContent(state: TimerState, settings: PomodoroSettings) {
    val modeLabel = if (state.mode == TimerMode.FOCUS) "专注" else "休息"
    val modeMinutes = if (state.mode == TimerMode.FOCUS) settings.focusMinutes else settings.breakMinutes
    val statusLabel = when (state.status) {
        TimerStatus.IDLE -> "准备就绪"
        TimerStatus.RUNNING -> if (state.mode == TimerMode.FOCUS) "专注中…" else "休息中…"
        TimerStatus.PAUSED -> "已暂停"
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        ModeBadge(text = "$modeLabel $modeMinutes 分", mode = state.mode)
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = PomodoroLogic.formatClock(state.remainingSeconds),
            fontSize = 64.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = (-1).sp,
            style = TextStyle(fontFeatureSettings = ClockFontFeature), // 等宽数字防跳动
            color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = statusLabel,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ModeBadge(text: String, mode: TimerMode) {
    val tint = if (mode == TimerMode.FOCUS) FocusGradient[1] else BreakGradient[0]
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = tint.copy(alpha = 0.16f),
        contentColor = tint,
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

/** 阶段切换 + 三主按钮 + 统计卡 + 今日记录。 */
@Composable
private fun DetailsPane(
    controller: PomodoroController,
    settings: PomodoroSettings,
    statsRounds: Int,
    statsDurationText: String,
    todayRecords: List<FocusRecord>,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        ModeSwitchRow(controller, settings)
        ControlRow(controller)
        StatsCard(rounds = statsRounds, durationText = statsDurationText)
        TodayList(todayRecords)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ModeSwitchRow(controller: PomodoroController, settings: PomodoroSettings) {
    val state = controller.state
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        FilterChip(
            selected = state.mode == TimerMode.FOCUS,
            onClick = { controller.switchMode(TimerMode.FOCUS) },
            enabled = state.status == TimerStatus.IDLE,
            label = { Text("专注 ${settings.focusMinutes} 分") },
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = FocusGradient[1].copy(alpha = 0.35f),
            ),
        )
        FilterChip(
            selected = state.mode == TimerMode.BREAK,
            onClick = { controller.switchMode(TimerMode.BREAK) },
            enabled = state.status == TimerStatus.IDLE,
            label = { Text("休息 ${settings.breakMinutes} 分") },
            colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = BreakGradient[0].copy(alpha = 0.35f),
            ),
        )
    }
}

@Composable
private fun ControlRow(controller: PomodoroController) {
    val state = controller.state
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Button(
            onClick = controller::start,
            enabled = state.status != TimerStatus.RUNNING,
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = FocusGradient[1]),
            modifier = Modifier.width(128.dp),
        ) {
            Text(if (state.status == TimerStatus.PAUSED) "继续" else "开始")
        }
        OutlinedButton(
            onClick = controller::pause,
            enabled = state.status == TimerStatus.RUNNING,
            shape = CircleShape,
            modifier = Modifier.width(104.dp),
        ) { Text("暂停") }
        OutlinedButton(
            onClick = controller::reset,
            shape = CircleShape,
            modifier = Modifier.width(104.dp),
        ) { Text("重置") }
    }
}

@Composable
private fun StatsCard(rounds: Int, durationText: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, Color(0x14FFFFFF)),
    ) {
        Row(
            modifier = Modifier.padding(vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            StatBlock(
                label = "今日完成",
                value = "$rounds 轮",
                modifier = Modifier.weight(1f),
            )
            HorizontalDivider(
                modifier = Modifier
                    .height(30.dp)
                    .width(1.dp),
                color = Color(0x1FFFFFFF),
            )
            StatBlock(
                label = "累计专注",
                value = durationText,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun StatBlock(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
        )
    }
}

@Composable
private fun TodayList(records: List<FocusRecord>) {
    if (records.isEmpty()) {
        Text(
            text = "完成第一轮专注后，记录会出现在这里",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        return
    }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, Color(0x14FFFFFF)),
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(
                text = "今日记录",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(4.dp))
            LazyColumn(modifier = Modifier.height((records.size.coerceAtMost(4) * 40).dp)) {
                items(records) { record ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = TsFormat.timeOf(record.startTs),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = PomodoroLogic.formatDurationZh(record.focusSeconds),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

/** 设置 BottomSheet：专注/休息分钟步进（clamp 边界双端锁死）+ 快捷预设。 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsSheet(
    current: PomodoroSettings,
    onDismiss: () -> Unit,
    onSave: (PomodoroSettings) -> Unit,
) {
    var focusMin by remember { mutableIntStateOf(current.focusMinutes) }
    var breakMin by remember { mutableIntStateOf(current.breakMinutes) }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = "自定义时长",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            StepperRow(
                label = "专注时长",
                value = focusMin,
                range = PomodoroSettings.FOCUS_MIN_MINUTES..PomodoroSettings.FOCUS_MAX_MINUTES,
                onChange = { focusMin = it },
            )
            StepperRow(
                label = "休息时长",
                value = breakMin,
                range = PomodoroSettings.BREAK_MIN_MINUTES..PomodoroSettings.BREAK_MAX_MINUTES,
                onChange = { breakMin = it },
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(25 to 5, 50 to 10, 90 to 15).forEach { (f, b) ->
                    FilterChip(
                        selected = focusMin == f && breakMin == b,
                        onClick = {
                            focusMin = f
                            breakMin = b
                        },
                        label = { Text("$f/$b") },
                    )
                }
            }
            Button(
                onClick = {
                    onSave(PomodoroSettings(focusMinutes = focusMin, breakMinutes = breakMin))
                },
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = FocusGradient[1]),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
            ) { Text("保存") }
        }
    }
}

@Composable
private fun StepperRow(
    label: String,
    value: Int,
    range: IntRange,
    onChange: (Int) -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
            )
            OutlinedButton(
                onClick = { onChange((value - 5).coerceIn(range.first, range.last)) },
                enabled = value > range.first,
                shape = CircleShape,
                contentPadding = PaddingValues(horizontal = 14.dp),
            ) { Text("−5") }
            Text(
                text = "$value 分钟",
                modifier = Modifier
                    .width(84.dp)
                    .padding(horizontal = 4.dp),
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
            )
            OutlinedButton(
                onClick = { onChange((value + 5).coerceIn(range.first, range.last)) },
                enabled = value < range.last,
                shape = CircleShape,
                contentPadding = PaddingValues(horizontal = 14.dp),
            ) { Text("＋5") }
        }
    }
}
