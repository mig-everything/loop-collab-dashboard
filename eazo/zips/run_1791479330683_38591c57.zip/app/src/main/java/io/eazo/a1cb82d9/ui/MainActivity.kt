package io.eazo.a1cb82d9.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import io.eazo.a1cb82d9.platform.AppRepo

/**
 * 骨架模板主界面：单 Activity + Jetpack Compose（UI 锁死声明式——与鸿蒙 ArkUI
 * 声明式对称，禁止 XML 布局/drawable 扇出；主题用 Compose MaterialTheme）。
 *
 * 本需求实现：PomodoroScreen（番茄钟）。硬规则 ②：onResume 只 refresh()
 * （重读内存态），禁止从持久化 load()——由 AppRepo.version 订阅触发重渲。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background,
                ) {
                    PomodoroScreen()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(this).refresh()
    }
}

/** 深色主题（需求口径：深色 + 柔和渐变点缀）。会话在此改配色，不另建 XML 主题。 */
private val DarkColors = androidx.compose.material3.darkColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFFF2916F),
    onPrimary = androidx.compose.ui.graphics.Color(0xFF2A1006),
    secondary = androidx.compose.ui.graphics.Color(0xFF37D0C0),
    onSecondary = androidx.compose.ui.graphics.Color(0xFF062B26),
    background = androidx.compose.ui.graphics.Color(0xFF0E1116),
    onBackground = androidx.compose.ui.graphics.Color(0xFFE9EDF3),
    surface = androidx.compose.ui.graphics.Color(0xFF151B23),
    onSurface = androidx.compose.ui.graphics.Color(0xFFE9EDF3),
    surfaceVariant = androidx.compose.ui.graphics.Color(0xFF1D242F),
    onSurfaceVariant = androidx.compose.ui.graphics.Color(0xFF9AA6B6),
    outline = androidx.compose.ui.graphics.Color(0xFF2A323F),
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
