package io.eazo.a683ca1ff.platform

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import io.eazo.a683ca1ff.core.FilterImage
import io.eazo.a683ca1ff.core.FilterType
import io.eazo.a683ca1ff.core.Filters
import io.eazo.a683ca1ff.core.SampleImages
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

/**
 * 平台层：AppRepo 进程内单例（硬规则 ①——UI 层禁止 new Repository，一律经
 * AppRepo.getRepo(context) 获取）。
 *
 * 内存态为权威状态：跨页面返回（onResume→refresh）只重读内存态，绝不从
 * 持久化 load()（硬规则 ②）。保存记录列表 listSaved() 走确定性排序
 * （硬规则 ③）：主键 savedAtMillis 降序、次键 id 字典序升序。
 */
object AppRepo {

    /** 保存记录（字段双端 1:1：id/fileName/filterId/filterLabel/strength/width/height/savedAtMillis）。 */
    data class SavedRecord(
        val id: String,
        val fileName: String,
        val filterId: String,
        val filterLabel: String,
        val strength: Int,
        val width: Int,
        val height: Int,
        val savedAtMillis: Long,
    )

    private val samples: List<FilterImage> by lazy { SampleImages.all() }
    private val saved = mutableListOf<SavedRecord>()
    private var saveSeq = 0
    private var album: FilterImage? = null

    var currentFilter: FilterType = FilterType.GRAYSCALE
        private set
    var currentStrength: Int = Filters.DEFAULT_STRENGTH
        private set
    var currentSampleIndex: Int = 0
        private set
    var useAlbum: Boolean = false
        private set

    /** 进程内单例入口（硬规则 ① 落点）——UI 层唯一获取通道。 */
    fun getRepo(context: Context): AppRepo = this

    fun listSamples(): List<FilterImage> = samples

    /** 当前生效图：相册选择优先，否则内置示例图。 */
    fun activeImage(): FilterImage =
        if (useAlbum) album ?: samples[currentSampleIndex] else samples[currentSampleIndex]

    fun selectSample(index: Int) {
        currentSampleIndex = index.coerceIn(samples.indices)
        useAlbum = false
    }

    fun setAlbum(image: FilterImage) {
        album = image
        useAlbum = true
    }

    fun setFilter(type: FilterType) {
        currentFilter = type
    }

    fun setStrength(value: Int) {
        currentStrength = value.coerceIn(Filters.MIN_STRENGTH, Filters.MAX_STRENGTH)
    }

    /** 硬规则 ②：refresh 只重读内存态（内存态即权威），禁止从持久化 load()。 */
    fun refresh() {
        // 内存态无外部写者，重读即 no-op；保留入口对齐骨架契约
    }

    /** 确定性排序：主键 savedAtMillis 降序、次键 id 字典序升序兜底。 */
    fun listSaved(): List<SavedRecord> =
        saved.sortedWith(compareByDescending<SavedRecord> { it.savedAtMillis }.thenBy { it.id })

    /** 生成保存记录（id 含毫秒时间戳 + 序号，同毫秒也保证唯一/字典序稳定）。 */
    fun recordSave(
        filter: FilterType,
        strength: Int,
        width: Int,
        height: Int,
        savedAtMillis: Long,
    ): SavedRecord {
        saveSeq = (saveSeq + 1) % 1000
        val id = String.format(Locale.ROOT, "%013d-%03d", savedAtMillis, saveSeq)
        return SavedRecord(
            id = id,
            fileName = "filtered_$id",
            filterId = filter.id,
            filterLabel = filter.label,
            strength = strength.coerceIn(Filters.MIN_STRENGTH, Filters.MAX_STRENGTH),
            width = width,
            height = height,
            savedAtMillis = savedAtMillis,
        )
    }

    fun addSaved(record: SavedRecord) {
        saved.add(record)
    }

    /** 仅供 JVM 单测：进程内单例无法重建，测试后清空内存态。 */
    fun clearForTest() {
        saved.clear()
        saveSeq = 0
        album = null
        currentFilter = FilterType.GRAYSCALE
        currentStrength = Filters.DEFAULT_STRENGTH
        currentSampleIndex = 0
        useAlbum = false
    }

    /**
     * 效果图落盘为 PNG：Q+ 走 MediaStore（无需存储权限），Q- 写应用专属
     * Pictures 目录并触发媒体扫描（同样零权限）。
     */
    fun savePng(context: Context, pixels: IntArray, width: Int, height: Int, fileName: String): Uri? {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                saveViaMediaStore(context, bitmap, fileName)
            } else {
                saveViaAppDir(context, bitmap, fileName)
            }
        } catch (_: Exception) {
            null
        } finally {
            bitmap.recycle()
        }
    }

    private fun saveViaMediaStore(context: Context, bitmap: Bitmap, fileName: String): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$fileName.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/光影滤镜")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        resolver.openOutputStream(uri)?.use { out ->
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) return null
        } ?: return null
        val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
        resolver.update(uri, done, null, null)
        return uri
    }

    private fun saveViaAppDir(context: Context, bitmap: Bitmap, fileName: String): Uri? {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return null
        val file = File(dir, "$fileName.png")
        FileOutputStream(file).use { out ->
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) return null
        }
        MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("image/png"), null)
        return Uri.fromFile(file)
    }
}
