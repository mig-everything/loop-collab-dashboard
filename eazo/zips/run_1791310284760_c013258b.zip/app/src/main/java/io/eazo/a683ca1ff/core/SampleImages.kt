package io.eazo.a683ca1ff.core

/**
 * 内置示例图：程序化确定性生成（纯整数运算，无资源文件扇出——骨架纪律 ②；
 * 同输入恒同输出，JVM 可单测）。固定顺序 = 内置示例图顺序（双端 1:1）。
 */
object SampleImages {

    fun all(): List<FilterImage> = listOf(sunset(), rings(), mosaic())

    /** ① 落日渐变：对角渐变 + 太阳圆盘。 */
    private fun sunset(): FilterImage {
        val w = 480
        val h = 320
        val px = IntArray(w * h)
        val sunX = 346
        val sunY = 122
        val sunR2 = 58 * 58
        for (y in 0 until h) {
            for (x in 0 until w) {
                val t = (x * 100 / (w - 1) + y * 100 / (h - 1)) / 2
                var r = (255 * (100 - t) + 92 * t) / 100
                var g = (140 * (100 - t) + 64 * t) / 100
                var b = (64 * (100 - t) + 160 * t) / 100
                val dx = x - sunX
                val dy = y - sunY
                if (dx * dx + dy * dy < sunR2) {
                    r = 255; g = 214; b = 140
                }
                px[y * w + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        return FilterImage("sample-sunset", "落日渐变", w, h, px)
    }

    /** ② 同心色环：距离平方分带取色（避免开方，保整数确定性）。 */
    private fun rings(): FilterImage {
        val w = 480
        val h = 320
        val px = IntArray(w * h)
        val cx = 240
        val cy = 160
        val palette = intArrayOf(
            0xFF1E2A44.toInt(), 0xFF2E5E8C.toInt(), 0xFF6FD8C9.toInt(), 0xFFF2C879.toInt(),
        )
        for (y in 0 until h) {
            for (x in 0 until w) {
                val dx = x - cx
                val dy = y - cy
                val band = ((dx * dx + dy * dy) / 1800) % palette.size
                px[y * w + x] = palette[band]
            }
        }
        return FilterImage("sample-rings", "同心色环", w, h, px)
    }

    /** ③ 几何拼贴：棋盘色块 + 对角条纹。 */
    private fun mosaic(): FilterImage {
        val w = 480
        val h = 320
        val px = IntArray(w * h)
        val block = 60
        for (y in 0 until h) {
            for (x in 0 until w) {
                val color = if ((x / block + y / block) % 2 == 0) {
                    0xFF2A2F3A.toInt()
                } else {
                    0xFFE8E2D4.toInt()
                }
                val onStripe = (x - y) in 150..210
                px[y * w + x] = if (onStripe) 0xFFFF8A5C.toInt() else color
            }
        }
        return FilterImage("sample-mosaic", "几何拼贴", w, h, px)
    }
}
