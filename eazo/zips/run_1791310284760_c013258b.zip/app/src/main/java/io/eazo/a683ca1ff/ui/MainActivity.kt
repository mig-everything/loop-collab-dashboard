package io.eazo.a683ca1ff.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.a683ca1ff.core.FilterImage
import io.eazo.a683ca1ff.core.FilterType
import io.eazo.a683ca1ff.core.Filters
import io.eazo.a683ca1ff.platform.AppRepo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/**
 * 「图片滤镜」主界面：单 Activity + Jetpack Compose（UI 锁死声明式——与
 * 鸿蒙 ArkUI 声明式对称，禁止 XML 布局/drawable 扇出）。
 *
 * 结构：对比画布（原图/效果拖拽分割 + 原图整览）→ 图源选择（内置示例图 +
 * 相册）→ 滤镜 chips → 强度滑杆 → 保存。滤镜计算走 core 纯整数引擎，
 * Default 线程计算不卡主线程。
 *
 * 硬规则 ②：onResume 只 refresh()（重读内存态），禁止从持久化 load()。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    FilterScreen()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        AppRepo.getRepo(this).refresh()
    }
}

/** 深色精致主题（骨架主题原位改造，不另建 XML 主题）。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = MaterialTheme.colorScheme.copy(
        primary = Color(0xFFFF8A5C),
        onPrimary = Color(0xFF2A1408),
        secondary = Color(0xFF6FD8C9),
        background = Color(0xFF101318),
        onBackground = Color(0xFFEDEFF4),
        surface = Color(0xFF181C24),
        onSurface = Color(0xFFEDEFF4),
        surfaceVariant = Color(0xFF232936),
        onSurfaceVariant = Color(0xFF9AA3B2),
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

private val CardShape = RoundedCornerShape(24.dp)
private val ChipShape = RoundedCornerShape(14.dp)

@Composable
private fun FilterScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repo = remember { AppRepo.getRepo(context) }

    var filter by remember { mutableStateOf(repo.currentFilter) }
    var strength by remember { mutableIntStateOf(repo.currentStrength) }
    var useAlbum by remember { mutableStateOf(repo.useAlbum) }
    var sourceKey by remember { mutableIntStateOf(0) } // 图源变更信号，驱动重读 activeImage
    var savedCount by remember { mutableIntStateOf(repo.listSaved().size) }
    var showOriginalOnly by remember { mutableStateOf(false) }
    var split by remember { mutableFloatStateOf(0.5f) }
    var originalBmp by remember { mutableStateOf<Bitmap?>(null) }
    var filteredBmp by remember { mutableStateOf<Bitmap?>(null) }
    var computing by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf<String?>(null) }

    val sampleBitmaps = remember { repo.listSamples().map { it.toBitmap().asImageBitmap() } }

    // 原图装载（图源变化时重解码）
    LaunchedEffect(useAlbum, sourceKey) {
        val img = repo.activeImage()
        originalBmp = withContext(Dispatchers.Default) { img.toBitmap() }
    }

    // 效果图计算（滤镜/强度/原图任一变化即重算；delay 兼作拖动防抖）
    LaunchedEffect(originalBmp, filter, strength) {
        val src = originalBmp ?: return@LaunchedEffect
        computing = true
        delay(20)
        val out = withContext(Dispatchers.Default) {
            Filters.apply(src.toIntArray(), filter, strength)
        }
        if (isActive) {
            filteredBmp = Bitmap
                .createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
                .also { it.setPixels(out, 0, src.width, 0, 0, src.width, src.height) }
        }
        computing = false
    }

    LaunchedEffect(toast) {
        toast?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            toast = null
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val img = withContext(Dispatchers.IO) { decodeAlbumImage(context, uri) }
                if (img != null) {
                    repo.setAlbum(img)
                    useAlbum = true
                    sourceKey++
                } else {
                    toast = "图片读取失败，换一张试试"
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("光影滤镜", fontSize = 26.sp, fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground)
                Text("7 款确定性滤镜 · 实时预览", fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Surface(shape = ChipShape, color = MaterialTheme.colorScheme.surfaceVariant) {
                Text(
                    "已保存 $savedCount",
                    Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.secondary,
                )
            }
        }
        Spacer(Modifier.height(16.dp))

        CompareView(
            original = originalBmp,
            filtered = filteredBmp,
            showOriginalOnly = showOriginalOnly,
            split = split,
            onDrag = { delta -> split = (split + delta).coerceIn(0f, 1f) },
            computing = computing,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(12.dp))

        // 原图 / 效果对比 模式切换
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ModeChip("原图", selected = showOriginalOnly, modifier = Modifier.weight(1f)) {
                showOriginalOnly = true
            }
            ModeChip("效果对比", selected = !showOriginalOnly, modifier = Modifier.weight(1f)) {
                showOriginalOnly = false
            }
        }
        Spacer(Modifier.height(16.dp))

        // 图源：内置示例图 + 相册
        SectionLabel("选择图片")
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(repo.listSamples()) { index, sample ->
                SourceTile(
                    label = sample.label,
                    selected = !useAlbum && repo.currentSampleIndex == index,
                    bitmap = sampleBitmaps[index],
                    onClick = {
                        repo.selectSample(index)
                        useAlbum = false
                        sourceKey++
                    },
                )
            }
            item {
                SourceTile(
                    label = "相册",
                    selected = useAlbum,
                    bitmap = null,
                    onClick = {
                        picker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                        )
                    },
                )
            }
        }
        Spacer(Modifier.height(16.dp))

        // 滤镜 chips
        SectionLabel("滤镜")
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(FilterType.entries.toList()) { ft ->
                FilterChip(
                    selected = filter == ft,
                    onClick = {
                        filter = ft
                        repo.setFilter(ft)
                    },
                    label = { Text(ft.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                    ),
                )
            }
        }
        Spacer(Modifier.height(16.dp))

        // 强度
        Surface(shape = CardShape, color = MaterialTheme.colorScheme.surface) {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("强度", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                    Spacer(Modifier.weight(1f))
                    Text(
                        "$strength%",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Slider(
                    value = strength / 100f,
                    onValueChange = {
                        strength = (it * 100).roundToInt()
                        repo.setStrength(strength)
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary,
                        inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant,
                    ),
                )
            }
        }
        Spacer(Modifier.height(20.dp))

        Button(
            onClick = {
                val bmp = filteredBmp ?: return@Button
                scope.launch {
                    computing = true
                    val message = withContext(Dispatchers.IO) {
                        val px = bmp.toIntArray()
                        val record = repo.recordSave(
                            filter, strength, bmp.width, bmp.height, System.currentTimeMillis(),
                        )
                        val uri = repo.savePng(context, px, bmp.width, bmp.height, record.fileName)
                        if (uri != null) {
                            repo.addSaved(record)
                            "已保存到相册（${record.filterLabel} · ${record.strength}%）"
                        } else {
                            "保存失败，请重试"
                        }
                    }
                    computing = false
                    savedCount = repo.listSaved().size
                    toast = message
                }
            },
            enabled = !computing && filteredBmp != null,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = ChipShape,
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
        ) {
            Text("保存效果图", fontSize = 16.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary)
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.onSurfaceVariant)
}

/** 原图/效果拖拽分割对比画布（同一 Canvas 双 drawImage，像素级对齐）。 */
@Composable
private fun CompareView(
    original: Bitmap?,
    filtered: Bitmap?,
    showOriginalOnly: Boolean,
    split: Float,
    onDrag: (Float) -> Unit,
    computing: Boolean,
    modifier: Modifier = Modifier,
) {
    Box(modifier) {
        val base = if (showOriginalOnly || filtered == null) original else filtered
        val overlay = if (showOriginalOnly || filtered == null) null else original
        if (base != null) {
            val ratio = base.width.toFloat() / base.height
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(ratio)
                    .clip(CardShape)
                    .pointerInput(overlay) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            onDrag(dragAmount.x / size.width)
                        }
                    },
            ) {
                val dst = IntSize(size.width.roundToInt(), size.height.roundToInt())
                drawImage(base.asImageBitmap(), dstSize = dst)
                overlay?.let {
                    clipRect(0f, 0f, size.width * split, size.height) {
                        drawImage(it.asImageBitmap(), dstSize = dst)
                    }
                    drawLine(
                        color = Color.White,
                        start = Offset(size.width * split, 0f),
                        end = Offset(size.width * split, size.height),
                        strokeWidth = 3f,
                    )
                }
            }
            if (computing) {
                Surface(
                    shape = ChipShape,
                    color = Color(0xCC000000),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp),
                ) {
                    Text(
                        "计算中…",
                        Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        fontSize = 11.sp,
                        color = Color.White,
                    )
                }
            }
            if (overlay != null && !showOriginalOnly) {
                Surface(
                    shape = ChipShape,
                    color = Color(0xCC000000),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 10.dp),
                ) {
                    Text(
                        "左右拖动对比原图",
                        Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                        fontSize = 11.sp,
                        color = Color.White,
                    )
                }
            }
        } else {
            // 装载占位（保持 3:2 版式不跳动）
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(3f / 2f)
                    .clip(CardShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
            ) {
                Text(
                    "装载中…",
                    Modifier.align(Alignment.Center),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ModeChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        shape = ChipShape,
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier.clip(ChipShape).clickable(onClick = onClick),
    ) {
        Text(
            text,
            Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}

/** 图源小卡：示例图缩略图 / 相册入口。 */
@Composable
private fun SourceTile(
    label: String,
    selected: Boolean,
    bitmap: ImageBitmap?,
    onClick: () -> Unit,
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clip(ChipShape).clickable(onClick = onClick),
    ) {
        Box(
            Modifier
                .size(width = 88.dp, height = 58.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .border(
                    width = if (selected) 2.dp else 1.dp,
                    color = if (selected) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    },
                    shape = RoundedCornerShape(12.dp),
                ),
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = label,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                )
            } else {
                Text(
                    "＋",
                    Modifier.align(Alignment.Center),
                    fontSize = 22.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            label,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = if (selected) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurfaceVariant
            },
        )
    }
}

// ---------- Bitmap / IntArray 搬运（平台层桥接，core 引擎保持纯 Kotlin） ----------

private fun Bitmap.toIntArray(): IntArray =
    IntArray(width * height).also { getPixels(it, 0, width, 0, 0, width, height) }

private fun FilterImage.toBitmap(): Bitmap =
    Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also {
        it.setPixels(pixels, 0, width, 0, 0, width, height)
    }

/** 相册图解码：按边长降采样到 ≤1536，保证滤镜实时重算流畅。 */
private fun decodeAlbumImage(context: Context, uri: Uri): FilterImage? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, bounds)
    } ?: return null
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

    var inSample = 1
    val maxDim = maxOf(bounds.outWidth, bounds.outHeight)
    while (maxDim / (inSample * 2) >= 768) inSample *= 2

    val opts = BitmapFactory.Options().apply { inSampleSize = inSample }
    val bmp = context.contentResolver.openInputStream(uri)?.use {
        BitmapFactory.decodeStream(it, null, opts)
    } ?: return null
    val px = bmp.toIntArray()
    val w = bmp.width
    val h = bmp.height
    bmp.recycle()
    return FilterImage("album-$uri", "相册", w, h, px)
}
