package io.eazo.a683ca1ff.core

/**
 * 滤镜枚举：7 款固定顺序（硬规则 ③——id/字面量/顺序双端 1:1，
 * 鸿蒙侧枚举字面量与本表完全一致）。
 */
enum class FilterType(val id: String, val label: String) {
    GRAYSCALE("grayscale", "灰度"),
    INVERT("invert", "反色"),
    SEPIA("sepia", "怀旧"),
    BRIGHTNESS("brightness", "亮度"),
    CONTRAST("contrast", "对比度"),
    WARM("warm", "暖色"),
    COOL("cool", "冷色");

    companion object {
        /** id 反查（双端契约字面量通道）。 */
        fun byId(id: String): FilterType? = entries.firstOrNull { it.id == id }
    }
}

/** 滤镜输入/输出图（纯数据，双端字段 1:1：id/label/width/height/pixels）。 */
class FilterImage(
    val id: String,
    val label: String,
    val width: Int,
    val height: Int,
    val pixels: IntArray,
)

/**
 * 确定性滤镜引擎（纯 Kotlin、纯整数运算，JVM 可直接单测——不依赖
 * Android 框架；UI 层只负责 Bitmap ↔ IntArray 搬运）。
 *
 * 确定性口径（与鸿蒙侧一致）：
 *  - 强度 s ∈ [0,100]，线性混合 out = v + floorDiv((target - v) * s + 50, 100)
 *    （floorDiv 向 -∞ 取整，负差值方向同样确定）；
 *  - 所有 target 先 clamp 到 [0,255] 再混合，alpha 原样保留。
 */
object Filters {

    const val MIN_STRENGTH = 0
    const val MAX_STRENGTH = 100
    const val DEFAULT_STRENGTH = 50

    /** 暖/冷色通道偏移满强度幅度。 */
    private const val TINT_OFFSET_MAX = 30

    /** 对灰度数组做滤镜，返回新数组（不改入参）。 */
    fun apply(pixels: IntArray, type: FilterType, strength: Int): IntArray {
        val s = strength.coerceIn(MIN_STRENGTH, MAX_STRENGTH)
        val out = IntArray(pixels.size)
        for (i in pixels.indices) {
            val p = pixels[i]
            val a = (p ushr 24) and 0xFF
            if (a == 0) {
                out[i] = 0
                continue
            }
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            val t = targetOf(type, s, r, g, b)
            val nr = mix(r, t.first, s)
            val ng = mix(g, t.second, s)
            val nb = mix(b, t.third, s)
            out[i] = (a shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
        return out
    }

    /** 线性混合（floorDiv 四舍五入口径，见类注释）。 */
    private fun mix(v: Int, target: Int, s: Int): Int =
        v + (((target - v) * s + 50).floorDivCompat(100))

    private fun Int.floorDivCompat(other: Int): Int {
        val q = this / other
        return if ((this xor other) >= 0 || q * other == this) q else q - 1
    }

    /** 按滤镜类型算三通道目标值（已 clamp）。 */
    private fun targetOf(type: FilterType, s: Int, r: Int, g: Int, b: Int): Triple<Int, Int, Int> = when (type) {
        FilterType.GRAYSCALE -> {
            val y = luma(r, g, b)
            Triple(y, y, y)
        }
        FilterType.INVERT -> Triple(255 - r, 255 - g, 255 - b)
        FilterType.SEPIA -> Triple(
            clamp((r * 393 + g * 769 + b * 189) / 1000),
            clamp((r * 349 + g * 686 + b * 168) / 1000),
            clamp((r * 272 + g * 534 + b * 131) / 1000),
        )
        FilterType.BRIGHTNESS -> {
            val off = TINT_OFFSET_MAX * 4 * s / 100 // 满强度 +120
            Triple(clamp(r + off), clamp(g + off), clamp(b + off))
        }
        FilterType.CONTRAST -> {
            val f = 100 + s // 满强度 2.0
            Triple(
                clamp(((r - 128) * f) / 100 + 128),
                clamp(((g - 128) * f) / 100 + 128),
                clamp(((b - 128) * f) / 100 + 128),
            )
        }
        FilterType.WARM -> {
            val off = TINT_OFFSET_MAX * s / 100
            Triple(clamp(r + off), g, clamp(b - off))
        }
        FilterType.COOL -> {
            val off = TINT_OFFSET_MAX * s / 100
            Triple(clamp(r - off), g, clamp(b + off))
        }
    }

    /** Rec.601 亮度（整数口径）。 */
    private fun luma(r: Int, g: Int, b: Int): Int = (r * 299 + g * 587 + b * 114) / 1000

    private fun clamp(v: Int): Int = v.coerceIn(0, 255)
}
