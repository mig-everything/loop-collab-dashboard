package io.eazo.a683ca1ff.contract

import io.eazo.a683ca1ff.core.FilterType
import io.eazo.a683ca1ff.core.Filters
import io.eazo.a683ca1ff.core.SampleImages
import io.eazo.a683ca1ff.platform.AppRepo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * 契约用例（JVM 纯逻辑，不依赖 Android 框架）：
 * 1. 滤镜枚举 7 款固定顺序/字面量（硬规则 ③ 双端 1:1）；
 * 2. 每款滤镜的确定性像素口径（强度 0 恒等 / 强度 100 目标值 / clamp）；
 * 3. 示例图确定性生成；
 * 4. 保存记录确定性排序（主键 savedAtMillis 降序、次键 id 字典序兜底）。
 */
class FilterContractTest {

    // ---------- 枚举契约 ----------

    @Test
    fun `七款滤镜固定顺序与字面量`() {
        val expected = listOf(
            "grayscale" to "灰度",
            "invert" to "反色",
            "sepia" to "怀旧",
            "brightness" to "亮度",
            "contrast" to "对比度",
            "warm" to "暖色",
            "cool" to "冷色",
        )
        assertEquals(expected, FilterType.entries.map { it.id to it.label })
        assertEquals(FilterType.GRAYSCALE, FilterType.byId("grayscale"))
        assertEquals(FilterType.COOL, FilterType.byId("cool"))
        assertNull(FilterType.byId("vivid"))
    }

    // ---------- 确定性像素口径 ----------

    @Test
    fun `强度0对所有滤镜恒等`() {
        val px = intArrayOf(0xFF102030.toInt(), 0xFF8040C0.toInt(), 0x00000000.toInt())
        for (type in FilterType.entries) {
            assertEquals("类型 $type", px.toList(), Filters.apply(px, type, 0).toList())
        }
    }

    @Test
    fun `灰度_强度100取Rec601亮度`() {
        // 0x10,0x20,0x30 → (16*299+32*587+48*114)/1000 = 29
        val out = Filters.apply(intArrayOf(0xFF102030.toInt()), FilterType.GRAYSCALE, 100)
        assertEquals(0xFF1D1D1D.toInt(), out[0])
    }

    @Test
    fun `灰度_强度50线性混合取整确定`() {
        // r=0,g=0,b=100 → y=(0+0+11400)/1000=11
        // mix: r=0+floorDiv(11*50+50,100)=6；b=100+floorDiv((11-100)*50+50,100)=56
        val out = Filters.apply(intArrayOf(0xFF000064.toInt()), FilterType.GRAYSCALE, 50)
        assertEquals(0xFF060638.toInt(), out[0])
    }

    @Test
    fun `反色_强度100全通道取反`() {
        val out = Filters.apply(intArrayOf(0xFF001020.toInt()), FilterType.INVERT, 100)
        // 00→FF, 10→EF, 20→DF
        assertEquals(0xFFFFEFDF.toInt(), out[0])
    }

    @Test
    fun `怀旧_强度100取sepia矩阵`() {
        // 100,100,100 → tr=135, tg=120, tb=93
        val out = Filters.apply(intArrayOf(0xFF646464.toInt()), FilterType.SEPIA, 100)
        assertEquals(0xFF87785D.toInt(), out[0])
    }

    @Test
    fun `怀旧_纯白纯黑不越界`() {
        val out = Filters.apply(intArrayOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt()), FilterType.SEPIA, 100)
        // 纯白：tr/tg clamp 回 255，tb=(255*937)/1000=238 → 0xFFFFFFEE（sepia 压蓝，正常）
        assertEquals(0xFFFFFFEE.toInt(), out[0])
        assertEquals(0xFF000000.toInt(), out[1]) // 纯黑三通道目标均为 0
    }

    @Test
    fun `亮度_强度100加120并clamp上界`() {
        val out = Filters.apply(
            intArrayOf(0xFF000000.toInt(), 0xFFC0C0C0.toInt()),
            FilterType.BRIGHTNESS, 100,
        )
        assertEquals(0xFF787878.toInt(), out[0])
        assertEquals(0xFFFFFFFF.toInt(), out[1]) // 192+120=312 → clamp 255
    }

    @Test
    fun `对比度_强度100双线性clamp上下界`() {
        val out = Filters.apply(
            intArrayOf(0xFF646464.toInt(), 0xFFC8C8C8.toInt()),
            FilterType.CONTRAST, 100,
        )
        // (100-128)*200/100+128 = 72 = 0x48；(200-128)*200/100+128 = 272 → clamp 255
        assertEquals(0xFF484848.toInt(), out[0])
        assertEquals(0xFFFFFFFF.toInt(), out[1])
    }

    @Test
    fun `暖色升红降蓝_冷色镜像`() {
        val warm = Filters.apply(intArrayOf(0xFF646464.toInt()), FilterType.WARM, 100)
        val cool = Filters.apply(intArrayOf(0xFF646464.toInt()), FilterType.COOL, 100)
        assertEquals(0xFF826446.toInt(), warm[0]) // r 100+30=130, g 100, b 100-30=70
        assertEquals(0xFF466482.toInt(), cool[0]) // r 70, g 100, b 130
    }

    @Test
    fun `alpha原样保留_透明像素输出透明`() {
        val out = Filters.apply(intArrayOf(0x80FF0000.toInt(), 0x00000000.toInt()), FilterType.GRAYSCALE, 100)
        assertEquals(0x80, (out[0] ushr 24) and 0xFF)
        assertEquals(0, out[1])
    }

    @Test
    fun `强度越界钳制_引擎不改入参且两次调用结果一致`() {
        val px = intArrayOf(0xFF102030.toInt(), 0xFF8040C0.toInt())
        // -5 钳制为 0 → 恒等；250 钳制为 100 → 等价满强度
        assertEquals(px.toList(), Filters.apply(px, FilterType.WARM, -5).toList())
        assertEquals(
            Filters.apply(px, FilterType.WARM, 100).toList(),
            Filters.apply(px, FilterType.WARM, 250).toList(),
        )
        // 同参数两次调用结果一致；入参数组不被修改
        assertEquals(
            Filters.apply(px, FilterType.WARM, 60).toList(),
            Filters.apply(px, FilterType.WARM, 60).toList(),
        )
        assertEquals(intArrayOf(0xFF102030.toInt(), 0xFF8040C0.toInt()).toList(), px.toList())
    }

    // ---------- 示例图契约 ----------

    @Test
    fun `内置示例图_固定三张_尺寸像素确定且不透明`() {
        val all = SampleImages.all()
        assertEquals(listOf("sample-sunset", "sample-rings", "sample-mosaic"), all.map { it.id })
        for (img in all) {
            assertEquals(img.width * img.height, img.pixels.size)
            assertTrue(img.pixels.all { (it ushr 24) and 0xFF == 0xFF })
        }
        // 同输入恒同输出
        val again = SampleImages.all()
        for (i in all.indices) {
            assertSame(all[i].id, again[i].id)
            assertTrue(all[i].pixels.contentEquals(again[i].pixels))
        }
        assertNotEquals(all[0].pixels.toList(), all[2].pixels.toList())
    }

    // ---------- 保存记录确定性排序（硬规则 ③） ----------

    @Test
    fun `保存记录_主键时间降序_次键id字典序兜底`() {
        val repo = AppRepo
        try {
            // 同毫秒两条记录 id 序号递增（-001/-002），乱序插入验证排序
            val r1 = repo.recordSave(FilterType.WARM, 50, 480, 320, 1_000L)
            val r2 = repo.recordSave(FilterType.COOL, 20, 480, 320, 1_000L)
            val r3 = repo.recordSave(FilterType.SEPIA, 80, 480, 320, 2_000L)
            assertTrue(r1.id < r2.id) // 同毫秒字典序兜底成立
            repo.addSaved(r3)
            repo.addSaved(r1)
            repo.addSaved(r2)
            assertEquals(listOf(r3.id, r1.id, r2.id), repo.listSaved().map { it.id })
            // 强度越界钳制
            assertEquals(0, repo.recordSave(FilterType.WARM, -9, 1, 1, 3_000L).strength)
            assertEquals(100, repo.recordSave(FilterType.WARM, 999, 1, 1, 3_000L).strength)
        } finally {
            AppRepo.clearForTest()
        }
    }
}
