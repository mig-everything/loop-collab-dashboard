// Top-level build file. Plugin versions pinned per docs/arch/req006/03-tech-selection.md §2.2.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.10" apply false
}
