package io.eazo.minesweeper.model

/**
 * REQ-007 扫雷数据模型（契约 02-interface-contract.md §1，双端 1:1）。
 * 枚举字面量与鸿蒙端完全同名，禁入 UI-only 状态（问号态）。
 */
enum class CellState { COVERED, REVEALED, FLAGGED }

enum class GameStatus { PLAYING, WON, LOST }

data class Board(
    val cells: List<CellState>,      // 行主序 index = r*9 + c；初始 81 格全 COVERED
    val mines: List<Int>,            // 雷位，升序、互异、值 ∈ [0, 81)
    val status: GameStatus,          // 初始 PLAYING
    val elapsedSeconds: Int          // 展示态整数秒；不参与数据对账（契约 §7.2）
)

data class RevealResult(
    val revealed: List<Int>,         // 本次新增翻开的格 index（升序；含起始格）
    val hitMine: Boolean,
    val wrongFlags: List<Int>        // 失败态：插错的旗（安全格被插旗）的 index（升序）；非失败态为 []
)
