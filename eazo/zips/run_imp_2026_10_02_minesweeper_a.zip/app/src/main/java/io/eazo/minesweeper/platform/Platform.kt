package io.eazo.minesweeper.platform

import java.util.concurrent.atomic.AtomicLong

/**
 * 生产路径 seed 源（契约 §7.1 C3-①）：时间片 + 递增扰动，保证每局雷区不同（不可背板）。
 * 非零、钳到 uint32 范围。测试路径不走这里——直接注入 seed。
 */
object SeedSource {
    private val counter = AtomicLong(0)

    fun nextSeed(): Long {
        val t = System.currentTimeMillis()
        val n = counter.incrementAndGet()
        var s = (t xor (n * 0x9E3779B97F4A7C15uL.toLong())) and 0xFFFFFFFFL
        if (s == 0L) s = 1L
        return s
    }
}

/**
 * 计时（契约 §7.2 C3-②）：起点 = 首次成功 reveal（revealed 非空且非终局 no-op）；
 * 插旗不计时；终局停表；reset/newGame 归零。elapsedSeconds 为展示态整数秒。
 */
class Timer {
    private var startMillis: Long = 0L
    private var running: Boolean = false
    private var accumulated: Int = 0

    /** 首次成功 reveal 起计（由 GameRepository/UI 在 revealed 非空时调用）。 */
    fun onStartReveal() {
        if (running) return
        startMillis = System.currentTimeMillis()
        running = true
    }

    /** 终局停表。 */
    fun onStop() {
        if (running) {
            accumulated = elapsedSeconds()
            running = false
        }
    }

    fun reset() {
        startMillis = 0L
        running = false
        accumulated = 0
    }

    fun elapsedSeconds(): Int {
        if (!running) return accumulated
        return ((System.currentTimeMillis() - startMillis) / 1000L).toInt()
    }
}
