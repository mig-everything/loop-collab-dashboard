package io.eazo.minesweeper.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.eazo.minesweeper.core.BoardLogic
import io.eazo.minesweeper.core.GameConstants
import io.eazo.minesweeper.core.GameRepository
import io.eazo.minesweeper.model.Board
import io.eazo.minesweeper.model.CellState
import io.eazo.minesweeper.model.GameStatus
import io.eazo.minesweeper.platform.Timer

/**
 * 扫雷（US-1~5 主链路）：9×9 棋盘、点击翻格、长按插旗、状态条（剩余雷数+用时）、新游戏。
 * 颜色/图标不进数据对账（契约 §8.1）——仅作美观度维度。
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    GameScreen()
                }
            }
        }
    }
}

/** 数字分色（契约 §8.1）：1..8 双端一致。 */
private val NUMBER_COLORS = listOf(
    Color(0xFF1976D2), // 1 蓝
    Color(0xFF388E3C), // 2 绿
    Color(0xFFD32F2F), // 3 红
    Color(0xFF1565C0), // 4 深蓝
    Color(0xFF8B0000), // 5 深红
    Color(0xFF0097A7), // 6 青
    Color(0xFF212121), // 7 黑
    Color(0xFF757575)  // 8 灰
)

private val COVERED_BG = Color(0xFF90A4AE)
private val REVEALED_BG = Color(0xFFECEFF1)

private fun GameStatus.label(): String = when (this) {
    GameStatus.PLAYING -> "进行中"
    GameStatus.WON -> "🎉 胜利"
    GameStatus.LOST -> "💥 踩雷"
}

@Composable
fun GameScreen() {
    val repo = remember { GameRepository.get() }
    val timer = remember { Timer() }
    var board by remember { mutableStateOf(repo.newGame()) }   // US-1 开局（生产随机 seed，契约 §7.1）
    var elapsed by mutableIntStateOf(0)
    var tickOn by mutableStateOf(false)
    val handler = remember { Handler(Looper.getMainLooper()) }
    val tick = remember {
        object : Runnable {
            override fun run() {
                elapsed = timer.elapsedSeconds()
                handler.postDelayed(this, 1000)
            }
        }
    }
    DisposableEffect(Unit) { onDispose { handler.removeCallbacks(tick) } }

    fun startTickIfNeeded(revealed: Int) {
        if (revealed > 0 && !tickOn) {            // 仅首次成功 reveal 起计（契约 §7.2）
            timer.onStartReveal()
            tickOn = true
            handler.post(tick)
        }
    }
    fun stopTick() {
        if (tickOn) {
            handler.removeCallbacks(tick)
            timer.onStop()
            elapsed = timer.elapsedSeconds()
            tickOn = false
        }
    }
    fun restart() {
        stopTick()
        timer.reset()
        board = repo.newGame()
        elapsed = 0
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 状态条（US-3）：剩余雷数 + 状态 + 用时 + 新游戏（US-4）
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("💣 ${BoardLogic.remainingMines(board)}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(board.status.label(), fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("⏱ ${elapsed}s", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(
                "新游戏",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1976D2),
                modifier = Modifier
                    .background(Color(0xFFE3F2FD))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .combinedClickableCompat { restart() }
            )
        }
        // 9×9 棋盘
        LazyVerticalGrid(
            columns = GridCells.Fixed(GameConstants.COLS),
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items((0 until GameConstants.CELLS).toList()) { i ->
                val r = i / GameConstants.COLS
                val c = i % GameConstants.COLS
                CellView(
                    board = board,
                    index = i,
                    onClick = {
                        val result = repo.applyClick(r, c)
                        startTickIfNeeded(result.revealed.size)
                        board = repo.gameState()
                        if (board.status != GameStatus.PLAYING) stopTick()
                    },
                    onLongPress = {
                        board = repo.applyFlag(r, c)   // 插旗不计时（契约 §7.2）
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CellView(board: Board, index: Int, onClick: () -> Unit, onLongPress: () -> Unit) {
    val state = board.cells[index]
    val r = index / GameConstants.COLS
    val c = index % GameConstants.COLS
    val isMine = board.mines.contains(index)
    val revealedNum = if (state == CellState.REVEALED && !isMine) BoardLogic.countAdjacent(board, r, c) else 0
    val text = when {
        state == CellState.FLAGGED -> "🚩"
        state == CellState.COVERED -> ""
        isMine -> "💣"
        revealedNum > 0 -> "$revealedNum"
        else -> ""
    }
    val bg = if (state == CellState.COVERED) COVERED_BG else REVEALED_BG
    val fg = if (revealedNum > 0) NUMBER_COLORS[revealedNum - 1] else Color(0xFF212121)
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .aspectRatio(1f)
            .background(bg)
            .combinedClickable(onClick = onClick, onLongClick = onLongPress)
    ) {
        Text(text = text, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = fg)
    }
}

/** Text 上直接用 combinedClickable 需要 OptIn，封装一层。 */
@OptIn(ExperimentalFoundationApi::class)
private fun Modifier.combinedClickableCompat(onClick: () -> Unit): Modifier =
    this.combinedClickable(onClick = onClick)
