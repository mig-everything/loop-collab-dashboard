package io.eazo.minesweeper.core

import io.eazo.minesweeper.model.Board
import io.eazo.minesweeper.model.CellState
import io.eazo.minesweeper.model.GameStatus
import io.eazo.minesweeper.model.RevealResult
import io.eazo.minesweeper.platform.SeedSource

/**
 * 常量集中（契约 §1）：可维护性——尺寸/雷数一处定义。
 */
object GameConstants {
    const val ROWS = 9
    const val COLS = 9
    const val MINES = 10
    const val CELLS = ROWS * COLS   // 81
}

/**
 * C1（★P0）确定性布雷：Xorshift32 标准型 + 部分 Fisher-Yates。
 *
 * 口径锁定（契约 §3.1/§3.2，违反任一条即 C1 未闭合）：
 *  - 状态承载：Long（低 32 位有效），每步位运算后 and 0xFFFFFFFFL 归一无符号；
 *  - 第 2 步逻辑右移：state ushr 17（禁 shr）；
 *  - 取模前值必须非负：next() 已归一到 [0, 2^32)，故 j = (next % (i+1)) ∈ [0, i]。
 *
 * 锚点（契约 §3.4）：seed = 20261010 -> mines = [2,3,6,28,47,49,50,63,67,77]
 * 注意锚点 seed 是 20261001。
 */
object Xorshift32 {

    /** 单步推进；返回值已归一到无符号 [0, 2^32)。 */
    fun next(state: Long): Long {
        var s = state and 0xFFFFFFFFL
        s = (s xor ((s shl 13) and 0xFFFFFFFFL)) and 0xFFFFFFFFL
        s = (s xor (s ushr 17)) and 0xFFFFFFFFL          // ★ 逻辑右移（禁 shr）
        s = (s xor ((s shl 5) and 0xFFFFFFFFL)) and 0xFFFFFFFFL
        return s and 0xFFFFFFFFL                          // 收尾归一（Kotlin Long+mask）
    }
}

object Mines {

    /**
     * 部分 Fisher-Yates：只做最后 MINES 次交换，取末尾 10 位升序。
     * 契约 §3.3 伪代码逐行等价。
     */
    fun placeMines(seed: Long): List<Int> {
        var state = seed and 0xFFFFFFFFL
        val cells = IntArray(GameConstants.CELLS) { it }
        for (i in GameConstants.CELLS - 1 downTo GameConstants.CELLS - GameConstants.MINES) {
            state = Xorshift32.next(state)
            val j = (state % (i + 1)).toInt()             // state 已非负 → j ∈ [0, i]
            val t = cells[i]; cells[i] = cells[j]; cells[j] = t
        }
        return cells.copyOfRange(GameConstants.CELLS - GameConstants.MINES, GameConstants.CELLS)
            .sorted()
    }
}

/**
 * 棋盘纯函数（契约 §4/§5/§6）——不依赖任何平台 API，可脱离 UI 单测。
 */
object BoardLogic {

    fun idx(r: Int, c: Int): Int = r * GameConstants.COLS + c

    fun isMine(board: Board, r: Int, c: Int): Boolean = board.mines.contains(idx(r, c))

    /**
     * 相邻雷计数（契约 §4）：8 邻域越界不计；★ 仅读 board.mines，不读 cells 状态——
     * 纯函数性声明：同一 board 同一 (r,c) 恒同输出，与展开/插旗顺序无关。
     */
    fun countAdjacent(board: Board, r: Int, c: Int): Int {
        var count = 0
        for (dr in -1..1) {
            for (dc in -1..1) {
                if (dr == 0 && dc == 0) continue
                val nr = r + dr
                val nc = c + dc
                if (nr in 0 until GameConstants.ROWS && nc in 0 until GameConstants.COLS && isMine(board, nr, nc)) {
                    count++
                }
            }
        }
        return count
    }

    fun revealedCount(board: Board): Int = board.cells.count { it == CellState.REVEALED }

    fun flaggedCount(board: Board): Int = board.cells.count { it == CellState.FLAGGED }

    /** 剩余雷数 = MINES − flaggedCount（可为负，如实显示，契约 §8.2）。 */
    fun remainingMines(board: Board): Int = GameConstants.MINES - flaggedCount(board)

    /** 判胜：所有非雷格均 REVEALED ⇔ revealedCount == 71（契约 §6）。 */
    fun isWin(board: Board): Boolean =
        revealedCount(board) == GameConstants.ROWS * GameConstants.COLS - GameConstants.MINES

    /** 判负：踩雷置 LOST（契约 §6）。 */
    fun isLose(board: Board): Boolean = board.status == GameStatus.LOST

    /** 失败态辅助：插错的旗（安全格被插旗）的 index 升序（契约 §8.3 O7）。 */
    fun sortedFlagsOnSafeCells(board: Board): List<Int> =
        board.cells.withIndex().filter { it.value == CellState.FLAGGED && !board.mines.contains(it.index) }
            .map { it.index }.sorted()

    /**
     * 洪泛展开（契约 §5.1 唯一路径）。★ 旗格透明：既不翻开自己、也不阻断 0 格连通传播。
     * 展开集合是 (board, r, c) 的纯函数（不引入 flagSet 参数）。
     */
    fun reveal(board: Board, r: Int, c: Int): RevealResult {
        // 越界 no-op（契约 §9）
        if (r !in 0 until GameConstants.ROWS || c !in 0 until GameConstants.COLS) {
            return RevealResult(emptyList(), false, emptyList())
        }
        // 终局 no-op / 旗格不响应翻格 / 已翻开幂等 no-op
        if (board.status != GameStatus.PLAYING) return RevealResult(emptyList(), false, emptyList())
        if (board.cells[idx(r, c)] == CellState.FLAGGED) return RevealResult(emptyList(), false, emptyList())
        if (board.cells[idx(r, c)] == CellState.REVEALED) return RevealResult(emptyList(), false, emptyList())

        // 踩雷：翻开该雷 + wrongFlags（安全格被插旗）
        if (isMine(board, r, c)) {
            return RevealResult(listOf(idx(r, c)), true, sortedFlagsOnSafeCells(board))
        }
        // 数字格：仅翻该格
        if (countAdjacent(board, r, c) > 0) {
            return RevealResult(listOf(idx(r, c)), false, emptyList())
        }
        // ---- 0 格：洪泛展开（BFS，集合语义与遍历顺序无关；契约 §5.3 #6 已证 DFS 等价）----
        val visited = HashSet<Int>()
        val revealed = sortedSetOf<Int>()
        val queue = ArrayDeque<Int>()
        queue.add(idx(r, c))
        while (queue.isNotEmpty()) {
            val cur = queue.removeFirst()
            if (!visited.add(cur)) continue
            // ★ 旗格透明（契约 §5.2 文字权威）：不翻开自己，但 0 格连通传播照常——
            //   邻居扩散放在旗检查之外，旗 0 格照样入队邻居（R03：旗@9 → 18,19 仍被翻开）。
            if (board.cells[cur] != CellState.FLAGGED) revealed.add(cur)
            val cr = cur / GameConstants.COLS
            val cc = cur % GameConstants.COLS
            if (countAdjacent(board, cr, cc) == 0) {
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        if (dr == 0 && dc == 0) continue
                        val nr = cr + dr
                        val nc = cc + dc
                        if (nr in 0 until GameConstants.ROWS && nc in 0 until GameConstants.COLS) {
                            val ni = idx(nr, nc)
                            if (!visited.contains(ni)) queue.add(ni)
                        }
                    }
                }
            }
        }
        return RevealResult(revealed.toList(), false, emptyList())
    }
}

/**
 * 游戏仓储（进程内单例，契约 §10/§12 规则 1）：状态更新口径（契约 §6）：
 * hitMine → LOST；isWin → WON；否则保持 PLAYING。
 */
class GameRepository private constructor() {

    private var board: Board = newBoard(DEFAULT_SEED)

    private fun newBoard(seed: Long): Board = Board(
        cells = List(GameConstants.CELLS) { CellState.COVERED },
        mines = Mines.placeMines(seed),
        status = GameStatus.PLAYING,
        elapsedSeconds = 0
    )

    companion object {
        /** 确定性基线（测试/演示/对账锚点），非生产默认（契约 §7.1）。 */
        const val DEFAULT_SEED: Long = 20261001L

        @Volatile
        private var instance: GameRepository? = null

        fun get(): GameRepository =
            instance ?: synchronized(this) {
                instance ?: GameRepository().also { instance = it }
            }

        /** 测试工厂：独立实例（测试路径注入 seed，契约 §7.1），不污染单例。 */
        fun newInstanceForTest(): GameRepository = GameRepository()
    }

    /** 新局（契约 §7.1）：seed 为 null 时走生产路径随机 seed。 */
    fun newGame(seed: Long? = null): Board {
        val s = seed ?: SeedSource.nextSeed()
        board = Board(
            cells = List(GameConstants.CELLS) { CellState.COVERED },
            mines = Mines.placeMines(s),
            status = GameStatus.PLAYING,
            elapsedSeconds = 0
        )
        return board
    }

    fun gameState(): Board = board

    /** 展示态计时秒数（展示态整数秒，不参与数据对账）。 */
    fun elapsedSeconds(): Int = board.elapsedSeconds

    fun setElapsedSeconds(v: Int) {
        board = board.copy(elapsedSeconds = v)
    }

    /**
     * 翻格（US-2）。返回 RevealResult；内部按契约 §6 更新 status。
     */
    fun applyClick(r: Int, c: Int): RevealResult {
        val result = BoardLogic.reveal(board, r, c)
        if (result.revealed.isEmpty()) return result   // no-op 分支集（契约 §9）：返回原状态
        val newCells = board.cells.toMutableList()
        for (i in result.revealed) newCells[i] = CellState.REVEALED
        var newStatus = board.status
        if (result.hitMine) {
            newStatus = GameStatus.LOST
            // 失败态展示全部雷位（契约 §6/§8.3）
            for (m in board.mines) newCells[m] = CellState.REVEALED
        } else if (BoardLogic.isWin(board.copy(cells = newCells))) {
            newStatus = GameStatus.WON
        }
        board = board.copy(cells = newCells, status = newStatus)
        return result
    }

    /**
     * 插旗/取消（US-3，契约 §9）：终局 no-op；已翻开格 no-op；COVERED↔FLAGGED 切换。
     */
    fun applyFlag(r: Int, c: Int): Board {
        if (r !in 0 until GameConstants.ROWS || c !in 0 until GameConstants.COLS) return board
        if (board.status != GameStatus.PLAYING) return board
        val i = BoardLogic.idx(r, c)
        val cur = board.cells[i]
        val next = when (cur) {
            CellState.COVERED -> CellState.FLAGGED
            CellState.FLAGGED -> CellState.COVERED
            CellState.REVEALED -> return board   // 长按已翻开格 no-op
        }
        val newCells = board.cells.toMutableList()
        newCells[i] = next
        board = board.copy(cells = newCells)
        return board
    }
}
