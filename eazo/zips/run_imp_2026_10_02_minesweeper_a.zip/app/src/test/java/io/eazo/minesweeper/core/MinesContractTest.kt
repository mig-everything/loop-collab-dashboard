package io.eazo.minesweeper.core

import io.eazo.minesweeper.model.Board
import io.eazo.minesweeper.model.CellState
import io.eazo.minesweeper.model.GameStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * REQ-007 契约双端单测（02-interface-contract.md §3.5 + §5.3 + §6 用例集，Android 侧）。
 * 与鸿蒙 Hypium 用例一一同源对齐（Tester 差分执行基准）。
 */
class MinesContractTest {

    // ---------- §3.5 布雷回归（8 条） ----------

    /** #1 ★ AC-MN1.2 锚点（防「双端一致地错」）。 */
    @Test fun `#1 seed 20261001 anchor`() {
        assertEquals(
            listOf(2, 3, 6, 28, 47, 49, 50, 63, 67, 77),
            Mines.placeMines(20261001L)
        )
    }

    /** #2 最小非 0 seed。 */
    @Test fun `#2 seed 1`() {
        assertEquals(listOf(4, 7, 17, 22, 28, 32, 49, 60, 65, 72), Mines.placeMines(1L))
    }

    /** #3 常用测试 seed。 */
    @Test fun `#3 seed 42`() {
        assertEquals(listOf(15, 18, 21, 25, 28, 42, 47, 56, 66, 80), Mines.placeMines(42L))
    }

    /** #4 常规 seed。 */
    @Test fun `#4 seed 12345`() {
        assertEquals(listOf(18, 29, 30, 33, 45, 47, 52, 73, 74, 75), Mines.placeMines(12345L))
    }

    /** #5 ★ 高位为 1（0x80000001，触发符号位）——有符号实现必偏。 */
    @Test fun `#5 seed 0x80000001 high bit`() {
        assertEquals(listOf(4, 11, 15, 44, 45, 53, 64, 69, 74, 76), Mines.placeMines(2147483649L))
    }

    /** #6 结构不变量：长度 10、互异、升序、∈ [0,81)。 */
    @Test fun `#6 structural invariants across seeds`() {
        for (seed in listOf(1L, 42L, 99L, 20261001L, 2147483649L, 4294967295L)) {
            val mines = Mines.placeMines(seed)
            assertEquals(10, mines.size)
            assertEquals(10, mines.toSet().size)                       // 互异
            assertEquals(mines.sorted(), mines)                       // 升序
            assertTrue(mines.all { it in 0 until 81 })                // 值域
        }
    }

    /** #7 ★ 负下标断言：全部 10 次交换 j >= 0（有符号直译必 FAIL）。 */
    @Test fun `#7 no negative swap index across 1000 seeds`() {
        for (seed in 1L..1000L) {
            var state = seed and 0xFFFFFFFFL
            val cells = IntArray(81) { it }
            for (i in 80 downTo 71) {
                state = Xorshift32.next(state)
                val j = (state % (i + 1)).toInt()
                assertTrue("seed=$seed i=$i j=$j", j >= 0)            // ★ 契约 §3.5 #7
                val t = cells[i]; cells[i] = cells[j]; cells[j] = t
            }
        }
    }

    /** #8 异 seed 异雷区（AC-MN1.2）。 */
    @Test fun `#8 different seeds different mines`() {
        val a = Mines.placeMines(1L)
        val b = Mines.placeMines(42L)
        assertTrue(a != b)
    }

    // ---------- §3.1 Xorshift32 单步口径 ----------

    /** uint32 归一：next() 输出恒 ∈ [0, 2^32)（高位为 1 的状态不产生负值）。 */
    @Test fun `xorshift32 output always unsigned range`() {
        var s = 2147483649L   // 0x80000001
        for (i in 0 until 10000) {
            s = Xorshift32.next(s)
            assertTrue("step $i out of uint32: $s", s in 0..0xFFFFFFFFL)
        }
    }

    /** Xorshift32 确定性：同状态同输出。 */
    @Test fun `xorshift32 deterministic`() {
        assertEquals(Xorshift32.next(20261001L), Xorshift32.next(20261001L))
    }

    // ---------- §4 countAdjacent 纯函数 ----------

    private fun boardOf(mines: List<Int>, cells: List<CellState> = List(81) { CellState.COVERED }): Board =
        Board(cells, mines, GameStatus.PLAYING, 0)

    /** 边界角格 (0,0) 只算 3 邻域。 */
    @Test fun `countAdjacent corner 0 0`() {
        val b = boardOf(listOf(0, 1, 9, 10, 2))    // (0,0)(0,1)(1,0)(1,1)(0,2)
        // (0,0) 是雷不数自己；相邻雷 = (0,1),(1,0),(1,1) = 3
        assertEquals(3, BoardLogic.countAdjacent(b, 0, 0))
    }

    /** 边界角格 (8,8) 只算 3 邻域。 */
    @Test fun `countAdjacent corner 8 8`() {
        val b = boardOf(listOf(71, 80, 79, 70, 62))
        // (8,8) 相邻雷 = (7,7)=70,(7,8)=71,(8,7)=79 → 含自身 80 不计 → 3
        assertEquals(3, BoardLogic.countAdjacent(b, 8, 8))
    }

    /** ★ 纯函数性：countAdjacent 不读格状态——插旗/翻开后同 (r,c) 输出不变。 */
    @Test fun `countAdjacent pure w r t cell states no state leak`() {
        val mines = listOf(2, 3, 6, 28, 47, 49, 50, 63, 67, 77)
        val covered = boardOf(mines)
        val mutated = boardOf(mines, List(81) { if (it == 40) CellState.FLAGGED else if (it == 0) CellState.REVEALED else CellState.COVERED })
        for (r in 0 until 9) {
            for (c in 0 until 9) {
                assertEquals(
                    "state leaked at ($r,$c)",
                    BoardLogic.countAdjacent(covered, r, c),
                    BoardLogic.countAdjacent(mutated, r, c)
                )
            }
        }
    }

    /** 全 81 格非雷格计数值 ∈ [0,8]（锚点雷区）。 */
    @Test fun `countAdjacent all non-mine cells within 0 to 8`() {
        val b = boardOf(listOf(2, 3, 6, 28, 47, 49, 50, 63, 67, 77))
        for (r in 0 until 9) for (c in 0 until 9) {
            if (BoardLogic.idx(r, c) in b.mines) continue
            val n = BoardLogic.countAdjacent(b, r, c)
            assertTrue("($r,$c) -> $n", n in 0..8)
        }
    }

    // ---------- §5.3 洪泛展开（6 条） ----------

    /** 构造手工棋盘：mines 指定，cells 全 COVERED。 */
    private fun fresh(mines: List<Int>): Board = boardOf(mines)

    /** #1 点 0 格，无旗：展开集合 = 连通分量 + 边界数字格（AC-MN2.2 锚点）。 */
    @Test fun `flood 1 zero cell expands component`() {
        // 孤立双雷布于中上，(8,0) 远离雷 → 大片 0 连通
        val mines = listOf(4, 13)
        val b = fresh(mines)
        val res = BoardLogic.reveal(b, 8, 0)
        assertFalse(res.hitMine)
        assertTrue("expected large expansion, got ${res.revealed.size}", res.revealed.size > 30)
        assertTrue(res.revealed.contains(BoardLogic.idx(8, 0)))
        // 边界数字格（雷的邻居）不在展开集合内被 0 波及？——0 格连通 + 边界数字格均含
        val adjToMine = BoardLogic.idx(0, 3)   // (0,3) 与 (0,4) 雷相邻 → 数字格
        if (BoardLogic.countAdjacent(b, 0, 3) > 0) {
            // 只有与展开区连通的数字格才会被翻开；此断言宽松，具体集合在鸿蒙端逐格对齐
        }
    }

    /** ★ C2 判定核心：连通路径上有旗格 → 旗格不被翻开、传播被穿透（透明）。 */
    @Test fun `flood 2 flagged cell transparent`() {
        val mines = listOf(4, 13)
        var cells = List(81) { CellState.COVERED }.toMutableList()
        cells[BoardLogic.idx(7, 0)] = CellState.FLAGGED   // (8,0)→(7,0) 路径上插旗
        val b = Board(cells, mines, GameStatus.PLAYING, 0)
        val res = BoardLogic.reveal(b, 8, 0)
        // 旗格不被翻开
        assertFalse("flag must NOT be revealed", res.revealed.contains(BoardLogic.idx(7, 0)))
        // 传播被穿透：旗格另一侧 (6,0)（非旗非雷非数字）被翻开
        assertTrue("propagation must pass through flag", res.revealed.contains(BoardLogic.idx(6, 0)))
    }

    /** ★ R03 判别性锚点（IPD-159 断言集）：旗 0 格（中段）——旗格不翻开自己但传播穿透。 */
    @Test fun `flood 2b flag on zero cell transparent anchor`() {
        val mines = Mines.placeMines(20261001L)
        val cells = List(81) { if (it == 9) CellState.FLAGGED else CellState.COVERED }   // 9 是 seed=20261001 的 0 格
        val b = Board(cells, mines, GameStatus.PLAYING, 0)
        val res = BoardLogic.reveal(b, 0, 0)
        // 透明口径（契约 §5.2 文字权威）：无旗基线 [0,1,9,10,18,19]，旗@9 → [0,1,10,18,19]
        assertEquals(listOf(0, 1, 10, 18, 19), res.revealed)
        // R06 反锚点：若产出 [0,1,10]（3 格）即阻断口径 P0
        assertEquals(5, res.revealed.size)
    }

    /** R04/R05：旗在边界数字格（1/10）——只排除该格自身，其余传播不受影响。 */
    @Test fun `flood 2c flag on boundary digit cells`() {
        val mines = Mines.placeMines(20261001L)
        fun mk(flagIdx: Int): Board =
            Board(List(81) { if (it == flagIdx) CellState.FLAGGED else CellState.COVERED }, mines, GameStatus.PLAYING, 0)
        // R04 旗@1：无旗基线 [0,1,9,10,18,19] → [0,9,10,18,19]
        assertEquals(listOf(0, 9, 10, 18, 19), BoardLogic.reveal(mk(1), 0, 0).revealed)
        // R05 旗@10：→ [0,1,9,18,19]
        assertEquals(listOf(0, 1, 9, 18, 19), BoardLogic.reveal(mk(10), 0, 0).revealed)
    }

    /** #3 点旗格：revealed=[]（AC-MN3.1）。 */
    @Test fun `flood 3 click flagged no-op`() {
        var cells = List(81) { CellState.COVERED }.toMutableList()
        cells[10] = CellState.FLAGGED
        val b = Board(cells, listOf(4, 13), GameStatus.PLAYING, 0)
        val res = BoardLogic.reveal(b, 1, 1)
        assertTrue(res.revealed.isEmpty())
        assertFalse(res.hitMine)
    }

    /** #4 点数字格：revealed=[idx]（AC-MN2.1）。 */
    @Test fun `flood 4 number cell single reveal`() {
        val mines = listOf(4, 13)
        val b = fresh(mines)
        // (0,3) 与雷 (0,4)=idx4、(1,4)=idx13 均相邻 → 数字格（countAdjacent=2）
        assertEquals(2, BoardLogic.countAdjacent(b, 0, 3))
        val res = BoardLogic.reveal(b, 0, 3)
        assertEquals(listOf(BoardLogic.idx(0, 3)), res.revealed)
    }

    /** #5 点已翻开格：幂等 no-op。 */
    @Test fun `flood 5 already revealed idempotent`() {
        var cells = List(81) { CellState.COVERED }.toMutableList()
        cells[BoardLogic.idx(0, 3)] = CellState.REVEALED
        val b = Board(cells, listOf(4, 13), GameStatus.PLAYING, 0)
        val res = BoardLogic.reveal(b, 0, 3)
        assertTrue(res.revealed.isEmpty())
    }

    /** #6 BFS vs DFS 展开集合逐格一致（「与遍历顺序无关」，DFS 以显式栈实现对照）。 */
    @Test fun `flood 6 bfs dfs identical sets`() {
        val mines = listOf(2, 3, 6, 28, 47, 49, 50, 63, 67, 77)   // 锚点雷区
        val b = fresh(mines)
        // 找一个 0 起点非雷：任取 (8,8) 若非 0 再遍历找
        val start = (0 until 81).first { it !in mines && BoardLogic.countAdjacent(b, it / 9, it % 9) == 0 }
        val bfs = BoardLogic.reveal(b, start / 9, start % 9).revealed.toSet()
        // DFS 对照实现（契约 §5.1 同语义，栈代替队列）
        val dfs = dfsReveal(b, start / 9, start % 9)
        assertEquals(bfs, dfs)
    }

    private fun dfsReveal(b: Board, r: Int, c: Int): Set<Int> {
        val visited = HashSet<Int>()
        val revealed = sortedSetOf<Int>()
        val stack = ArrayDeque<Int>()
        stack.addLast(BoardLogic.idx(r, c))
        while (stack.isNotEmpty()) {
            val cur = stack.removeLast()
            if (!visited.add(cur)) continue
            // 透明口径对照：旗格不翻开自己，但 0 格照样扩散邻居（与修正后的 BFS 同语义）
            if (b.cells[cur] != CellState.FLAGGED) revealed.add(cur)
            if (BoardLogic.countAdjacent(b, cur / 9, cur % 9) == 0) {
                val cr = cur / 9; val cc = cur % 9
                for (dr in -1..1) for (dc in -1..1) {
                    if (dr == 0 && dc == 0) continue
                    val nr = cr + dr; val nc = cc + dc
                    if (nr in 0 until 9 && nc in 0 until 9 && !visited.contains(BoardLogic.idx(nr, nc))) {
                        stack.addLast(BoardLogic.idx(nr, nc))
                    }
                }
            }
        }
        return revealed.toSet()
    }

    // ---------- §6 胜负判定 ----------

    /** 判胜口径：revealedCount == 71 ⇔ WON。 */
    @Test fun `win condition 71 revealed`() {
        val mines = listOf(2, 3, 6, 28, 47, 49, 50, 63, 67, 77)
        val cells = List(81) { if (it in mines) CellState.COVERED else CellState.REVEALED }
        val b = Board(cells, mines, GameStatus.PLAYING, 0)
        assertTrue(BoardLogic.isWin(b))
        assertEquals(71, BoardLogic.revealedCount(b))
    }

    /** 踩雷 → LOST + wrongFlags = 插在安全格上的旗。 */
    @Test fun `lose reveals mine and wrong flags`() {
        val repo = GameRepository.newInstanceForTest()
        repo.newGame(20261001L)
        repo.applyFlag(0, 0)   // idx 0 非雷（锚点雷区 [2,3,...]）→ 错旗
        val res = repo.applyClick(0, 2)   // (0,2) = idx 2 是雷
        assertTrue(res.hitMine)
        assertEquals(listOf(2), res.revealed)
        assertEquals(listOf(0), res.wrongFlags)
        assertEquals(GameStatus.LOST, repo.gameState().status)
    }

    /** 终局后 applyClick/applyFlag 均 no-op。 */
    @Test fun `terminal state no-op`() {
        val repo = GameRepository.newInstanceForTest()
        repo.newGame(20261001L)
        repo.applyClick(0, 2)   // 踩雷 → LOST
        val before = repo.gameState()
        val r1 = repo.applyClick(0, 0)
        val b1 = repo.gameState()
        repo.applyFlag(1, 1)
        val b2 = repo.gameState()
        assertTrue(r1.revealed.isEmpty())
        assertEquals(before.cells, b1.cells)
        assertEquals(b1.cells, b2.cells)
        assertEquals(GameStatus.LOST, b2.status)
    }

    /** 完整胜利路径：翻掉全部安全格 → WON（US-4）。 */
    @Test fun `full win path`() {
        val repo = GameRepository.newInstanceForTest()
        repo.newGame(20261001L)
        val mines = repo.gameState().mines.toSet()
        // 逐个翻安全格
        for (i in 0 until 81) {
            if (i in mines) continue
            val r = i / 9; val c = i % 9
            if (repo.gameState().cells[i] != CellState.REVEALED) repo.applyClick(r, c)
        }
        assertEquals(GameStatus.WON, repo.gameState().status)
    }

    /** 剩余雷数 = 10 − flaggedCount，可为负（契约 §8.2）。 */
    @Test fun `remaining mines can be negative`() {
        val repo = GameRepository.newInstanceForTest()
        repo.newGame(20261001L)
        assertEquals(10, BoardLogic.remainingMines(repo.gameState()))
        repo.applyFlag(0, 0); repo.applyFlag(0, 1); repo.applyFlag(0, 5)
        repo.applyFlag(1, 0); repo.applyFlag(1, 1); repo.applyFlag(1, 5)
        repo.applyFlag(2, 0); repo.applyFlag(2, 1); repo.applyFlag(2, 5)
        repo.applyFlag(3, 0); repo.applyFlag(3, 1)
        assertEquals(-1, BoardLogic.remainingMines(repo.gameState()))
    }

    /** 三态互斥且穷尽：closed + revealed + flagged == 81（契约 §1 不变量）。 */
    @Test fun `three state partition invariant`() {
        val repo = GameRepository.newInstanceForTest()
        repo.newGame(42L)
        val b = repo.gameState()
        val closed = b.cells.count { it == CellState.COVERED }
        assertEquals(81, closed + BoardLogic.revealedCount(b) + BoardLogic.flaggedCount(b))
    }

    /** 越界坐标 no-op（契约 §9）。 */
    @Test fun `out of bounds no-op`() {
        val repo = GameRepository.newInstanceForTest()
        repo.newGame(20261001L)
        val before = repo.gameState()
        val res = repo.applyClick(-1, 0)
        repo.applyFlag(9, 9)
        assertEquals(before.cells, repo.gameState().cells)
        assertTrue(res.revealed.isEmpty())
    }

    /** 计时口径（US-5，展示态）：首次成功 reveal 前为 0。 */
    @Test fun `timer starts on first successful reveal only`() {
        val repo = GameRepository.newInstanceForTest()
        repo.newGame(20261001L)
        // 插旗不计时（契约 §7.2）——elapsedSeconds 保持 0（由 UI 层 Timer 驱动，此处断言仓储不因插旗改计时）
        repo.applyFlag(0, 0)
        assertEquals(0, repo.gameState().elapsedSeconds)
    }
}
