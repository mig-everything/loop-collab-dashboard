// Top-level build file. Plugin versions pinned per docs/arch/req010/03-tech-selection.md §1（2026-10-04 复验零漂移）。
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.10" apply false
}
