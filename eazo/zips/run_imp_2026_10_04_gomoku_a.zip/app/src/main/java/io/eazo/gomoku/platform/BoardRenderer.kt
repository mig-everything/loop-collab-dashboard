package io.eazo.gomoku.platform

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import io.eazo.gomoku.core.GomokuConstants
import io.eazo.gomoku.model.Move
import kotlin.math.floor

/**
 * REQ-010 棋盘渲染（US-1/US-5，Compose Canvas 自绘）——纯渲染层，展示态不入数据对账（AC-G8.1 排除项）。
 * 坐标映射（01-overview R5）：15×15 等分交叉点网格；命中半径半格。
 * 数据/渲染解耦：交叉点坐标系 15×15 等分不随断点变（04-features §1.1）。
 */
object BoardRenderer {

    /** 交叉点 → 画布像素中心（等分网格，pad 为边缘留白比例内含在 size 内）。 */
    fun cellCenter(sizePx: Float, r: Int, c: Int): Offset {
        val step = sizePx / (GomokuConstants.SIZE + 1)
        return Offset(step * (c + 1), step * (r + 1))
    }

    /** 像素 → 交叉点（命中半径半格；越界返回 null）。 */
    fun hitTest(sizePx: Float, x: Float, y: Float): Pair<Int, Int>? {
        val step = sizePx / (GomokuConstants.SIZE + 1)
        val c = floor(x / step - 0.5f + 0.5f).toInt()   // round((x-step)/step) 等价
        val r = floor(y / step - 0.5f + 0.5f).toInt()
        val rr = Math.round((y - step) / step)
        val cc = Math.round((x - step) / step)
        if (rr < 0 || rr >= GomokuConstants.SIZE || cc < 0 || cc >= GomokuConstants.SIZE) return null
        return rr to cc
    }

    val LINE_COLOR = Color(0xFF8D6E4C)
    val STAR_COLOR = Color(0xFF6D4C33)
    val BOARD_BG = Color(0xFFE8C88F)
    val BLACK_STONE = Color(0xFF1A1A1A)
    val WHITE_STONE = Color(0xFFFFFFFF)
    val HIGHLIGHT = Color(0xFFC2452D)

    /** Compose Canvas 棋盘（交叉点网格 + 星位 + 棋子 + 最后一手高亮）。 */
    @Composable
    fun Board(
        board: Array<IntArray>,
        lastMove: Move?,
        onTap: (r: Int, c: Int) -> Unit
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .aspectRatio(1f)
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val ev = awaitPointerEvent()
                            val down = ev.changes.firstOrNull()
                            if (down != null && down.pressed) {
                                val hit = hitTest(size.width.toFloat(), down.position.x, down.position.y)
                                if (hit != null) {
                                    onTap(hit.first, hit.second)
                                    ev.changes.forEach { it.consume() }
                                }
                            }
                        }
                    }
                }
        ) {
            val sizePx = size.width
            drawRect(BOARD_BG)
            val step = sizePx / (GomokuConstants.SIZE + 1)
            // 网格线
            for (i in 0 until GomokuConstants.SIZE) {
                val o = step * (i + 1)
                drawLine(LINE_COLOR, Offset(step, o), Offset(sizePx - step, o), strokeWidth = 1.dp.toPx())
                drawLine(LINE_COLOR, Offset(o, step), Offset(o, sizePx - step), strokeWidth = 1.dp.toPx())
            }
            // 星位 5 点
            for ((r, c) in GomokuConstants.STARS) {
                drawCircle(STAR_COLOR, radius = step * 0.09f, center = cellCenter(sizePx, r, c))
            }
            // 棋子
            for (r in 0 until GomokuConstants.SIZE) {
                for (c in 0 until GomokuConstants.SIZE) {
                    val v = board[r][c]
                    if (v == GomokuConstants.EMPTY) continue
                    val center = cellCenter(sizePx, r, c)
                    drawCircle(
                        if (v == GomokuConstants.BLACK) BLACK_STONE else WHITE_STONE,
                        radius = step * 0.42f,
                        center = center
                    )
                    if (v == GomokuConstants.WHITE) {
                        drawCircle(LINE_COLOR, radius = step * 0.42f, center = center, style = Stroke(1.dp.toPx()))
                    }
                }
            }
            // 最后一手高亮（US-5，展示态）
            if (lastMove != null) {
                drawCircle(
                    HIGHLIGHT,
                    radius = step * 0.16f,
                    center = cellCenter(sizePx, lastMove.r, lastMove.c)
                )
            }
        }
    }
}
