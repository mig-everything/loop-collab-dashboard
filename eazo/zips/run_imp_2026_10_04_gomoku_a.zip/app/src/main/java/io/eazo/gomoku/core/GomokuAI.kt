package io.eazo.gomoku.core

/**
 * REQ-010 人机 AI（契约 §2.2，确定性 Alpha-Beta）——逐行对照伪代码。
 *
 * 前置条件（★ C2/C6，契约 §2.3）：aiMove / alphaBeta 仅在 status == PLAYING 且轮到 turn 方落子时调用
 * （UI 层守卫；违反为未定义行为，core 不防御）。由此 evaluate 永不收到含五连的棋盘，
 * WINDOW_SCORE[5] 与 WIN_BONUS 两量纲永不同台比较。
 *
 * 禁用清单（契约 §2.5）：平手比较禁止 >=（必须严格 >，锚点 B）；
 * candidates 排序禁止非 row-major；禁止契约外剪枝/缓存/Top-K（05-NFR P5）。
 */
object GomokuAI {

    /** 契约 §2.2 evaluate：5 格窗口打分，四方向全盘滑动；混色窗口 0 分。 */
    fun evaluate(board: Array<IntArray>, aiSide: Int): Int {
        var score = 0
        val opp = if (aiSide == GomokuConstants.BLACK) GomokuConstants.WHITE else GomokuConstants.BLACK
        val dirs = listOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)
        for ((dr, dc) in dirs) {
            for (r in 0 until GomokuConstants.SIZE) {
                for (c in 0 until GomokuConstants.SIZE) {
                    if (!BoardLogic.inBounds(r + 4 * dr, c + 4 * dc)) continue
                    var cntAI = 0
                    var cntOpp = 0
                    for (k in 0..4) {
                        val v = board[r + dr * k][c + dc * k]
                        if (v == aiSide) cntAI += 1
                        else if (v == opp) cntOpp += 1
                    }
                    if (cntAI > 0 && cntOpp > 0) continue       // 混色窗口 0 分
                    if (cntOpp > 0) score -= GomokuConstants.windowScore(cntOpp)
                    else if (cntAI > 0) score += GomokuConstants.windowScore(cntAI)
                }
            }
        }
        return score
    }

    /** 契约 §2.2 candidates：Chebyshev ≤ 2 邻域，set 去重，row-major 字典序升序（确定性）。 */
    fun candidates(board: Array<IntArray>): List<Pair<Int, Int>> {
        var allEmpty = true
        for (r in 0 until GomokuConstants.SIZE) {
            for (c in 0 until GomokuConstants.SIZE) {
                if (board[r][c] != GomokuConstants.EMPTY) { allEmpty = false; break }
            }
            if (!allEmpty) break
        }
        if (allEmpty) return listOf(7 to 7)                     // 首手天元
        val pts = HashSet<Pair<Int, Int>>()                     // set 去重
        for (r in 0 until GomokuConstants.SIZE) {
            for (c in 0 until GomokuConstants.SIZE) {
                if (board[r][c] != GomokuConstants.EMPTY) {
                    for (dr in -2..2) {
                        for (dc in -2..2) {
                            val nr = r + dr
                            val nc = c + dc
                            if (BoardLogic.inBounds(nr, nc) && board[nr][nc] == GomokuConstants.EMPTY) {
                                pts.add(nr to nc)
                            }
                        }
                    }
                }
            }
        }
        return pts.sortedWith(compareBy({ it.first }, { it.second }))   // row-major 字典序（契约 §2.5）
    }

    /** 契约 §2.2 alphaBeta：固定深度搜索，根/内层双立即胜路径语义见契约 §2.3。 */
    fun alphaBeta(
        board: Array<IntArray>,
        depth: Int,
        alphaIn: Int,
        betaIn: Int,
        aiSide: Int,
        turn: Int
    ): Int {
        if (depth == 0) return evaluate(board, aiSide)
        val cands = candidates(board)
        if (cands.isEmpty()) return 0                           // 满盘平局
        var alpha = alphaIn
        var beta = betaIn
        val opp = if (aiSide == GomokuConstants.BLACK) GomokuConstants.WHITE else GomokuConstants.BLACK
        if (turn == aiSide) {                                   // 最大化层
            var v = Int.MIN_VALUE
            for ((r, c) in cands) {                             // row-major 顺序（确定性）
                board[r][c] = turn
                v = maxOf(v, if (BoardLogic.checkWin(board, r, c)) {
                    GomokuConstants.WIN_BONUS + depth           // 内层立即胜，越早（depth 大）越优
                } else {
                    alphaBeta(board, depth - 1, alpha, beta, aiSide, opp)
                })
                board[r][c] = GomokuConstants.EMPTY
                if (v > alpha) alpha = v
                if (beta <= alpha) break                        // 剪枝（不改变节点精确值）
            }
            return v
        } else {                                                // 最小化层
            var v = Int.MAX_VALUE
            for ((r, c) in cands) {
                board[r][c] = turn
                v = minOf(v, if (BoardLogic.checkWin(board, r, c)) {
                    -(GomokuConstants.WIN_BONUS + depth)        // 对手内层立即胜
                } else {
                    alphaBeta(board, depth - 1, alpha, beta, aiSide, opp)
                })
                board[r][c] = GomokuConstants.EMPTY
                if (v < beta) beta = v
                if (beta <= alpha) break
            }
            return v
        }
    }

    /** 契约 §2.2 aiMove：根循环立即胜（锚点 F）优先返回；否则全候选搜索，严格 > 平手取 row-major 最小（锚点 B）。 */
    fun aiMove(board: Array<IntArray>, aiSide: Int): Pair<Int, Int> {
        var allEmpty = true
        for (r in 0 until GomokuConstants.SIZE) {
            for (c in 0 until GomokuConstants.SIZE) {
                if (board[r][c] != GomokuConstants.EMPTY) { allEmpty = false; break }
            }
            if (!allEmpty) break
        }
        if (allEmpty) return 7 to 7
        val opp = if (aiSide == GomokuConstants.BLACK) GomokuConstants.WHITE else GomokuConstants.BLACK
        var bestMove: Pair<Int, Int>? = null
        var bestScore = Int.MIN_VALUE
        for ((r, c) in candidates(board)) {                     // row-major 顺序
            board[r][c] = aiSide
            if (BoardLogic.checkWin(board, r, c)) {             // 根循环立即胜（锚点 F 路径）
                board[r][c] = GomokuConstants.EMPTY
                return r to c
            }
            val score = alphaBeta(board, GomokuConstants.DEPTH - 1, Int.MIN_VALUE, Int.MAX_VALUE, aiSide, opp)
            board[r][c] = GomokuConstants.EMPTY
            if (score > bestScore) {                            // ★ 严格 >：平手取 row-major 最小（锚点 B）
                bestScore = score
                bestMove = r to c
            }
        }
        return bestMove!!
    }
}
