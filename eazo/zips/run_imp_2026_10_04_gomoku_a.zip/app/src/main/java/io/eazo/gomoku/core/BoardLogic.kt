package io.eazo.gomoku.core

import io.eazo.gomoku.model.GameStatus
import io.eazo.gomoku.model.Move

/**
 * REQ-010 双人核心纯函数（契约 §2.1，逐行对照伪代码）——不依赖任何平台 API，可脱离 UI 单测。
 *
 * 口径锁定（契约 §2.5 禁用清单）：
 *  - checkWin 计数必须 count >= 5（六连/七连同判，用例 13）；
 *  - aiMove/alphaBeta 平手比较必须严格 >（锚点 B）；
 *  - core 禁 random/时间/IO。
 */
object BoardLogic {

    fun emptyBoard(): Array<IntArray> = Array(GomokuConstants.SIZE) { IntArray(GomokuConstants.SIZE) }

    fun cloneBoard(board: Array<IntArray>): Array<IntArray> = Array(GomokuConstants.SIZE) { r -> board[r].copyOf() }

    fun inBounds(r: Int, c: Int): Boolean =
        r >= 0 && r < GomokuConstants.SIZE && c >= 0 && c < GomokuConstants.SIZE

    /** 契约 §2.1 isLegal：终局禁落 → 越界拒 → 已有子拒。 */
    fun isLegal(board: Array<IntArray>, r: Int, c: Int, status: GameStatus): Boolean {
        if (status != GameStatus.PLAYING) return false
        if (r < 0 || r >= GomokuConstants.SIZE || c < 0 || c >= GomokuConstants.SIZE) return false
        return board[r][c] == GomokuConstants.EMPTY
    }

    /** 契约 §2.1 checkWin：以最近落子为中心，四方向正反扫，count >= 5 判胜。 */
    fun checkWin(board: Array<IntArray>, r: Int, c: Int): Boolean {
        val p = board[r][c]
        if (p == GomokuConstants.EMPTY) return false
        val dirs = listOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)   // 横/竖/斜\/斜/
        for ((dr, dc) in dirs) {
            var count = 1
            for (step in 1..4) {                              // 正方向
                val nr = r + dr * step
                val nc = c + dc * step
                if (inBounds(nr, nc) && board[nr][nc] == p) count += 1 else break
            }
            for (step in 1..4) {                              // 反方向
                val nr = r - dr * step
                val nc = c - dc * step
                if (inBounds(nr, nc) && board[nr][nc] == p) count += 1 else break
            }
            if (count >= 5) return true
        }
        return false
    }

    /**
     * 契约 §2.1 place：落子 + moveStack push + checkWin/满盘/继续三分支状态机。
     * 前置：isLegal(board, r, c, status) == true。
     * @return 新 status
     */
    fun place(board: Array<IntArray>, moveStack: MutableList<Move>, r: Int, c: Int, player: Int): GameStatus {
        board[r][c] = player
        moveStack.add(Move(r, c, player))
        if (checkWin(board, r, c)) {
            return if (player == GomokuConstants.BLACK) GameStatus.BLACK_WIN else GameStatus.WHITE_WIN
        }
        if (moveStack.size == GomokuConstants.CELLS) return GameStatus.DRAW
        return GameStatus.PLAYING
    }

    /**
     * 契约 §2.1 undo（★ C5）：弹栈 (r,c,player) → 格回 EMPTY → status=PLAYING →
     * nextPlayer = 被撤销一手的执子方（显式锁定）。空栈返回 UndoResult(r=-1, c=-1, player=0, ok=false) 无效果。
     */
    data class UndoResult(val ok: Boolean, val r: Int, val c: Int, val player: Int)

    fun undo(board: Array<IntArray>, moveStack: MutableList<Move>): UndoResult {
        if (moveStack.isEmpty()) return UndoResult(false, -1, -1, 0)
        val m = moveStack.removeAt(moveStack.lastIndex)
        board[m.r][m.c] = GomokuConstants.EMPTY
        return UndoResult(true, m.r, m.c, m.player)
    }

    /** 契约 §2.1 restart：225 格 EMPTY + 黑先（status/nextPlayer 由 GameSession 持有）。 */
    fun restart(board: Array<IntArray>, moveStack: MutableList<Move>) {
        for (r in 0 until GomokuConstants.SIZE) {
            for (c in 0 until GomokuConstants.SIZE) {
                board[r][c] = GomokuConstants.EMPTY
            }
        }
        moveStack.clear()
    }
}
