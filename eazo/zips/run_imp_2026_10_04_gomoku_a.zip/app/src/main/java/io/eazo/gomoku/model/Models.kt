package io.eazo.gomoku.model

/**
 * REQ-010 五子棋数据模型（契约 02-interface-contract.md §1，双端 1:1）。
 * 枚举序值锁定：PLAYING=0 / BLACK_WIN=1 / WHITE_WIN=2 / DRAW=3（入数据对账 AC-G8.1）。
 */
enum class GameStatus { PLAYING, BLACK_WIN, WHITE_WIN, DRAW }

/**
 * 落子栈元素（契约 §1 Move 结构体）：三字段 r/c/player。
 */
data class Move(val r: Int, val c: Int, val player: Int)
