package io.eazo.gomoku.platform

import io.eazo.gomoku.core.BoardLogic
import io.eazo.gomoku.core.GomokuAI
import io.eazo.gomoku.core.GomokuConstants
import io.eazo.gomoku.model.GameStatus
import io.eazo.gomoku.model.Move

/**
 * REQ-010 单局状态机持有（契约 §2.1 restart + 01-overview §2）：
 * board / moveStack / status / moveCount / nextPlayer——页面唯一数据源。
 *
 * - 单局态无持久化（PRD §3.2）：进程内持有，页面销毁即丢。
 * - 人机模式 UI 守卫（C2/C6，契约 §2.3）：aiMove 只在 status==PLAYING 且轮到 AI 时调用；
 *   终局后 UI 不再触发 AI。
 * - moveCount == moveStack.size 恒成立（契约 §1 不变量）。
 */
class GameSession(
    /** true = 双人本地对弈；false = 人机（AI 执白）。 */
    var vsAi: Boolean = true
) {
    var board: Array<IntArray> = BoardLogic.emptyBoard()
        private set
    var moveStack: MutableList<Move> = ArrayList()
        private set
    var status: GameStatus = GameStatus.PLAYING
        private set
    var nextPlayer: Int = GomokuConstants.BLACK
        private set

    val moveCount: Int get() = moveStack.size

    /** AI 执子方（人机模式固定 AI 执白）。 */
    val aiSide: Int get() = GomokuConstants.WHITE

    /** 契约 §2.1 restart：清盘黑先。 */
    fun restart() {
        BoardLogic.restart(board, moveStack)
        status = GameStatus.PLAYING
        nextPlayer = GomokuConstants.BLACK
    }

    /**
     * 玩家落子（US-2）：非法落子返回 false 无副作用；
     * 人机模式下若落子成功且轮到 AI，自动触发 AI 应手（UI 守卫内调用 aiMove）。
     */
    fun playerMove(r: Int, c: Int): Boolean {
        if (!BoardLogic.isLegal(board, r, c, status)) return false
        applyMove(r, c, nextPlayer)
        if (vsAi && status == GameStatus.PLAYING && nextPlayer == aiSide) {
            aiTurn()
        }
        return true
    }

    /** 内部：落一子（前置 isLegal 已过）——落子后轮到对手。 */
    private fun applyMove(r: Int, c: Int, player: Int) {
        status = BoardLogic.place(board, moveStack, r, c, player)
        nextPlayer = if (player == GomokuConstants.BLACK) GomokuConstants.WHITE else GomokuConstants.BLACK
    }

    /** AI 应手（前置：status==PLAYING 且轮到 aiSide——由调用点保证，契约 §2.3）。 */
    private fun aiTurn() {
        if (status != GameStatus.PLAYING || nextPlayer != aiSide) return
        val (r, c) = GomokuAI.aiMove(board, aiSide)
        applyMove(r, c, aiSide)
    }

    /**
     * 悔棋（US-4，★ C5 契约 §2.1 undo）：
     * 人机模式下弹两手（AI 一手 + 玩家一手），让玩家重新执子；双人模式弹一手。
     * 空栈无效果返回 false。终局撤销回到对弈（status=PLAYING）。
     */
    fun undo(): Boolean {
        if (moveStack.isEmpty()) return false
        var last = BoardLogic.undo(board, moveStack)
        status = GameStatus.PLAYING
        nextPlayer = last.player                 // 被撤销一手的执子方重新执子（C5）
        if (vsAi && last.player == aiSide && moveStack.isNotEmpty()) {
            // 人机：再弹玩家一手（若还有），nextPlayer 落回玩家
            last = BoardLogic.undo(board, moveStack)
            if (last.ok) nextPlayer = last.player
        }
        if (vsAi && nextPlayer == aiSide && moveStack.isEmpty()) {
            nextPlayer = GomokuConstants.BLACK   // 极端保护：弹空后仍轮黑
        }
        return true
    }

    /** 快照（BoardRenderer 只读棋盘快照不写状态，01-overview §2）。 */
    fun snapshotBoard(): Array<IntArray> = BoardLogic.cloneBoard(board)
}
