package io.eazo.gomoku.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalConfiguration
import io.eazo.gomoku.core.GomokuConstants
import io.eazo.gomoku.model.GameStatus
import io.eazo.gomoku.model.Move
import io.eazo.gomoku.platform.BoardRenderer
import io.eazo.gomoku.platform.GameSession

/**
 * REQ-010 五子棋对弈页（US-1~7）：棋盘 + 状态条 + 悔棋/重开/模式切换；
 * WindowSizeClass compact/medium 断点对齐鸿蒙 600vp（US-7，600dp≈600vp 量级）。
 * 展示态（高亮/提示文案）不入数据对账（AC-G8.1 排除）。
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    GameScreen()
                }
            }
        }
    }
}

private val PAGE_BG = Color(0xFFF7F3EB)
private val CARD_BG = Color(0xFFFFFBF4)
private val TEXT_PRIMARY = Color(0xFF3E3629)
private val TEXT_SECONDARY = Color(0xFF5F574C)   // IPD-234 WCAG AA 口径
private val ACCENT = Color(0xFFC2452D)

private fun GameStatus.label(): String = when (this) {
    GameStatus.PLAYING -> "对弈中"
    GameStatus.BLACK_WIN -> "⚫ 黑方胜"
    GameStatus.WHITE_WIN -> "⚪ 白方胜"
    GameStatus.DRAW -> "🤝 平局"
}

@Composable
fun GameScreen() {
    val session = remember { GameSession(vsAi = true) }
    var board by remember { mutableStateOf(session.snapshotBoard()) }
    var status by remember { mutableStateOf(session.status) }
    var nextPlayer by remember { mutableStateOf(session.nextPlayer) }
    var lastMove by remember { mutableStateOf<Move?>(null) }
    var vsAi by remember { mutableStateOf(session.vsAi) }
    var moveCount by remember { mutableStateOf(0) }

    fun refresh() {
        board = session.snapshotBoard()
        status = session.status
        nextPlayer = session.nextPlayer
        lastMove = session.moveStack.lastOrNull()
        moveCount = session.moveCount
    }

    // US-7 断点：compact(<600dp) 竖排 / medium(≥600dp) 侧栏（WindowSizeClass 对齐 600vp）
    val isMedium = LocalConfiguration.current.screenWidthDp >= 600

    val boardPane: @Composable () -> Unit = {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                status.label(),
                fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TEXT_PRIMARY
            )
            Spacer(Modifier.height(6.dp))
            BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
                val side = if (maxWidth < maxHeight) maxWidth else maxHeight
                BoardRenderer.Board(
                    board = board,
                    lastMove = lastMove,
                    onTap = { r, c ->
                        session.playerMove(r, c)
                        refresh()
                    }
                )
            }
        }
    }

    val controls: @Composable () -> Unit = {
        Column(
            Modifier
                .fillMaxWidth()
                .background(CARD_BG)
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                if (status == GameStatus.PLAYING) {
                    if (nextPlayer == GomokuConstants.BLACK) "⚫ 黑方执子" else "⚪ 白方执子"
                } else "终局",
                fontSize = 15.sp, fontWeight = FontWeight.Medium, color = TEXT_PRIMARY
            )
            Text(
                if (vsAi) "人机对战 · 你执黑先行" else "双人本地对弈",
                fontSize = 12.sp, color = TEXT_SECONDARY
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionChip("↩ 悔棋") { session.undo(); refresh() }
                ActionChip("↻ 重开") { session.restart(); refresh() }
                ActionChip(if (vsAi) "切双人" else "切人机") {
                    session.vsAi = !session.vsAi
                    vsAi = session.vsAi
                    session.restart()
                    refresh()
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("第 $moveCount 手 · 15×15", fontSize = 11.sp, color = TEXT_SECONDARY)
        }
    }

    Column(Modifier.fillMaxSize().background(PAGE_BG)) {
        Spacer(Modifier.height(10.dp))
        if (isMedium) {
            // 平板横屏：棋盘 + 信息侧栏（US-7）
            Row(Modifier.weight(1f)) {
                Box(Modifier.weight(1.6f), contentAlignment = Alignment.Center) { boardPane() }
                Box(Modifier.weight(1f).padding(end = 12.dp, top = 4.dp)) { controls() }
            }
        } else {
            // 手机竖屏：竖排紧凑
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { boardPane() }
            controls()
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ActionChip(text: String, onClick: () -> Unit) {
    Text(
        text,
        fontSize = 14.sp,
        fontWeight = FontWeight.Medium,
        color = Color(0xFFFFFFFF),
        modifier = Modifier
            .background(ACCENT)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    )
}
