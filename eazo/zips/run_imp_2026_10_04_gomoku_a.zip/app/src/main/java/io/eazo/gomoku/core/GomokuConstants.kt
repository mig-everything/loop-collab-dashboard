package io.eazo.gomoku.core

/**
 * REQ-010 常量集中（契约 §1）——双端 1:1，C4 直断言落点（契约 §2.4）。
 * 禁用清单：core/ 禁 random / 时间 API / IO（契约 §2.5）。
 */
object GomokuConstants {
    const val SIZE = 15                       // 15×15 交叉点
    const val CELLS = SIZE * SIZE             // 225
    const val EMPTY = 0
    const val BLACK = 1
    const val WHITE = 2

    /** 星位 5 点（渲染用，非数据契约，契约 §1）。 */
    val STARS: List<Pair<Int, Int>> = listOf(
        7 to 7, 3 to 3, 3 to 11, 11 to 3, 11 to 11
    )

    // ===== 人机 AI 参数（★ C4：单测直断言，契约 §2.6/§2.4）=====
    const val WS5 = 10000000                  // WINDOW_SCORE[5]
    const val WS4 = 100000                    // WINDOW_SCORE[4]
    const val WS3 = 1000                      // WINDOW_SCORE[3]
    const val WS2 = 100                       // WINDOW_SCORE[2]
    const val WS1 = 10                        // WINDOW_SCORE[1]
    const val DEPTH = 2                       // 固定搜索深度（AI 1 手 + 对手 1 手）
    const val WIN_BONUS = 100000000           // 立即胜量纲基值（alphaBeta 内层 ±(WIN_BONUS+depth)）

    /** 契约 §2.6 WINDOW_SCORE 表（5 格窗口逐项写死）。 */
    fun windowScore(cnt: Int): Int = when (cnt) {
        5 -> WS5
        4 -> WS4
        3 -> WS3
        2 -> WS2
        1 -> WS1
        else -> 0
    }
}
