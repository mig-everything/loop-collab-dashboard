package io.eazo.gomoku.core

import io.eazo.gomoku.model.GameStatus
import io.eazo.gomoku.model.Move
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * REQ-010 契约双端单测（02-interface-contract.md §6 用例集，Android 侧）。
 * 与鸿蒙 Hypium（GomokuContract.test.ets）一一同源对齐（Tester 差分执行基准）。
 * 期望值全部取契约锚点（47/47 复算脚本 sa_req010_final_verify.py + SE 50/50）。
 */
class GomokuContractTest {

    // ---------- §6.1 双人核心（13 用例） ----------

    private fun boardOf(vararg stones: Triple<Int, Int, Int>): Array<IntArray> {
        val b = BoardLogic.emptyBoard()
        for ((r, c, p) in stones) b[r][c] = p
        return b
    }

    /** 用例 1 五连横：黑 (7,3)~(7,7)。 */
    @Test fun `case1_horizontal_five`() {
        val b = boardOf(
            Triple(7, 3, GomokuConstants.BLACK), Triple(7, 4, GomokuConstants.BLACK),
            Triple(7, 5, GomokuConstants.BLACK), Triple(7, 6, GomokuConstants.BLACK),
            Triple(7, 7, GomokuConstants.BLACK)
        )
        assertTrue(BoardLogic.checkWin(b, 7, 7))
    }

    /** 用例 2 五连竖：白 (3,5)~(7,5)。 */
    @Test fun `case2_vertical_five`() {
        val b = boardOf(
            Triple(3, 5, GomokuConstants.WHITE), Triple(4, 5, GomokuConstants.WHITE),
            Triple(5, 5, GomokuConstants.WHITE), Triple(6, 5, GomokuConstants.WHITE),
            Triple(7, 5, GomokuConstants.WHITE)
        )
        assertTrue(BoardLogic.checkWin(b, 7, 5))
    }

    /** 用例 3 五连斜 \\：黑 (3,3)~(7,7)。 */
    @Test fun `case3_diagonal_five`() {
        val b = boardOf(
            Triple(3, 3, GomokuConstants.BLACK), Triple(4, 4, GomokuConstants.BLACK),
            Triple(5, 5, GomokuConstants.BLACK), Triple(6, 6, GomokuConstants.BLACK),
            Triple(7, 7, GomokuConstants.BLACK)
        )
        assertTrue(BoardLogic.checkWin(b, 7, 7))
    }

    /** 用例 4 五连反斜 /：黑 (3,7)~(7,3)。 */
    @Test fun `case4_antidiagonal_five`() {
        val b = boardOf(
            Triple(3, 7, GomokuConstants.BLACK), Triple(4, 6, GomokuConstants.BLACK),
            Triple(5, 5, GomokuConstants.BLACK), Triple(6, 4, GomokuConstants.BLACK),
            Triple(7, 3, GomokuConstants.BLACK)
        )
        assertTrue(BoardLogic.checkWin(b, 7, 3))
    }

    /** 用例 5 四连不判胜：黑 (7,3)~(7,6)。 */
    @Test fun `case5_four_not_win`() {
        val b = boardOf(
            Triple(7, 3, GomokuConstants.BLACK), Triple(7, 4, GomokuConstants.BLACK),
            Triple(7, 5, GomokuConstants.BLACK), Triple(7, 6, GomokuConstants.BLACK)
        )
        assertFalse(BoardLogic.checkWin(b, 7, 6))
    }

    /** 用例 6 间断五子不判胜。 */
    @Test fun `case6_gapped_not_win`() {
        val b = boardOf(
            Triple(7, 3, GomokuConstants.BLACK), Triple(7, 4, GomokuConstants.BLACK),
            Triple(7, 5, GomokuConstants.BLACK), Triple(7, 7, GomokuConstants.BLACK),
            Triple(7, 8, GomokuConstants.BLACK)
        )
        assertFalse(BoardLogic.checkWin(b, 7, 8))
    }

    /** 用例 7 越界拒绝。 */
    @Test fun `case7_out_of_bounds_rejected`() {
        val b = BoardLogic.emptyBoard()
        val st = GameStatus.PLAYING
        assertFalse(BoardLogic.isLegal(b, 15, 0, st))
        assertFalse(BoardLogic.isLegal(b, -1, 0, st))
        assertFalse(BoardLogic.isLegal(b, 0, 15, st))
        // 边界 0 行/列不误判（M3 变异守）
        assertTrue(BoardLogic.isLegal(b, 0, 0, st))
        assertTrue(BoardLogic.isLegal(b, 14, 14, st))
    }

    /** 用例 8 已有子拒绝。 */
    @Test fun `case8_occupied_rejected`() {
        val b = BoardLogic.emptyBoard()
        val stack = ArrayList<Move>()
        BoardLogic.place(b, stack, 5, 5, GomokuConstants.BLACK)
        assertFalse(BoardLogic.isLegal(b, 5, 5, GameStatus.PLAYING))
    }

    /** 用例 9 终局禁落。 */
    @Test fun `case9_terminal_rejects`() {
        val b = BoardLogic.emptyBoard()
        assertFalse(BoardLogic.isLegal(b, 5, 5, GameStatus.BLACK_WIN))
    }

    /** 用例 10 ★ C3 平局确定性构造：(r+2c) mod 5 < 3 → BLACK，摆满 225 格无五连，末手 DRAW。 */
    @Test fun `case10_draw_construction`() {
        val b = BoardLogic.emptyBoard()
        val stack = ArrayList<Move>()
        var status = GameStatus.PLAYING
        // 按构造直接摆满（黑白着色 (r+2c) mod 5 < 3 ? BLACK : WHITE）——先验证全盘无五连
        for (r in 0 until GomokuConstants.SIZE) {
            for (c in 0 until GomokuConstants.SIZE) {
                b[r][c] = if ((r + 2 * c) % 5 < 3) GomokuConstants.BLACK else GomokuConstants.WHITE
            }
        }
        for (r in 0 until GomokuConstants.SIZE) {
            for (c in 0 until GomokuConstants.SIZE) {
                assertFalse("($r,$c) 不应判胜", BoardLogic.checkWin(b, r, c))
            }
        }
        // place 末手路径：清盘重放最后一手为第 225 手（简化：直接重放全序列取 status）
        val b2 = BoardLogic.emptyBoard()
        val stack2 = ArrayList<Move>()
        for (r in 0 until GomokuConstants.SIZE) {
            for (c in 0 until GomokuConstants.SIZE) {
                val player = if ((r + 2 * c) % 5 < 3) GomokuConstants.BLACK else GomokuConstants.WHITE
                status = BoardLogic.place(b2, stack2, r, c, player)
            }
        }
        assertEquals(GameStatus.DRAW, status)
        assertEquals(225, stack2.size)
    }

    /** 用例 11 上边界五连：黑 (0,0)~(0,4)。 */
    @Test fun `case11_top_edge_five`() {
        val b = boardOf(
            Triple(0, 0, GomokuConstants.BLACK), Triple(0, 1, GomokuConstants.BLACK),
            Triple(0, 2, GomokuConstants.BLACK), Triple(0, 3, GomokuConstants.BLACK),
            Triple(0, 4, GomokuConstants.BLACK)
        )
        assertTrue(BoardLogic.checkWin(b, 0, 4))
    }

    /** 用例 12 角边界斜五连：黑 (0,0)~(4,4)。 */
    @Test fun `case12_corner_diagonal_five`() {
        val b = boardOf(
            Triple(0, 0, GomokuConstants.BLACK), Triple(1, 1, GomokuConstants.BLACK),
            Triple(2, 2, GomokuConstants.BLACK), Triple(3, 3, GomokuConstants.BLACK),
            Triple(4, 4, GomokuConstants.BLACK)
        )
        assertTrue(BoardLogic.checkWin(b, 4, 4))
    }

    /** 用例 13 ★ 六连判胜（M5 判别）：黑 (7,4)~(7,9) 恰六连。 */
    @Test fun `case13_six_in_row_wins`() {
        val b = boardOf(
            Triple(7, 4, GomokuConstants.BLACK), Triple(7, 5, GomokuConstants.BLACK),
            Triple(7, 6, GomokuConstants.BLACK), Triple(7, 7, GomokuConstants.BLACK),
            Triple(7, 8, GomokuConstants.BLACK), Triple(7, 9, GomokuConstants.BLACK)
        )
        assertTrue(BoardLogic.checkWin(b, 7, 6))   // ==5 变异实现漏判 → CAUGHT
        assertTrue(BoardLogic.checkWin(b, 7, 4))
        // 七连 (7,4)~(7,10) 同判
        b[7][10] = GomokuConstants.BLACK
        assertTrue(BoardLogic.checkWin(b, 7, 6))
        assertTrue(BoardLogic.checkWin(b, 7, 4))
    }

    // ---------- §6.2 9 手落子序列锚点（10 断言） ----------

    /** 黑 (7,7)→白(0,0)→…→黑(7,11)，终局 BLACK_WIN。 */
    @Test fun `anchor_9move_sequence`() {
        val seq = listOf(
            7 to 7, 0 to 0, 7 to 8, 0 to 1, 7 to 9, 0 to 2, 7 to 10, 0 to 3, 7 to 11
        )
        val b = BoardLogic.emptyBoard()
        val stack = ArrayList<Move>()
        var status = GameStatus.PLAYING
        var after8: GameStatus = GameStatus.PLAYING
        seq.forEachIndexed { i, (r, c) ->
            val player = if (i % 2 == 0) GomokuConstants.BLACK else GomokuConstants.WHITE
            assertTrue(BoardLogic.isLegal(b, r, c, status))
            status = BoardLogic.place(b, stack, r, c, player)
            if (i == 7) after8 = status
        }
        assertEquals(9, stack.size)                       // ① moveCount==9
        val blacks = (0 until 9).filter { it % 2 == 0 }.map { seq[it] }
        val whites = (0 until 9).filter { it % 2 == 1 }.map { seq[it] }
        for ((r, c) in blacks) assertEquals(GomokuConstants.BLACK, b[r][c])  // ② 黑子集
        for ((r, c) in whites) assertEquals(GomokuConstants.WHITE, b[r][c])  // ③ 白子集
        var empties = 0
        for (r in 0 until GomokuConstants.SIZE) {
            for (c in 0 until GomokuConstants.SIZE) {
                if (b[r][c] == GomokuConstants.EMPTY) empties++
            }
        }
        assertEquals(216, empties)                        // ④ 其余 216 格 EMPTY
        assertEquals(GameStatus.BLACK_WIN, status)        // ⑤
        assertTrue(BoardLogic.checkWin(b, 7, 11))         // ⑥
        assertTrue(BoardLogic.checkWin(b, 7, 10))         // ⑦
        assertEquals(GameStatus.PLAYING, after8)          // ⑧ 第 8 手后 PLAYING
        assertFalse(BoardLogic.checkWin(b, 7, 10) && after8 == GameStatus.BLACK_WIN)  // ⑨ 四连不判胜
        // ⑩ 第 8 手时 (7,10) 尚未落子 → checkWin 不适用，以状态断言兜底（与鸿蒙同口径）
    }

    // ---------- §2.4 参数直断言（C4） ----------

    @Test fun `params_direct_assert`() {
        // WINDOW_SCORE 五值逐项 + DEPTH==2 + WIN_BONUS（契约 §2.4/§2.6）
        assertEquals(10000000, GomokuConstants.WS5)
        assertEquals(100000, GomokuConstants.WS4)
        assertEquals(1000, GomokuConstants.WS3)
        assertEquals(100, GomokuConstants.WS2)
        assertEquals(10, GomokuConstants.WS1)
        assertEquals(10000000, GomokuConstants.windowScore(5))
        assertEquals(100000, GomokuConstants.windowScore(4))
        assertEquals(1000, GomokuConstants.windowScore(3))
        assertEquals(100, GomokuConstants.windowScore(2))
        assertEquals(10, GomokuConstants.windowScore(1))
        assertEquals(2, GomokuConstants.DEPTH)
        assertEquals(100000000, GomokuConstants.WIN_BONUS)
        // SIZE/EMPTY/BLACK/WHITE + STARS（矩阵 §3）
        assertEquals(15, GomokuConstants.SIZE)
        assertEquals(0, GomokuConstants.EMPTY)
        assertEquals(1, GomokuConstants.BLACK)
        assertEquals(2, GomokuConstants.WHITE)
        assertEquals(
            listOf(7 to 7, 3 to 3, 3 to 11, 11 to 3, 11 to 11),
            GomokuConstants.STARS
        )
        // 枚举序四态 0~3（矩阵 §3 Models 行）
        assertEquals(0, GameStatus.PLAYING.ordinal)
        assertEquals(1, GameStatus.BLACK_WIN.ordinal)
        assertEquals(2, GameStatus.WHITE_WIN.ordinal)
        assertEquals(3, GameStatus.DRAW.ordinal)
    }

    // ---------- §6.3 人机锚点 A~I ----------

    private fun aiAnchor(board: Array<IntArray>, side: Int): Pair<Int, Int> =
        GomokuAI.aiMove(board, side)

    /** A 空棋盘首手天元。 */
    @Test fun `anchor_A_first_move_tengen`() {
        val mv = aiAnchor(BoardLogic.emptyBoard(), GomokuConstants.BLACK)
        assertEquals(Pair(7, 7), mv)
    }

    /** B 两连延伸 (7,6)——平手判别（严格 > 取 row-major 最小）。 */
    @Test fun `anchor_B_two_extend`() {
        val b = boardOf(
            Triple(7, 7, GomokuConstants.BLACK), Triple(7, 8, GomokuConstants.BLACK),
            Triple(0, 0, GomokuConstants.WHITE)
        )
        assertEquals(Pair(7, 6), aiAnchor(b, GomokuConstants.BLACK))
    }

    /** C 挡活三 (7,6)。 */
    @Test fun `anchor_C_block_open_three`() {
        val b = boardOf(
            Triple(7, 7, GomokuConstants.BLACK), Triple(7, 8, GomokuConstants.BLACK),
            Triple(7, 9, GomokuConstants.BLACK), Triple(0, 0, GomokuConstants.WHITE)
        )
        assertEquals(Pair(7, 6), aiAnchor(b, GomokuConstants.WHITE))
    }

    /** D 挡冲四 (7,4)。 */
    @Test fun `anchor_D_block_four`() {
        val b = boardOf(
            Triple(7, 5, GomokuConstants.BLACK), Triple(7, 6, GomokuConstants.BLACK),
            Triple(7, 7, GomokuConstants.BLACK), Triple(7, 8, GomokuConstants.BLACK),
            Triple(7, 9, GomokuConstants.WHITE), Triple(0, 0, GomokuConstants.WHITE)
        )
        assertEquals(Pair(7, 4), aiAnchor(b, GomokuConstants.WHITE))
    }

    /** E 活三成四 (7,5)。 */
    @Test fun `anchor_E_open_three_to_four`() {
        val b = boardOf(
            Triple(7, 6, GomokuConstants.BLACK), Triple(7, 7, GomokuConstants.BLACK),
            Triple(7, 8, GomokuConstants.BLACK), Triple(0, 0, GomokuConstants.WHITE)
        )
        assertEquals(Pair(7, 5), aiAnchor(b, GomokuConstants.BLACK))
    }

    /** F 四连根循环立即胜 (7,4)。 */
    @Test fun `anchor_F_root_immediate_win`() {
        val b = boardOf(
            Triple(7, 5, GomokuConstants.BLACK), Triple(7, 6, GomokuConstants.BLACK),
            Triple(7, 7, GomokuConstants.BLACK), Triple(7, 8, GomokuConstants.BLACK),
            Triple(0, 0, GomokuConstants.WHITE)
        )
        assertEquals(Pair(7, 4), aiAnchor(b, GomokuConstants.BLACK))
    }

    /** G 搜索层攻防 (0,4)（C2-2）。 */
    @Test fun `anchor_G_search_defense`() {
        val b = boardOf(
            // 黑 (7,5)~(7,8) 被白 (7,4),(7,9) 堵两端
            Triple(7, 5, GomokuConstants.BLACK), Triple(7, 6, GomokuConstants.BLACK),
            Triple(7, 7, GomokuConstants.BLACK), Triple(7, 8, GomokuConstants.BLACK),
            Triple(7, 4, GomokuConstants.WHITE), Triple(7, 9, GomokuConstants.WHITE),
            // 白 (0,0),(0,1),(0,2) 活三
            Triple(0, 0, GomokuConstants.WHITE), Triple(0, 1, GomokuConstants.WHITE),
            Triple(0, 2, GomokuConstants.WHITE)
        )
        assertEquals(Pair(0, 4), aiAnchor(b, GomokuConstants.BLACK))
    }

    /** H WS[2] 行为判别 (5,9)（C4-2）。 */
    @Test fun `anchor_H_ws2_discrimination`() {
        val b = boardOf(
            Triple(7, 7, GomokuConstants.BLACK),
            Triple(5, 7, GomokuConstants.WHITE), Triple(5, 8, GomokuConstants.WHITE)
        )
        assertEquals(Pair(5, 9), aiAnchor(b, GomokuConstants.BLACK))
    }

    /** I DEPTH 判别（同 B 局面）(7,6)。 */
    @Test fun `anchor_I_depth_discrimination`() {
        val b = boardOf(
            Triple(7, 7, GomokuConstants.BLACK), Triple(7, 8, GomokuConstants.BLACK),
            Triple(0, 0, GomokuConstants.WHITE)
        )
        assertEquals(Pair(7, 6), aiAnchor(b, GomokuConstants.BLACK))
    }

    // ---------- §6.4 用例 14 undo 终局撤销锚点（C5） ----------

    @Test fun `case14_undo_after_terminal`() {
        val b = BoardLogic.emptyBoard()
        val stack = ArrayList<Move>()
        val seq = listOf(
            7 to 7, 0 to 0, 7 to 8, 0 to 1, 7 to 9, 0 to 2, 7 to 10, 0 to 3, 7 to 11
        )
        var status = GameStatus.PLAYING
        seq.forEachIndexed { i, (r, c) ->
            val player = if (i % 2 == 0) GomokuConstants.BLACK else GomokuConstants.WHITE
            status = BoardLogic.place(b, stack, r, c, player)
        }
        assertEquals(GameStatus.BLACK_WIN, status)
        val res = BoardLogic.undo(b, stack)
        assertTrue(res.ok)
        assertEquals(GomokuConstants.EMPTY, b[7][11])     // ① (7,11) 回 EMPTY
        assertEquals(GomokuConstants.BLACK, res.player)   // ② nextPlayer == BLACK（被撤销一手执子方）
        assertEquals(8, stack.size)                       // ③ moveCount == 8
        // ④ status 回 PLAYING 由 GameSession 持有（undo 纯函数侧：栈/盘已回退）
        // 空栈 undo 无效果
        val b1 = BoardLogic.emptyBoard()
        val s1 = ArrayList<Move>()
        val r1 = BoardLogic.undo(b1, s1)
        assertFalse(r1.ok)
    }

    // ---------- §6.5 用例 15 NFR 锚定局面（C1-2） ----------

    /** 20 手确定性自博弈棋谱 → aiMove(黑) == (4,9)；3 次一致；耗时记录（<500ms 阈值）。 */
    @Test fun `case15_nfr_anchor_20_moves`() {
        val record = listOf(
            7 to 7, 5 to 5, 6 to 8, 5 to 9, 5 to 7, 3 to 7, 4 to 6, 7 to 9,
            8 to 7, 6 to 7, 3 to 5, 2 to 4, 8 to 6, 9 to 5, 8 to 5, 8 to 8,
            8 to 4, 8 to 3, 4 to 8, 6 to 6
        )
        val b = BoardLogic.emptyBoard()
        record.forEachIndexed { i, (r, c) ->
            b[r][c] = if (i % 2 == 0) GomokuConstants.BLACK else GomokuConstants.WHITE
        }
        val t0 = System.nanoTime()
        val mv1 = GomokuAI.aiMove(b, GomokuConstants.BLACK)
        val t1 = System.nanoTime()
        val mv2 = GomokuAI.aiMove(b, GomokuConstants.BLACK)
        val mv3 = GomokuAI.aiMove(b, GomokuConstants.BLACK)
        assertEquals(Pair(4, 9), mv1)                     // 第 21 手期望
        assertEquals(mv1, mv2)                            // 3 次一致（AC-G6.2）
        assertEquals(mv1, mv3)
        val ms = (t1 - t0) / 1_000_000
        println("NFR anchor aiMove elapsed: ${ms}ms")     // 耗时留痕（阈值 500ms，超阈降级契约 §5.3）
        assertTrue("aiMove ${ms}ms 超阈 500ms（降级口径留痕不阻断）", ms < 500)
    }

    // ---------- 补充：restart 初始态（US-1 锚点） ----------

    @Test fun `restart_initial_state`() {
        val b = BoardLogic.emptyBoard()
        val stack = ArrayList<Move>()
        BoardLogic.place(b, stack, 7, 7, GomokuConstants.BLACK)
        BoardLogic.restart(b, stack)
        var allEmpty = true
        for (r in 0 until GomokuConstants.SIZE) {
            for (c in 0 until GomokuConstants.SIZE) {
                if (b[r][c] != GomokuConstants.EMPTY) allEmpty = false
            }
        }
        assertTrue(allEmpty)                              // 225 格全 EMPTY
        assertEquals(0, stack.size)
    }

    /** candidates 确定性排序（row-major）+ 首手天元。 */
    @Test fun `candidates_deterministic_order`() {
        val empty = BoardLogic.emptyBoard()
        assertEquals(listOf(7 to 7), GomokuAI.candidates(empty))
        val b = boardOf(Triple(7, 7, GomokuConstants.BLACK))
        val cands = GomokuAI.candidates(b)
        assertEquals(24, cands.size)                      // Chebyshev ≤2 邻域 5×5-1
        // row-major 升序
        for (i in 1 until cands.size) {
            val (pr, pc) = cands[i - 1]
            val (cr, cc) = cands[i]
            assertTrue(pr < cr || (pr == cr && pc < cc))
        }
    }

    // ---------- GameSession 人机走查（C6 UI 守卫：玩家落子后 AI 应手）——与鸿蒙 session_ai_guards 同源 ----------

    @Test fun `session_ai_guards`() {
        val session = io.eazo.gomoku.platform.GameSession(vsAi = true)   // 人机，玩家执黑
        assertTrue(session.playerMove(7, 7))
        assertEquals(2, session.moveCount)                // 玩家黑 + AI 白自动应手
        assertEquals(GomokuConstants.BLACK, session.nextPlayer)
        // undo 人机弹两手
        val s2 = io.eazo.gomoku.platform.GameSession(vsAi = true)
        s2.playerMove(7, 7)                               // 玩家 + AI = 2 手
        s2.undo()
        assertEquals(0, s2.moveCount)
        assertEquals(GomokuConstants.BLACK, s2.nextPlayer)
        // 双人模式交替：黑→白→黑
        val s3 = io.eazo.gomoku.platform.GameSession(vsAi = false)
        s3.playerMove(7, 7)
        assertEquals(GomokuConstants.WHITE, s3.nextPlayer)
        s3.playerMove(0, 0)
        assertEquals(GomokuConstants.BLACK, s3.nextPlayer)
    }
}
