package io.eazo.a2908eba.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.eazo.moodtracker.data.MOOD_TAGS
import io.eazo.a2908eba.core.MoodRecord
import io.eazo.a2908eba.core.civilFromDays
import io.eazo.a2908eba.core.daysInMonth
import io.eazo.a2908eba.core.firstDayOffset
import io.eazo.a2908eba.core.moodColorForId
import io.eazo.a2908eba.platform.AppRepo

/** "#RRGGBB" → Compose Color（展示层）。 */
fun parseHexColor(hex: String): Color {
    val v = hex.removePrefix("#").toLong(16)
    return Color(red = ((v shr 16) and 0xFF).toInt() / 255f, green = ((v shr 8) and 0xFF).toInt() / 255f, blue = (v and 0xFF).toInt() / 255f)
}

private val WEEKDAY_CN = arrayOf("日", "一", "二", "三", "四", "五", "六")

/** 主页：今日打卡（标签选择 + 一句话 + 保存）+ 月历热力图 + 心情分布（契约 §3 HomePage）。 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MoodScreen(refreshTick: Int, onOpenHistory: () -> Unit) {
    val repo = AppRepo.repo
    var monthY by remember { mutableIntStateOf(civilFromDays(repo.todayEpochDay).first) }
    var monthM by remember { mutableIntStateOf(civilFromDays(repo.todayEpochDay).second) }
    var note by remember { mutableStateOf("") }
    var saveTick by remember { mutableIntStateOf(0) } // 保存后即时刷新月历/分布（写后立读内存态）
    val selected = repo.selectedMoodId
    val phase = repo.pickPhase
    val todayCivil = civilFromDays(repo.todayEpochDay)
    val monthMap = remember(monthY, monthM, refreshTick, saveTick) { repo.recordsByMonth(monthY, monthM) }
    val dist = remember(monthY, monthM, refreshTick, saveTick) { repo.distributionOfMonth(monthY, monthM) }

    fun shiftMonth(delta: Int) {
        var y = monthY; var m = monthM + delta
        if (m < 1) { m = 12; y -= 1 }; if (m > 12) { m = 1; y += 1 }
        monthY = y; monthM = m
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        HeaderRow(todayCivil, onOpenHistory)
        Spacer(Modifier.height(12.dp))
        if (adaptiveColumns(androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp) == 1) {
            TodayCard(repo, selected, phase, note, { note = it }, { repo.pick(it) }, { repo.save(note); note = ""; saveTick++ })
            Spacer(Modifier.height(12.dp))
            CalendarCard(monthY, monthM, monthMap, todayCivil, ::shiftMonth)
            Spacer(Modifier.height(12.dp))
            DistributionCard(dist, monthM)
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f)) {
                    TodayCard(repo, selected, phase, note, { note = it }, { repo.pick(it) }, { repo.save(note); note = ""; saveTick++ })
                }
                Column(Modifier.weight(1f)) {
                    CalendarCard(monthY, monthM, monthMap, todayCivil, ::shiftMonth)
                    Spacer(Modifier.height(12.dp))
                    DistributionCard(dist, monthM)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun HeaderRow(todayCivil: Triple<Int, Int, Int>, onOpenHistory: () -> Unit) {
    val (y, m, d) = todayCivil
    val wd = WEEKDAY_CN[(io.eazo.a2908eba.core.daysFromCivil(y, m, d) + 4) % 7]
    Row(Modifier.fillMaxWidth().padding(top = 20.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("心情打卡", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("$y 年 $m 月 $d 日 · 星期$wd", style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onClick = onOpenHistory) {
            Icon(Icons.Filled.List, contentDescription = "历史记录", tint = MaterialTheme.colorScheme.primary)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TodayCard(
    repo: io.eazo.a2908eba.platform.MoodRepo,
    selected: String?,
    phase: io.eazo.a2908eba.core.PickPhase,
    note: String,
    onNoteChange: (String) -> Unit,
    onPick: (String) -> Unit,
    onSave: () -> Unit,
) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp)) {
            Text("今日心情", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            FlowRow(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                MOOD_TAGS.forEach { tag ->
                    val picked = selected == tag.id
                    val bg = parseHexColor(tag.color)
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (picked) bg else bg.copy(alpha = 0.12f))
                            .clickable { onPick(tag.id) }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(tag.emoji)
                        Spacer(Modifier.width(6.dp))
                        Text(tag.name, color = if (picked) Color(0xFFFFFFFF) else MaterialTheme.colorScheme.onSurface,
                            fontWeight = if (picked) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = note,
                onValueChange = { if (it.length <= 200) onNoteChange(it) },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("一句话记录今天（可选）") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
            )
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (selected != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
                        .clickable(enabled = selected != null) { onSave() }
                        .padding(horizontal = 28.dp, vertical = 12.dp),
                ) {
                    Text("保存今天", color = if (selected != null) Color(0xFFFFFFFF) else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.width(12.dp))
                if (phase == io.eazo.a2908eba.core.PickPhase.SAVED) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = parseHexColor("#6BCB77"))
                    Spacer(Modifier.width(4.dp))
                    Text("已保存", color = parseHexColor("#6BCB77"))
                }
            }
        }
    }
}

@Composable
private fun CalendarCard(
    monthY: Int, monthM: Int,
    monthMap: Map<Int, String>,
    todayCivil: Triple<Int, Int, Int>,
    onShift: (Int) -> Unit,
) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("$monthY 年 $monthM 月", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                IconButton(onClick = { onShift(-1) }) { Icon(Icons.Filled.KeyboardArrowLeft, contentDescription = "上月") }
                IconButton(onClick = { onShift(1) }) { Icon(Icons.Filled.KeyboardArrowRight, contentDescription = "下月") }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                WEEKDAY_CN.forEach {
                    Text(it, Modifier.weight(1f), textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(4.dp))
            val offset = firstDayOffset(monthY, monthM)
            val dim = daysInMonth(monthY, monthM)
            Column(Modifier.fillMaxWidth()) {
                var day = 1 - offset
                while (day <= dim) {
                    Row(Modifier.fillMaxWidth()) {
                        repeat(7) {
                            if (day in 1..dim) {
                                val moodId = monthMap[day]
                                val color = if (moodId != null) parseHexColor(moodColorForId(moodId)) else null
                                val isToday = todayCivil == Triple(monthY, monthM, day)
                                Box(
                                    Modifier.weight(1f).padding(2.dp).aspectRatio(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(color ?: MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text(
                                        "$day",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isToday) MaterialTheme.colorScheme.primary
                                        else if (color != null) Color(0xFFFFFFFF) else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = if (isToday || color != null) FontWeight.Bold else FontWeight.Normal,
                                    )
                                }
                            } else {
                                Spacer(Modifier.weight(1f).padding(2.dp).aspectRatio(1f))
                            }
                            day++
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MOOD_TAGS.forEach { tag ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(parseHexColor(tag.color)))
                        Spacer(Modifier.width(3.dp))
                        Text("${tag.emoji}${tag.name}", style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun DistributionCard(dist: io.eazo.a2908eba.core.Distribution, monthM: Int) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("心情分布", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("本月 ${dist.total} 次", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(10.dp))
            MOOD_TAGS.forEach { tag ->
                val count = dist.counts[tag.id] ?: 0
                val pm = dist.permille[tag.id] ?: 0
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${tag.emoji} ${tag.name}", Modifier.width(64.dp), style = MaterialTheme.typography.bodyMedium)
                    Box(
                        Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Box(
                            Modifier.fillMaxWidth(pm / 1000f).height(10.dp).clip(RoundedCornerShape(5.dp))
                                .background(parseHexColor(tag.color))
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("$count 次 · $pm‰", Modifier.width(76.dp), textAlign = TextAlign.End,
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

/** 历史记录行（供 HistoryScreen 复用）。 */
@Composable
fun RecordRow(record: MoodRecord) {
    val (y, m, d) = civilFromDays(record.dateEpochDay)
    val wd = WEEKDAY_CN[(record.dateEpochDay + 4) % 7]
    val tag = MOOD_TAGS.firstOrNull { it.id == record.moodId }
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(parseHexColor(tag?.color ?: "#9B9B9B").copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center,
        ) { Text(tag?.emoji ?: "") }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("$y-$m-$d 星期$wd · ${tag?.name ?: record.moodId}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            if (record.note.isNotEmpty()) {
                Text(record.note, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Text("无记录语句", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
            }
        }
    }
}
