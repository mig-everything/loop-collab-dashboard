package io.eazo.a2908eba.core

import com.eazo.moodtracker.data.MOOD_IDS
import com.eazo.moodtracker.data.MOOD_TAGS

/**
 * REQ-021 确定性核心（契约 docs/arch/req021/02-interface-contract.md §2）。
 * 纯函数族：零 IO / 零网络 / 零随机 / 零时间源（D8 禁用清单）——
 * 日期由 platform 层显式注入，core 只接受参数。
 */

// ===== model（契约 §1.1，与 ArkTS 1:1）=====

data class MoodRecord(
    val key: String,        // moodRecordKey(dateEpochDay, moodId)
    val dateEpochDay: Int,  // 自 1970-01-01 起的天数（1970-01-01 == 0）
    val moodId: String,     // "M01".."M05"
    val note: String        // 一句话可选记录，自由文本、不入对账口径
)

data class Distribution(
    val counts: Map<String, Int>,    // MoodId -> 次数
    val total: Int,                  // 合法标签计数总和
    val permille: Map<String, Int>   // MoodId -> 千分比 floor(count*1000/total)
)

val MOOD_COUNT: Int = MOOD_IDS.size // 契约常量 5（自 MOOD_IDS 派生，禁手打）

// ===== 状态机字面量（契约 §2.5，与 ArkTS 1:1）=====

enum class NavState(val id: String) { HOME("home"), HISTORY("history") }
enum class NavEvent(val id: String) { OPEN_HISTORY("openHistory"), BACK("back") }
enum class PickPhase(val id: String) { NONE("none"), PICKED("picked"), SAVED("saved") }

/** 导航状态机（契约 §2.5）：3 有效转移 + 未列出组合忽略（返回原态）；HOME+BACK → null（退出 App 根态）。 */
fun nextNav(state: NavState, event: NavEvent): NavState? = when (state) {
    NavState.HOME -> if (event == NavEvent.OPEN_HISTORY) NavState.HISTORY else null
    NavState.HISTORY -> if (event == NavEvent.BACK) NavState.HOME else NavState.HISTORY
}

/** 打卡相位状态机（契约 §2.5）：none/picked/saved × pick/save/reset，未列出组合忽略（返回原态）。 */
fun nextPhase(phase: PickPhase, event: String): PickPhase = when (phase) {
    PickPhase.NONE -> if (event == "pick") PickPhase.PICKED else PickPhase.NONE
    PickPhase.PICKED -> when (event) {
        "pick" -> PickPhase.PICKED
        "save" -> PickPhase.SAVED
        "reset" -> PickPhase.NONE
        else -> PickPhase.PICKED
    }
    PickPhase.SAVED -> when (event) {
        "pick" -> PickPhase.PICKED
        "reset" -> PickPhase.NONE
        else -> PickPhase.SAVED
    }
}

// ===== 确定性核心纯函数（契约 §2.1~§2.4，伪代码逐行落码）=====

/** epoch-day 整数域（Howard Hinnant 纯整数算法；Int 域整除天然向零截断；1970-01-01 == 0）。 */
fun daysFromCivil(y0: Int, m: Int, d: Int): Int {
    val y = if (m <= 2) y0 - 1 else y0
    val era = y / 400
    val yoe = y - era * 400
    val doy = (153 * (m + (if (m > 2) -3 else 9)) + 2) / 5 + d - 1
    val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
    return era * 146097 + doe - 719468
}

/** daysFromCivil 逆运算（展示层日期文案用，纯函数；z ≥ 0 域）。返回 (y, m, d)。 */
fun civilFromDays(z0: Int): Triple<Int, Int, Int> {
    val z = z0 + 719468
    val era = z / 146097
    val doe = z - era * 146097
    val yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365
    val y = yoe + era * 400
    val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
    val mp = (5 * doy + 2) / 153
    val d = doy - (153 * mp + 2) / 5 + 1
    val m = if (mp < 10) mp + 3 else mp - 9
    return Triple(if (m <= 2) y + 1 else y, m, d)
}

/** 记录键（契约 §2.2）：同日期 + 同标签 → 同键；分隔符 U+007C 半角竖线，epoch-day 在前。 */
fun moodRecordKey(d: Int, id: String): String = "$d|$id"

/** 分布统计（契约 §2.3）：整数计数 + 整数千分比 floor；total==0 全 0；域外标签跳过。 */
fun moodDistribution(moodIds: List<String>): Distribution {
    val counts = LinkedHashMap<String, Int>()
    for (id in MOOD_IDS) counts[id] = 0
    for (id in moodIds) if (counts.containsKey(id)) counts[id] = counts[id]!! + 1
    val total = counts.values.sum()
    val permille = if (total == 0) {
        MOOD_IDS.associateWith { 0 }
    } else {
        MOOD_IDS.associateWith { (counts[it]!! * 1000) / total } // Int 域整除天然 floor（正值域）
    }
    return Distribution(counts, total, permille)
}

/** 色块查表（契约 §2.4）：纯查表数据态可测；非法 moodId 返回空串（禁崩溃）。 */
fun moodColorForId(moodId: String): String =
    MOOD_TAGS.firstOrNull { it.id == moodId }?.color ?: ""

// ===== 月历数据面（契约 §3）=====

fun isLeapYear(y: Int): Boolean = y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)

fun daysInMonth(y: Int, m: Int): Int = when (m) {
    1, 3, 5, 7, 8, 10, 12 -> 31
    4, 6, 9, 11 -> 30
    2 -> if (isLeapYear(y)) 29 else 28
    else -> 30
}

/** 月历首日偏移：每月 1 号星期几（0=周日..6=周六；1970-01-01 为周四 → (epochDay+4)%7）。 */
fun firstDayOffset(y: Int, m: Int): Int = (daysFromCivil(y, m, 1) + 4) % 7
