package io.eazo.a2908eba.ui

/**
 * 多端自适应（契约 §10 AC-S7.1，Should 可降级；与鸿蒙 600vp 断点同口径）：
 * 手机竖屏 → 单列；平板/横屏 ≥600dp → 双列。纯函数，数据态可测。
 */
fun adaptiveColumns(widthDp: Int): Int = if (widthDp >= 600) 2 else 1
