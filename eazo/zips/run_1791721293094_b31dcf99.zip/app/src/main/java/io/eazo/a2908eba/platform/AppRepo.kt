package io.eazo.a2908eba.platform

import android.content.Context
import com.eazo.moodtracker.data.MOOD_IDS
import io.eazo.a2908eba.core.Distribution
import io.eazo.a2908eba.core.MoodRecord
import io.eazo.a2908eba.core.PickPhase
import io.eazo.a2908eba.core.daysFromCivil
import io.eazo.a2908eba.core.daysInMonth
import io.eazo.a2908eba.core.moodDistribution
import io.eazo.a2908eba.core.moodRecordKey
import io.eazo.a2908eba.core.nextPhase
import java.util.Calendar

/**
 * 骨架模板平台层：AppRepo 进程内单例（生成器硬规则 ①——UI/卡片层禁止
 * new XxxRepository(...)，一律经 AppRepo.getRepo(context) 获取）。
 *
 * 业务仓储 MoodRepo 作为本 object 成员挂接（参照基线工程 Platform.kt 范式，
 * getRepo() 双检锁构造），保持 getRepo(context) 单例入口不变。
 */

/** 持久化端口（存储格式双端可异构，不入对账口径——契约 §6.5 S3）。 */
interface RecordStore {
    fun read(): String?
    fun write(value: String)
}

/** 内存实现（JVM 单测注入用；模拟重启 = 同一 store 构造第二个 MoodRepo）。 */
class MemoryStore : RecordStore {
    var data: String? = null
    override fun read(): String? = data
    override fun write(value: String) { data = value }
}

/** SharedPreferences 实现（真机持久化，契约 §9：SharedPreferences/DataStore）。 */
class PrefsStore(context: Context) : RecordStore {
    private val prefs = context.getSharedPreferences("mood_records_v1", Context.MODE_PRIVATE)
    override fun read(): String? = prefs.getString("records", null)
    override fun write(value: String) { prefs.edit().putString("records", value).apply() }
}

/**
 * 心情打卡仓储（契约 §3 AppRepo 职责）：
 * - 日期显式注入：todayEpochDay 由构造参数注入（真机 = UI/platform 层取一次系统日期，
 *   core 纯函数零时间源 D8）；
 * - 冷启动 load 一次，此后内存态为唯一事实源，save 写穿持久化；
 * - 覆写幂等（§6.5）：同 key 再存 → 仍 1 条；单日一条口径：同日换标签 → 顶替当日旧记录。
 */
class MoodRepo(private val store: RecordStore, val todayEpochDay: Int) {

    var pickPhase: PickPhase = PickPhase.NONE
        private set
    var selectedMoodId: String? = null
        private set

    private val records = LinkedHashMap<String, MoodRecord>()

    init { load() }

    /** 冷启动装载（唯一一次从持久化 load；此后 refresh 只读内存态——硬规则 ②）。 */
    private fun load() {
        val text = store.read() ?: return
        for (line in text.split('\n')) {
            if (line.isBlank()) continue
            val p = line.split(UNIT)
            if (p.size != 3) continue
            val day = p[0].substringBefore('|').toIntOrNull() ?: continue
            records[p[0]] = MoodRecord(key = p[0], dateEpochDay = day, moodId = p[1], note = p[2])
        }
    }

    private fun persist() {
        val text = records.values.joinToString("\n") { r ->
            listOf(r.key, r.moodId, r.note.replace('\n', ' ').replace(UNIT, ' ')).joinToString(UNIT.toString())
        }
        store.write(text)
    }

    // ===== 打卡相位（契约 §2.5）=====

    fun pick(moodId: String) {
        if (moodId in MOOD_IDS) {
            pickPhase = nextPhase(pickPhase, "pick")
            selectedMoodId = moodId
        }
    }

    /** 重置选择（只清选择不清库——契约 §2.5/§6.8）。 */
    fun reset() {
        pickPhase = nextPhase(pickPhase, "reset")
        selectedMoodId = null
    }

    /** 保存当日打卡：相位 picked 才生效；返回记录键（无效转移返回 null）。note 可空、截 200 字。 */
    fun save(note: String): String? {
        val sel = selectedMoodId
        if (pickPhase != PickPhase.PICKED || sel == null) return null
        pickPhase = nextPhase(pickPhase, "save")
        val key = moodRecordKey(todayEpochDay, sel)
        val clean = note.replace('\n', ' ').replace(UNIT, ' ').trim().take(200)
        // 单日一条（§6.5）：同日已有记录（换标签）→ 顶替旧记录；同键再存 → 覆写（幂等）
        val sameDay = records.values.filter { it.dateEpochDay == todayEpochDay }.map { it.key }
        for (k in sameDay) records.remove(k)
        records[key] = MoodRecord(key = key, dateEpochDay = todayEpochDay, moodId = sel, note = clean)
        persist()
        return key
    }

    // ===== 读接口（只读内存态）=====

    /** 记录列表：dateEpochDay 降序，moodId 字典序兜底（硬规则 ③，与鸿蒙 1:1）。 */
    fun list(): List<MoodRecord> =
        records.values.sortedWith(compareByDescending<MoodRecord> { it.dateEpochDay }.thenBy { it.moodId })

    /** 月历数据面（契约 §3）：day-of-month → moodId 映射。 */
    fun recordsByMonth(y: Int, m: Int): Map<Int, String> {
        val start = daysFromCivil(y, m, 1)
        val dim = daysInMonth(y, m)
        return records.values
            .filter { it.dateEpochDay >= start && it.dateEpochDay < start + dim }
            .associate { (it.dateEpochDay - start + 1) to it.moodId }
    }

    /** 分布统计（月为默认 scope，与月历同集数据——契约 §3）。 */
    fun distributionOfMonth(y: Int, m: Int): Distribution =
        moodDistribution(recordsByMonth(y, m).values.toList())

    companion object {
        private const val UNIT = 'ᐟ' // U+141F Canadian Syllabics（内容禁用字符域外，分隔安全）
    }
}

object AppRepo {

    @Volatile
    private var moodRepo: MoodRepo? = null

    /** 进程内单例入口（硬规则 ① 落点）——UI/卡片层唯一获取通道。双检锁构造。 */
    fun getRepo(context: Context): AppRepo {
        if (moodRepo == null) {
            synchronized(this) {
                if (moodRepo == null) {
                    // 系统日期唯一取用点（契约 §3 日期注入链）：取一次 → daysFromCivil → 注入
                    val c = Calendar.getInstance()
                    val today = daysFromCivil(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
                    moodRepo = MoodRepo(PrefsStore(context.applicationContext), today)
                }
            }
        }
        return this
    }

    /** 仓储句柄（getRepo 之后可用）。 */
    val repo: MoodRepo get() = requireNotNull(moodRepo) { "AppRepo 未初始化：先调 getRepo(context)" }

    /** 硬规则 ②：onResume 只 refresh（重读内存态），禁止从持久化 load()。 */
    fun refresh() {
        // 内存态即事实源；compose 侧经 refreshTick 触发重读 repo.list()/recordsByMonth()
    }
}
