package io.eazo.a2908eba.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import io.eazo.a2908eba.core.NavEvent
import io.eazo.a2908eba.core.NavState
import io.eazo.a2908eba.core.nextNav
import io.eazo.a2908eba.platform.AppRepo

/**
 * 骨架模板主界面：单 Activity + Jetpack Compose（UI 锁死声明式——与鸿蒙 ArkUI
 * 声明式对称，禁止 XML 布局/drawable 扇出；图标用 material-icons，主题用
 * Compose MaterialTheme）。
 *
 * 导航走 nextNav 状态机（契约 §2.5：home↔history 3 有效转移；HOME+BACK=退出
 * 由系统返回兜底——BackHandler 仅在 history 态拦截）。
 * 硬规则 ②：onResume 只 refresh()（重读内存态），禁止从持久化 load()。
 */
class MainActivity : ComponentActivity() {

    private var refreshTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        AppRepo.getRepo(this) // 进程内单例初始化（日期注入 + 冷启动装载）
        setContent {
            AppTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Screen(refreshTick)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    /** 硬规则 ②：onResume 只重读内存态刷新，绝不从持久化重新 load。 */
    private fun render() {
        AppRepo.getRepo(this)
        refreshTick++ // 触发 compose 重读内存态 list()/recordsByMonth()
    }
}

/** 骨架默认主题（浅色）精修：按需求配柔和靛紫主色 + 暖纸底。 */
@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF5B5BD6),
            onPrimary = Color(0xFFFFFFFF),
            surface = Color(0xFFFFFFFF),
            background = Color(0xFFF7F6F2),
            onSurface = Color(0xFF1C1B22),
            onSurfaceVariant = Color(0xFF6E6A75),
            surfaceVariant = Color(0xFFE9E7F2),
        ),
        content = content,
    )
}

/** 根屏：导航状态机 home/history（契约 §2.5 NavState）。 */
@Composable
private fun Screen(refreshTick: Int) {
    var nav by remember { mutableStateOf(NavState.HOME) }
    BackHandler(enabled = nav == NavState.HISTORY) {
        nextNav(nav, NavEvent.BACK)?.let { nav = it }
    }
    when (nav) {
        NavState.HOME -> MoodScreen(refreshTick, onOpenHistory = {
            nextNav(nav, NavEvent.OPEN_HISTORY)?.let { nav = it }
        })
        NavState.HISTORY -> HistoryScreen(refreshTick, onBack = {
            nextNav(nav, NavEvent.BACK)?.let { nav = it }
        })
    }
}
