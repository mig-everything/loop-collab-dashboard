package io.eazo.a2908eba.contract

import com.eazo.moodtracker.data.MOOD_IDS
import com.eazo.moodtracker.data.MOOD_TAGS
import com.eazo.moodtracker.data.TAGS_BYTES
import com.eazo.moodtracker.data.TAGS_SHA256
import io.eazo.a2908eba.core.MOOD_COUNT
import io.eazo.a2908eba.core.PickPhase
import io.eazo.a2908eba.core.civilFromDays
import io.eazo.a2908eba.core.daysFromCivil
import io.eazo.a2908eba.core.daysInMonth
import io.eazo.a2908eba.core.firstDayOffset
import io.eazo.a2908eba.core.moodColorForId
import io.eazo.a2908eba.core.moodDistribution
import io.eazo.a2908eba.core.moodRecordKey
import io.eazo.a2908eba.platform.MemoryStore
import io.eazo.a2908eba.platform.MoodRepo
import io.eazo.a2908eba.ui.adaptiveColumns
import java.io.File
import java.security.MessageDigest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * REQ-021 契约用例（cases-frozen.json v eazo-cases-1.0.0，14 条）：
 * 用例名逐字等于 slug；断言集为契约 §6 锚点全集的同集展开。
 * 契约：docs/arch/req021/02-interface-contract.md（commit 6e53b5e）。
 */
class MoodContractTest {

    /** 样本 A：2026-10 整月 31 天（M01×10 / M02×16 / M03×3 / M04×1 / M05×1）。 */
    private val sampleA = List(10) { "M01" } + List(16) { "M02" } + List(3) { "M03" } + List(1) { "M04" } + List(1) { "M05" }

    /** 样本 B：14 条混合（M01×4 / M02×5 / M03×3 / M04×1 / M05×1）。 */
    private val sampleB = List(4) { "M01" } + List(5) { "M02" } + List(3) { "M03" } + List(1) { "M04" } + List(1) { "M05" }

    @Test
    fun `mood_pick_save`() {
        val repo = MoodRepo(MemoryStore(), 20737)
        // 相位主链 none → picked → saved（契约 §2.5/§6.7）
        assertEquals(PickPhase.NONE, repo.pickPhase)
        assertNull("未选标签时 save 为无效转移，应被忽略", repo.save("还没选"))
        assertEquals(PickPhase.NONE, repo.pickPhase)
        repo.pick("M01")
        assertEquals(PickPhase.PICKED, repo.pickPhase)
        assertEquals("M01", repo.selectedMoodId)
        assertEquals("20737|M01", repo.save("今天很好"))
        assertEquals(PickPhase.SAVED, repo.pickPhase)
        assertEquals(1, repo.list().size)
        assertEquals("20737|M01", repo.list()[0].key)
        // 同键再存（换 note）→ 仍 1 条（覆写幂等，契约 §6.5）
        repo.pick("M01")
        repo.save("换个说法")
        assertEquals(1, repo.list().size)
        assertEquals("换个说法", repo.list()[0].note)
        // 同日换标签 → 单日一条口径：顶替当日旧记录（§6.5）
        repo.pick("M03")
        repo.save("换标签")
        val l = repo.list()
        assertEquals(1, l.size)
        assertEquals("20737|M03", l[0].key)
        assertEquals("M03", l[0].moodId)
    }

    @Test
    fun `mood_tags_5_items`() {
        assertEquals(5, MOOD_TAGS.size)
        assertEquals(5, MOOD_COUNT)
        assertEquals(listOf("M01", "M02", "M03", "M04", "M05"), MOOD_IDS)
        assertEquals(listOf("开心", "平静", "难过", "生气", "疲惫"), MOOD_TAGS.map { it.name })
        MOOD_TAGS.forEach { assertTrue("color 非 #RRGGBB 大写: ${it.color}", it.color.matches(Regex("#[0-9A-F]{6}"))) }
    }

    @Test
    fun `mood_note_optional`() {
        val repo = MoodRepo(MemoryStore(), 20737)
        // 不写一句话 → 可空
        repo.pick("M02")
        assertEquals("20737|M02", repo.save(""))
        assertEquals("", repo.list()[0].note)
        // 写一句话 → 可填
        repo.pick("M03")
        assertEquals("20737|M03", repo.save("一句话"))
        assertEquals("一句话", repo.list()[0].note)
        // note 不入键：键只由日期+标签决定（同日期同标签不同 note → 同键）
        assertEquals(moodRecordKey(20737, "M03"), repo.list()[0].key)
        repo.pick("M01")
        assertEquals("20737|M01", repo.save("另一句完全不同的话"))
    }

    @Test
    fun `deterministic_record_key`() {
        // 3 锚点（契约 §6.2）
        assertEquals("20737|M01", moodRecordKey(20737, "M01"))
        assertEquals("20737|M03", moodRecordKey(20737, "M03"))
        assertEquals("20738|M01", moodRecordKey(20738, "M01"))
        // 3 性质
        assertEquals(moodRecordKey(20737, "M01"), moodRecordKey(20737, "M01")) // 同日期同标签两次相等
        assertFalse(moodRecordKey(20737, "M01") == moodRecordKey(20737, "M03")) // 同日期不同标签不等
        assertFalse(moodRecordKey(20737, "M01") == moodRecordKey(20738, "M01")) // 不同日期同标签不等
        // 分隔符为半角 U+007C（V11c 全角高危面）
        assertEquals('|', moodRecordKey(20737, "M01")[5])
    }

    @Test
    fun `date_epoch_day`() {
        // 8 条锚点（契约 §6.3）
        assertEquals(0, daysFromCivil(1970, 1, 1))
        assertEquals(20454, daysFromCivil(2026, 1, 1))
        assertEquals(20727, daysFromCivil(2026, 10, 1))
        assertEquals(20737, daysFromCivil(2026, 10, 11))
        assertEquals(20757, daysFromCivil(2026, 10, 31))
        assertEquals(19782, daysFromCivil(2024, 2, 29))
        assertEquals(19417, daysFromCivil(2023, 2, 29)) // 平年 2/29 天然归一化，不抛异常
        assertEquals(19417, daysFromCivil(2023, 3, 1))
        // 4 条强化锚点（P-1）
        assertEquals(19783, daysFromCivil(2024, 3, 1)) // 闰年差 1 天判别点
        assertEquals(1, daysFromCivil(2100, 3, 1) - daysFromCivil(2100, 2, 28)) // 2100 非闰
        assertEquals(2, daysFromCivil(2400, 3, 1) - daysFromCivil(2400, 2, 28)) // 2400 闰
        assertEquals(146097, daysFromCivil(2370, 1, 1) - daysFromCivil(1970, 1, 1)) // 400 年周期
        // civilFromDays 逆往返（展示层）
        assertEquals(Triple(1970, 1, 1), civilFromDays(0))
        assertEquals(Triple(2026, 10, 11), civilFromDays(20737))
        assertEquals(Triple(2026, 10, 1), civilFromDays(20727))
    }

    @Test
    fun `distribution_count`() {
        // 样本 A（契约 §6.4）
        val a = moodDistribution(sampleA)
        assertEquals(31, a.total)
        assertEquals(mapOf("M01" to 10, "M02" to 16, "M03" to 3, "M04" to 1, "M05" to 1), a.counts)
        assertEquals(a.total, a.counts.values.sum()) // sum == total
        // 样本 B
        val b = moodDistribution(sampleB)
        assertEquals(14, b.total)
        assertEquals(mapOf("M01" to 4, "M02" to 5, "M03" to 3, "M04" to 1, "M05" to 1), b.counts)
        assertEquals(b.total, b.counts.values.sum())
    }

    @Test
    fun `distribution_permille`() {
        // 样本 A（整数域 floor；M03 3/31=96.77‰ → 96，round 得 97 即错——V2/V8）
        val a = moodDistribution(sampleA)
        assertEquals(mapOf("M01" to 322, "M02" to 516, "M03" to 96, "M04" to 32, "M05" to 32), a.permille)
        assertEquals(998, a.permille.values.sum()) // floor 合计域 [1000-4,1000]
        // 样本 B
        val b = moodDistribution(sampleB)
        assertEquals(mapOf("M01" to 285, "M02" to 357, "M03" to 214, "M04" to 71, "M05" to 71), b.permille)
        // 边界：空样本全 0（A7）
        val e = moodDistribution(emptyList())
        assertEquals(0, e.total)
        e.permille.values.forEach { assertEquals(0, it) }
        // 边界：单条样本 permille=1000（A8）
        assertEquals(1000, moodDistribution(listOf("M01")).permille["M01"])
        // 边界：均匀样本 5×3 → 全 200‰ 合计恰 1000（E2）
        val u = moodDistribution(MOOD_IDS.flatMap { id -> List(3) { id } })
        u.permille.values.forEach { assertEquals(200, it) }
        assertEquals(1000, u.permille.values.sum())
        // 边界：域外标签跳过（E4）
        val o = moodDistribution(listOf("M01", "XX", "M01"))
        assertEquals(2, o.total)
        assertEquals(2, o.counts["M01"])
        assertEquals(0, o.counts["M04"])
    }

    @Test
    fun `mood_tags_serialization_hash`() {
        // 规范序列化：id|name|color|emoji，id 升序，LF 连接，行尾无换行，UTF-8
        val ser = MOOD_TAGS.sortedBy { it.id }
            .map { "${it.id}|${it.name}|${it.color}|${it.emoji}" }
            .joinToString("\n")
        val bytes = ser.toByteArray(Charsets.UTF_8)
        assertEquals(TAGS_BYTES, bytes.size) // 119 = 5 行 114B + 4 LF
        val hex = MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it.toInt() and 0xFF) }
        assertEquals(TAGS_SHA256, hex)
        // emoji 单码点 NFC（V13 VS16 / 形近替换即哈希分叉）
        MOOD_TAGS.forEach { t ->
            assertEquals(1, Character.codePointCount(t.emoji, 0, t.emoji.length))
        }
    }

    @Test
    fun `calendar_heatmap_color`() {
        // 查表值 ×5（数据态，契约 §2.4；色块渲染为展示态不入对账）
        assertEquals("#FFD93D", moodColorForId("M01"))
        assertEquals("#6BCB77", moodColorForId("M02"))
        assertEquals("#4D96FF", moodColorForId("M03"))
        assertEquals("#FF6B6B", moodColorForId("M04"))
        assertEquals("#9B9B9B", moodColorForId("M05"))
        MOOD_TAGS.forEach { t -> assertEquals(t.color, moodColorForId(t.id)) }
        // 非法 moodId 返回空串，禁崩溃
        assertEquals("", moodColorForId("XX"))
    }

    @Test
    fun `month_calendar_render`() {
        val store = MemoryStore()
        MoodRepo(store, 20737).let { it.pick("M01"); it.save("今天很好") } // 10-11
        MoodRepo(store, 20727).let { it.pick("M02"); it.save("") }         // 10-01
        MoodRepo(store, 20756).let { it.pick("M04"); it.save("测试") }     // 10-30
        val repo = MoodRepo(store, 20737)
        // 月历数据面（契约 §3/§6.5）：day-of-month → moodId，31 槽位
        assertEquals(31, daysInMonth(2026, 10))
        val map = repo.recordsByMonth(2026, 10)
        assertEquals(3, map.size)
        assertEquals("M02", map[1])
        assertEquals("M01", map[11])
        assertEquals("M04", map[30])
        // 首日偏移：2026-10-01 星期四（0=周日 → 4）
        assertEquals(4, firstDayOffset(2026, 10))
        // 跨月不串：11 月无记录
        assertTrue(repo.recordsByMonth(2026, 11).isEmpty())
        // 色块查表联动（月历渲染数据源）
        assertEquals("#FFD93D", moodColorForId(map[11]!!))
    }

    @Test
    fun `mood_tags_immutable`() {
        val before = MOOD_TAGS.map { listOf(it.id, it.name, it.color, it.emoji) }
        val repo = MoodRepo(MemoryStore(), 20737)
        repeat(3) { i ->
            repo.pick(MOOD_IDS[i % 5])
            repo.save("第${i}次")
        }
        val after = MOOD_TAGS.map { listOf(it.id, it.name, it.color, it.emoji) }
        assertEquals(before, after) // 多次打卡后逐字段恒定（深比较）
        assertEquals(5, MOOD_TAGS.size)
        assertEquals(listOf("M01", "M02", "M03", "M04", "M05"), MOOD_IDS) // 升序不变
    }

    @Test
    fun `no_random_source`() {
        // 运行时确定性：同输入重算全等（50 轮）
        val keyA = moodRecordKey(20737, "M01")
        val distA = moodDistribution(sampleA)
        repeat(50) { i ->
            assertEquals(keyA, moodRecordKey(20737, "M01"))
            assertEquals(20737, daysFromCivil(2026, 10, 11))
            assertEquals(20737 + i, daysFromCivil(2026, 10, 11 + i)) // 连续日序列恒 +1
            assertEquals(distA, moodDistribution(sampleA))
        }
        // 静态检查（D8 禁用清单）：core/data 源码无随机/时间源 token
        val forbidden = listOf("Random", "currentTimeMillis", "nanoTime", "Calendar", "Thread.sleep", "Date(", "Date.now", "Math.random")
        for (rel in listOf(
            "app/src/main/java/io/eazo/a2908eba/core/MoodCore.kt",
            "app/src/main/java/com/eazo/moodtracker/data/MoodTags.kt",
        )) {
            val f = findSource(rel)
            assertNotNull("源文件未找到: $rel（user.dir=${System.getProperty("user.dir")}）", f)
            val src = f!!.readText()
            for (tok in forbidden) assertFalse("core/data 含禁用 token: $tok", src.contains(tok))
        }
    }

    @Test
    fun `local_storage_persist`() {
        val store = MemoryStore()
        val r1 = MoodRepo(store, 20737)
        r1.pick("M01")
        r1.save("今天很好")
        // 模拟重启：新进程新仓储实例，同一持久化介质冷启动装载
        val r2 = MoodRepo(store, 20738)
        assertEquals(1, r2.list().size)
        assertEquals("20737|M01", r2.list()[0].key)
        assertEquals("今天很好", r2.list()[0].note)
        assertEquals(mapOf(11 to "M01"), r2.recordsByMonth(2026, 10))
        // reset 只清选择不清库（契约 §2.5/§6.8）
        r2.pick("M05")
        r2.reset()
        assertEquals(PickPhase.NONE, r2.pickPhase)
        assertNull(r2.selectedMoodId)
        assertEquals(1, r2.list().size)
    }

    @Test
    fun `multiscreen_adaptive`() {
        // 手机竖屏 → 单列；平板/横屏 ≥600dp → 双列（Should，可降级；与鸿蒙 600vp 同口径）
        assertEquals(1, adaptiveColumns(360))
        assertEquals(1, adaptiveColumns(411))
        assertEquals(1, adaptiveColumns(599))
        assertEquals(2, adaptiveColumns(600))
        assertEquals(2, adaptiveColumns(840))
        assertEquals(2, adaptiveColumns(1280))
    }

    /** 从 user.dir 逐级上溯定位源文件（gradle 单测工作目录为模块/工程根均可命中）。 */
    private fun findSource(rel: String): File? {
        var dir: File? = File(System.getProperty("user.dir") ?: ".")
        repeat(6) {
            val f = File(dir, rel)
            if (f.isFile) return f
            dir = dir?.parentFile ?: return null
        }
        return null
    }
}
